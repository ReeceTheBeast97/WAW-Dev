import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Booking {
  id: string;
  customerId: string;
  serviceType: string;
  serviceName: string;
  vehicleType: string;
  vehicleInfo?: string;
  location: {
    address: string;
    latitude: number;
    longitude: number;
  };
  price: number;
  status: 'pending' | 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  valeterId?: string;
  valeterName?: string;
  valeterRating?: number;
  valeterOrganization?: string;
  valeterPhoto?: string;
  estimatedArrival?: string;
  scheduledDate?: string;
  scheduledTime?: string;
  createdAt: string;
  updatedAt: string;
  specialInstructions?: string;
  paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded';
  paymentMethod?: string;
}

class BookingService {
  private static instance: BookingService;
  private listeners: Map<string, (bookings: Booking[]) => void> = new Map();

  static getInstance(): BookingService {
    if (!BookingService.instance) {
      BookingService.instance = new BookingService();
    }
    return BookingService.instance;
  }

  // Generate unique booking ID
  private generateBookingId(): string {
    return `booking_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Create a new booking
  async createBooking(bookingData: Omit<Booking, 'id' | 'createdAt' | 'updatedAt'>): Promise<Booking> {
    const booking: Booking = {
      ...bookingData,
      id: this.generateBookingId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const bookings = await this.getUserBookings(bookingData.customerId);
    bookings.unshift(booking);
    await this.saveUserBookings(bookingData.customerId, bookings);

    // Notify listeners
    this.notifyListeners(bookingData.customerId, bookings);

    return booking;
  }

  // Get all bookings for a user
  async getUserBookings(userId: string): Promise<Booking[]> {
    try {
      const bookingsJson = await AsyncStorage.getItem(`bookings_${userId}`);
      return bookingsJson ? JSON.parse(bookingsJson) : [];
    } catch (error) {
      console.error('Error loading bookings:', error);
      return [];
    }
  }

  // Get a specific booking by ID
  async getBooking(bookingId: string, userId: string): Promise<Booking | null> {
    const bookings = await this.getUserBookings(userId);
    return bookings.find(booking => booking.id === bookingId) || null;
  }

  // Update booking status
  async updateBookingStatus(bookingId: string, userId: string, status: Booking['status'], updates?: Partial<Booking>): Promise<Booking | null> {
    const bookings = await this.getUserBookings(userId);
    const bookingIndex = bookings.findIndex(booking => booking.id === bookingId);
    
    if (bookingIndex === -1) return null;

    bookings[bookingIndex] = {
      ...bookings[bookingIndex],
      ...updates,
      status,
      updatedAt: new Date().toISOString(),
    };

    await this.saveUserBookings(userId, bookings);
    this.notifyListeners(userId, bookings);

    return bookings[bookingIndex];
  }

  // Assign valeter to booking
  async assignValeter(bookingId: string, userId: string, valeterData: {
    valeterId: string;
    valeterName: string;
    valeterRating?: number;
    valeterOrganization?: string;
    valeterPhoto?: string;
  }): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'valeter_assigned', valeterData);
  }

  // Update valeter location/arrival time
  async updateValeterLocation(bookingId: string, userId: string, estimatedArrival: string): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'en_route', { estimatedArrival });
  }

  // Mark valeter as arrived
  async markValeterArrived(bookingId: string, userId: string): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'arrived');
  }

  // Start service
  async startService(bookingId: string, userId: string): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'in_progress');
  }

  // Complete service
  async completeService(bookingId: string, userId: string): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'completed');
  }

  // Cancel booking
  async cancelBooking(bookingId: string, userId: string): Promise<Booking | null> {
    return this.updateBookingStatus(bookingId, userId, 'cancelled');
  }

  // Get active booking (most recent non-completed booking)
  async getActiveBooking(userId: string): Promise<Booking | null> {
    const bookings = await this.getUserBookings(userId);
    return bookings.find(booking => 
      !['completed', 'cancelled'].includes(booking.status)
    ) || null;
  }

  // Get booking statistics
  async getBookingStats(userId: string): Promise<{
    totalBookings: number;
    totalSpent: number;
    completedServices: number;
    averageRating: number;
    savings: number;
  }> {
    const bookings = await this.getUserBookings(userId);
    const completedBookings = bookings.filter(booking => booking.status === 'completed');
    
    const totalSpent = completedBookings.reduce((sum, booking) => sum + booking.price, 0);
    const averageRating = completedBookings.length > 0 
      ? completedBookings.reduce((sum, booking) => sum + (booking.valeterRating || 0), 0) / completedBookings.length
      : 0;

    return {
      totalBookings: bookings.length,
      totalSpent,
      completedServices: completedBookings.length,
      averageRating: Math.round(averageRating * 10) / 10,
      savings: Math.round(totalSpent * 0.1), // 10% savings estimate
    };
  }

  // Subscribe to booking updates
  subscribeToBookings(userId: string, callback: (bookings: Booking[]) => void): () => void {
    this.listeners.set(userId, callback);
    
    // Return unsubscribe function
    return () => {
      this.listeners.delete(userId);
    };
  }

  // Notify listeners of booking updates
  private notifyListeners(userId: string, bookings: Booking[]): void {
    const callback = this.listeners.get(userId);
    if (callback) {
      callback(bookings);
    }
  }

  // Save bookings to AsyncStorage
  private async saveUserBookings(userId: string, bookings: Booking[]): Promise<void> {
    try {
      await AsyncStorage.setItem(`bookings_${userId}`, JSON.stringify(bookings));
    } catch (error) {
      console.error('Error saving bookings:', error);
    }
  }

  // Clear all bookings (for testing/debugging)
  async clearAllBookings(userId: string): Promise<void> {
    await AsyncStorage.removeItem(`bookings_${userId}`);
    this.notifyListeners(userId, []);
  }

  // Create sample bookings for testing
  async createSampleBookings(userId: string): Promise<void> {
    const sampleBookings: Omit<Booking, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        customerId: userId,
        serviceType: 'full-valet',
        serviceName: 'Full Valet',
        vehicleType: 'medium',
        vehicleInfo: 'BMW 3 Series',
        location: {
          address: 'Home Address',
          latitude: 51.5074,
          longitude: -0.1278,
        },
        price: 45.00,
        status: 'completed',
        valeterId: 'valeter_001',
        valeterName: 'John Smith',
        valeterRating: 4.8,
        valeterOrganization: 'Elite Valet Services',
        valeterPhoto: '👨‍🔧',
        paymentStatus: 'paid',
        paymentMethod: 'card',
        specialInstructions: '',
      },
      {
        customerId: userId,
        serviceType: 'premium-wash',
        serviceName: 'Premium Wash',
        vehicleType: 'small',
        vehicleInfo: 'Mini Cooper',
        location: {
          address: 'Work Office',
          latitude: 51.5074,
          longitude: -0.1278,
        },
        price: 25.00,
        status: 'scheduled',
        valeterId: 'valeter_002',
        valeterName: 'Sarah Wilson',
        valeterRating: 4.9,
        valeterOrganization: 'Premium Car Care',
        valeterPhoto: '👩‍🔧',
        paymentStatus: 'paid',
        paymentMethod: 'card',
        specialInstructions: 'Please be careful with the paintwork',
      },
      {
        customerId: userId,
        serviceType: 'basic-wash',
        serviceName: 'Basic Wash',
        vehicleType: 'large',
        vehicleInfo: 'Range Rover',
        location: {
          address: 'Shopping Center',
          latitude: 51.5074,
          longitude: -0.1278,
        },
        price: 15.00,
        status: 'in_progress',
        valeterId: 'valeter_003',
        valeterName: 'Mike Johnson',
        valeterRating: 4.7,
        valeterOrganization: 'Quick Clean Pro',
        valeterPhoto: '👨‍🔧',
        paymentStatus: 'paid',
        paymentMethod: 'card',
        specialInstructions: '',
      },
    ];

    for (const bookingData of sampleBookings) {
      await this.createBooking(bookingData);
    }
  }
}

export default BookingService.getInstance();
