import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  TextInput,
  Image,
} from 'react-native';
import { GestureHandlerRootView, PanGestureHandler, State } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../../app/enhanced-auth-context';
import { organizationVerificationService, Organization, OrganizationDocument, OrganizationValeter } from '../../services/OrganizationVerificationService';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import LoadingScreen from '../LoadingScreen';

const { width } = Dimensions.get('window');

interface DocumentCardProps {
  document: OrganizationDocument;
  onUpload: (documentType: string) => void;
}

const DocumentCard: React.FC<DocumentCardProps> = ({ document, onUpload }) => {
  const getStatusColor = () => {
    if (document.verified) return '#10B981';
    if (document.uploaded) return '#F59E0B';
    return '#6B7280';
  };

  const getStatusText = () => {
    if (document.verified) return '✓ Verified';
    if (document.uploaded) return '⏳ Pending';
    return '📄 Required';
  };

  const getDocumentIcon = () => {
    switch (document.type) {
      case 'business_license': return '🏢';
      case 'insurance_certificate': return '🛡️';
      case 'tax_registration': return '💰';
      case 'disclaimer_signed': return '📋';
      default: return '📄';
    }
  };

  return (
    <View style={[styles.documentCard, { borderColor: getStatusColor() }]}>
      <View style={styles.documentHeader}>
        <View style={styles.documentInfo}>
          <Text style={styles.documentIcon}>{getDocumentIcon()}</Text>
          <View style={styles.documentTextContainer}>
            <Text style={styles.documentName}>{document.name}</Text>
            <Text style={styles.documentDescription}>{document.description}</Text>
          </View>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}>
          <Text style={styles.statusText}>{getStatusText()}</Text>
        </View>
      </View>
      
      {document.uploaded && (
        <Text style={styles.uploadedText}>
          Uploaded: {document.uploadedAt?.toLocaleDateString()}
        </Text>
      )}
      
      {!document.uploaded && (
        <TouchableOpacity
          style={[styles.uploadButton, { backgroundColor: getStatusColor() }]}
          onPress={() => onUpload(document.type)}
        >
          <Text style={styles.uploadButtonText}>📷 Upload {document.name}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

interface ValeterCardProps {
  valeter: OrganizationValeter;
  onViewDetails: (valeterId: string) => void;
}

const ValeterCard: React.FC<ValeterCardProps> = ({ valeter, onViewDetails }) => {
  const getStatusColor = () => {
    switch (valeter.status) {
      case 'active': return '#10B981';
      case 'approved': return '#3B82F6';
      case 'pending': return '#F59E0B';
      case 'rejected': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getStatusText = () => {
    switch (valeter.status) {
      case 'active': return '🟢 Active';
      case 'approved': return '🔵 Approved';
      case 'pending': return '🟡 Pending';
      case 'rejected': return '🔴 Rejected';
      default: return '⚪ Unknown';
    }
  };

  const documentsComplete = valeter.documents.idProof && valeter.documents.selfie && valeter.documents.detailsCompleted;

  return (
    <TouchableOpacity
      style={[styles.valeterCard, { borderColor: getStatusColor() }]}
      onPress={() => onViewDetails(valeter.id)}
    >
      <View style={styles.valeterHeader}>
        <View style={styles.valeterInfo}>
          <Text style={styles.valeterName}>{valeter.name}</Text>
          <Text style={styles.valeterEmail}>{valeter.email}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor() }]}>
          <Text style={styles.statusText}>{getStatusText()}</Text>
        </View>
      </View>
      <View style={styles.valeterDetails}>
        <Text style={styles.valeterPhone}>📞 {valeter.phone}</Text>
        <Text style={styles.valeterJoined}>
          Joined: {valeter.joinedAt.toLocaleDateString()}
        </Text>
      </View>
      <View style={styles.documentsStatus}>
        <Text style={styles.documentsTitle}>Documents:</Text>
        <View style={styles.documentChecks}>
          <Text style={[styles.documentCheck, valeter.documents.idProof && styles.documentComplete]}>
            {valeter.documents.idProof ? '✓' : '○'} ID Proof
          </Text>
          <Text style={[styles.documentCheck, valeter.documents.selfie && styles.documentComplete]}>
            {valeter.documents.selfie ? '✓' : '○'} Selfie
          </Text>
          <Text style={[styles.documentCheck, valeter.documents.detailsCompleted && styles.documentComplete]}>
            {valeter.documents.detailsCompleted ? '✓' : '○'} Details
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default function OrganizationDashboard() {
  const { user, logout } = useAuth();
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [stats, setStats] = useState({
    totalValeters: 0,
    activeValeters: 0,
    pendingValeters: 0,
    documentsComplete: false,
    canOperate: false,
  });
  const [loading, setLoading] = useState(true);
  const [showAddValeter, setShowAddValeter] = useState(false);
  const [showDocumentUpload, setShowDocumentUpload] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<string>('');
  const [newValeterData, setNewValeterData] = useState({
    name: '',
    email: '',
    phone: '',
  });

  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [200, 120],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    loadOrganizationData();
  }, []);

  const loadOrganizationData = async () => {
    try {
      // For demo, create a sample organization
      const orgId = user?.id || 'org_1';
      let org = await organizationVerificationService.getOrganization(orgId);
      
      if (!org) {
        org = await organizationVerificationService.createOrganization({
          name: 'Professional Valeting Co.',
          email: 'admin@provaleting.co.uk',
          phone: '+44 800 123 4567',
          address: '123 Business Street, London, UK',
          businessType: 'valeting',
        });
      }

      setOrganization(org);
      
      const orgStats = await organizationVerificationService.getOrganizationStats(orgId);
      setStats(orgStats);
    } catch (error) {
      console.error('Error loading organization data:', error);
      Alert.alert('Error', 'Failed to load organization data');
    } finally {
      setLoading(false);
    }
  };

  const handleDocumentUpload = (documentType: string) => {
    setSelectedDocument(documentType);
    setShowDocumentUpload(true);
  };

  const uploadDocument = async () => {
    if (!organization || !selectedDocument) return;

    try {
      // Request permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant permission to access your media library');
        return;
      }

      // Show image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (result.canceled) {
        return;
      }

      const image = result.assets[0];
      console.log('Selected image:', image);

      // Get document name for better feedback
      const documentName = organization.documents.find(doc => doc.type === selectedDocument)?.name || selectedDocument;

      // Simulate file upload with actual image info
      const fileUrl = `https://example.com/documents/${selectedDocument}_${Date.now()}.jpg`;
      
      const success = await organizationVerificationService.uploadDocument(
        organization.id,
        selectedDocument,
        fileUrl
      );

      if (success) {
        hapticFeedback('success');
        Alert.alert('Success', `${documentName} uploaded successfully!`);
        await loadOrganizationData(); // Reload data
      } else {
        Alert.alert('Error', `Failed to upload ${documentName}`);
      }
    } catch (error) {
      console.error('Error uploading document:', error);
      Alert.alert('Error', 'Failed to upload document');
    } finally {
      setShowDocumentUpload(false);
      setSelectedDocument('');
    }
  };

  const addValeter = async () => {
    if (!organization || !newValeterData.name || !newValeterData.email || !newValeterData.phone) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    try {
      const valeter = await organizationVerificationService.addValeter(organization.id, newValeterData);
      
      if (valeter) {
        hapticFeedback('success');
        Alert.alert('Success', 'Valeter added successfully!');
        setNewValeterData({ name: '', email: '', phone: '' });
        setShowAddValeter(false);
        await loadOrganizationData(); // Reload data
      } else {
        Alert.alert('Error', 'Failed to add valeter');
      }
    } catch (error) {
      console.error('Error adding valeter:', error);
      Alert.alert('Error', 'Failed to add valeter');
    }
  };

  const handleViewValeterDetails = (valeterId: string) => {
    // Navigate to valeter details page
    router.push(`/valeter-details/${valeterId}`);
  };

  const handleGoOnline = async () => {
    if (!organization) return;

    const canOperate = await organizationVerificationService.canOrganizationOperate(organization.id);
    
    if (canOperate) {
      const activated = await organizationVerificationService.activateOrganization(organization.id);
      if (activated) {
        hapticFeedback('success');
        Alert.alert('Success', 'Organization is now active!');
        await loadOrganizationData();
      }
    } else {
      Alert.alert('Cannot Go Online', 'Please complete all required documents first');
    }
  };

  if (loading) {
    return <LoadingScreen message="Loading organization dashboard..." />;
  }

  if (!organization) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Organization not found</Text>
        <TouchableOpacity style={styles.errorButton} onPress={() => router.back()}>
          <Text style={styles.errorButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaView style={styles.container}>
        {/* Animated Header */}
        <Animated.View
          style={[
            styles.header,
            {
              height: headerHeight,
              opacity: headerOpacity,
            },
          ]}
        >
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => router.back()}
              >
                <Text style={styles.backButtonIcon}>←</Text>
              </TouchableOpacity>
              <View style={styles.headerTextContainer}>
                <Text style={styles.greeting}>
                  {new Date().getHours() < 12 ? 'Good morning! 👋' : 
                   new Date().getHours() < 17 ? 'Good afternoon! 🌟' : 'Good evening! 🌙'}
                </Text>
                <Text style={styles.organizationName}>{organization.name}</Text>
                <Text style={styles.subtitle}>
                  Status: {organization.status === 'active' ? '🟢 Active' : 
                          organization.status === 'verified' ? '🔵 Verified' : 
                          organization.status === 'pending' ? '🟡 Pending' : '🔴 Suspended'}
                </Text>
              </View>
            </View>
            
            <View style={styles.headerActions}>
              <TouchableOpacity
                style={styles.profileButton}
                onPress={() => router.push('/profile')}
              >
                {user?.profilePicture ? (
                  <Image 
                    source={{ uri: user.profilePicture }} 
                    style={styles.profileImage}
                  />
                ) : (
                  <Text style={styles.profileIcon}>👤</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.poweredByContainer}>
            <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        {/* Stats Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Organization Stats</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.totalValeters}</Text>
              <Text style={styles.statLabel}>Total Valeters</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.activeValeters}</Text>
              <Text style={styles.statLabel}>Active</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.pendingValeters}</Text>
              <Text style={styles.statLabel}>Pending</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.documentsComplete ? '✓' : '✗'}</Text>
              <Text style={styles.statLabel}>Documents</Text>
            </View>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.section}>
          <View style={styles.actionButtons}>
            <TouchableOpacity
              style={[styles.actionButton, !stats.canOperate && styles.actionButtonDisabled]}
              onPress={handleGoOnline}
              disabled={!stats.canOperate}
            >
              <Text style={styles.actionButtonIcon}>🚀</Text>
              <Text style={styles.actionButtonText}>Go Online</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => setShowAddValeter(true)}
            >
              <Text style={styles.actionButtonIcon}>👥</Text>
              <Text style={styles.actionButtonText}>Add Valeter</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionButton}
              onPress={() => router.push('/organization-rewards-system')}
            >
              <Text style={styles.actionButtonIcon}>🎁</Text>
              <Text style={styles.actionButtonText}>Rewards</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          <Text style={styles.sectionSubtitle}>
            Complete these documents to activate your organization
          </Text>
          {organization.documents.map((document) => (
            <DocumentCard
              key={document.id}
              document={document}
              onUpload={handleDocumentUpload}
            />
          ))}
        </View>

        {/* Valeters List */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Valeters ({organization.valeters.length})</Text>
          {organization.valeters.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateIcon}>👥</Text>
              <Text style={styles.emptyStateText}>No valeters added yet</Text>
              <TouchableOpacity
                style={styles.emptyStateButton}
                onPress={() => setShowAddValeter(true)}
              >
                <Text style={styles.emptyStateButtonText}>Add Your First Valeter</Text>
              </TouchableOpacity>
            </View>
          ) : (
            organization.valeters.map((valeter) => (
              <ValeterCard
                key={valeter.id}
                valeter={valeter}
                onViewDetails={handleViewValeterDetails}
              />
            ))
          )}
        </View>
      </Animated.ScrollView>

      {/* Add Valeter Modal */}
      <Modal
        visible={showAddValeter}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Add New Valeter</Text>
            <TouchableOpacity onPress={() => setShowAddValeter(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.modalContent}>
            <Text style={styles.inputLabel}>Full Name</Text>
            <TextInput
              style={styles.textInput}
              value={newValeterData.name}
              onChangeText={(text) => setNewValeterData({ ...newValeterData, name: text })}
              placeholder="Enter valeter's full name"
              placeholderTextColor="#6B7280"
            />
            
            <Text style={styles.inputLabel}>Email Address</Text>
            <TextInput
              style={styles.textInput}
              value={newValeterData.email}
              onChangeText={(text) => setNewValeterData({ ...newValeterData, email: text })}
              placeholder="Enter email address"
              placeholderTextColor="#6B7280"
              keyboardType="email-address"
            />
            
            <Text style={styles.inputLabel}>Phone Number</Text>
            <TextInput
              style={styles.textInput}
              value={newValeterData.phone}
              onChangeText={(text) => setNewValeterData({ ...newValeterData, phone: text })}
              placeholder="Enter phone number"
              placeholderTextColor="#6B7280"
              keyboardType="phone-pad"
            />
          </View>
          
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={addValeter}
            >
              <Text style={styles.modalButtonText}>Add Valeter</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Document Upload Modal */}
      <Modal
        visible={showDocumentUpload}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Upload Document</Text>
            <TouchableOpacity onPress={() => setShowDocumentUpload(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.modalContent}>
            <Text style={styles.uploadText}>
              Upload {organization?.documents.find(doc => doc.type === selectedDocument)?.name || selectedDocument.replace('_', ' ')}
            </Text>
            <Text style={styles.uploadSubtext}>
              Select an image from your photo library
            </Text>
            
            <View style={styles.uploadOptions}>
              <TouchableOpacity
                style={styles.uploadOption}
                onPress={uploadDocument}
              >
                <Text style={styles.uploadOptionIcon}>📷</Text>
                <Text style={styles.uploadOptionText}>Choose Image</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.modalActions}>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => setShowDocumentUpload(false)}
            >
              <Text style={styles.modalButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      </SafeAreaView>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  errorText: {
    color: '#F9FAFB',
    fontSize: 16,
    marginBottom: 20,
  },
  errorButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  errorButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  headerContent: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  headerLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  backButtonIcon: {
    fontSize: 24,
    color: '#F9FAFB',
    fontWeight: 'bold',
  },
  headerTextContainer: {
    flex: 1,
  },
  greeting: {
    fontSize: 16,
    color: '#F9FAFB',
    opacity: 0.9,
  },
  organizationName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginTop: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginTop: 4,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    fontSize: 20,
  },
  poweredByContainer: {
    alignItems: 'flex-end',
    marginTop: 8,
  },
  poweredByText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
    fontWeight: '400',
  },
  scrollView: {
    flex: 1,
    paddingTop: 200,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 11,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  actionButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  actionButtonIcon: {
    fontSize: 20,
    marginBottom: 8,
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '600',
  },
  documentCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 2,
  },
  documentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  documentInfo: {
    flexDirection: 'row',
    flex: 1,
    alignItems: 'flex-start',
  },
  documentIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  documentTextContainer: {
    flex: 1,
  },
  documentName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 8,
  },
  uploadedText: {
    color: '#9CA3AF',
    fontSize: 11,
  },
  uploadButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginTop: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  uploadButtonText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  valeterCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 2,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  valeterEmail: {
    color: '#87CEEB',
    fontSize: 12,
  },
  valeterDetails: {
    marginBottom: 8,
  },
  valeterPhone: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  valeterJoined: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentsStatus: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: 8,
  },
  documentsTitle: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  documentChecks: {
    flexDirection: 'row',
    gap: 16,
  },
  documentCheck: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  documentComplete: {
    color: '#10B981',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyStateText: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  emptyStateButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  emptyStateButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalClose: {
    color: '#F9FAFB',
    fontSize: 20,
  },
  modalContent: {
    padding: 20,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: '#1E3A8A',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 16,
  },
  uploadText: {
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 8,
  },
  uploadSubtext: {
    color: '#87CEEB',
    fontSize: 12,
  },
  uploadOptions: {
    marginTop: 20,
  },
  uploadOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  uploadOptionIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  uploadOptionText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  modalActions: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalButton: {
    backgroundColor: '#87CEEB',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
});
