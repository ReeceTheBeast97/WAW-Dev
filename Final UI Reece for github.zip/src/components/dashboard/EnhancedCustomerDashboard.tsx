import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Animated, 
  Dimensions,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  Image
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../app/enhanced-auth-context';
import ExpoMap from '../../../app/components/ExpoMap';
import BookingService, { Booking } from '../../services/BookingService';
import AIChatComponent from '../chat/AIChatComponent';

const { width, height } = Dimensions.get('window');

// Responsive breakpoints
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

// Use the Booking interface from BookingService instead of local interface

interface Stats {
  totalBookings: number;
  totalSpent: number;
  averageRating: number;
  completedServices: number;
  savings: number;
}

interface QuickAction {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  route: string;
  color: string;
  gradient: string[];
}

interface NearbyValeter {
  id: string;
  name: string;
  rating: number;
  distance: number;
  isOnline: boolean;
  organization: string;
}

export default function EnhancedCustomerDashboard() {
  const { user, logout } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [activeBooking, setActiveBooking] = useState<Booking | null>(null);
  const [showChat, setShowChat] = useState(false);
  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
    savings: 0,
  });
  const [loading, setLoading] = useState(true);
  
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [180, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.9, 0.8],
    extrapolate: 'clamp',
  });

  // Animation for valeter dots
  const valeterDotAnim1 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim2 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim3 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim4 = useRef(new Animated.Value(0)).current;
  const valeterDotAnim5 = useRef(new Animated.Value(0)).current;

  // Quick actions with your existing color scheme
  const quickActions: QuickAction[] = [
    {
      id: 'instant-wash',
      icon: '⚡',
      title: 'Instant Wash',
      subtitle: 'Quick booking',
      route: '/auto-service-booking',
      color: '#10B981',
      gradient: ['#10B981', '#059669']
    },
    {
      id: 'priority-wash',
      icon: '⭐',
      title: 'Local Priority',
      subtitle: 'Premium service',
      route: '/priority-wash',
      color: '#8B5CF6',
      gradient: ['#8B5CF6', '#7C3AED']
    },
    {
      id: 'rewards',
      icon: '🎁',
      title: 'Rewards',
      subtitle: 'Earn points & rewards',
      route: '/rewards-system',
      color: '#F59E0B',
      gradient: ['#F59E0B', '#D97706']
    },
    {
      id: 'wash-history',
      icon: '📸',
      title: 'Wash History',
      subtitle: 'View completed washes',
      route: '/wash-history',
      color: '#10B981',
      gradient: ['#10B981', '#059669']
    }
  ];

  useEffect(() => {
    const loadDashboardData = async () => {
      if (!user) return;

      try {
        // Load real booking data
        const userBookings = await BookingService.getUserBookings(user.id);
        setBookings(userBookings);

        // Get active booking (most recent non-completed booking)
        const active = await BookingService.getActiveBooking(user.id);
        setActiveBooking(active);

        // Get booking statistics
        const bookingStats = await BookingService.getBookingStats(user.id);
        setStats(bookingStats);

        // Load nearby valeters
        loadNearbyValeters();

        // Subscribe to booking updates
        const unsubscribe = BookingService.subscribeToBookings(user.id, (updatedBookings) => {
          setBookings(updatedBookings);
          
          // Update active booking
          const updatedActive = updatedBookings.find(booking => 
            !['completed', 'cancelled'].includes(booking.status)
          );
          setActiveBooking(updatedActive || null);
          
          // Update stats
          BookingService.getBookingStats(user.id).then(setStats);
        });

        setLoading(false);

        // Cleanup subscription on unmount
        return unsubscribe;
      } catch (error) {
        console.error('Error loading dashboard data:', error);
        setLoading(false);
      }
    };

    loadDashboardData();
  }, [user]);

  const loadNearbyValeters = async () => {
    // Mock nearby valeters data - in real app, this would come from location service
    const mockValeters: NearbyValeter[] = [
      {
        id: 'val_1',
        name: 'Mike Johnson',
        rating: 4.8,
        distance: 0.5,
        isOnline: true,
        organization: 'Professional Valeting Co.'
      },
      {
        id: 'val_2',
        name: 'Sarah Williams',
        rating: 4.6,
        distance: 1.2,
        isOnline: true,
        organization: 'Elite Car Care'
      },
      {
        id: 'val_3',
        name: 'David Brown',
        rating: 4.9,
        distance: 2.1,
        isOnline: false,
        organization: 'Premium Valet Services'
      },
      {
        id: 'val_4',
        name: 'Emma Davis',
        rating: 4.7,
        distance: 0.8,
        isOnline: true,
        organization: 'Quick Wash Pro'
      },
      {
        id: 'val_5',
        name: 'James Wilson',
        rating: 4.5,
        distance: 1.5,
        isOnline: true,
        organization: 'Mobile Valet Express'
      }
    ];

    setNearbyValeters(mockValeters);
  };

  const handleQuickAction = async (action: QuickAction) => {
    try {
      router.push(action.route as any);
    } catch (error) {
      console.error('Quick action error:', error);
      router.push(action.route as any);
    }
  };

  const handleViewProfile = () => {
    router.push('/owner-profile');
  };

  const handleViewAnalytics = () => {
    router.push('/detailed-stats');
  };

  const handleVehicleManagement = () => {
    router.push('/vehicle-management');
  };

  const handleOrganizations = () => {
    router.push('/organizations');
  };

  const handleLiveTracking = () => {
    if (activeBooking) {
      // Route to appropriate tracking page based on service type
      if (activeBooking.serviceType === 'priority_wash') {
        router.push({
          pathname: '/priority-wash-tracking',
          params: { bookingId: activeBooking.id }
        });
      } else {
        router.push({
          pathname: '/uber-tracking',
          params: { bookingId: activeBooking.id }
        });
      }
    }
  };

  const handleChat = () => {
    if (activeBooking) {
      setShowChat(true);
    }
  };

  const handleInstantWashBooking = () => {
    router.push('/auto-service-booking');
  };

  const getServiceIcon = (serviceType: string) => {
    switch (serviceType) {
      case 'priority_wash':
        return '⭐';
      case 'instant_wash':
        return '⚡';
      case 'full_valet':
        return '✨';
      default:
        return '🚗';
    }
  };

  const getServiceColor = (serviceType: string): [string, string] => {
    switch (serviceType) {
      case 'priority_wash':
        return ['#8B5CF6', '#7C3AED'];
      case 'instant_wash':
        return ['#10B981', '#059669'];
      case 'full_valet':
        return ['#F59E0B', '#D97706'];
      default:
        return ['#1E3A8A', '#87CEEB'];
    }
  };

  const getOnlineValetersCount = () => {
    return nearbyValeters.filter(valeter => valeter.isOnline).length;
  };

  const getAverageRating = () => {
    const onlineValeters = nearbyValeters.filter(valeter => valeter.isOnline);
    if (onlineValeters.length === 0) return 0;
    return onlineValeters.reduce((sum, valeter) => sum + valeter.rating, 0) / onlineValeters.length;
  };

  // Start valeter dot animations
  useEffect(() => {
    const startAnimations = () => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(valeterDotAnim1, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(valeterDotAnim1, {
            toValue: 0,
            duration: 2000,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(valeterDotAnim2, {
            toValue: 1,
            duration: 2500,
            useNativeDriver: true,
          }),
          Animated.timing(valeterDotAnim2, {
            toValue: 0,
            duration: 2500,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(valeterDotAnim3, {
            toValue: 1,
            duration: 3000,
            useNativeDriver: true,
          }),
          Animated.timing(valeterDotAnim3, {
            toValue: 0,
            duration: 3000,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(valeterDotAnim4, {
            toValue: 1,
            duration: 2200,
            useNativeDriver: true,
          }),
          Animated.timing(valeterDotAnim4, {
            toValue: 0,
            duration: 2200,
            useNativeDriver: true,
          }),
        ])
      ).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(valeterDotAnim5, {
            toValue: 1,
            duration: 2800,
            useNativeDriver: true,
          }),
          Animated.timing(valeterDotAnim5, {
            toValue: 0,
            duration: 2800,
            useNativeDriver: true,
          }),
        ])
      ).start();
    };

    startAnimations();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <Animated.View style={[styles.header, { height: headerHeight, opacity: headerOpacity }]}>
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.profileSection}>
              {user?.profilePicture ? (
                <Image source={{ uri: user.profilePicture }} style={styles.profileImage} />
              ) : (
                <TouchableOpacity style={styles.profileButton} onPress={handleViewProfile}>
                  <Text style={styles.profileIcon}>👤</Text>
                </TouchableOpacity>
              )}
              <View style={styles.greetingContainer}>
                <Text style={styles.greeting}>
                  {new Date().getHours() < 12 ? 'Good morning' : 
                   new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening'}
                </Text>
                <Text style={styles.userName}>{user?.name || 'Customer'}</Text>
                <Text style={styles.subtitle}>Customer Dashboard</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.analyticsButton} onPress={handleViewAnalytics}>
              <Text style={styles.analyticsIcon}>📊</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
      >
        {/* Active Service or Location Tab */}
        {activeBooking ? (
          <View style={styles.activeBookingBanner}>
            <LinearGradient
              colors={getServiceColor(activeBooking.serviceType)}
              style={styles.activeBookingGradient}
            >
              <View style={styles.activeBookingContent}>
                <View style={styles.activeBookingLeft}>
                  <View style={styles.serviceHeader}>
                    <Text style={styles.serviceIcon}>{getServiceIcon(activeBooking.serviceType)}</Text>
                    <Text style={styles.activeBookingTitle}>Active Service</Text>
                  </View>
                  <Text style={styles.activeBookingService}>{activeBooking.serviceName}</Text>
                  <Text style={styles.activeBookingValeter}>
                    {activeBooking.valeterName} • {activeBooking.valeterOrganization}
                  </Text>
                  <Text style={styles.activeBookingStatus}>
                    Status: {activeBooking.status.replace('_', ' ').toUpperCase()}
                  </Text>
                </View>
                <View style={styles.activeBookingActions}>
                  <TouchableOpacity 
                    style={styles.messageButton}
                    onPress={handleChat}
                  >
                    <Text style={styles.messageButtonText}>💬</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.trackButton}
                    onPress={handleLiveTracking}
                  >
                    <Text style={styles.trackButtonText}>Track</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </LinearGradient>
          </View>
        ) : (
          <TouchableOpacity 
            style={styles.mapViewBanner}
            onPress={handleInstantWashBooking}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['#0A1929', '#1E3A8A']}
              style={styles.mapViewGradient}
            >
              <View style={styles.mapViewContent}>
                <View style={styles.mapViewLeft}>
                  <Text style={styles.mapViewTitle}>Where's your wash?</Text>
                  <Text style={styles.mapViewSubtitle}>Tap to book your wash instantly</Text>
                  <View style={styles.valeterCount}>
                    <Text style={styles.valeterCountText}>
                      🚗 {getOnlineValetersCount()} valeters nearby
                    </Text>
                    <Text style={styles.valeterRating}>
                      ⭐ {getAverageRating().toFixed(1)} average rating
                    </Text>
                  </View>
                  <View style={styles.nearestValeter}>
                    <Text style={styles.nearestValeterText}>
                      Nearest: {nearbyValeters.find(v => v.isOnline)?.name || 'No valeters online'}
                    </Text>
                  </View>
                </View>
                <View style={styles.mapViewRight}>
                  <View style={styles.mapHolder}>
                    <Text style={styles.mapIcon}>📍</Text>
                    <View style={styles.valeterDots}>
                      <Animated.View 
                        style={[
                          styles.valeterDot, 
                          styles.valeterDot1,
                          {
                            opacity: valeterDotAnim1,
                            transform: [{ scale: valeterDotAnim1.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0.5, 1.2]
                            })}]
                          }
                        ]} 
                      />
                      <Animated.View 
                        style={[
                          styles.valeterDot, 
                          styles.valeterDot2,
                          {
                            opacity: valeterDotAnim2,
                            transform: [{ scale: valeterDotAnim2.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0.5, 1.2]
                            })}]
                          }
                        ]} 
                      />
                      <Animated.View 
                        style={[
                          styles.valeterDot, 
                          styles.valeterDot3,
                          {
                            opacity: valeterDotAnim3,
                            transform: [{ scale: valeterDotAnim3.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0.5, 1.2]
                            })}]
                          }
                        ]} 
                      />
                      <Animated.View 
                        style={[
                          styles.valeterDot, 
                          styles.valeterDot4,
                          {
                            opacity: valeterDotAnim4,
                            transform: [{ scale: valeterDotAnim4.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0.5, 1.2]
                            })}]
                          }
                        ]} 
                      />
                      <Animated.View 
                        style={[
                          styles.valeterDot, 
                          styles.valeterDot5,
                          {
                            opacity: valeterDotAnim5,
                            transform: [{ scale: valeterDotAnim5.interpolate({
                              inputRange: [0, 1],
                              outputRange: [0.5, 1.2]
                            })}]
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* Quick Actions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsContainer}
          >
            {quickActions.map((action) => (
              <TouchableOpacity 
                key={action.id}
                style={styles.quickActionCard}
                onPress={() => handleQuickAction(action)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={action.gradient}
                  style={styles.quickActionGradient}
                >
                  <Text style={styles.quickActionIcon}>{action.icon}</Text>
                  <Text style={styles.quickActionTitle}>{action.title}</Text>
                  <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{stats.totalSpent}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating}⭐</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
          </View>
        </View>

        {/* Recent Bookings */}
        {bookings.length > 0 && (
          <View style={styles.recentBookingsSection}>
            <Text style={styles.sectionTitle}>Recent Bookings</Text>
            <ScrollView 
              horizontal 
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.recentBookingsContainer}
            >
              {bookings.slice(0, 5).map((booking) => (
                <TouchableOpacity 
                  key={booking.id}
                  style={styles.recentBookingCard}
                  onPress={() => {
                    if (booking.status === 'completed') {
                      router.push('/wash-history');
                    } else {
                      handleLiveTracking();
                    }
                  }}
                >
                  <View style={styles.recentBookingHeader}>
                    <Text style={styles.recentBookingService}>{booking.serviceName}</Text>
                    <Text style={styles.recentBookingDate}>
                      {new Date(booking.createdAt).toLocaleDateString()}
                    </Text>
                  </View>
                  <Text style={styles.recentBookingStatus}>{booking.status}</Text>
                  <Text style={styles.recentBookingPrice}>£{booking.price}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Nearby Valeters */}
        <View style={styles.nearbyValetersSection}>
          <Text style={styles.sectionTitle}>Nearby Valeters</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.nearbyValetersContainer}
          >
            {nearbyValeters.filter(v => v.isOnline).slice(0, 5).map((valeter) => (
              <View key={valeter.id} style={styles.nearbyValeterCard}>
                <View style={styles.valeterInfo}>
                  <Text style={styles.valeterName}>{valeter.name}</Text>
                  <Text style={styles.valeterOrganization}>{valeter.organization}</Text>
                  <Text style={styles.valeterRating}>⭐ {valeter.rating}</Text>
                  <Text style={styles.valeterDistance}>{valeter.distance}km away</Text>
                </View>
                <View style={[styles.onlineIndicator, { backgroundColor: valeter.isOnline ? '#10B981' : '#6B7280' }]} />
              </View>
            ))}
          </ScrollView>
        </View>
      </Animated.ScrollView>

      {/* Chat Modal */}
      <Modal
        visible={showChat}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        <AIChatComponent
          userType="customer"
          onClose={() => setShowChat(false)}
        />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  header: {
    position: 'sticky',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: '#0A1929',
  },
  headerContent: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: isSmallScreen ? 16 : isMediumScreen ? 20 : 24,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    fontSize: 20,
  },
  profileImage: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  greetingContainer: {
    flex: 1,
  },
  greeting: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    marginBottom: 4,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : isMediumScreen ? 22 : 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  subtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
  },
  analyticsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  analyticsIcon: {
    fontSize: 20,
  },
  poweredByContainer: {
    alignItems: 'flex-end',
    marginTop: 8,
  },
  poweredByText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
    fontWeight: '400',
  },
  scrollView: {
    flex: 1,
  },
  activeBookingBanner: {
    marginHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
    marginBottom: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  activeBookingGradient: {
    padding: 20,
  },
  activeBookingContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  activeBookingLeft: {
    flex: 1,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  serviceIcon: {
    fontSize: 24,
    marginRight: 8,
  },
  activeBookingTitle: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  activeBookingService: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  activeBookingValeter: {
    color: '#FFFFFF',
    fontSize: 14,
    opacity: 0.9,
  },
  activeBookingStatus: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
  },
  activeBookingActions: {
    flexDirection: 'row',
    gap: 12,
  },
  messageButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageButtonText: {
    fontSize: 20,
  },
  trackButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  trackButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  quickActionsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
  },
  quickActionsContainer: {
    paddingHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
  },
  quickActionCard: {
    width: isSmallScreen ? 140 : isMediumScreen ? 150 : 160,
    height: isSmallScreen ? 140 : isMediumScreen ? 150 : 160,
    borderRadius: 16,
    marginRight: 12,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  quickActionGradient: {
    flex: 1,
    padding: isSmallScreen ? 16 : 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActionIcon: {
    fontSize: isSmallScreen ? 32 : 36,
    marginBottom: 10,
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 6,
    textAlign: 'center',
  },
  quickActionSubtitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 10 : 12,
    opacity: 0.9,
    textAlign: 'center',
  },
  statsSection: {
    marginBottom: 24,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
  },
  statCard: {
    width: (width - (isSmallScreen ? 48 : isMediumScreen ? 64 : 80)) / 2,
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  statNumber: {
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: isSmallScreen ? 11 : 12,
    color: '#87CEEB',
    textAlign: 'center',
  },
  mapSection: {
    marginBottom: 24,
  },
  mapContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 16,
    marginHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    height: 250,
    position: 'relative',
  },
  mapOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(10, 25, 41, 0.9)',
    padding: 12,
    alignItems: 'center',
  },
  mapOverlayText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  bookingsSection: {
    marginBottom: 24,
  },
  recentBookingsSection: {
    marginBottom: 24,
  },
  recentBookingsContainer: {
    paddingHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
  },
  recentBookingCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    width: isSmallScreen ? 120 : isMediumScreen ? 130 : 140,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  recentBookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  recentBookingService: {
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  recentBookingDate: {
    fontSize: isSmallScreen ? 10 : 11,
    color: '#87CEEB',
  },
  recentBookingStatus: {
    fontSize: 11,
    color: '#87CEEB',
    marginBottom: 4,
  },
  recentBookingPrice: {
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: 'bold',
    color: '#10B981',
  },
  nearbyValetersSection: {
    marginBottom: 24,
  },
  nearbyValetersContainer: {
    paddingHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
  },
  nearbyValeterCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginRight: 12,
    width: isSmallScreen ? 120 : isMediumScreen ? 130 : 140,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 2,
  },
  valeterOrganization: {
    fontSize: isSmallScreen ? 10 : 11,
    color: '#87CEEB',
    marginBottom: 2,
  },
  valeterRating: {
    fontSize: isSmallScreen ? 12 : 13,
    color: '#F59E0B',
    fontWeight: '600',
  },
  valeterDistance: {
    fontSize: isSmallScreen ? 10 : 11,
    color: '#87CEEB',
  },
  onlineIndicator: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  mapViewBanner: {
    marginHorizontal: isSmallScreen ? 12 : isMediumScreen ? 16 : 20,
    marginBottom: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  mapViewGradient: {
    padding: 20,
  },
  mapViewContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  mapViewLeft: {
    flex: 1,
  },
  mapViewTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  mapViewSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 12,
  },
  valeterCount: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    marginBottom: 8,
  },
  valeterCountText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
     valeterRatingText: {
     color: '#87CEEB',
     fontSize: 12,
   },
  nearestValeter: {
    marginTop: 8,
  },
  nearestValeterText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  mapViewRight: {
    width: 100,
    alignItems: 'center',
  },
  mapHolder: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  mapIcon: {
    fontSize: 30,
  },
  valeterDots: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: 40,
  },
  valeterDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  valeterDot1: {
    backgroundColor: '#87CEEB',
  },
  valeterDot2: {
    backgroundColor: '#87CEEB',
  },
  valeterDot3: {
    backgroundColor: '#87CEEB',
  },
  valeterDot4: {
    backgroundColor: '#87CEEB',
  },
  valeterDot5: {
    backgroundColor: '#87CEEB',
  },
});
