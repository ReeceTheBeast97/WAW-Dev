import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  Alert,
  ActivityIndicator,
  ScrollView,
  Image,
} from 'react-native';
import { documentUploadService, UploadedDocument, UploadProgress } from '../services/DocumentUploadService';

interface DocumentUploadModalProps {
  visible: boolean;
  onClose: () => void;
  onUploadComplete: (documents: UploadedDocument[]) => void;
  userId: string;
  documentType: string;
  title?: string;
  description?: string;
  allowMultiple?: boolean;
  maxFiles?: number;
}

export default function DocumentUploadModal({
  visible,
  onClose,
  onUploadComplete,
  userId,
  documentType,
  title = 'Upload Document',
  description = 'Please upload your document',
  allowMultiple = false,
  maxFiles = 1
}: DocumentUploadModalProps) {
  const [uploading, setUploading] = useState(false);
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    if (visible) {
      // Add progress listener
      const progressListener = (progress: UploadProgress) => {
        setUploadProgress(prev => ({
          ...prev,
          [progress.documentId]: progress.progress
        }));
      };

      documentUploadService.addProgressListener(progressListener);

      return () => {
        documentUploadService.removeProgressListener(progressListener);
      };
    }
  }, [visible]);

  const handleTakePhoto = async () => {
    try {
      setUploading(true);
      const photo = await documentUploadService.takePhoto({
        quality: 0.8,
        allowsEditing: true,
        aspect: [1, 1]
      });

      if (photo) {
        photo.userId = userId;
        photo.type = documentType;
        
        const success = await documentUploadService.uploadDocument(photo, (progress) => {
          setUploadProgress(prev => ({
            ...prev,
            [photo.id]: progress
          }));
        });

        if (success) {
          setDocuments(prev => [...prev, photo]);
          Alert.alert('Success', 'Photo uploaded successfully!');
        } else {
          Alert.alert('Error', 'Failed to upload photo. Please try again.');
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handlePickDocument = async () => {
    try {
      setUploading(true);
      const pickedDocs = await documentUploadService.pickDocument({
        type: 'document',
        multiple: allowMultiple,
        maxFiles: allowMultiple ? maxFiles : 1,
        maxSize: 10 * 1024 * 1024 // 10MB
      });

      if (pickedDocs.length > 0) {
        // Set user ID and type for all documents
        const processedDocs = pickedDocs.map(doc => ({
          ...doc,
          userId,
          type: documentType
        }));

        // Upload all documents
        const { success, failed } = await documentUploadService.uploadMultipleDocuments(
          processedDocs,
          (documentId, progress) => {
            setUploadProgress(prev => ({
              ...prev,
              [documentId]: progress
            }));
          }
        );

        if (success.length > 0) {
          const uploadedDocs = processedDocs.filter(doc => success.includes(doc.id));
          setDocuments(prev => [...prev, ...uploadedDocs]);
          Alert.alert('Success', `${success.length} document(s) uploaded successfully!`);
        }

        if (failed.length > 0) {
          Alert.alert('Warning', `${failed.length} document(s) failed to upload.`);
        }
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick document. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveDocument = (documentId: string) => {
    Alert.alert(
      'Remove Document',
      'Are you sure you want to remove this document?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => {
            documentUploadService.deleteDocument(documentId);
            setDocuments(prev => prev.filter(doc => doc.id !== documentId));
            setUploadProgress(prev => {
              const newProgress = { ...prev };
              delete newProgress[documentId];
              return newProgress;
            });
          }
        }
      ]
    );
  };

  const handleComplete = () => {
    if (documents.length > 0) {
      onUploadComplete(documents);
      onClose();
    } else {
      Alert.alert('No Documents', 'Please upload at least one document before continuing.');
    }
  };

  const getStatusColor = (status: UploadedDocument['status']) => {
    switch (status) {
      case 'completed': return '#4CAF50';
      case 'uploading': return '#2196F3';
      case 'pending': return '#FF9800';
      case 'failed': return '#F44336';
      case 'verified': return '#4CAF50';
      case 'rejected': return '#F44336';
      default: return '#9E9E9E';
    }
  };

  const getStatusText = (status: UploadedDocument['status']) => {
    switch (status) {
      case 'completed': return 'Uploaded';
      case 'uploading': return 'Uploading...';
      case 'pending': return 'Pending';
      case 'failed': return 'Failed';
      case 'verified': return 'Verified';
      case 'rejected': return 'Rejected';
      default: return 'Unknown';
    }
  };

  return (
    <Modal
      visible={visible}
      transparent={true}
      animationType="slide"
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>{title}</Text>
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>✕</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.description}>{description}</Text>

          {/* Upload Options */}
          <View style={styles.uploadOptions}>
            <TouchableOpacity
              style={[styles.uploadButton, uploading && styles.uploadButtonDisabled]}
              onPress={handleTakePhoto}
              disabled={uploading}
            >
              <Text style={styles.uploadButtonIcon}>📷</Text>
              <Text style={styles.uploadButtonText}>Take Photo</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.uploadButton, uploading && styles.uploadButtonDisabled]}
              onPress={handlePickDocument}
              disabled={uploading}
            >
              <Text style={styles.uploadButtonIcon}>📁</Text>
              <Text style={styles.uploadButtonText}>Pick Document</Text>
            </TouchableOpacity>
          </View>

          {/* Upload Progress */}
          {uploading && (
            <View style={styles.progressContainer}>
              <ActivityIndicator size="small" color="#87CEEB" />
              <Text style={styles.progressText}>Uploading...</Text>
            </View>
          )}

          {/* Uploaded Documents */}
          {documents.length > 0 && (
            <View style={styles.documentsContainer}>
              <Text style={styles.documentsTitle}>Uploaded Documents:</Text>
              <ScrollView style={styles.documentsList}>
                {documents.map((doc) => (
                  <View key={doc.id} style={styles.documentItem}>
                    <View style={styles.documentInfo}>
                      <Text style={styles.documentName}>{doc.fileName}</Text>
                      <Text style={styles.documentSize}>
                        {documentUploadService.formatFileSize(doc.fileSize)}
                      </Text>
                      <View style={styles.documentStatus}>
                        <View style={[styles.statusDot, { backgroundColor: getStatusColor(doc.status) }]} />
                        <Text style={styles.statusText}>{getStatusText(doc.status)}</Text>
                      </View>
                    </View>

                    {/* Progress Bar */}
                    {doc.status === 'uploading' && uploadProgress[doc.id] !== undefined && (
                      <View style={styles.progressBar}>
                        <View 
                          style={[styles.progressFill, { width: `${uploadProgress[doc.id]}%` }]} 
                        />
                      </View>
                    )}

                    {/* Remove Button */}
                    <TouchableOpacity
                      style={styles.removeButton}
                      onPress={() => handleRemoveDocument(doc.id)}
                    >
                      <Text style={styles.removeButtonText}>🗑️</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </ScrollView>
            </View>
          )}

          {/* Action Buttons */}
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.cancelButton} onPress={onClose}>
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.completeButton, documents.length === 0 && styles.completeButtonDisabled]}
              onPress={handleComplete}
              disabled={documents.length === 0}
            >
              <Text style={styles.completeButtonText}>
                Complete ({documents.length})
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E3A8A',
  },
  closeButton: {
    padding: 8,
  },
  closeButtonText: {
    fontSize: 20,
    color: '#666666',
  },
  description: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 20,
    textAlign: 'center',
  },
  uploadOptions: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  uploadButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  uploadButtonDisabled: {
    backgroundColor: '#E0E0E0',
  },
  uploadButtonIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  uploadButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  progressText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#666666',
  },
  documentsContainer: {
    marginBottom: 20,
  },
  documentsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 12,
  },
  documentsList: {
    maxHeight: 200,
  },
  documentItem: {
    backgroundColor: '#F8F9FA',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  documentInfo: {
    flex: 1,
  },
  documentName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E3A8A',
    marginBottom: 4,
  },
  documentSize: {
    fontSize: 12,
    color: '#666666',
    marginBottom: 4,
  },
  documentStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    fontSize: 12,
    color: '#666666',
  },
  progressBar: {
    height: 4,
    backgroundColor: '#E0E0E0',
    borderRadius: 2,
    marginVertical: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
  },
  removeButton: {
    padding: 8,
  },
  removeButtonText: {
    fontSize: 16,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#E0E0E0',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666666',
  },
  completeButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  completeButtonDisabled: {
    backgroundColor: '#E0E0E0',
  },
  completeButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});
