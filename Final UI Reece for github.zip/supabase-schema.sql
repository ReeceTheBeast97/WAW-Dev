-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  user_type TEXT NOT NULL CHECK (user_type IN ('customer', 'valeter', 'business', 'super_admin')),
  is_verified BOOLEAN DEFAULT FALSE,
  verification_type TEXT DEFAULT 'email',
  total_washes INTEGER DEFAULT 0,
  tier TEXT DEFAULT 'bronze',
  tier_points INTEGER DEFAULT 0,
  join_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Valeter specific fields
  is_individual_valeter BOOLEAN,
  organization_id UUID REFERENCES organizations(id),
  individual_license_verified BOOLEAN DEFAULT FALSE,
  individual_insurance_verified BOOLEAN DEFAULT FALSE,
  individual_documents_uploaded BOOLEAN DEFAULT FALSE,
  background_check_passed BOOLEAN DEFAULT FALSE,
  
  -- Organization specific fields
  organization_type TEXT CHECK (organization_type IN ('independent', 'registered')),
  organization_name TEXT,
  organization_license_verified BOOLEAN DEFAULT FALSE,
  organization_insurance_verified BOOLEAN DEFAULT FALSE,
  organization_documents_uploaded BOOLEAN DEFAULT FALSE
);

-- Create organizations table
CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  license_number TEXT NOT NULL,
  insurance_number TEXT NOT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create valeter_profiles table
CREATE TABLE valeter_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  working_radius INTEGER DEFAULT 10,
  is_online BOOLEAN DEFAULT FALSE,
  current_location JSONB,
  specializations TEXT[] DEFAULT '{}',
  documents JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create bookings table
CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  customer_id UUID REFERENCES users(id) ON DELETE CASCADE,
  valeter_id UUID REFERENCES users(id),
  service_type TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'en_route', 'arrived', 'in_progress', 'completed', 'cancelled')),
  location JSONB NOT NULL,
  special_instructions TEXT,
  scheduled_time TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  review TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create admin_access_logs table
CREATE TABLE admin_access_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  access_code TEXT NOT NULL,
  success BOOLEAN NOT NULL,
  device_id TEXT NOT NULL,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create RLS (Row Level Security) policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE valeter_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_access_logs ENABLE ROW LEVEL SECURITY;

-- Users policies
CREATE POLICY "Users can view their own profile" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON users
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Super admins can view all users" ON users
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

CREATE POLICY "Super admins can update all users" ON users
  FOR UPDATE USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

-- Organizations policies
CREATE POLICY "Organizations are viewable by all authenticated users" ON organizations
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Only super admins can manage organizations" ON organizations
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

-- Valeter profiles policies
CREATE POLICY "Valeters can view their own profile" ON valeter_profiles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Valeters can update their own profile" ON valeter_profiles
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Super admins can view all valeter profiles" ON valeter_profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

-- Bookings policies
CREATE POLICY "Users can view their own bookings" ON bookings
  FOR SELECT USING (auth.uid() = customer_id OR auth.uid() = valeter_id);

CREATE POLICY "Users can create bookings" ON bookings
  FOR INSERT WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Valeters can update bookings they're assigned to" ON bookings
  FOR UPDATE USING (auth.uid() = valeter_id);

CREATE POLICY "Super admins can view all bookings" ON bookings
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

-- Admin access logs policies
CREATE POLICY "Users can view their own access logs" ON admin_access_logs
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own access logs" ON admin_access_logs
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Super admins can view all access logs" ON admin_access_logs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM users WHERE id = auth.uid() AND user_type = 'super_admin'
    )
  );

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_user_type ON users(user_type);
CREATE INDEX idx_bookings_customer_id ON bookings(customer_id);
CREATE INDEX idx_bookings_valeter_id ON bookings(valeter_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_valeter_profiles_user_id ON valeter_profiles(user_id);
CREATE INDEX idx_admin_access_logs_user_id ON admin_access_logs(user_id);
CREATE INDEX idx_admin_access_logs_created_at ON admin_access_logs(created_at);

-- Create functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_valeter_profiles_updated_at BEFORE UPDATE ON valeter_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert initial super admin user (Reeceyrackz)
INSERT INTO users (
  id,
  email,
  name,
  phone,
  user_type,
  is_verified,
  verification_type,
  total_washes,
  tier,
  tier_points,
  join_date,
  created_at,
  updated_at
) VALUES (
  uuid_generate_v4(),
  'Reeceyrackz@gmail.com',
  'Reeceyrackz (Founder)',
  '+44 7700 900001',
  'super_admin',
  TRUE,
  'none',
  0,
  'platinum',
  9999,
  NOW(),
  NOW(),
  NOW()
);

-- Create a function to get user with profile data
CREATE OR REPLACE FUNCTION get_user_with_profile(user_uuid UUID)
RETURNS TABLE (
  user_data JSONB,
  valeter_profile JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    to_jsonb(u.*) as user_data,
    to_jsonb(vp.*) as valeter_profile
  FROM users u
  LEFT JOIN valeter_profiles vp ON u.id = vp.user_id
  WHERE u.id = user_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a function to get booking statistics
CREATE OR REPLACE FUNCTION get_booking_stats(user_uuid UUID)
RETURNS TABLE (
  total_bookings INTEGER,
  completed_bookings INTEGER,
  pending_bookings INTEGER,
  total_spent DECIMAL(10,2),
  average_rating DECIMAL(3,2)
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*)::INTEGER as total_bookings,
    COUNT(*) FILTER (WHERE status = 'completed')::INTEGER as completed_bookings,
    COUNT(*) FILTER (WHERE status IN ('pending', 'confirmed'))::INTEGER as pending_bookings,
    COALESCE(SUM(price) FILTER (WHERE status = 'completed'), 0) as total_spent,
    COALESCE(AVG(rating) FILTER (WHERE rating IS NOT NULL), 0) as average_rating
  FROM bookings
  WHERE customer_id = user_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
