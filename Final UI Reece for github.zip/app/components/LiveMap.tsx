import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Animated, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';

const { width, height } = Dimensions.get('window');

interface LiveMapProps {
  valeterLocation: {
    latitude: number;
    longitude: number;
    address: string;
  };
  userLocation?: {
    latitude: number;
    longitude: number;
    timestamp: number;
    address: string;
  } | null;
  showMap: boolean;
  isCustomerView?: boolean;
}

export default function LiveMap({ valeterLocation, userLocation, showMap, isCustomerView = true }: LiveMapProps) {
  const [currentValeterLocation, setCurrentValeterLocation] = useState(valeterLocation);
  const [currentUserLocation, setCurrentUserLocation] = useState(userLocation);
  const [mapLoaded, setMapLoaded] = useState(false);
  
  // Animation values for smooth movement
  const valeterAnimX = useRef(new Animated.Value(0)).current;
  const valeterAnimY = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  // Initialize map
  useEffect(() => {
    setMapLoaded(true);
    console.log('🗺️ LiveMap initialized with WebView Google Maps');
    
    // Start pulse animation
    const pulseAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    pulseAnimation.start();
  }, []);

  // Update locations in real-time
  useEffect(() => {
    setCurrentValeterLocation(valeterLocation);
  }, [valeterLocation]);

  useEffect(() => {
    setCurrentUserLocation(userLocation);
  }, [userLocation]);

  // Simulate real-time movement with smooth animations
  useEffect(() => {
    if (!mapLoaded || !currentUserLocation) return;

    const movementInterval = setInterval(() => {
      try {
        // Calculate movement towards customer
        const latDiff = currentUserLocation.latitude - currentValeterLocation.latitude;
        const lonDiff = currentUserLocation.longitude - currentValeterLocation.longitude;
        
        // Move valeter 3% closer to customer every 2 seconds
        const moveStep = 0.03;
        const newLat = currentValeterLocation.latitude + (latDiff * moveStep);
        const newLng = currentValeterLocation.longitude + (lonDiff * moveStep);
        
        // Animate the movement smoothly
        Animated.parallel([
          Animated.timing(valeterAnimX, {
            toValue: (newLng - valeterLocation.longitude) * 1000,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(valeterAnimY, {
            toValue: (newLat - valeterLocation.latitude) * 1000,
            duration: 2000,
            useNativeDriver: true,
          }),
        ]).start();
        
        setCurrentValeterLocation({
          ...currentValeterLocation,
          latitude: newLat,
          longitude: newLng,
        });

        console.log('🗺️ Valeter moved to:', newLat, newLng);
      } catch (error) {
        console.error('Error in movement simulation:', error);
      }
    }, 2000);

    return () => clearInterval(movementInterval);
  }, [mapLoaded, currentUserLocation, currentValeterLocation, valeterLocation]);

  if (!showMap) {
    return null;
  }

  // Create HTML for Google Maps with animated markers
  const createMapHTML = () => {
    const centerLat = currentUserLocation ? 
      (currentValeterLocation.latitude + currentUserLocation.latitude) / 2 : 
      currentValeterLocation.latitude;
    const centerLng = currentUserLocation ? 
      (currentValeterLocation.longitude + currentUserLocation.longitude) / 2 : 
      currentValeterLocation.longitude;

    const valeterSvg = encodeURIComponent('<svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><circle cx="20" cy="20" r="18" fill="#87CEEB" stroke="#fff" stroke-width="3"/><text x="20" y="25" text-anchor="middle" font-size="20">🧽</text></svg>');
    const userSvg = encodeURIComponent('<svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><circle cx="20" cy="20" r="18" fill="#28a745" stroke="#fff" stroke-width="3"/><text x="20" y="25" text-anchor="middle" font-size="20">📍</text></svg>');

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { margin: 0; padding: 0; }
            #map { width: 100%; height: 100vh; }
            .pulse {
              animation: pulse 2s infinite;
            }
            @keyframes pulse {
              0% { transform: scale(1); }
              50% { transform: scale(1.1); }
              100% { transform: scale(1); }
            }
          </style>
        </head>
        <body>
          <div id="map"></div>
          <script>
            function initMap() {
              const map = new google.maps.Map(document.getElementById('map'), {
                center: { lat: ${centerLat}, lng: ${centerLng} },
                zoom: 15,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                styles: [
                  {
                    featureType: 'poi',
                    elementType: 'labels',
                    stylers: [{ visibility: 'off' }]
                  }
                ]
              });

              // Valeter marker with pulse animation
              const valeterMarker = new google.maps.Marker({
                position: { lat: ${currentValeterLocation.latitude}, lng: ${currentValeterLocation.longitude} },
                map: map,
                title: 'Valeter',
                icon: {
                  url: 'data:image/svg+xml;charset=UTF-8,${valeterSvg}',
                  scaledSize: new google.maps.Size(40, 40)
                }
              });

              ${currentUserLocation ? `
              // User marker
              const userMarker = new google.maps.Marker({
                position: { lat: ${currentUserLocation.latitude}, lng: ${currentUserLocation.longitude} },
                map: map,
                title: 'Your Location',
                icon: {
                  url: 'data:image/svg+xml;charset=UTF-8,${userSvg}',
                  scaledSize: new google.maps.Size(40, 40)
                }
              });
              ` : ''}

              // Info windows
              const valeterInfo = new google.maps.InfoWindow({
                content: '<div style="padding: 10px;"><strong>Valeter</strong><br>${currentValeterLocation.address}<br><small>ETA: ~8 minutes</small></div>'
              });

              valeterMarker.addListener('click', () => {
                valeterInfo.open(map, valeterMarker);
              });

              ${currentUserLocation ? `
              const userInfo = new google.maps.InfoWindow({
                content: '<div style="padding: 10px;"><strong>Your Location</strong><br>${currentUserLocation.address}</div>'
              });

              userMarker.addListener('click', () => {
                userInfo.open(map, userMarker);
              });
              ` : ''}

              // Fit bounds to show both markers
              ${currentUserLocation ? `
              const bounds = new google.maps.LatLngBounds();
              bounds.extend(valeterMarker.getPosition());
              bounds.extend(userMarker.getPosition());
              map.fitBounds(bounds);
              ` : ''}

              // Simulate real-time movement
              setInterval(() => {
                const currentPos = valeterMarker.getPosition();
                const userPos = ${currentUserLocation ? `new google.maps.LatLng(${currentUserLocation.latitude}, ${currentUserLocation.longitude})` : 'null'};
                
                if (userPos) {
                  const latDiff = userPos.lat() - currentPos.lat();
                  const lngDiff = userPos.lng() - currentPos.lng();
                  const moveStep = 0.03;
                  
                  const newLat = currentPos.lat() + (latDiff * moveStep);
                  const newLng = currentPos.lng() + (lngDiff * moveStep);
                  
                  valeterMarker.setPosition(new google.maps.LatLng(newLat, newLng));
                }
              }, 2000);
            }
          </script>
          <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg&callback=initMap">
          </script>
        </body>
      </html>
    `;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>🗺️ Live Tracking</Text>
        <Text style={styles.subtitle}>
          {isCustomerView ? 'Track your valeter in real-time' : 'Navigate to customer location'}
        </Text>
      </View>

      <View style={styles.mapContainer}>
        <WebView
          source={{ html: createMapHTML() }}
          style={styles.map}
          onLoad={() => {
            console.log('🗺️ WebView Google Maps loaded successfully');
            setMapLoaded(true);
          }}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          startInLoadingState={true}
          scalesPageToFit={true}
          bounces={false}
          scrollEnabled={false}
        />
      </View>

      {/* Live Status Overlay */}
      <View style={styles.statusOverlay}>
        <View style={styles.statusCard}>
          <Text style={styles.statusTitle}>
            {isCustomerView ? 'Valeter Status' : 'Customer Status'}
          </Text>
          <Text style={styles.statusText}>
            {isCustomerView ? '🚗 On the way' : '📍 Waiting for valeter'}
          </Text>
          <Text style={styles.etaText}>
            {isCustomerView ? 'ETA: ~8 minutes' : 'ETA: ~5 minutes'}
          </Text>
          <Text style={styles.distanceText}>Distance: 1.2 km</Text>
        </View>
      </View>

      {/* Action Buttons */}
      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>📞 Call</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>💬 Message</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Text style={styles.actionButtonText}>📍 Share Location</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    padding: 20,
    backgroundColor: '#1E3A8A',
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  mapContainer: {
    flex: 1,
    position: 'relative',
  },
  map: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  statusOverlay: {
    position: 'absolute',
    top: 20,
    left: 20,
    right: 20,
  },
  statusCard: {
    backgroundColor: 'rgba(30, 58, 138, 0.95)',
    borderRadius: 15,
    padding: 15,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  statusTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  statusText: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 5,
  },
  etaText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 3,
  },
  distanceText: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  actionButtons: {
    position: 'absolute',
    bottom: 20,
    left: 20,
    right: 20,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 20,
    minWidth: 80,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
