import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';
import { GOOGLE_MAPS_API_KEY } from '../../src/config/google-maps';

const { width, height } = Dimensions.get('window');

interface ExpoMapProps {
  valeterLocation: {
    latitude: number;
    longitude: number;
    address: string;
  };
  userLocation?: {
    latitude: number;
    longitude: number;
    address: string;
  } | null;
  showMap: boolean;
  isCustomerView?: boolean;
}

export default function ExpoMap({ valeterLocation, userLocation, showMap, isCustomerView = true }: ExpoMapProps) {
  const [currentValeterLocation, setCurrentValeterLocation] = useState(valeterLocation);
  const [currentUserLocation, setCurrentUserLocation] = useState(userLocation);
  const [mapLoaded, setMapLoaded] = useState(true);
  const [mapError, setMapError] = useState<string | null>(null);

  // Initialize map
  useEffect(() => {
    setMapLoaded(true);
    console.log('🗺️ Enhanced WebView Google Maps initialized');
  }, []);

  // Update locations in real-time
  useEffect(() => {
    setCurrentValeterLocation(valeterLocation);
  }, [valeterLocation]);

  useEffect(() => {
    setCurrentUserLocation(userLocation);
  }, [userLocation]);

  // Enhanced road-following movement simulation
  useEffect(() => {
    if (!mapLoaded) return;

    // Define road waypoints for more realistic movement
    const waypoints = [
      { lat: 51.5074, lng: -0.1278 },
      { lat: 51.5076, lng: -0.1276 },
      { lat: 51.5078, lng: -0.1274 },
      { lat: 51.5080, lng: -0.1272 },
      { lat: 51.5082, lng: -0.1270 },
      { lat: 51.5084, lng: -0.1268 },
      { lat: 51.5086, lng: -0.1266 },
      { lat: 51.5088, lng: -0.1264 },
      { lat: 51.5090, lng: -0.1262 },
      { lat: 51.5092, lng: -0.1260 },
    ];

    let currentWaypointIndex = 0;
    let progressAlongWaypoint = 0;

    const movementInterval = setInterval(() => {
      try {
        if (currentUserLocation && waypoints.length > 0) {
          // Move along waypoints for more realistic road following
          const currentWaypoint = waypoints[currentWaypointIndex];
          const nextWaypoint = waypoints[currentWaypointIndex + 1] || currentUserLocation;
          
          // Calculate movement along current waypoint segment
          const latDiff = nextWaypoint.lat - currentWaypoint.lat;
          const lngDiff = nextWaypoint.lng - currentWaypoint.lng;
          
          // Move 20% along the current waypoint segment
          const moveStep = 0.2;
          progressAlongWaypoint += moveStep;
          
          if (progressAlongWaypoint >= 1) {
            // Move to next waypoint
            currentWaypointIndex = Math.min(currentWaypointIndex + 1, waypoints.length - 1);
            progressAlongWaypoint = 0;
          }
          
          // Calculate new position along the waypoint path
          const newLat = currentWaypoint.lat + (latDiff * progressAlongWaypoint);
          const newLng = currentWaypoint.lng + (lngDiff * progressAlongWaypoint);
          
          setCurrentValeterLocation(prev => ({
            ...prev,
            latitude: newLat,
            longitude: newLng,
            address: getCurrentAddress(prev.status)
          }));
        }
      } catch (error) {
        console.error('Error in road-following movement simulation:', error);
      }
    }, 2000); // Slightly slower for more realistic movement

    return () => clearInterval(movementInterval);
  }, [mapLoaded, currentUserLocation, currentValeterLocation]);

  const getCurrentAddress = (status?: string) => {
    switch (status) {
      case 'en_route':
        return 'On the way to your location';
      case 'arrived':
        return 'Arrived at your location';
      case 'in_progress':
        return 'At your location - Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'On the way to your location';
    }
  };

  const handleRetryMap = () => {
    setMapError(null);
    setMapLoaded(false);
    setTimeout(() => setMapLoaded(true), 1000);
  };

  if (!showMap) {
    return null;
  }

  // Enhanced HTML for Google Maps with better styling and no text boxes
  const createMapHTML = () => {
    const centerLat = currentUserLocation ? 
      (currentValeterLocation.latitude + currentUserLocation.latitude) / 2 : 
      currentValeterLocation.latitude;
    const centerLng = currentUserLocation ? 
      (currentValeterLocation.longitude + currentUserLocation.longitude) / 2 : 
      currentValeterLocation.longitude;

    // Enhanced SVG icons without text boxes
    const valeterSvg = encodeURIComponent('<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"><circle cx="25" cy="25" r="22" fill="#87CEEB" stroke="#1E3A8A" stroke-width="3"/><circle cx="25" cy="25" r="18" fill="#87CEEB" opacity="0.8"/><text x="25" y="32" text-anchor="middle" font-size="24" font-weight="bold">🧽</text></svg>');
    const userSvg = encodeURIComponent('<svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg"><circle cx="25" cy="25" r="22" fill="#10B981" stroke="#1E3A8A" stroke-width="3"/><circle cx="25" cy="25" r="18" fill="#10B981" opacity="0.8"/><text x="25" y="32" text-anchor="middle" font-size="24" font-weight="bold">📍</text></svg>');

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { 
              margin: 0; 
              padding: 0; 
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }
            #map { 
              width: 100%; 
              height: 100vh; 
            }


          </style>
        </head>
        <body>
          <div id="map"></div>
          


          <script>
            let map, valeterMarker, userMarker;

            function initMap() {
                             map = new google.maps.Map(document.getElementById('map'), {
                 center: { lat: ${centerLat}, lng: ${centerLng} },
                 zoom: 18,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                styles: [
                  {
                    featureType: 'poi',
                    elementType: 'labels',
                    stylers: [{ visibility: 'off' }]
                  },
                  {
                    featureType: 'transit',
                    elementType: 'labels',
                    stylers: [{ visibility: 'off' }]
                  },
                  {
                    featureType: 'landscape',
                    elementType: 'geometry',
                    stylers: [{ color: '#f5f5f5' }]
                  },
                  {
                    featureType: 'road',
                    elementType: 'geometry',
                    stylers: [{ color: '#ffffff' }]
                  },
                  {
                    featureType: 'road',
                    elementType: 'geometry.stroke',
                    stylers: [{ color: '#e0e0e0' }]
                  }
                ],
                disableDefaultUI: true,
                zoomControl: true,
                streetViewControl: false,
                mapTypeControl: false,
                fullscreenControl: false
              });

              // Enhanced valeter marker with pulsing effect
              valeterMarker = new google.maps.Marker({
                position: { lat: ${currentValeterLocation.latitude}, lng: ${currentValeterLocation.longitude} },
                map: map,
                title: 'Valeter',
                icon: {
                  url: 'data:image/svg+xml;charset=UTF-8,${valeterSvg}',
                  scaledSize: new google.maps.Size(50, 50),
                  anchor: new google.maps.Point(25, 25)
                },
                animation: google.maps.Animation.BOUNCE
              });

              ${currentUserLocation ? `
              // Enhanced user marker
              userMarker = new google.maps.Marker({
                position: { lat: ${currentUserLocation.latitude}, lng: ${currentUserLocation.longitude} },
                map: map,
                title: 'Your Location',
                icon: {
                  url: 'data:image/svg+xml;charset=UTF-8,${userSvg}',
                  scaledSize: new google.maps.Size(50, 50),
                  anchor: new google.maps.Point(25, 25)
                }
              });
              ` : ''}

              // Enhanced info windows with better styling
              const valeterInfo = new google.maps.InfoWindow({
                content: '<div style="padding: 15px; font-family: -apple-system, sans-serif;"><strong style="color: #1E3A8A;">🧽 Valeter</strong><br><span style="color: #6B7280;">${currentValeterLocation.address}</span></div>'
              });

              valeterMarker.addListener('click', () => {
                valeterInfo.open(map, valeterMarker);
              });

              ${currentUserLocation ? `
              const userInfo = new google.maps.InfoWindow({
                content: '<div style="padding: 15px; font-family: -apple-system, sans-serif;"><strong style="color: #1E3A8A;">📍 Your Location</strong><br><span style="color: #6B7280;">${currentUserLocation.address}</span></div>'
              });

              userMarker.addListener('click', () => {
                userInfo.open(map, userMarker);
              });
              ` : ''}

              // Fit bounds to show both markers
              ${currentUserLocation ? `
              const bounds = new google.maps.LatLngBounds();
              bounds.extend(valeterMarker.getPosition());
              bounds.extend(userMarker.getPosition());
              map.fitBounds(bounds);
              ` : ''}

              // Initialize traffic layer
              trafficLayer = new google.maps.TrafficLayer();
              
              // Create road path polyline
              const waypoints = [
                { lat: 51.5074, lng: -0.1278 },
                { lat: 51.5076, lng: -0.1276 },
                { lat: 51.5078, lng: -0.1274 },
                { lat: 51.5080, lng: -0.1272 },
                { lat: 51.5082, lng: -0.1270 },
                { lat: 51.5084, lng: -0.1268 },
                { lat: 51.5086, lng: -0.1266 },
                { lat: 51.5088, lng: -0.1264 },
                { lat: 51.5090, lng: -0.1262 },
                { lat: 51.5092, lng: -0.1260 },
              ];
              
              const roadPath = new google.maps.Polyline({
                path: waypoints,
                geodesic: true,
                strokeColor: '#87CEEB',
                strokeOpacity: 0.8,
                strokeWeight: 4,
                map: map
              });
              
              // Add direction arrows along the path
              waypoints.forEach((waypoint, index) => {
                if (index < waypoints.length - 1) {
                  const nextWaypoint = waypoints[index + 1];
                  const heading = google.maps.geometry.spherical.computeHeading(
                    new google.maps.LatLng(waypoint.lat, waypoint.lng),
                    new google.maps.LatLng(nextWaypoint.lat, nextWaypoint.lng)
                  );
                  
                  const arrowMarker = new google.maps.Marker({
                    position: { lat: waypoint.lat, lng: waypoint.lng },
                    map: map,
                    icon: {
                      path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                      scale: 3,
                      strokeColor: '#87CEEB',
                      fillColor: '#87CEEB',
                      rotation: heading
                    },
                    title: 'Route Direction'
                  });
                }
              });
            }

                         function centerMap() {
               ${currentUserLocation ? `
               const bounds = new google.maps.LatLngBounds();
               bounds.extend(valeterMarker.getPosition());
               bounds.extend(userMarker.getPosition());
               map.fitBounds(bounds);
               ` : `
               map.setCenter(valeterMarker.getPosition());
               map.setZoom(18);
               `}
             }

            function toggleTraffic() {
              if (trafficEnabled) {
                trafficLayer.setMap(null);
                trafficEnabled = false;
              } else {
                trafficLayer.setMap(map);
                trafficEnabled = true;
              }
            }

            // Update marker positions for smooth movement
            function updateValeterPosition(lat, lng) {
              const newPosition = new google.maps.LatLng(lat, lng);
              valeterMarker.setPosition(newPosition);
            }
          </script>
          <script async defer
            src="https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&callback=initMap&libraries=geometry">
          </script>
        </body>
      </html>
    `;
  };

  return (
    <View style={styles.mapContainer}>
      <View style={styles.mapHeader}>
        <Text style={styles.mapTitle}>🗺️ Enhanced Live Tracking</Text>
        <Text style={styles.mapSubtitle}>
          {isCustomerView ? 'Follow your valeter in real-time' : 'Navigate to customer location'}
        </Text>
      </View>
      
      <View style={styles.mapContent}>
        {mapError ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>Map loading error: {mapError}</Text>
            <TouchableOpacity style={styles.retryButton} onPress={handleRetryMap}>
              <Text style={styles.retryButtonText}>Retry</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <WebView
            source={{ html: createMapHTML() }}
            style={styles.map}
            onLoad={() => {
              console.log('🗺️ Enhanced WebView Google Maps loaded successfully');
              setMapLoaded(true);
            }}
            onError={(error) => {
              console.error('🗺️ Enhanced WebView Google Maps error:', error);
              setMapError(error.nativeEvent?.description || 'Unknown map error');
            }}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            startInLoadingState={true}
            scalesPageToFit={true}
            bounces={false}
            scrollEnabled={false}
            showsHorizontalScrollIndicator={false}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  mapContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  mapHeader: {
    padding: 20,
    backgroundColor: '#1E3A8A',
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
  },
  mapTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  mapSubtitle: {
    fontSize: 16,
    color: '#B0E0E6',
  },
  mapContent: {
    flex: 1,
    position: 'relative',
  },
  map: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
  },
  errorText: {
    color: '#ff6b6b',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
  },
  retryButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: 'bold',
  },
});
