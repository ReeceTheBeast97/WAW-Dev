import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  Switch,
  Modal,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  isRequired: boolean;
  isCompleted: boolean;
}

interface Organization {
  id: string;
  name: string;
  verified: boolean;
}

export default function ValeterOnboardingEnhanced() {
  const { user, updateUser } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [isIndividualValeter, setIsIndividualValeter] = useState<boolean | null>(null);
  const [selectedOrganization, setSelectedOrganization] = useState<string | null>(null);
  const [showOrganizationModal, setShowOrganizationModal] = useState(false);
  const [organizations, setOrganizations] = useState<Organization[]>([
    { id: 'org_1', name: 'Elite Valet Services Ltd', verified: true },
    { id: 'org_2', name: 'Premium Car Care Ltd', verified: true },
    { id: 'org_3', name: 'Quick Clean Pro Ltd', verified: false },
  ]);

  const [onboardingSteps, setOnboardingSteps] = useState<OnboardingStep[]>([]);

  useEffect(() => {
    if (isIndividualValeter !== null) {
      updateOnboardingSteps();
    }
  }, [isIndividualValeter, selectedOrganization]);

  const updateOnboardingSteps = () => {
    if (isIndividualValeter) {
      // Individual valeter steps
      setOnboardingSteps([
        {
          id: 'personal_info',
          title: 'Personal Information',
          description: 'Basic details about you',
          isRequired: true,
          isCompleted: true,
        },
        {
          id: 'license',
          title: 'Driving License',
          description: 'Upload your driving license',
          isRequired: true,
          isCompleted: false,
        },
        {
          id: 'insurance',
          title: 'Insurance Documents',
          description: 'Upload insurance certificates',
          isRequired: true,
          isCompleted: false,
        },
        {
          id: 'background_check',
          title: 'Background Check',
          description: 'Complete background verification',
          isRequired: true,
          isCompleted: false,
        },
        {
          id: 'vehicle_info',
          title: 'Vehicle Information',
          description: 'Details about your vehicle',
          isRequired: true,
          isCompleted: false,
        },
      ]);
    } else if (selectedOrganization) {
      // Organization valeter steps
      setOnboardingSteps([
        {
          id: 'personal_info',
          title: 'Personal Information',
          description: 'Basic details about you',
          isRequired: true,
          isCompleted: true,
        },
        {
          id: 'organization_verification',
          title: 'Organization Verification',
          description: 'Verify your organization details',
          isRequired: true,
          isCompleted: false,
        },
        {
          id: 'background_check',
          title: 'Background Check',
          description: 'Complete background verification',
          isRequired: true,
          isCompleted: false,
        },
        {
          id: 'vehicle_info',
          title: 'Vehicle Information',
          description: 'Details about your vehicle',
          isRequired: true,
          isCompleted: false,
        },
      ]);
    }
  };

  const handleValeterTypeSelection = (isIndividual: boolean) => {
    setIsIndividualValeter(isIndividual);
    if (!isIndividual) {
      setShowOrganizationModal(true);
    }
  };

  const handleOrganizationSelection = (orgId: string) => {
    setSelectedOrganization(orgId);
    setShowOrganizationModal(false);
  };

  const handleStepCompletion = (stepId: string) => {
    setOnboardingSteps(prev => 
      prev.map(step => 
        step.id === stepId 
          ? { ...step, isCompleted: true }
          : step
      )
    );
  };

  const handleCompleteOnboarding = async () => {
    try {
      // Update user with valeter type and organization info
      await updateUser({
        userType: 'valeter',
        isIndividualValeter,
        organizationId: selectedOrganization,
        isVerified: true,
        documentsUploaded: true,
        insuranceVerified: true,
        licenseVerified: true,
        backgroundCheckPassed: true,
      });

      Alert.alert(
        'Onboarding Complete! 🎉',
        'Welcome to Wish a Wash! You can now start accepting bookings.',
        [
          {
            text: 'Go to Dashboard',
            onPress: () => router.replace('/driver-dashboard')
          }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to complete onboarding. Please try again.');
    }
  };

  const getStepIcon = (stepId: string) => {
    switch (stepId) {
      case 'personal_info': return '👤';
      case 'license': return '🚗';
      case 'insurance': return '🛡️';
      case 'background_check': return '🔍';
      case 'vehicle_info': return '🚙';
      case 'organization_verification': return '🏢';
      default: return '📋';
    }
  };

  const getStepColor = (step: OnboardingStep) => {
    if (step.isCompleted) return '#10B981';
    if (step.isRequired) return '#F59E0B';
    return '#6B7280';
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <LinearGradient
            colors={['#0A1929', '#1E3A8A']}
            style={styles.headerGradient}
          >
            <Text style={styles.headerTitle}>Valeter Onboarding</Text>
            <Text style={styles.headerSubtitle}>Join our professional network</Text>
          </LinearGradient>
        </View>

        {/* Valeter Type Selection */}
        {isIndividualValeter === null && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Your Valeter Type</Text>
            <Text style={styles.sectionDescription}>
              Select whether you work as an individual valeter or for an organization
            </Text>
            
            <View style={styles.typeSelection}>
              <TouchableOpacity
                style={styles.typeCard}
                onPress={() => handleValeterTypeSelection(true)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#1E3A8A', '#87CEEB']}
                  style={styles.typeCardGradient}
                >
                  <Text style={styles.typeIcon}>👤</Text>
                  <Text style={styles.typeTitle}>Individual Valeter</Text>
                  <Text style={styles.typeDescription}>
                    Work independently with your own license and insurance
                  </Text>
                  <Text style={styles.typeRequirements}>
                    Requires: Personal license, insurance, background check
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.typeCard}
                onPress={() => handleValeterTypeSelection(false)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  style={styles.typeCardGradient}
                >
                  <Text style={styles.typeIcon}>🏢</Text>
                  <Text style={styles.typeTitle}>Organization Valeter</Text>
                  <Text style={styles.typeDescription}>
                    Work for a registered organization with their credentials
                  </Text>
                  <Text style={styles.typeRequirements}>
                    Requires: Organization verification, background check
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Organization Selection Modal */}
        <Modal
          visible={showOrganizationModal}
          animationType="slide"
          transparent={true}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Select Your Organization</Text>
              <Text style={styles.modalSubtitle}>
                Choose the organization you work for
              </Text>
              
              <ScrollView style={styles.organizationList}>
                {organizations.map((org) => (
                  <TouchableOpacity
                    key={org.id}
                    style={[
                      styles.organizationItem,
                      selectedOrganization === org.id && styles.selectedOrganization
                    ]}
                    onPress={() => handleOrganizationSelection(org.id)}
                  >
                    <View style={styles.organizationInfo}>
                      <Text style={styles.organizationName}>{org.name}</Text>
                      <View style={styles.organizationStatus}>
                        <Text style={[
                          styles.organizationStatusText,
                          { color: org.verified ? '#10B981' : '#F59E0B' }
                        ]}>
                          {org.verified ? '✓ Verified' : '⚠ Pending Verification'}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </ScrollView>

              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => {
                    setShowOrganizationModal(false);
                    setIsIndividualValeter(null);
                  }}
                >
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.confirmButton,
                    !selectedOrganization && styles.confirmButtonDisabled
                  ]}
                  onPress={() => {
                    if (selectedOrganization) {
                      setShowOrganizationModal(false);
                    }
                  }}
                  disabled={!selectedOrganization}
                >
                  <Text style={styles.confirmButtonText}>Confirm</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

        {/* Onboarding Steps */}
        {onboardingSteps.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Onboarding Steps</Text>
            <Text style={styles.sectionDescription}>
              Complete these steps to start accepting bookings
            </Text>
            
            <View style={styles.stepsContainer}>
              {onboardingSteps.map((step, index) => (
                <View key={step.id} style={styles.stepCard}>
                  <View style={styles.stepHeader}>
                    <View style={[
                      styles.stepIcon,
                      { backgroundColor: getStepColor(step) }
                    ]}>
                      <Text style={styles.stepIconText}>{getStepIcon(step.id)}</Text>
                    </View>
                    <View style={styles.stepInfo}>
                      <Text style={styles.stepTitle}>{step.title}</Text>
                      <Text style={styles.stepDescription}>{step.description}</Text>
                    </View>
                    <View style={styles.stepStatus}>
                      {step.isCompleted ? (
                        <Text style={styles.completedIcon}>✓</Text>
                      ) : (
                        <Text style={styles.pendingIcon}>○</Text>
                      )}
                    </View>
                  </View>
                  
                  {!step.isCompleted && (
                    <TouchableOpacity
                      style={styles.completeStepButton}
                      onPress={() => handleStepCompletion(step.id)}
                    >
                      <Text style={styles.completeStepButtonText}>
                        Mark as Complete
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Complete Onboarding Button */}
        {onboardingSteps.length > 0 && onboardingSteps.every(step => step.isCompleted) && (
          <View style={styles.section}>
            <TouchableOpacity
              style={styles.completeOnboardingButton}
              onPress={handleCompleteOnboarding}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.completeOnboardingGradient}
              >
                <Text style={styles.completeOnboardingText}>
                  Complete Onboarding
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}

        {/* Back Button */}
        <View style={styles.backSection}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    marginBottom: 24,
  },
  headerGradient: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  headerSubtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 16 : 18,
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionDescription: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 20,
    lineHeight: 22,
  },
  typeSelection: {
    gap: 16,
  },
  typeCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  typeCardGradient: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
  },
  typeIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  typeTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  typeDescription: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 22,
  },
  typeRequirements: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 12 : 14,
    textAlign: 'center',
    opacity: 0.9,
    fontStyle: 'italic',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: isSmallScreen ? 20 : 24,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  modalSubtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  organizationList: {
    maxHeight: 300,
  },
  organizationItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  selectedOrganization: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  organizationInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  organizationName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '600',
    flex: 1,
  },
  organizationStatus: {
    marginLeft: 12,
  },
  organizationStatusText: {
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: '600',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 20,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  confirmButton: {
    flex: 1,
    backgroundColor: '#10B981',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  stepsContainer: {
    gap: 16,
  },
  stepCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  stepIconText: {
    fontSize: 24,
  },
  stepInfo: {
    flex: 1,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  stepDescription: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
  },
  stepStatus: {
    marginLeft: 12,
  },
  completedIcon: {
    color: '#10B981',
    fontSize: 24,
    fontWeight: 'bold',
  },
  pendingIcon: {
    color: '#6B7280',
    fontSize: 24,
  },
  completeStepButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  completeStepButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  completeOnboardingButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
  },
  completeOnboardingGradient: {
    padding: 20,
    alignItems: 'center',
  },
  completeOnboardingText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  backSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 40,
  },
  backButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
});
