import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Dimensions,
  TextInput,
  Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { priorityWashService, CarWashLocation, PriorityWashBooking } from '../src/services/PriorityWashService';
import { paymentSystem } from '../src/services/PaymentSystem';


const { width } = Dimensions.get('window');

interface VehicleType {
  id: string;
  name: string;
  icon: string;
  description: string;
  baseMultiplier: number;
}

interface ServiceType {
  id: string;
  name: string;
  description: string;
  duration: string;
  multiplier: number;
}

export default function PriorityWash() {
  const router = useRouter();
  const { user } = useAuth();
  
  // Step management - Changed to 4 steps
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;
  
  const [carWashLocations, setCarWashLocations] = useState<CarWashLocation[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<CarWashLocation | null>(null);
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>('');
  const [selectedServiceType, setSelectedServiceType] = useState<string>('');
  const [priorityLevel, setPriorityLevel] = useState<'standard' | 'priority'>('standard');
  const [isLoading, setIsLoading] = useState(false);
  const [pricing, setPricing] = useState<{
    basePrice: number;
    priorityFee: number;
    totalPrice: number;
    estimatedWaitTime: number;
    canSkipQueue: boolean;
  } | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState({
    make: '',
    model: '',
    registration: '',
    photo: ''
  });
  const [etaCountdown, setEtaCountdown] = useState<number>(0);
  const [isBooked, setIsBooked] = useState(false);
  const [currentBooking, setCurrentBooking] = useState<PriorityWashBooking | null>(null);
  const [showVehicleOptions, setShowVehicleOptions] = useState(false);
  const [selectedVehicleOption, setSelectedVehicleOption] = useState<'stored' | 'new'>('stored');
  const [storedVehicles, setStoredVehicles] = useState([
    {
      id: '1',
      make: 'BMW',
      model: 'X5',
      registration: 'BM20 X5X',
      photo: 'bmw_x5.jpg',
      nickname: 'My BMW'
    },
    {
      id: '2',
      make: 'Mercedes',
      model: 'C-Class',
      registration: 'ME21 CCL',
      photo: 'mercedes_c.jpg',
      nickname: 'Work Car'
    }
  ]);
  const [selectedStoredVehicle, setSelectedStoredVehicle] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<{
    id: string;
    make: string;
    model: string;
    registration: string;
    nickname: string;
  } | null>(null);

  // Animation for countdown
  const countdownAnim = new Animated.Value(1);

  // Step navigation functions
  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 1: return selectedLocation !== null;
      case 2: return selectedVehicleType !== '';
      case 3: return selectedServiceType !== '';
      case 4: return true; // Confirmation step
      default: return false;
    }
  };

  // Auto-progression functions
  const handleLocationSelect = (location: CarWashLocation) => {
    setSelectedLocation(location);
    // Auto-progress to next step after a short delay
    setTimeout(() => {
      nextStep();
    }, 500);
  };

  const handleVehicleTypeSelect = (vehicleType: string) => {
    setSelectedVehicleType(vehicleType);
    // Auto-progress to next step after a short delay
    setTimeout(() => {
      nextStep();
    }, 500);
  };

  const handleServiceTypeSelect = (serviceType: string) => {
    setSelectedServiceType(serviceType);
    // Auto-progress to next step after a short delay
    setTimeout(() => {
      nextStep();
    }, 500);
  };

  const vehicleTypes: VehicleType[] = [
    { id: 'bike', name: 'Motorcycle', icon: '🏍️', description: 'Motorcycles and scooters', baseMultiplier: 0.6 },
    { id: 'small_car', name: 'Small Car', icon: '🚗', description: 'Hatchbacks and small sedans', baseMultiplier: 1.0 },
    { id: 'large_car', name: 'Large Car', icon: '🚙', description: 'Saloon cars and estates', baseMultiplier: 1.3 },
    { id: 'suv', name: 'SUV', icon: '🚙', description: 'Sports Utility Vehicles', baseMultiplier: 1.5 },
    { id: 'van', name: 'Van', icon: '🚐', description: 'Commercial vans and minibuses', baseMultiplier: 1.8 },
    { id: 'coach', name: 'Coach', icon: '🚌', description: 'Large coaches and buses', baseMultiplier: 3.0 },
    { id: 'luxury', name: 'Luxury Vehicle', icon: '🏎️', description: 'High-end and sports cars', baseMultiplier: 2.0 },
  ];

  const serviceTypes: ServiceType[] = [
    { id: 'exterior_only', name: 'Exterior Only', description: 'Wash exterior only', duration: '15 min', multiplier: 0.7 },
    { id: 'standard', name: 'Standard Wash', description: 'Exterior and interior clean', duration: '30 min', multiplier: 1.0 },
    { id: 'premium', name: 'Premium Wash', description: 'Deep clean with wax', duration: '45 min', multiplier: 1.4 },
    { id: 'luxury', name: 'Luxury Detail', description: 'Full detail and protection', duration: '90 min', multiplier: 2.0 },
  ];

  useEffect(() => {
    loadCarWashLocations();
  }, []);

  useEffect(() => {
    if (selectedLocation && selectedVehicleType && selectedServiceType) {
      calculatePricing();
    }
  }, [selectedLocation, selectedVehicleType, selectedServiceType, priorityLevel]);

  // ETA Countdown Timer
  useEffect(() => {
    if (isBooked && currentBooking) {
      const interval = setInterval(() => {
        const now = new Date().getTime();
        const arrivalTime = currentBooking.estimatedArrivalTime.getTime();
        const timeLeft = Math.max(0, Math.floor((arrivalTime - now) / 1000));
        
        setEtaCountdown(timeLeft);
        
        if (timeLeft === 0) {
          clearInterval(interval);
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isBooked, currentBooking]);

  const loadCarWashLocations = async () => {
    setIsLoading(true);
    try {
      const locations = await priorityWashService.getCarWashLocations();
      setCarWashLocations(locations);
    } catch (error) {
      console.error('Error loading locations:', error);
      Alert.alert('Error', 'Failed to load car wash locations');
    } finally {
      setIsLoading(false);
    }
  };

  const calculatePricing = () => {
    if (!selectedLocation || !selectedVehicleType || !selectedServiceType) return;

    const vehicleType = vehicleTypes.find(vt => vt.id === selectedVehicleType);
    const serviceType = serviceTypes.find(st => st.id === selectedServiceType);

    if (!vehicleType || !serviceType) return;

    const basePrice = selectedLocation.basePrice * vehicleType.baseMultiplier * serviceType.multiplier;
    const priorityFee = selectedLocation.priorityPrice;
    const totalPrice = basePrice + priorityFee;

    setPricing({
      basePrice,
      priorityFee,
      totalPrice,
      estimatedWaitTime: selectedLocation.currentWaitTime,
      canSkipQueue: priorityLevel === 'priority'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green': return '#FFD700';
      case 'yellow': return '#FFA500';
      case 'orange': return '#FF8C00';
      case 'red': return '#FF4500';
      default: return '#FFD700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'green': return 'Low Wait';
      case 'yellow': return 'Moderate Wait';
      case 'orange': return 'High Wait';
      case 'red': return 'Very Busy';
      default: return 'Unknown';
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const handleBookPriorityWash = async () => {
    if (!selectedLocation || !selectedVehicleType || !selectedServiceType) {
      Alert.alert('Error', 'Please complete all selections');
      return;
    }

    setIsLoading(true);
    try {
      const booking = await priorityWashService.createPriorityWashBooking({
        userId: user!.id,
        locationId: selectedLocation.id,
        vehicleType: selectedVehicleType,
        serviceType: selectedServiceType,
        priorityLevel,
        estimatedPrice: pricing?.totalPrice || 0,
        estimatedWaitTime: pricing?.estimatedWaitTime || 0
      });

      setCurrentBooking(booking);
      setIsBooked(true);
      
      // Navigate to tracking page after successful booking
      setTimeout(() => {
        router.push('/priority-wash-tracking');
      }, 2000);

    } catch (error) {
      console.error('Booking error:', error);
      Alert.alert('Error', 'Failed to create booking. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderBookingConfirmation = () => {
    if (!isBooked || !currentBooking) return null;

    return (
      <View style={styles.confirmationContainer}>
        <View style={styles.confirmationContent}>
          <Text style={styles.confirmationTitle}>🎉 Booking Confirmed!</Text>
          <Text style={styles.confirmationSubtitle}>Your priority wash is scheduled</Text>
          
          <View style={styles.confirmationDetails}>
            <Text style={styles.confirmationDetail}>📍 {selectedLocation?.name}</Text>
            <Text style={styles.confirmationDetail}>🚗 {vehicleTypes.find(vt => vt.id === selectedVehicleType)?.name}</Text>
            <Text style={styles.confirmationDetail}>✨ {serviceTypes.find(st => st.id === selectedServiceType)?.name}</Text>
            <Text style={styles.confirmationDetail}>💰 £{pricing?.totalPrice.toFixed(2)}</Text>
          </View>

          <View style={styles.etaContainer}>
            <Text style={styles.etaTitle}>Estimated Arrival Time</Text>
            <Animated.Text style={[styles.etaCountdown, { transform: [{ scale: countdownAnim }] }]}>
              {formatTime(etaCountdown)}
            </Animated.Text>
          </View>

          <TouchableOpacity 
            style={styles.trackButton}
            onPress={() => router.push('/priority-wash-tracking')}
          >
            <Text style={styles.trackButtonText}>Live GPS Tracking</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Priority Wash</Text>
          <TouchableOpacity onPress={() => router.push('/owner-dashboard')} style={styles.dashboardButton}>
            <Text style={styles.dashboardButtonText}>🏠</Text>
          </TouchableOpacity>
        </View>

        {/* Step Progress Bar */}
        <View style={styles.stepProgressContainer}>
          <View style={styles.stepProgressBar}>
            {Array.from({ length: totalSteps }, (_, index) => (
              <View key={index} style={styles.stepProgressItem}>
                <View style={[
                  styles.stepProgressDot,
                  currentStep > index + 1 && styles.stepProgressDotCompleted,
                  currentStep === index + 1 && styles.stepProgressDotActive
                ]}>
                  <Text style={[
                    styles.stepProgressNumber,
                    currentStep > index + 1 && styles.stepProgressNumberCompleted,
                    currentStep === index + 1 && styles.stepProgressNumberActive
                  ]}>
                    {currentStep > index + 1 ? '✓' : index + 1}
                  </Text>
                </View>
                {index < totalSteps - 1 && (
                  <View style={[
                    styles.stepProgressLine,
                    currentStep > index + 1 && styles.stepProgressLineCompleted
                  ]} />
                )}
              </View>
            ))}
          </View>
          <Text style={styles.stepTitle}>
            {currentStep === 1 && 'Step 1: Choose Location'}
            {currentStep === 2 && 'Step 2: Select Vehicle Type'}
            {currentStep === 3 && 'Step 3: Pick Service'}
            {currentStep === 4 && 'Step 4: Confirm & Book'}
          </Text>
        </View>

        {/* Step Content */}
        <View style={styles.stepContent}>
          {/* Step 1: Location Selection */}
          {currentStep === 1 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>🏢 Choose Your Location</Text>
              <Text style={styles.stepSectionSubtitle}>Select from our premium car wash partners</Text>
              
              {isLoading ? (
                <ActivityIndicator size="large" color="#87CEEB" />
              ) : (
                carWashLocations.map((location) => (
                  <TouchableOpacity
                    key={location.id}
                    style={[
                      styles.locationCard,
                      selectedLocation?.id === location.id && styles.selectedLocationCard
                    ]}
                    onPress={() => handleLocationSelect(location)}
                  >
                    <View style={styles.locationHeader}>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName}>{location.name}</Text>
                        <Text style={styles.locationAddress}>{location.address}</Text>
                        <View style={styles.locationRating}>
                          <Text style={styles.ratingText}>⭐ {location.rating} ({location.totalReviews} reviews)</Text>
                        </View>
                      </View>
                      
                      <View style={styles.statusContainer}>
                        <View style={[styles.statusDot, { backgroundColor: getStatusColor(location.status) }]} />
                        <Text style={styles.statusText}>{getStatusText(location.status)}</Text>
                      </View>
                    </View>

                    <View style={styles.locationDetails}>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Current Wait:</Text>
                        <Text style={styles.detailValue}>{location.currentWaitTime} min</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Priority Fee:</Text>
                        <Text style={styles.detailValue}>£{location.priorityPrice}</Text>
                      </View>
                      <View style={styles.detailRow}>
                        <Text style={styles.detailLabel}>Base Price:</Text>
                        <Text style={styles.detailValue}>£{location.basePrice}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))
              )}
            </View>
          )}

          {/* Step 2: Vehicle Type Selection */}
          {currentStep === 2 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>🚗 Select Vehicle Type</Text>
              <Text style={styles.stepSectionSubtitle}>Choose your vehicle category for accurate pricing</Text>
              
              {vehicleTypes.map((vehicleType) => (
                <TouchableOpacity
                  key={vehicleType.id}
                  style={[
                    styles.vehicleTypeCard,
                    selectedVehicleType === vehicleType.id && styles.selectedVehicleTypeCard
                  ]}
                  onPress={() => handleVehicleTypeSelect(vehicleType.id)}
                >
                  <View style={styles.vehicleTypeHeader}>
                    <Text style={styles.vehicleTypeIcon}>{vehicleType.icon}</Text>
                    <View style={styles.vehicleTypeInfo}>
                      <Text style={styles.vehicleTypeName}>{vehicleType.name}</Text>
                      <Text style={styles.vehicleTypeDescription}>{vehicleType.description}</Text>
                    </View>
                    <View style={styles.vehicleTypeMultiplier}>
                      <Text style={styles.multiplierText}>{vehicleType.baseMultiplier}x</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Step 3: Service Type Selection */}
          {currentStep === 3 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>✨ Choose Your Service</Text>
              <Text style={styles.stepSectionSubtitle}>Select the level of service you need</Text>
              
              {serviceTypes.map((serviceType) => (
                <TouchableOpacity
                  key={serviceType.id}
                  style={[
                    styles.serviceTypeCard,
                    selectedServiceType === serviceType.id && styles.selectedServiceTypeCard
                  ]}
                  onPress={() => handleServiceTypeSelect(serviceType.id)}
                >
                  <View style={styles.serviceTypeHeader}>
                    <View style={styles.serviceTypeInfo}>
                      <Text style={styles.serviceTypeName}>{serviceType.name}</Text>
                      <Text style={styles.serviceTypeDescription}>{serviceType.description}</Text>
                      <Text style={styles.serviceTypeDuration}>⏱️ {serviceType.duration}</Text>
                    </View>
                    <View style={styles.serviceTypeMultiplier}>
                      <Text style={styles.multiplierText}>{serviceType.multiplier}x</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          )}

          {/* Step 4: Confirmation and Booking */}
          {currentStep === 4 && (
            <View style={styles.stepSection}>
              <Text style={styles.stepSectionTitle}>📋 Booking Summary</Text>
              <Text style={styles.stepSectionSubtitle}>Review your selections and confirm booking</Text>
              
              {pricing && (
                <View style={styles.bookingSummaryCard}>
                  <View style={styles.summaryHeader}>
                    <Text style={styles.summaryTitle}>Booking Details</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Location:</Text>
                    <Text style={styles.summaryValue}>{selectedLocation?.name}</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Vehicle:</Text>
                    <Text style={styles.summaryValue}>{vehicleTypes.find(vt => vt.id === selectedVehicleType)?.name}</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Service:</Text>
                    <Text style={styles.summaryValue}>{serviceTypes.find(st => st.id === selectedServiceType)?.name}</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Base Price:</Text>
                    <Text style={styles.summaryValue}>£{pricing.basePrice.toFixed(2)}</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Priority Fee:</Text>
                    <Text style={styles.summaryValue}>£{pricing.priorityFee.toFixed(2)}</Text>
                  </View>
                  
                  <View style={[styles.summaryRow, styles.totalRow]}>
                    <Text style={styles.totalLabel}>Total:</Text>
                    <Text style={styles.totalValue}>£{pricing.totalPrice.toFixed(2)}</Text>
                  </View>
                  
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Estimated Wait:</Text>
                    <Text style={styles.summaryValue}>{pricing.estimatedWaitTime} minutes</Text>
                  </View>
                </View>
              )}
              
              <TouchableOpacity
                style={[styles.confirmButton, isLoading && styles.confirmButtonDisabled]}
                onPress={handleBookPriorityWash}
                disabled={isLoading}
              >
                {isLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <Text style={styles.confirmButtonText}>Confirm Booking & Track</Text>
                )}
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
      
      {/* Booking Confirmation Overlay */}
      {renderBookingConfirmation()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  placeholder: {
    width: 60,
  },
  dashboardButton: {
    padding: 6,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dashboardButtonText: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
  },
  etaContainer: {
    margin: 20,
  },
  etaCard: {
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  etaTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 10,
  },
  countdownContainer: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 10,
  },
  countdownText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#87CEEB',
    textAlign: 'center',
  },
  etaSubtitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 15,
  },
  trackButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 8,
    padding: 12,
  },
  trackButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  trackButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#87CEEB',
  },
  section: {
    padding: 20,
    backgroundColor: '#1E293B',
    marginBottom: 10,
    borderRadius: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 16,
    opacity: 0.9,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  locationCard: {
    borderRadius: 12,
    marginBottom: 12,
    overflow: 'hidden',
  },
  selectedLocationCard: {
    borderWidth: 2,
    borderColor: '#FFFFFF',
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
  },
  locationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 12,
    marginBottom: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  locationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  locationAddress: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 4,
    opacity: 0.9,
  },
  locationRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 12,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  locationDetails: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  detailLabel: {
    fontSize: 14,
    color: '#CBD5E1',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  vehicleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
    paddingHorizontal: 4,
  },
  vehicleCard: {
    width: (width - 80) / 2,
    backgroundColor: '#334155',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 120,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  selectedVehicleCard: {
    borderWidth: 3,
    borderColor: '#87CEEB',
    backgroundColor: '#1E293B',
    shadowColor: '#87CEEB',
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  vehicleIcon: {
    fontSize: 40,
    marginBottom: 12,
    textAlign: 'center',
  },
  vehicleName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 6,
    textAlign: 'center',
  },
  vehicleDescription: {
    fontSize: 13,
    color: '#CBD5E1',
    textAlign: 'center',
    lineHeight: 18,
  },
  serviceGrid: {
    gap: 12,
  },
  serviceCard: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  selectedServiceCard: {
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  serviceCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
  },
  serviceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  serviceDescription: {
    fontSize: 14,
    color: '#CBD5E1',
    marginBottom: 4,
  },
  serviceDuration: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  vehicleDetailsForm: {
    gap: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#87CEEB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#334155',
    color: '#F9FAFB',
  },
  photoButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  photoButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  photoButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  photoButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0A1929',
  },
  priorityOptions: {
    gap: 12,
  },
  priorityCard: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  selectedPriorityCard: {
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  priorityCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
  },
  priorityTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  priorityDescription: {
    fontSize: 14,
    color: '#CBD5E1',
  },
  selectedIndicator: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#87CEEB',
    borderRadius: 20,
    width: 28,
    height: 28,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  selectedIcon: {
    color: '#0A1929',
    fontSize: 18,
    fontWeight: 'bold',
  },
  pricingCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
  },
  pricingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  pricingLabel: {
    fontSize: 16,
    color: '#CBD5E1',
  },
  pricingValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  pricingLabelTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  pricingValueTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  pricingDivider: {
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginVertical: 8,
  },
  skipQueueBadge: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  skipQueueText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  bookButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    opacity: 0.5,
  },
  bookButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  vehicleOptionsContainer: {
    marginBottom: 16,
  },
  vehicleOptionButton: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  vehicleOptionIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  vehicleOptionText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  vehicleOptionArrow: {
    fontSize: 16,
    color: '#F9FAFB',
  },
  vehicleOptionsDropdown: {
    backgroundColor: '#1E293B',
    borderRadius: 8,
    marginTop: 4,
    overflow: 'hidden',
  },
  vehicleOptionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135, 206, 235, 0.2)',
  },
  vehicleOptionItemIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  vehicleOptionItemText: {
    flex: 1,
    fontSize: 16,
    color: '#F9FAFB',
  },
  vehicleOptionItemCount: {
    fontSize: 14,
    color: '#87CEEB',
    opacity: 0.7,
  },
  storedVehiclesContainer: {
    marginTop: 16,
  },
  storedVehiclesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 12,
  },
  storedVehicleCard: {
    borderRadius: 12,
    marginBottom: 8,
    overflow: 'hidden',
  },
  selectedStoredVehicleCard: {
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  storedVehicleCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    marginBottom: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  storedVehicleInfo: {
    flex: 1,
  },
  storedVehicleNickname: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  storedVehicleDetails: {
    fontSize: 14,
    color: '#CBD5E1',
  },
  saveVehicleButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  saveVehicleIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  saveVehicleText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0A1929',
  },
  noVehiclesContainer: {
    alignItems: 'center',
    padding: 32,
    backgroundColor: '#1E293B',
    borderRadius: 12,
    marginTop: 16,
  },
  noVehiclesIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  noVehiclesTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 8,
  },
  noVehiclesText: {
    fontSize: 14,
    color: '#CBD5E1',
    textAlign: 'center',
    marginBottom: 20,
    opacity: 0.8,
  },
  vehicleOptionsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  vehicleOptionCard: {
    flex: 1,
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  selectedVehicleOptionCard: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  vehicleOptionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  vehicleOptionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  vehicleOptionSubtitle: {
    fontSize: 12,
    color: '#CBD5E1',
    textAlign: 'center',
  },
  storedVehiclesTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 12,
  },
  storedVehicleCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    marginBottom: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectedStoredVehicleCard: {
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  storedVehicleInfo: {
    flex: 1,
  },
  storedVehicleName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  storedVehicleDetails: {
    fontSize: 14,
    color: '#CBD5E1',
  },
  newVehicleContainer: {
    marginTop: 16,
  },
  newVehicleTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 16,
  },
  inputContainer: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#334155',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#F9FAFB',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  photoButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  photoButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  photoButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0A1929',
  },
  addFirstVehicleButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addFirstVehicleIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  addFirstVehicleText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#0A1929',
  },
  // Step-by-step wizard styles
  stepProgressContainer: {
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  stepProgressBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  stepProgressItem: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  stepProgressDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  stepProgressDotActive: {
    backgroundColor: '#FFFFFF',
    borderColor: '#FFFFFF',
  },
  stepProgressDotCompleted: {
    backgroundColor: '#87CEEB',
    borderColor: '#87CEEB',
  },
  stepProgressNumber: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'rgba(255, 255, 255, 0.7)',
  },
  stepProgressNumberActive: {
    color: '#0A1929',
  },
  stepProgressNumberCompleted: {
    color: '#0A1929',
  },
  stepProgressLine: {
    flex: 1,
    height: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginHorizontal: 8,
  },
  stepProgressLineCompleted: {
    backgroundColor: '#87CEEB',
  },
  stepTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  stepContent: {
    flex: 1,
  },
  stepSection: {
    padding: 20,
  },
  stepSectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  stepSectionSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 24,
    textAlign: 'center',
    opacity: 0.9,
  },
  bookingSummary: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  summaryItemLocation: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  summaryLabel: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  summaryValue: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  summaryValueLocation: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: 'bold',
    marginTop: 4,
    flexWrap: 'wrap',
    flex: 1,
  },
  pricingTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 16,
    textAlign: 'center',
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  navButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    minWidth: 120,
    alignItems: 'center',
  },
  navButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },

  // Success step styles
  successContainer: {
    alignItems: 'center',
    padding: 20,
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#87CEEB',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  successCheckmark: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  successTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  successSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 30,
    textAlign: 'center',
    opacity: 0.9,
  },
  bookingDetails: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  bookingDetailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  bookingDetailItemLocation: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  bookingDetailLabel: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  bookingDetailValue: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  bookingDetailValueLocation: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: 'bold',
    flexWrap: 'wrap',
    flex: 1,
  },
  etaInfo: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 30,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  etaTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 8,
  },
  etaTime: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  etaWait: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  successActions: {
    width: '100%',
    gap: 12,
  },
  trackButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  trackButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  trackButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  dashboardButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  dashboardButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  dashboardButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  newBookingButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  newBookingButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  newBookingButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  confirmationContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  confirmationContent: {
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 30,
    alignItems: 'center',
    width: '80%',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  confirmationTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  confirmationSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 20,
    textAlign: 'center',
    opacity: 0.9,
  },
  confirmationDetails: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    width: '100%',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  confirmationDetail: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 8,
  },
  etaCountdown: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginTop: 10,
  },
  bookingSummaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  summaryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  summaryTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  totalRow: {
    borderBottomWidth: 0,
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  confirmButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  confirmButtonDisabled: {
    opacity: 0.5,
  },
  confirmButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  vehicleTypeCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  selectedVehicleTypeCard: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  vehicleTypeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  vehicleTypeIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  vehicleTypeInfo: {
    flex: 1,
  },
  vehicleTypeName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 2,
  },
  vehicleTypeDescription: {
    fontSize: 13,
    color: '#CBD5E1',
  },
  vehicleTypeMultiplier: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  multiplierText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#87CEEB',
  },
  serviceTypeCard: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
  },
  selectedServiceTypeCard: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  serviceTypeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceTypeInfo: {
    flex: 1,
  },
  serviceTypeName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 2,
  },
  serviceTypeDescription: {
    fontSize: 13,
    color: '#CBD5E1',
    marginBottom: 4,
  },
  serviceTypeDuration: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  serviceTypeMultiplier: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 8,
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
});
