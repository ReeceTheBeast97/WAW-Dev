import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  Alert,
  ScrollView,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import BookingService, { Booking } from '../src/services/BookingService';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface CustomerData {
  customerName: string;
  customerPhoto: string;
  customerRating: number;
  vehicleInfo: string;
  vehicleMake: string;
  vehicleModel: string;
  vehicleColor: string;
  vehiclePlate: string;
  serviceType: string;
  price: number;
  status: 'en_route' | 'arriving' | 'arrived' | 'in_progress' | 'completed';
  customerLocation: {
    latitude: number;
    longitude: number;
    address: string;
  };
  estimatedArrival: string;
  specialInstructions: string;
}

export default function CurrentTrip() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  
  const [customerData, setCustomerData] = useState<CustomerData | null>(null);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const cardSlideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loadBookingData = async () => {
      // Always use mock data for demo purposes
      setCustomerData({
        customerName: 'John Smith',
        customerPhoto: '👤',
        customerRating: 4.8,
        vehicleInfo: 'White BMW 3 Series',
        vehicleMake: 'BMW',
        vehicleModel: '3 Series',
        vehicleColor: 'White',
        vehiclePlate: 'AB12 CDE',
        serviceType: 'Express Wash',
        price: 15.00,
        status: 'en_route',
        customerLocation: {
          latitude: 51.5074,
          longitude: -0.1278,
          address: '123 Oxford Street, London'
        },
        estimatedArrival: '5 min',
        specialInstructions: 'Please be careful with the paintwork'
      });

      // Try to load real booking data if available
      if (bookingId && user) {
        try {
          const bookingData = await BookingService.getBooking(bookingId, user.id);
          if (bookingData) {
            setBooking(bookingData);
            
            // Update customer data with real booking information
            setCustomerData({
              customerName: bookingData.customerName || 'John Smith',
              customerPhoto: bookingData.customerPhoto || '👤',
              customerRating: bookingData.customerRating || 4.8,
              vehicleInfo: bookingData.vehicleInfo || 'White BMW 3 Series',
              vehicleMake: bookingData.vehicleMake || 'BMW',
              vehicleModel: bookingData.vehicleModel || '3 Series',
              vehicleColor: bookingData.vehicleColor || 'White',
              vehiclePlate: bookingData.vehiclePlate || 'AB12 CDE',
              serviceType: bookingData.serviceName,
              price: bookingData.price,
              status: bookingData.status as any,
              customerLocation: {
                latitude: bookingData.location.latitude,
                longitude: bookingData.location.longitude,
                address: bookingData.location.address
              },
              estimatedArrival: bookingData.estimatedArrival || '5 min',
              specialInstructions: bookingData.specialInstructions || 'Please be careful with the paintwork'
            });
          }
        } catch (error) {
          console.error('Error loading booking:', error);
          // Keep using mock data if real data fails to load
        }
      }
    };

    loadBookingData();

    // Start pulse animation
    const startPulse = () => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    };

    startPulse();
  }, []);

  const handleBack = () => {
    router.back();
  };

  const handleCall = async () => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    Alert.alert('Call Customer', `Calling ${customerData?.customerName}...`);
  };

  const handleMessage = async () => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    router.push('/chat-screen');
  };

  const handleExpand = async () => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setIsExpanded(!isExpanded);
    Animated.timing(slideAnim, {
      toValue: isExpanded ? 0 : 1,
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const handleMinimize = async () => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    if (isMinimized) {
      // Bring card back down (extend it)
      setIsMinimized(false);
      Animated.timing(cardSlideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    } else {
      // Minimize the card (but don't let it go off screen)
      setIsMinimized(true);
      Animated.timing(cardSlideAnim, {
        toValue: 1, // Slide up to reveal status button
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  };

  const updateStatus = async (newStatus: string) => {
    if (!customerData) return;

    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }

    // Show confirmation dialog for important status changes
    const showConfirmation = (currentStatus: string, nextStatus: string) => {
      const confirmMessages = {
        'arriving': 'Are you sure you want to mark as arriving?',
        'arrived': 'Have you arrived at the customer location?',
        'in_progress': 'Are you ready to start the wash?',
        'completed': 'Have you completed the wash service?'
      };

      return confirmMessages[nextStatus as keyof typeof confirmMessages] || null;
    };

    const confirmationMessage = showConfirmation(customerData.status, newStatus);
    
    if (confirmationMessage) {
      Alert.alert(
        'Confirm Status Update',
        confirmationMessage,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Confirm',
            onPress: async () => {
              await performStatusUpdate(newStatus);
            }
          }
        ]
      );
    } else {
      await performStatusUpdate(newStatus);
    }
  };

  const performStatusUpdate = async (newStatus: string) => {
    if (!customerData) return;

    setIsUpdatingStatus(true);

    try {
      // Update local state immediately for better UX
      setCustomerData(prev => prev ? { ...prev, status: newStatus as any } : null);

      // Update booking service if we have a real booking
      if (bookingId && user) {
        await BookingService.updateBookingStatus(bookingId, user.id, newStatus);
      }

      // Show success message with appropriate feedback
      const successMessages = {
        'arriving': '🚗 Marked as arriving! Customer notified.',
        'arrived': '📍 Arrived at location! Starting service.',
        'in_progress': '🧽 Wash in progress! Keep up the great work.',
        'completed': '✨ Wash completed! Great job! 🎉'
      };

      const successMessage = successMessages[newStatus as keyof typeof successMessages] || 'Status updated successfully!';

      Alert.alert(
        'Status Updated',
        successMessage,
        [
          {
            text: 'OK',
            onPress: () => {
              // If completed, automatically navigate to wash completion page
              if (newStatus === 'completed') {
                Alert.alert(
                  'Job Complete!',
                  'Great job! Now let\'s complete the wash documentation.',
                  [
                    { 
                      text: 'Complete Wash', 
                      onPress: () => {
                        // Navigate to wash completion with booking details
                        router.push({
                          pathname: '/wash-completion-upload',
                          params: { 
                            bookingId: bookingId || 'mock_booking',
                            customerId: customerData.customerName || 'mock_customer'
                          }
                        });
                      }
                    }
                  ]
                );
              }
            }
          }
        ]
      );

      // Trigger additional animations for completed status
      if (newStatus === 'completed') {
        // Add celebration animation
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.3,
            duration: 200,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 200,
            useNativeDriver: true,
          }),
        ]).start();
      }

    } catch (error) {
      console.error('Error updating status:', error);
      
      // Revert local state if update failed
      setCustomerData(prev => prev ? { ...prev, status: customerData.status } : null);
      
      Alert.alert(
        'Update Failed',
        'Failed to update status. Please try again.',
        [{ text: 'OK' }]
      );
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'en_route': return '#10B981';
      case 'arriving': return '#F59E0B';
      case 'arrived': return '#3B82F6';
      case 'in_progress': return '#8B5CF6';
      case 'completed': return '#059669';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'en_route': return 'On the way!';
      case 'arriving': return 'Nearly there!';
      case 'arrived': return 'Arrived!';
      case 'in_progress': return 'Washing in progress';
      case 'completed': return 'Wash completed!';
      default: return 'On the way!';
    }
  };

  const getNextStatus = (currentStatus: string) => {
    switch (currentStatus) {
      case 'en_route': return 'arriving';
      case 'arriving': return 'arrived';
      case 'arrived': return 'in_progress';
      case 'in_progress': return 'completed';
      case 'completed': return 'completed'; // Stay completed
      default: return 'en_route';
    }
  };

  const canUpdateStatus = (currentStatus: string) => {
    return currentStatus !== 'completed';
  };

  const getNextStatusText = (currentStatus: string) => {
    switch (currentStatus) {
      case 'en_route': return 'Mark as Arriving';
      case 'arriving': return 'Mark as Arrived';
      case 'arrived': return 'Start Washing';
      case 'in_progress': return 'Mark Complete';
      case 'completed': return 'Completed!';
      default: return 'Start Journey';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'en_route': return '🚗';
      case 'arriving': return '📍';
      case 'arrived': return '✅';
      case 'in_progress': return '🧽';
      case 'completed': return '✨';
      default: return '🚗';
    }
  };



  if (!customerData) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading trip details...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Current Trip</Text>
        <View style={styles.headerSpacer} />
      </View>

      {/* Map Section */}
      <View style={styles.mapSection}>
        {/* Map Holder - Replace with Mapbox during testing */}
        <View style={styles.mapHolder}>
          <View style={styles.mapPlaceholder}>
            <Text style={styles.mapPlaceholderIcon}>🗺️</Text>
            <Text style={styles.mapPlaceholderText}>Map with Directions</Text>
            <Text style={styles.mapPlaceholderSubtext}>Replace with Mapbox</Text>
            <Text style={styles.mapPlaceholderSubtext}>Live tracking to customer</Text>
          </View>
        </View>
        
        {/* Map Overlay Controls */}
        <View style={styles.mapOverlay}>
          <TouchableOpacity style={styles.expandButton} onPress={handleExpand}>
            <Text style={styles.expandIcon}>{isExpanded ? '↓' : '↑'}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Customer Card */}
      <Animated.View 
        style={[
          styles.customerCard,
          {
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, -200],
                })
              },
              {
                translateY: cardSlideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, 80], // Slide up just enough to reveal the status button
                })
              }
            ]
          }
        ]}
      >
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          style={styles.customerGradient}
        >
          {/* Status Bar */}
          <View style={styles.statusBar}>
            <Animated.View 
              style={[
                styles.statusIndicator,
                { 
                  backgroundColor: getStatusColor(customerData.status),
                  transform: [{ scale: pulseAnim }]
                }
              ]}
            />
            <Text style={styles.statusText}>{getStatusText(customerData.status)}</Text>
            <Text style={styles.etaText}>ETA: {customerData.estimatedArrival}</Text>
            <TouchableOpacity style={styles.minimizeButton} onPress={handleMinimize}>
              <Text style={styles.minimizeIcon}>{isMinimized ? '⬇️' : '⬆️'}</Text>
            </TouchableOpacity>
          </View>

          {/* Customer Info */}
          <View style={styles.customerSection}>
            <View style={styles.customerInfo}>
              <Text style={styles.customerPhoto}>{customerData.customerPhoto}</Text>
              <View style={styles.customerDetails}>
                <Text style={styles.customerName}>{customerData.customerName}</Text>
                <View style={styles.ratingContainer}>
                  <Text style={styles.ratingText}>⭐ {customerData.customerRating}</Text>
                </View>
                <Text style={styles.serviceInfo}>
                  {customerData.serviceType} • £{customerData.price}
                </Text>
              </View>
            </View>
            
            <View style={styles.actionButtons}>
              <TouchableOpacity style={styles.actionButton} onPress={handleCall}>
                <Text style={styles.actionIcon}>📞</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={handleMessage}>
                <Text style={styles.actionIcon}>💬</Text>
              </TouchableOpacity>
            </View>
                                  </View>

            {/* Vehicle Info */}
            <View style={styles.vehicleSection}>
              <Text style={styles.vehicleTitle}>Vehicle Details</Text>
              <View style={styles.vehicleInfo}>
                <Text style={styles.vehicleText}>
                  {customerData.vehicleColor} {customerData.vehicleMake} {customerData.vehicleModel}
                </Text>
                <Text style={styles.vehiclePlate}>{customerData.vehiclePlate}</Text>
              </View>
            </View>

            {/* Progress Bar */}
            <View style={styles.progressSection}>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill,
                    { 
                      width: `${customerData.status === 'en_route' ? 30 : 
                             customerData.status === 'arriving' ? 60 : 
                             customerData.status === 'arrived' ? 80 : 
                             customerData.status === 'in_progress' ? 90 : 100}%`,
                      backgroundColor: getStatusColor(customerData.status)
                    }
                  ]} 
                />
              </View>
              <View style={styles.progressLabels}>
                <Text style={styles.progressLabel}>On the way</Text>
                <Text style={styles.progressLabel}>Nearly there</Text>
                <Text style={styles.progressLabel}>Washing</Text>
                <Text style={styles.progressLabel}>Complete</Text>
              </View>
            </View>
          </LinearGradient>
              </Animated.View>

        {/* Single Integrated Status Update Button */}
        <View style={styles.statusButtonsContainer}>
          <TouchableOpacity
            style={[
              styles.progressButton,
              { 
                backgroundColor: isUpdatingStatus ? '#6B7280' : 
                  customerData.status === 'completed' ? '#059669' : getStatusColor(getNextStatus(customerData.status)),
                opacity: isUpdatingStatus ? 0.7 : customerData.status === 'completed' ? 0.8 : 1
              }
            ]}
            onPress={() => !isUpdatingStatus && canUpdateStatus(customerData.status) && updateStatus(getNextStatus(customerData.status))}
            activeOpacity={0.8}
            disabled={isUpdatingStatus || customerData.status === 'completed'}
          >
            <Animated.View style={[styles.progressButtonContent, { transform: [{ scale: pulseAnim }] }]}>
              <Text style={styles.progressButtonIcon}>
                {isUpdatingStatus ? '⏳' : getStatusIcon(getNextStatus(customerData.status))}
              </Text>
              <Text style={styles.progressButtonText}>
                {isUpdatingStatus ? 'Updating...' : getNextStatusText(customerData.status)}
              </Text>
            </Animated.View>
          </TouchableOpacity>
          
          {/* Current Status Indicator */}
          <View style={styles.currentStatusIndicator}>
            <Text style={styles.currentStatusText}>
              Current: {getStatusText(customerData.status)}
            </Text>
          </View>
        </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  mapSection: {
    flex: 1,
    position: 'relative',
    marginBottom: 360, // Keep margin for status button and profile card
  },
  mapHolder: {
    flex: 1,
    backgroundColor: '#1E3A8A',
  },
  mapPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
  },
  mapPlaceholderIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  mapPlaceholderText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  mapPlaceholderSubtext: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
  },
  mapOverlay: {
    position: 'absolute',
    top: 20,
    right: 20,
  },
  expandButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  expandIcon: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  customerCard: {
    position: 'absolute',
    bottom: 0, // Use the rest of the bottom space
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
    height: 280, // Increased height to use more bottom space
    zIndex: 2, // Higher z-index to overlap the status button
  },
  customerGradient: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    height: '100%',
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    flex: 1,
  },
  etaText: {
    color: '#E0E7FF',
    fontSize: 14,
  },
  minimizeButton: {
    marginLeft: 'auto',
    padding: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  minimizeIcon: {
    fontSize: 16,
    color: '#FFFFFF',
  },
  customerSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  customerInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  customerPhoto: {
    fontSize: 32,
    marginRight: 8,
  },
  customerDetails: {
    flex: 1,
  },
  customerName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingText: {
    color: '#FCD34D',
    fontSize: 12,
    fontWeight: '500',
  },
  serviceInfo: {
    color: '#E0E7FF',
    fontSize: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionIcon: {
    fontSize: 20,
  },
  vehicleSection: {
    marginBottom: 16,
  },
  vehicleTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  vehicleInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  vehicleText: {
    color: '#E0E7FF',
    fontSize: 14,
    fontWeight: '500',
  },
  vehiclePlate: {
    color: '#FCD34D',
    fontSize: 16,
    fontWeight: 'bold',
  },
  instructionsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
  },
  instructionsTitle: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  instructionsText: {
    color: '#E0E7FF',
    fontSize: 12,
    lineHeight: 16,
  },
  progressSection: {
    marginBottom: 16,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressLabel: {
    color: '#E0E7FF',
    fontSize: 10,
    textAlign: 'center',
    flex: 1,
  },
  statusUpdateSection: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  statusUpdateTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  statusButtonsContainer: {
    position: 'absolute',
    bottom: 280, // Moved up a bit more
    left: 0,
    right: 0,
    height: 60, // Made bigger
    zIndex: 1, // Lower z-index so profile card can overlap
  },
  progressButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 0,
    padding: 0,
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    width: '100%',
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 0,
    elevation: 4,
  },
  progressButtonContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressButtonIcon: {
    fontSize: 18,
    marginBottom: 4,
  },
  progressButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FFFFFF',
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  currentStatusIndicator: {
    position: 'absolute',
    top: -30,
    left: 0,
    right: 0,
    alignItems: 'center',
    paddingVertical: 8,
  },
  currentStatusText: {
    color: '#E0E7FF',
    fontSize: 12,
    fontWeight: '500',
    textAlign: 'center',
  },
});
