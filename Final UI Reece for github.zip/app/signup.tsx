import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  SafeAreaView,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');

// const { width, height } = Dimensions.get('window');

export default function SignupScreen() {
  const { register } = useAuth();
  const [userType, setUserType] = useState<'customer' | 'valeter' | 'organization'>('customer');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const backgroundAnim = useRef(new Animated.Value(0)).current;
  
  // Sea animation values
  const wave1Anim = useRef(new Animated.Value(0)).current;
  const wave2Anim = useRef(new Animated.Value(0)).current;
  const wave3Anim = useRef(new Animated.Value(0)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const rippleAnim = useRef(new Animated.Value(0)).current;
  
  // Sea background colors
  const seaColors = {
    valeter: ['#0C4A6E', '#0B3A5A', '#0A2A46', '#081B32'], // Darker blue for valeter
    customer: ['#0A1929', '#1E3A8A', '#1E40AF', '#1E293B'],
    organization: ['#1E3A8A', '#0F172A', '#0C4A6E', '#1E40AF'] // Professional blue for organizations
  };

  // Only reset form if user explicitly wants to start over
  // This preserves user input when navigating away and coming back

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(backgroundAnim, {
        toValue: 1,
        duration: 1500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Start sea animations
  useEffect(() => {
    // Wave animations
    const wave1Loop = Animated.loop(
      Animated.timing(wave1Anim, {
        toValue: 1,
        duration: 8000,
        useNativeDriver: true,
      })
    );
    
    const wave2Loop = Animated.loop(
      Animated.timing(wave2Anim, {
        toValue: 1,
        duration: 10000,
        useNativeDriver: true,
      })
    );
    
    const wave3Loop = Animated.loop(
      Animated.timing(wave3Anim, {
        toValue: 1,
        duration: 12000,
        useNativeDriver: true,
      })
    );
    
    // Bubble animation
    const bubbleLoop = Animated.loop(
      Animated.timing(bubbleAnim, {
        toValue: 1,
        duration: 6000,
        useNativeDriver: true,
      })
    );
    
    // Ripple animation
    const rippleLoop = Animated.loop(
      Animated.timing(rippleAnim, {
        toValue: 1,
        duration: 4000,
        useNativeDriver: true,
      })
    );
    
    wave1Loop.start();
    wave2Loop.start();
    wave3Loop.start();
    bubbleLoop.start();
    rippleLoop.start();
    
    return () => {
      wave1Loop.stop();
      wave2Loop.stop();
      wave3Loop.stop();
      bubbleLoop.stop();
      rippleLoop.stop();
    };
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      password: '',
    });
    setIsLoading(false);
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      Alert.alert('Error', 'Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const userData = {
        email: formData.email,
        name: formData.name,
        userType: userType,
        password: formData.password,
      };
      
      const success = await register(userData);
      
      if (success) {
        resetForm();
        Alert.alert(
          'Success!',
          'Account created successfully! Please check your email for verification.',
          [
            {
              text: 'OK',
              onPress: () => router.replace('/login')
            }
          ]
        );
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (error: any) {
      console.error('Signup error:', error);
      
      // Show user-friendly error message
      setError(error.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Removed duplicate handleSignup function



  // Removed old step functions - now using single form

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView 
        style={styles.keyboardAvoidingView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <LinearGradient
          colors={userType === 'valeter' ? seaColors.valeter : 
                  userType === 'organization' ? seaColors.organization : 
                  seaColors.customer}
          style={styles.container}
        >
        {/* Sea Background Animations */}
        <View style={styles.seaBackground}>
          {/* Animated Waves */}
          <Animated.View
            style={[
              styles.wave,
              styles.wave1,
              {
                transform: [
                  {
                    translateX: wave1Anim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [-100, 100],
                    }),
                  },
                ],
                opacity: wave1Anim.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0.3, 0.6, 0.3],
                }),
              },
            ]}
          />
          <Animated.View
            style={[
              styles.wave,
              styles.wave2,
              {
                transform: [
                  {
                    translateX: wave2Anim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [100, -100],
                    }),
                  },
                ],
                opacity: wave2Anim.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0.2, 0.5, 0.2],
                }),
              },
            ]}
          />
          <Animated.View
            style={[
              styles.wave,
              styles.wave3,
              {
                transform: [
                  {
                    translateX: wave3Anim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [-50, 150],
                    }),
                  },
                ],
                opacity: wave3Anim.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0.1, 0.4, 0.1],
                }),
              },
            ]}
          />

          {/* Floating Bubbles */}
          <Animated.View
            style={[
              styles.seaBubble,
              styles.bubble1,
              {
                transform: [
                  {
                    translateY: bubbleAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [height, -100],
                    }),
                  },
                ],
                opacity: bubbleAnim.interpolate({
                  inputRange: [0, 0.1, 0.9, 1],
                  outputRange: [0, 0.6, 0.6, 0],
                }),
              },
            ]}
          />
          <Animated.View
            style={[
              styles.seaBubble,
              styles.bubble2,
              {
                transform: [
                  {
                    translateY: bubbleAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [height, -100],
                    }),
                  },
                ],
                opacity: bubbleAnim.interpolate({
                  inputRange: [0, 0.1, 0.9, 1],
                  outputRange: [0, 0.4, 0.4, 0],
                }),
              },
            ]}
          />

          {/* Ripple Effect */}
          <Animated.View
            style={[
              styles.ripple,
              {
                transform: [
                  {
                    scale: rippleAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, 2],
                    }),
                  },
                ],
                opacity: rippleAnim.interpolate({
                  inputRange: [0, 0.5, 1],
                  outputRange: [0.8, 0.4, 0],
                }),
              },
            ]}
          />
                  </View>

          <ScrollView 
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Logo Section */}
            <View style={styles.logoContainer}>
              <View style={styles.titleBubble}>
                <View style={styles.titleContainer}>
                  <Text style={styles.titleWish}>Wish</Text>
                  <Text style={styles.titleA}> a </Text>
                  <Text style={styles.titleWash}>Wash</Text>
                  <Text style={styles.spongeAtEnd}>🧽</Text>
                </View>
              </View>
              <Text style={styles.sloganText}>Your Wish Our Wash 🚿</Text>
            </View>

            {/* User Type Selection */}
            <View style={styles.userTypeContainer}>
              <TouchableOpacity
                style={[
                  styles.userTypeButton,
                  userType === 'customer' && styles.userTypeButtonActive
                ]}
                onPress={() => {
                  setUserType('customer');
                  hapticFeedback('light');
                }}
              >
                <Text style={styles.userTypeIcon}>🚗</Text>
                <Text style={[
                  styles.userTypeText,
                  userType === 'customer' && styles.userTypeTextActive
                ]}>
                  Customer
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.userTypeButton,
                  userType === 'valeter' && styles.userTypeButtonActive
                ]}
                onPress={() => {
                  setUserType('valeter');
                  hapticFeedback('light');
                }}
              >
                <Text style={styles.userTypeIcon}>🧽</Text>
                <Text style={[
                  styles.userTypeText,
                  userType === 'valeter' && styles.userTypeTextActive
                ]}>
                  Valeter
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.userTypeButton,
                  userType === 'organization' && styles.userTypeButtonOrganization
                ]}
                onPress={() => {
                  setUserType('organization');
                  hapticFeedback('light');
                }}
              >
                <Text style={styles.userTypeIcon}>🏢</Text>
                <Text style={[
                  styles.userTypeText,
                  userType === 'organization' && styles.userTypeTextActive
                ]}>
                  Business
                </Text>
              </TouchableOpacity>
            </View>

            {/* Signup Form */}
            <View style={styles.formContainer}>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>
                  {userType === 'organization' ? 'Company Name' : 'Full Name'}
                </Text>
                <TextInput
                  style={styles.input}
                  placeholder={userType === 'organization' ? "Enter your company name" : "Enter your full name"}
                  placeholderTextColor="#87CEEB"
                  value={formData.name}
                  onChangeText={(value) => updateFormData('name', value)}
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Email Address</Text>
                <TextInput
                  style={styles.input}
                  placeholder="your@email.com"
                  placeholderTextColor="#87CEEB"
                  value={formData.email}
                  onChangeText={(value) => updateFormData('email', value)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Create a password (min 6 characters)"
                  placeholderTextColor="#87CEEB"
                  value={formData.password}
                  onChangeText={(value) => updateFormData('password', value)}
                  secureTextEntry
                />
              </View>

              {/* OAuth Placeholder for future implementation */}
              <View style={styles.oauthContainer}>
                <Text style={styles.oauthText}>Coming Soon: Sign up with Google, Apple, or Facebook</Text>
              </View>

              {/* Terms and Conditions */}
              <View style={styles.termsContainer}>
                <Text style={styles.termsText}>
                  By creating an account, you agree to our{' '}
                  <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </View>

              {/* Error Display */}
              {error && (
                <View style={styles.errorContainer}>
                  <Text style={styles.errorText}>⚠️ {error}</Text>
                </View>
              )}

              {/* Signup Button */}
              <TouchableOpacity
                style={[styles.primaryButton, isLoading && styles.primaryButtonDisabled]}
                onPress={handleSignup}
                disabled={isLoading}
              >
                <Text style={styles.primaryButtonText}>
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Text>
              </TouchableOpacity>

              {/* Login Link */}
              <View style={styles.loginContainer}>
                <Text style={styles.loginText}>Already have an account? </Text>
                <TouchableOpacity onPress={() => router.replace('/login')}>
                  <Text style={styles.loginLink}>Sign In</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
    </LinearGradient>
    </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  container: {
    flex: 1,
  },
  seaBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    overflow: 'hidden',
  },
  wave: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  wave1: {
    top: '20%',
    left: '10%',
  },
  wave2: {
    top: '60%',
    right: '15%',
  },
  wave3: {
    bottom: '30%',
    left: '20%',
  },
  seaBubble: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  bubble1: {
    left: '20%',
  },
  bubble2: {
    right: '25%',
  },
  ripple: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    top: '50%',
    left: '50%',
    marginLeft: -50,
    marginTop: -50,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 40,
  },
  userTypeContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    padding: 4,
    marginBottom: 32,
  },
  userTypeButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 10,
  },
  userTypeButtonActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
  },
  userTypeButtonOrganization: {
    backgroundColor: '#6B7280',
    paddingVertical: 20,
    paddingHorizontal: 24,
    borderRadius: 12,
  },
  userTypeIcon: {
    fontSize: 28,
    marginBottom: 6,
  },
  userTypeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
    flexWrap: 'nowrap',
  },
  userTypeTextActive: {
    color: '#0A1929',
  },
  floatingElement: {
    position: 'absolute',
    borderRadius: 50,
    opacity: 0.15,
  },
  element1: {
    width: 100,
    height: 100,
    top: '20%',
    left: '10%',
    backgroundColor: '#87CEEB',
  },
  element2: {
    width: 150,
    height: 150,
    top: '60%',
    right: '15%',
    backgroundColor: '#4682B4',
  },
  element3: {
    width: 80,
    height: 80,
    bottom: '20%',
    left: '20%',
    backgroundColor: '#00BFFF',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  backButton: {
    // marginBottom: 20, // removed since it's now in headerTopRow
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  startOverButton: {
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FF3B30',
  },
  startOverButtonText: {
    color: '#FF3B30',
    fontSize: 14,
    fontWeight: '600',
  },
  headerContent: {
    alignItems: 'center',
    marginBottom: 20,
  },
  formContainer: {
    paddingHorizontal: 20,
  },
  formContainer: {
    marginBottom: 20,
  },
  formTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
  },
  formSubtitle: {
    fontSize: 16,
    color: '#B0E0E6',
    textAlign: 'center',
    marginBottom: 30,
  },
  section: {
    marginBottom: 25,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 15,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 14,
    color: '#FFFFFF',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  inputRow: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  bubbleContainer: {
    marginRight: 15,
  },
  soapBubble: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  spongeInBubble: {
    fontSize: 32,
  },
  bubbleShine: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  shineText: {
    fontSize: 14,
  },
  wawContainer: {
    alignItems: 'flex-start',
  },
  wawText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 4,
  },
  titleBubble: {
    backgroundColor: 'rgba(128, 128, 128, 0.3)',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleWish: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929', // Navy blue
    textShadowColor: 'rgba(255, 255, 255, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  titleA: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF', // White
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  titleWash: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0EA5E9', // Sky blue
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  spongeAtEnd: {
    fontSize: 32,
    marginLeft: 8,
    textShadowColor: 'rgba(0, 0, 0, 1)',
    textShadowOffset: { width: 3, height: 3 },
    textShadowRadius: 6,
  },
  sloganText: {
    fontSize: 14,
    color: '#FFFFFF',
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 8,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subtitle: {
    fontSize: 18,
    color: '#B0E0E6',
    fontWeight: '500',
  },
  // Removed progress bar styles
  toggleContainer: {
    flexDirection: 'row',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 25,
    padding: 4,
    marginHorizontal: 20,
    marginBottom: 20,
  },
  toggleButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 21,
    alignItems: 'center',
  },
  activeToggle: {
    backgroundColor: '#87CEEB',
  },
  toggleText: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
  },
  activeToggleText: {
    color: '#0A1929',
  },
  scrollContainer: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  // Removed old step styles
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 8,
    fontWeight: '600',
  },
  input: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 14,
    color: '#fff',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  phoneInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
    paddingHorizontal: 16,
    paddingVertical: 15,
  },
  countryCode: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
    marginRight: 8,
  },
  phoneInput: {
    flex: 1,
    fontSize: 14,
    color: '#fff',
  },
  emailInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
    paddingHorizontal: 16,
    paddingVertical: 15,
  },
  emailInput: {
    flex: 1,
    fontSize: 14,
    color: '#fff',
  },
  verifiedBadge: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  verifiedIcon: {
    fontSize: 14,
    color: '#fff',
    fontWeight: 'bold',
  },
  verifyButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignItems: 'center',
    marginTop: 8,
  },
  verifyButtonText: {
    fontSize: 14,
    color: '#fff',
    fontWeight: '600',
  },
  passwordTips: {
    marginTop: 10,
  },
  passwordTipText: {
    color: '#B0E0E6',
    fontSize: 14,
    fontStyle: 'italic',
  },
  termsContainer: {
    marginTop: 20,
    padding: 15,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
  },
  termsText: {
    color: '#B0E0E6',
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  termsLink: {
    color: '#87CEEB',
    textDecorationLine: 'underline',
  },
  oauthContainer: {
    marginTop: 20,
    padding: 15,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
    borderStyle: 'dashed',
  },
  oauthText: {
    color: '#B0E0E6',
    fontSize: 14,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  buttonContainer: {
    flexDirection: 'row',
    gap: 15,
    marginTop: 20,
  },
  primaryButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 30,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  primaryButtonDisabled: {
    opacity: 0.7,
  },
  primaryButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: 'transparent',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  secondaryButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#87CEEB',
  },
  loginContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
  },
  loginText: {
    color: '#B0E0E6',
    fontSize: 16,
  },
  loginLink: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },
  errorContainer: {
    backgroundColor: 'rgba(255, 59, 48, 0.1)',
    borderWidth: 1,
    borderColor: '#FF3B30',
    borderRadius: 8,
    padding: 12,
    marginBottom: 15,
  },
  errorText: {
    color: '#FF3B30',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '500',
  },
});
