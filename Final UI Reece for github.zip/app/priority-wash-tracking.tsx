import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ScrollView,
  Dimensions,
  Linking,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { priorityWashService, PriorityWashBooking, CarWashLocation } from '../src/services/PriorityWashService';
import { LinearGradient } from 'expo-linear-gradient';
import LoadingScreen from '../src/components/LoadingScreen';

const { width } = Dimensions.get('window');

export default function PriorityWashTracking() {
  const router = useRouter();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  
  const [booking, setBooking] = useState<PriorityWashBooking | null>(null);
  const [location, setLocation] = useState<CarWashLocation | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [etaCountdown, setEtaCountdown] = useState<number>(0);
  const [currentWaitTime, setCurrentWaitTime] = useState<number>(0);

  useEffect(() => {
    loadBookingData();
  }, [bookingId]);

  useEffect(() => {
    if (booking) {
      startEtaCountdown();
      startWaitTimeUpdate();
    }
  }, [booking]);

  const loadBookingData = () => {
    if (!bookingId) {
      // If no specific booking, load the most recent one
      const userBookings = priorityWashService.getUserPriorityBookings(user?.id || '');
      if (userBookings.length > 0) {
        const latestBooking = userBookings[0];
        setBooking(latestBooking);
        const carWashLocation = priorityWashService.getCarWashLocation(latestBooking.carWashId);
        setLocation(carWashLocation || null);
      }
    } else {
      const specificBooking = priorityWashService.getPriorityBooking(bookingId);
      if (specificBooking) {
        setBooking(specificBooking);
        const carWashLocation = priorityWashService.getCarWashLocation(specificBooking.carWashId);
        setLocation(carWashLocation || null);
      }
    }
    setIsLoading(false);
  };

  const startEtaCountdown = () => {
    if (!booking) return;
    
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const arrivalTime = booking.estimatedArrivalTime.getTime();
      const timeLeft = Math.max(0, Math.floor((arrivalTime - now) / 1000));
      
      setEtaCountdown(timeLeft);
      
      if (timeLeft === 0) {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  };

  const startWaitTimeUpdate = () => {
    if (!location) return;
    
    const interval = setInterval(() => {
      // Simulate real-time wait time updates
      const newWaitTime = Math.max(0, location.currentWaitTime - Math.floor(Math.random() * 2));
      setCurrentWaitTime(newWaitTime);
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  };

  const formatCountdown = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  const handleGetDirections = () => {
    if (!location) return;
    
    const url = `https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`;
    Linking.openURL(url);
  };

  const handleCallCarWash = () => {
    if (!location) return;
    
    Alert.alert(
      'Call Car Wash',
      `Call ${location.name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call', onPress: () => {
          Linking.openURL(`tel:${location.phone}`);
        }}
      ]
    );
  };

  const handleChangeToStandard = () => {
    if (!booking || !location) return;
    
    Alert.alert(
      'Change to Standard Booking',
      `The car wash is currently not busy. You can save £${booking.priorityFee} by switching to standard booking. Would you like to change?`,
      [
        { text: 'Keep Priority', style: 'cancel' },
        { 
          text: 'Switch to Standard', 
          onPress: () => {
            // Update booking to standard
            const updatedBooking = { ...booking };
            updatedBooking.priorityLevel = 'standard';
            updatedBooking.totalPrice = updatedBooking.basePrice;
            updatedBooking.priorityFee = 0;
            updatedBooking.estimatedWaitTime = location.estimatedWaitTime;
            
            priorityWashService.updateBookingStatus(booking.id, 'confirmed');
            setBooking(updatedBooking);
            
            Alert.alert(
              'Booking Updated',
              `You've saved £${booking.priorityFee}! Your booking is now standard.`
            );
          }
        }
      ]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return '#FF9800';
      case 'confirmed': return '#2196F3';
      case 'in_progress': return '#4CAF50';
      case 'completed': return '#4CAF50';
      case 'cancelled': return '#F44336';
      default: return '#9E9E9E';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return '⏳ Pending Confirmation';
      case 'confirmed': return '✅ Confirmed';
      case 'in_progress': return '🚗 In Progress';
      case 'completed': return '✨ Completed';
      case 'cancelled': return '❌ Cancelled';
      default: return '❓ Unknown';
    }
  };

  const getServiceTypeText = (serviceType: string) => {
    switch (serviceType) {
      case 'exterior_only': return 'Exterior Only';
      case 'standard': return 'Standard Wash';
      case 'premium': return 'Premium Wash';
      case 'luxury': return 'Luxury Detail';
      default: return serviceType.replace('_', ' ');
    }
  };

  if (isLoading) {
    return <LoadingScreen message="Loading your booking..." />;
  }

  if (!booking || !location) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>No active booking found</Text>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Priority Wash Tracking</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Organization Profile Card */}
        <View style={styles.organizationCard}>
          <View style={styles.organizationHeader}>
            <View style={styles.organizationInfo}>
              <Text style={styles.organizationName}>{location.organization}</Text>
              <Text style={styles.organizationRating}>⭐ {location.rating} ({location.totalReviews} reviews)</Text>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: getStatusColor(booking.status) }]}>
              <Text style={styles.statusText}>{getStatusText(booking.status)}</Text>
            </View>
          </View>
          
          <View style={styles.organizationDetails}>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>📍 Address:</Text>
              <Text style={styles.detailValue}>{location.address}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>📞 Phone:</Text>
              <Text style={styles.detailValue}>{location.phone}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>🕒 Hours:</Text>
              <Text style={styles.detailValue}>{location.operatingHours.open} - {location.operatingHours.close}</Text>
            </View>
          </View>
        </View>

        {/* Service Type Card */}
        <View style={styles.serviceCard}>
          <Text style={styles.serviceCardTitle}>✨ Service Details</Text>
          <View style={styles.serviceInfo}>
            <Text style={styles.serviceType}>{getServiceTypeText(booking.serviceType)}</Text>
            <Text style={styles.serviceDescription}>
              {booking.serviceType === 'exterior_only' && 'Exterior wash only'}
              {booking.serviceType === 'standard' && 'Exterior and interior clean'}
              {booking.serviceType === 'premium' && 'Deep clean with wax and polish'}
              {booking.serviceType === 'luxury' && 'Full detail and protection treatment'}
            </Text>
          </View>
        </View>

        {/* Vehicle Details */}
        <View style={styles.vehicleCard}>
          <Text style={styles.vehicleCardTitle}>🚗 Vehicle Information</Text>
          <View style={styles.vehicleInfo}>
            <Text style={styles.vehicleDetails}>
              {booking.vehicleDetails.make} {booking.vehicleDetails.model}
            </Text>
            <Text style={styles.vehicleRegistration}>{booking.vehicleDetails.registration}</Text>
          </View>
        </View>

        {/* ETA and Wait Time */}
        <View style={styles.etaCard}>
          <Text style={styles.etaCardTitle}>⏰ Estimated Arrival</Text>
          <Text style={styles.etaTime}>{formatCountdown(etaCountdown)}</Text>
          <Text style={styles.etaSubtitle}>
            Arrival: {booking.estimatedArrivalTime.toLocaleTimeString()}
          </Text>
          <Text style={styles.waitTime}>
            Current wait: {currentWaitTime} minutes
          </Text>
        </View>

        {/* Priority Level with Change Option */}
        <View style={styles.priorityCard}>
          <View style={styles.priorityHeader}>
            <Text style={styles.priorityTitle}>
              {booking.priorityLevel === 'priority' ? '🚀 Premium Priority' : '📋 Standard Queue'}
            </Text>
            <Text style={styles.priorityPrice}>
              {booking.priorityLevel === 'priority' ? `+£${booking.priorityFee}` : 'No extra fee'}
            </Text>
          </View>
          
          {booking.priorityLevel === 'priority' && currentWaitTime < 10 && (
            <TouchableOpacity 
              style={styles.changeToStandardButton}
              onPress={handleChangeToStandard}
            >
              <Text style={styles.changeToStandardText}>
                💡 Car wash not busy - Switch to Standard to save £{booking.priorityFee}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleGetDirections}
          >
            <Text style={styles.actionButtonIcon}>🗺️</Text>
            <Text style={styles.actionButtonText}>Get Directions</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleCallCarWash}
          >
            <Text style={styles.actionButtonIcon}>📞</Text>
            <Text style={styles.actionButtonText}>Call Car Wash</Text>
          </TouchableOpacity>
        </View>

        {/* Booking Summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>💰 Booking Summary</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Base Price:</Text>
            <Text style={styles.summaryValue}>£{booking.basePrice}</Text>
          </View>
          {booking.priorityLevel === 'priority' && (
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Priority Fee:</Text>
              <Text style={styles.summaryValue}>£{booking.priorityFee}</Text>
            </View>
          )}
          <View style={styles.summaryDivider} />
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabelTotal}>Total:</Text>
            <Text style={styles.summaryValueTotal}>£{booking.totalPrice}</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 60,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 16,
    marginTop: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginBottom: 20,
  },
  organizationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  organizationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  organizationInfo: {
    flex: 1,
  },
  organizationName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  organizationRating: {
    fontSize: 14,
    color: '#87CEEB',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  organizationDetails: {
    gap: 8,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  detailLabel: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '600',
    width: 80,
  },
  detailValue: {
    fontSize: 14,
    color: '#FFFFFF',
    flex: 1,
  },
  serviceCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  serviceCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  serviceInfo: {
    alignItems: 'center',
  },
  serviceType: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 8,
  },
  serviceDescription: {
    fontSize: 14,
    color: '#FFFFFF',
    textAlign: 'center',
    opacity: 0.8,
  },
  vehicleCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  vehicleCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  vehicleInfo: {
    alignItems: 'center',
  },
  vehicleDetails: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  vehicleRegistration: {
    fontSize: 16,
    color: '#87CEEB',
  },
  etaCard: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  etaCardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 12,
  },
  etaTime: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  etaSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 4,
  },
  waitTime: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.8,
  },
  priorityCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  priorityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  priorityTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  priorityPrice: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
  },
  changeToStandardButton: {
    backgroundColor: 'rgba(255, 193, 7, 0.2)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#FFC107',
  },
  changeToStandardText: {
    fontSize: 14,
    color: '#FFC107',
    textAlign: 'center',
    fontWeight: '600',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  summaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 16,
    textAlign: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 16,
    color: '#FFFFFF',
  },
  summaryValue: {
    fontSize: 16,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  summaryDivider: {
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    marginVertical: 12,
  },
  summaryLabelTotal: {
    fontSize: 18,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  summaryValueTotal: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
  },
});
