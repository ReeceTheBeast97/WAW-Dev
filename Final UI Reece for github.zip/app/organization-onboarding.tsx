import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';

export default function OrganizationOnboarding() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const steps = [
    {
      title: "Welcome to Wish a Wash Business! 🏢✨",
      subtitle: "Your journey to building a successful valeting team starts here",
      description: "You're now part of our business network. Manage your team, grow your operations, and deliver exceptional service.",
      icon: "🌟"
    },
    {
      title: "Team Management Made Simple 👥",
      subtitle: "Manage your valeters efficiently",
      description: "Add team members, track their performance, and ensure all documentation is complete.",
      icon: "👥"
    },
    {
      title: "Business Growth & Analytics 📊",
      subtitle: "Track performance and grow your business",
      description: "Monitor team performance, track revenue, and access detailed analytics to scale your operations.",
      icon: "📊"
    },
    {
      title: "You're Ready to Scale! 🚀",
      subtitle: "Your business journey awaits",
      description: "Your business account is set up and ready! Start building your team and growing your valeting business.",
      icon: "🚀"
    }
  ];

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  const completeOnboarding = async () => {
    try {
      // Mark organization onboarding as seen
      await AsyncStorage.setItem('organization_onboarding_seen', 'true');
      router.replace('/organization-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      router.replace('/organization-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const skipOnboarding = () => {
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      <View style={styles.header}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
        
        <View style={styles.progressContainer}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentStep && styles.progressDotActive,
                index < currentStep && styles.progressDotCompleted
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
      </View>

      <View style={styles.content}>
        <Animated.View style={[styles.stepContainer, { opacity: fadeAnim }]}>
          <View style={styles.iconContainer}>
            <Text style={styles.stepIcon}>{currentStepData.icon}</Text>
          </View>

          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStepData.subtitle}</Text>
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

          {currentStep === 0 && (
            <View style={styles.welcomeCard}>
              <Text style={styles.welcomeText}>
                Hello, {user?.name || 'Business Owner'}! 👋
              </Text>
              <Text style={styles.welcomeSubtext}>
                Welcome to the most trusted business platform for valeting services.
              </Text>
            </View>
          )}

          {currentStep === 1 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Team Management Features:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>➕</Text>
                <Text style={styles.featureText}>Add team members easily</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📋</Text>
                <Text style={styles.featureText}>Track documentation status</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>👀</Text>
                <Text style={styles.featureText}>Monitor team performance</Text>
              </View>
            </View>
          )}

          {currentStep === 2 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Business Analytics:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📈</Text>
                <Text style={styles.featureText}>Revenue tracking</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>👥</Text>
                <Text style={styles.featureText}>Team performance metrics</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⭐</Text>
                <Text style={styles.featureText}>Customer satisfaction scores</Text>
              </View>
            </View>
          )}

          {currentStep === 3 && (
            <View style={styles.finalCard}>
              <Text style={styles.finalTitle}>Ready to Build Your Team?</Text>
              <Text style={styles.finalText}>
                Your business platform is ready! Start adding team members and growing your valeting business.
              </Text>
            </View>
          )}
        </Animated.View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity style={styles.nextButton} onPress={nextStep}>
          <Text style={styles.nextButtonText}>
            {currentStep === steps.length - 1 ? 'Start Building' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  skipText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: '#FFFFFF',
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  progressDotCompleted: {
    backgroundColor: '#10B981',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  stepContainer: {
    alignItems: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  stepIcon: {
    fontSize: 60,
  },
  stepTitle: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 36,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 24,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 40,
    opacity: 0.9,
  },
  welcomeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  welcomeText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  welcomeSubtext: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    width: '100%',
  },
  featureTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  featureText: {
    color: '#FFFFFF',
    fontSize: 16,
    flex: 1,
  },
  finalCard: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  finalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  finalText: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  footer: {
    paddingHorizontal: 30,
    paddingBottom: 60,
  },
  nextButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
