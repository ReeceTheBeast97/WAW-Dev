import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  userType: 'customer' | 'valeter';
  isEmailVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
  // Valeter specific fields
  isVerified?: boolean;
  documentsUploaded?: boolean;
  insuranceVerified?: boolean;
  licenseVerified?: boolean;
  backgroundCheckPassed?: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'isEmailVerified' | 'createdAt' | 'updatedAt'> & { password: string }) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user database for simulation
const mockUsers: User[] = [
  {
    id: 'customer_1',
    email: 'customer@test.com',
    name: 'John Customer',
    phone: '+44 7700 900001',
    userType: 'customer',
    isEmailVerified: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'valeter_1',
    email: 'valeter@test.com',
    name: 'Mike Valeter',
    phone: '+44 7700 900123',
    userType: 'valeter',
    isEmailVerified: true,
    isVerified: true,
    documentsUploaded: true,
    insuranceVerified: true,
    licenseVerified: true,
    backgroundCheckPassed: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  // Auto-login test users
  {
    id: 'auto_customer',
    email: 'auto@customer.com',
    name: 'Auto Customer',
    phone: '+44 7700 900999',
    userType: 'customer',
    isEmailVerified: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'auto_valeter',
    email: 'auto@valeter.com',
    name: 'Auto Valeter',
    phone: '+44 7700 900888',
    userType: 'valeter',
    isEmailVerified: true,
    isVerified: true,
    documentsUploaded: true,
    insuranceVerified: true,
    licenseVerified: true,
    backgroundCheckPassed: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
         // Special admin access users
       {
         id: 'admin_user_1',
         email: 'admin@wishawash.com',
         name: 'Admin User',
         phone: '+44 7700 900000',
         userType: 'customer',
         isEmailVerified: true,
         createdAt: new Date(),
         updatedAt: new Date(),
       },
       {
         id: 'charlie_admin',
         email: 'charlie@wishawash.com',
         name: 'Charlie Blunders',
         phone: '+44 7700 900002',
         userType: 'customer',
         isEmailVerified: true,
         createdAt: new Date(),
         updatedAt: new Date(),
       },
       // Business owner test account
       {
         id: 'business_owner_1',
         email: 'business@elitevalet.com',
         name: 'Elite Valet Services Ltd',
         phone: '+44 7700 900003',
         userType: 'customer',
         isEmailVerified: true,
         createdAt: new Date(),
         updatedAt: new Date(),
       }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const checkStoredUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem('user_session');
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          setUser(userData);
        }
      } catch (error) {
        console.error('Error checking stored user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkStoredUser();
  }, []);

  const login = async (email: string, _password: string): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find user in mock database
      const foundUser = mockUsers.find(u => u.email === email);
      
      if (foundUser) {
        // In real app, verify password here
        // For now, we ignore the password parameter in mock implementation
        await AsyncStorage.setItem('user_session', JSON.stringify(foundUser));
        setUser(foundUser);
        return true;
      } else {
        return false;
      }
    } catch (error: any) {
      console.error('Login error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      console.log('Logout: Starting logout process...');
      console.log('Logout: Current user before logout:', user);
      
      await AsyncStorage.removeItem('user_session');
      console.log('Logout: AsyncStorage cleared successfully');
      
      setUser(null);
      console.log('Logout: User state set to null');
      
      console.log('Logout: Logout process completed successfully');
    } catch (error) {
      console.error('Logout error:', error);
      throw error; // Re-throw to let calling code handle it
    }
  };

  const register = async (userData: Omit<User, 'id' | 'isEmailVerified' | 'createdAt' | 'updatedAt'> & { password: string }): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Check if user already exists
      const existingUser = mockUsers.find(u => u.email === userData.email);
      if (existingUser) {
        return false; // User already exists
      }
      
      // Create new user
      const newUser: User = {
        id: `${userData.userType}_${Date.now()}`,
        email: userData.email,
        name: userData.name,
        phone: userData.phone,
        userType: userData.userType,
        isEmailVerified: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        // Initialize valeter verification fields
        ...(userData.userType === 'valeter' && {
          isVerified: false,
          documentsUploaded: false,
          insuranceVerified: false,
          licenseVerified: false,
          backgroundCheckPassed: false,
        })
      };
      
      // Add to mock database
      mockUsers.push(newUser);
      
      // Store session
      await AsyncStorage.setItem('user_session', JSON.stringify(newUser));
      setUser(newUser);
      
      return true;
    } catch (error: any) {
      console.error('Registration error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (!user) return;
    
    try {
      const updatedUser = { ...user, ...updates, updatedAt: new Date() };
      
      // Update in mock database
      const userIndex = mockUsers.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        mockUsers[userIndex] = updatedUser;
      }
      
      // Update session
      await AsyncStorage.setItem('user_session', JSON.stringify(updatedUser));
      setUser(updatedUser);
    } catch (error) {
      console.error('Update user error:', error);
    }
  };

  const updatePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    if (!user) throw new Error('No user logged in');
    
    try {
      // Simulate password validation and update
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, you would validate the current password here
      if (currentPassword !== 'password123') { // Mock validation
        throw new Error('Current password is incorrect');
      }
      
      console.log('Password updated successfully');
    } catch (error) {
      console.error('Update password error:', error);
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => {
    return updateUser(updates);
  };

  const resetPassword = async (email: string): Promise<void> => {
    try {
      // Simulate password reset
      await new Promise(resolve => setTimeout(resolve, 1000));
      console.log(`Password reset email sent to ${email}`);
    } catch (error) {
      console.error('Reset password error:', error);
      throw error;
    }
  };

  const autoLoginCustomer = async () => {
    const autoUser = mockUsers.find(u => u.id === 'auto_customer');
    if (autoUser) {
      await AsyncStorage.setItem('user_session', JSON.stringify(autoUser));
      setUser(autoUser);
    }
  };

  const autoLoginValeter = async () => {
    const autoUser = mockUsers.find(u => u.id === 'auto_valeter');
    if (autoUser) {
      await AsyncStorage.setItem('user_session', JSON.stringify(autoUser));
      setUser(autoUser);
    }
  };

  const hasAdminAccess = (): boolean => {
    if (!user) return false;
    
    // Only specific users have admin access
    const adminUserIds = ['admin_user_1', 'charlie_admin'];
    return adminUserIds.includes(user.id);
  };

  const isBusinessOwner = (): boolean => {
    if (!user) return false;
    
    // Business owner accounts
    const businessUserIds = ['business_owner_1'];
    return businessUserIds.includes(user.id);
  };

  const markWelcomeSeen = async (userType: 'customer' | 'valeter'): Promise<void> => {
    try {
      await AsyncStorage.setItem(`welcome_seen_${userType}`, 'true');
    } catch (error) {
      console.log('Error marking welcome as seen:', error);
    }
  };

  const hasSeenWelcome = async (userType: 'customer' | 'valeter'): Promise<boolean> => {
    try {
      const seen = await AsyncStorage.getItem(`welcome_seen_${userType}`);
      return seen === 'true';
    } catch (error) {
      console.log('Error checking welcome status:', error);
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      isLoading,
      login,
      logout,
      register,
      updateUser,
      updatePassword,
      updateProfile,
      resetPassword,
      autoLoginCustomer,
      autoLoginValeter,
      hasAdminAccess,
      isBusinessOwner,
      markWelcomeSeen,
      hasSeenWelcome,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthProvider;