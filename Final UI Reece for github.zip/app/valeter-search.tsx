import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Animated,
  Dimensions,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import BookingService from '../src/services/BookingService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function ValeterSearch() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  
  const pulseAnim = useRef(new Animated.Value(0)).current;
  const searchAnim = useRef(new Animated.Value(0)).current;
  const dotAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Pulse animation
    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1500,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 0,
          duration: 1500,
          useNativeDriver: true,
        }),
      ])
    );

    // Search signal animation (using scaleX for better performance)
    const searchLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(searchAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true, // Can use native driver with scaleX
        }),
        Animated.timing(searchAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true, // Can use native driver with scaleX
        }),
      ])
    );

    // Dot animation
    const dotLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(dotAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(dotAnim, {
          toValue: 0,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );

    pulseLoop.start();
    searchLoop.start();
    dotLoop.start();

    // Simulate finding a valeter after 3-5 seconds
    const searchTime = Math.random() * 2000 + 3000; // 3-5 seconds
    const timer = setTimeout(async () => {
      if (bookingId && user) {
        try {
          // Assign a mock valeter to the booking
          const mockValeter = {
            valeterId: 'valeter_001',
            valeterName: 'Mike Johnson',
            valeterRating: 4.7,
            valeterOrganization: 'Quick Clean Pro',
            valeterPhoto: '👨‍🔧',
          };

          await BookingService.assignValeter(bookingId, user.id, mockValeter);
          console.log('✅ Valeter assigned to booking:', bookingId);

          // Navigate to tracking with booking ID
          router.replace({
            pathname: '/uber-tracking',
            params: { bookingId }
          });
        } catch (error) {
          console.error('Error assigning valeter:', error);
          Alert.alert('Error', 'Failed to assign valeter. Please try again.');
        }
      } else {
        // Fallback if no booking ID
        router.replace('/uber-tracking');
      }
    }, searchTime);

    return () => {
      pulseLoop.stop();
      searchLoop.stop();
      dotLoop.stop();
      clearTimeout(timer);
    };
  }, []);

  const renderSearchSignals = () => {
    const signals = [];
    for (let i = 0; i < 5; i++) {
      const delay = i * 200;
      const signalAnim = useRef(new Animated.Value(0)).current;

      useEffect(() => {
        const signalLoop = Animated.loop(
          Animated.sequence([
            Animated.delay(delay),
            Animated.timing(signalAnim, {
              toValue: 1,
              duration: 1000,
              useNativeDriver: true,
            }),
            Animated.timing(signalAnim, {
              toValue: 0,
              duration: 1000,
              useNativeDriver: true,
            }),
          ])
        );
        signalLoop.start();
        return () => signalLoop.stop();
      }, []);

      signals.push(
        <Animated.View
          key={i}
          style={[
            styles.signalBar,
            {
              opacity: signalAnim,
              transform: [
                {
                  scale: signalAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.3, 1],
                  }),
                },
              ],
            },
          ]}
        />
      );
    }
    return signals;
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={styles.gradient}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Finding Your Valeter</Text>
          <Text style={styles.headerSubtitle}>Searching for available valeters in your area...</Text>
        </View>

        {/* Main Content */}
        <View style={styles.content}>
          {/* Pulse Circle */}
          <Animated.View
            style={[
              styles.pulseCircle,
              {
                transform: [
                  {
                    scale: pulseAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [1, 1.2],
                    }),
                  },
                ],
                opacity: pulseAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.7, 1],
                }),
              },
            ]}
          >
            <View style={styles.innerCircle}>
              <Text style={styles.searchIcon}>🔍</Text>
            </View>
          </Animated.View>

          {/* Search Message */}
          <View style={styles.messageContainer}>
            <Text style={styles.mainMessage}>Finding you a valeter</Text>
            <Animated.View style={styles.dotsContainer}>
              <Animated.Text
                style={[
                  styles.dots,
                  {
                    opacity: dotAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.3, 1],
                    }),
                  },
                ]}
              >
                ...
              </Animated.Text>
            </Animated.View>
          </View>

          {/* Search Signals */}
          <View style={styles.signalsContainer}>
            <Text style={styles.signalsTitle}>Searching nearby valeters</Text>
            <View style={styles.signalsWrapper}>
              {renderSearchSignals()}
            </View>
          </View>

          {/* Status Messages */}
          <View style={styles.statusContainer}>
            <Text style={styles.statusText}>📍 Scanning your area</Text>
            <Text style={styles.statusText}>🚗 Checking vehicle compatibility</Text>
            <Text style={styles.statusText}>⭐ Finding top-rated valeters</Text>
          </View>

          {/* Progress Indicator */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <Animated.View
                style={[
                  styles.progressFill,
                  {
                    transform: [
                      {
                        scaleX: searchAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [0, 1],
                        }),
                      },
                    ],
                  },
                ]}
              />
            </View>
            <Text style={styles.progressText}>Searching...</Text>
          </View>
        </View>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  gradient: {
    flex: 1,
  },
  header: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 14 : 16,
    marginTop: 5,
    textAlign: 'center',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  pulseCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  innerCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchIcon: {
    fontSize: 32,
  },
  messageContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  mainMessage: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  dotsContainer: {
    height: 30,
    justifyContent: 'center',
  },
  dots: {
    color: '#10B981',
    fontSize: 24,
    fontWeight: 'bold',
  },
  signalsContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  signalsTitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 16 : 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  signalsWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 60,
    gap: 8,
  },
  signalBar: {
    width: 8,
    backgroundColor: '#10B981',
    borderRadius: 4,
    height: 40,
  },
  statusContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  statusText: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  progressContainer: {
    alignItems: 'center',
    width: '100%',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginBottom: 12,
    overflow: 'hidden',
  },
  progressFill: {
    width: '100%', // Fixed width, will be scaled by transform
    height: '100%',
    backgroundColor: '#10B981',
    borderRadius: 2,
    transformOrigin: 'left', // Ensure scaling starts from left
  },
  progressText: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
  },
});
