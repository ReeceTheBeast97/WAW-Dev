import WashRatingAndTip from '../src/components/wash/WashRatingAndTip';
import { useLocalSearchParams } from 'expo-router';

export default function WashRatingScreen() {
  const { washCompletionId } = useLocalSearchParams<{ washCompletionId: string }>();

  if (!washCompletionId) {
    return null;
  }

  return (
    <WashRatingAndTip
      washCompletionId={washCompletionId}
      onComplete={() => {
        // Handle completion - could navigate back to wash history
      }}
      onClose={() => {
        // Handle close - could navigate back
      }}
    />
  );
}
