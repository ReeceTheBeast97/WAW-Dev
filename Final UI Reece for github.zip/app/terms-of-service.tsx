import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function TermsOfService() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Terms of Service</Text>
          <View style={styles.placeholder} />
        </View>

        <View style={styles.content}>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString()}</Text>

          <Text style={styles.sectionTitle}>1. Acceptance of Terms</Text>
          <Text style={styles.text}>
            By accessing and using the Wish a Wash mobile application ("App"), you accept and agree to be bound by the terms and provision of this agreement.
          </Text>

          <Text style={styles.sectionTitle}>2. Service Description</Text>
          <Text style={styles.text}>
            Wish a Wash provides a platform connecting car owners with professional valeting services. Our service includes booking, payment processing, service coordination, and real-time tracking. We offer instant washes, scheduled bookings, and priority wash services at local car washes.
          </Text>

          <Text style={styles.sectionTitle}>3. User Responsibilities</Text>
          <Text style={styles.text}>
            <Text style={styles.subsectionTitle}>For Customers:{'\n'}</Text>
            • Provide accurate vehicle information and location{'\n'}
            • Ensure vehicle is accessible for service{'\n'}
            • Pay for services as agreed{'\n'}
            • Provide honest feedback and ratings{'\n'}
            • Report any issues within 24 hours{'\n'}
            {'\n'}
            <Text style={styles.subsectionTitle}>For Valeters:{'\n'}</Text>
            • Maintain professional appearance and conduct{'\n'}
            • Arrive on time for scheduled appointments{'\n'}
            • Use only approved cleaning products and methods{'\n'}
            • Complete services to the highest quality standards{'\n'}
            • Maintain valid insurance and licensing{'\n'}
            • Provide accurate documentation and verification
          </Text>

          <Text style={styles.sectionTitle}>4. Valeter Code of Conduct</Text>
          <Text style={styles.text}>
            All valeters must adhere to the following strict guidelines:
          </Text>

          <Text style={styles.subsectionTitle}>4.1 Professional Standards</Text>
          <Text style={styles.text}>
            • Maintain professional appearance and conduct{'\n'}
            • Arrive on time for scheduled appointments{'\n'}
            • Use only approved cleaning products and methods{'\n'}
            • Complete services to the highest quality standards{'\n'}
            • Maintain valid insurance and licensing documentation{'\n'}
            • Keep equipment and supplies in good condition
          </Text>

          <Text style={styles.subsectionTitle}>4.2 Customer Interaction Policy</Text>
          <Text style={styles.text}>
            • All customer interactions must be conducted through the Wish a Wash platform{'\n'}
            • Maintain professional boundaries at all times{'\n'}
            • Report any customer concerns or issues through the app{'\n'}
            • Use the in-app messaging system for all communications{'\n'}
            • Respect customer privacy and property
          </Text>

          <Text style={styles.subsectionTitle}>4.3 Vehicle Care and Safety</Text>
          <Text style={styles.text}>
            • Handle customer vehicles with extreme care{'\n'}
            • Report any damage immediately{'\n'}
            • Follow safety protocols for all cleaning procedures{'\n'}
            • Use appropriate protective measures for different vehicle types{'\n'}
            • Maintain clean and organized work areas
          </Text>

          <Text style={styles.sectionTitle}>5. STRICT BUSINESS CONDUCT RULES</Text>
          <Text style={styles.warningText}>
            ⚠️ CRITICAL: Valeters are STRICTLY PROHIBITED from approaching Wish your Wash customers for private hire outside of the platform.
          </Text>

          <Text style={styles.subsectionTitle}>5.1 Anti-Competition Policy</Text>
          <Text style={styles.text}>
            Valeters who meet customers through the Wish a Wash platform are ABSOLUTELY FORBIDDEN from:{'\n'}
            • Offering private services to customers outside the app{'\n'}
            • Soliciting customers for direct business{'\n'}
            • Providing contact information for off-platform services{'\n'}
            • Accepting cash payments or direct bookings{'\n'}
            • Circumventing the platform's payment system
          </Text>

          <Text style={styles.subsectionTitle}>5.2 Consequences of Violation</Text>
          <Text style={styles.text}>
            Violation of these business conduct rules will result in:{'\n'}
            • Immediate account termination{'\n'}
            • Permanent ban from the platform{'\n'}
            • Legal action if necessary{'\n'}
            • Reporting to relevant authorities{'\n'}
            • Loss of all pending payments and earnings
          </Text>

          <Text style={styles.subsectionTitle}>5.3 Reporting Violations</Text>
          <Text style={styles.text}>
            Customers are encouraged to report any valeter who attempts to solicit business outside the platform. All reports will be investigated thoroughly.
          </Text>

          <Text style={styles.sectionTitle}>6. Payment and Refund Policy</Text>
          <Text style={styles.text}>
            • All payments are processed securely through the platform{'\n'}
            • Valeters receive up to 85% of booking value (platform fee applies){'\n'}
            • Refunds are available according to our cancellation policy{'\n'}
            • Service fees are non-refundable{'\n'}
            • Disputes must be reported within 24 hours of service completion{'\n'}
            • Payment processing may take 2-5 business days for valeters{'\n'}
            • Customers are charged immediately upon booking confirmation
          </Text>

          <Text style={styles.sectionTitle}>7. Cancellation Policy</Text>
          <Text style={styles.text}>
            <Text style={styles.subsectionTitle}>For Instant Wash Bookings:{'\n'}</Text>
            • Cancel within 5 minutes: Full refund (100%){'\n'}
            • Cancel within 15 minutes: 90% refund{'\n'}
            • Cancel within 30 minutes: 75% refund{'\n'}
            • Cancel within 1 hour: 50% refund{'\n'}
            • Cancel within 2 hours: 25% refund{'\n'}
            • After 2 hours: No refund{'\n'}
            {'\n'}
            <Text style={styles.subsectionTitle}>For Scheduled Bookings:{'\n'}</Text>
            • Cancel up to 24 hours before: Full refund{'\n'}
            • Cancel 12-24 hours before: 75% refund{'\n'}
            • Cancel 6-12 hours before: 50% refund{'\n'}
            • Cancel less than 6 hours before: No refund{'\n'}
            {'\n'}
            <Text style={styles.subsectionTitle}>For Priority Wash Bookings:{'\n'}</Text>
            • Cancel up to 2 hours before: Full refund{'\n'}
            • Cancel 1-2 hours before: 50% refund{'\n'}
            • Cancel less than 1 hour before: No refund{'\n'}
            {'\n'}
            • Refunds processed within 24 hours{'\n'}
            • Valeters must provide 30 minutes notice for cancellations
          </Text>

          <Text style={styles.sectionTitle}>8. Privacy and Data Protection</Text>
          <Text style={styles.text}>
            We collect and process personal data in accordance with our Privacy Policy and applicable data protection laws. Your privacy is our priority. We collect location data for service delivery, vehicle information for bookings, and communication data for customer support.
          </Text>

          <Text style={styles.sectionTitle}>9. Limitation of Liability</Text>
          <Text style={styles.text}>
            Wish a Wash acts as a platform connecting customers and valeters. We are not liable for damages arising from valeter services, including vehicle damage, personal injury, or financial loss. Valeters are responsible for their own insurance coverage and service quality. Customers should report issues immediately for investigation and resolution.
          </Text>

          <Text style={styles.sectionTitle}>10. Account Termination</Text>
          <Text style={styles.text}>
            We reserve the right to terminate accounts that:{'\n'}
            • Violate these terms of service{'\n'}
            • Engage in fraudulent activity{'\n'}
            • Fail to maintain service quality standards{'\n'}
            • Attempt to circumvent the platform{'\n'}
            • Provide false information or documentation{'\n'}
            • Receive multiple customer complaints{'\n'}
            • Fail to maintain valid insurance or licensing (valeters)
          </Text>

          <Text style={styles.sectionTitle}>11. Changes to Terms</Text>
          <Text style={styles.text}>
            We may update these terms from time to time. Continued use of the app constitutes acceptance of any changes.
          </Text>

          <Text style={styles.sectionTitle}>12. Contact Information</Text>
          <Text style={styles.text}>
            For questions about these terms, contact us at:{'\n'}
            Email: legal@wishawash.com{'\n'}
            Phone: +44 20 1234 5678{'\n'}
            Address: Wish a Wash Ltd, London, UK
          </Text>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              By using Wish a Wash, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  content: {
    padding: 20,
  },
  lastUpdated: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 20,
    fontStyle: 'italic',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  subsectionTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 15,
    marginBottom: 8,
  },
  text: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 15,
  },
  warningText: {
    color: '#EF4444',
    fontSize: 16,
    fontWeight: 'bold',
    lineHeight: 22,
    marginBottom: 15,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    padding: 15,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#EF4444',
  },
  footer: {
    marginTop: 30,
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
  },
  footerText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});
