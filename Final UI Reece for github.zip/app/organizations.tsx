import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

type TabType = 'overview' | 'browse' | 'my-org' | 'applications';

interface Organization {
  id: string;
  name: string;
  description: string;
  location: string;
  rating: number;
  employeeCount: number;
  specializations: string[];
  isJoined: boolean;
  isApplied: boolean;
}

interface Application {
  id: string;
  organizationName: string;
  status: 'pending' | 'approved' | 'rejected';
  appliedDate: string;
  position: string;
}

export default function Organizations() {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [organizations, setOrganizations] = useState<Organization[]>([
    {
      id: '1',
      name: 'Elite Valet Services Ltd',
      description: 'Premium car care services across London',
      location: 'London, UK',
      rating: 4.8,
      employeeCount: 12,
      specializations: ['Luxury Cars', 'Classic Cars', 'Detailing'],
      isJoined: false,
      isApplied: false,
    },
    {
      id: '2',
      name: 'Premium Car Care Ltd',
      description: 'Professional valeting and detailing services',
      location: 'Manchester, UK',
      rating: 4.9,
      employeeCount: 8,
      specializations: ['Sports Cars', 'Commercial Vehicles'],
      isJoined: false,
      isApplied: false,
    },
    {
      id: '3',
      name: 'Auto Shine Pro',
      description: 'Mobile valeting services with eco-friendly products',
      location: 'Birmingham, UK',
      rating: 4.7,
      employeeCount: 15,
      specializations: ['Mobile Service', 'Eco-Friendly'],
      isJoined: true,
      isApplied: false,
    },
  ]);

  const [applications, setApplications] = useState<Application[]>([
    {
      id: '1',
      organizationName: 'Elite Valet Services Ltd',
      status: 'pending',
      appliedDate: '2024-01-15',
      position: 'Senior Valeter',
    },
    {
      id: '2',
      organizationName: 'Premium Car Care Ltd',
      status: 'approved',
      appliedDate: '2024-01-10',
      position: 'Valeter',
    },
  ]);

  const handleTabPress = async (tab: TabType) => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    setActiveTab(tab);
  };

  const handleApplyToOrganization = async (orgId: string) => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    
    setOrganizations(prev => prev.map(org => 
      org.id === orgId ? { ...org, isApplied: true } : org
    ));
    
    // Add to applications
    const org = organizations.find(o => o.id === orgId);
    if (org) {
      const newApplication: Application = {
        id: Date.now().toString(),
        organizationName: org.name,
        status: 'pending',
        appliedDate: new Date().toISOString().split('T')[0],
        position: 'Valeter',
      };
      setApplications(prev => [newApplication, ...prev]);
    }
  };

  const handleJoinOrganization = async (orgId: string) => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
    
    setOrganizations(prev => prev.map(org => 
      org.id === orgId ? { ...org, isJoined: true } : org
    ));
  };

  const renderOverview = () => (
    <View style={styles.tabContent}>
      {/* Hero Section */}
      <LinearGradient
        colors={['#3B82F6', '#1D4ED8']}
        style={styles.heroSection}
      >
        <Text style={styles.heroIcon}>🏢</Text>
        <Text style={styles.heroTitle}>Organization Hub</Text>
        <Text style={styles.heroSubtitle}>Connect with the best valeting teams</Text>
      </LinearGradient>

      {/* Stats Cards */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{organizations.filter(org => org.isJoined).length}</Text>
          <Text style={styles.statLabel}>Organizations Joined</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{applications.length}</Text>
          <Text style={styles.statLabel}>Applications</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{applications.filter(app => app.status === 'approved').length}</Text>
          <Text style={styles.statLabel}>Approved</Text>
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActionsContainer}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={styles.quickActionCard}
            onPress={() => handleTabPress('browse')}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>🔍</Text>
              <Text style={styles.quickActionTitle}>Browse Organizations</Text>
              <Text style={styles.quickActionSubtitle}>Find your perfect team</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.quickActionCard}
            onPress={() => handleTabPress('applications')}
          >
            <LinearGradient
              colors={['#F59E0B', '#D97706']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>📋</Text>
              <Text style={styles.quickActionTitle}>My Applications</Text>
              <Text style={styles.quickActionSubtitle}>Track your progress</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderBrowse = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>Available Organizations</Text>
      <ScrollView showsVerticalScrollIndicator={false}>
        {organizations.map((org) => (
          <View key={org.id} style={styles.orgCard}>
            <View style={styles.orgHeader}>
              <View style={styles.orgInfo}>
                <Text style={styles.orgName}>{org.name}</Text>
                <Text style={styles.orgLocation}>{org.location}</Text>
                <View style={styles.orgRating}>
                  <Text style={styles.ratingText}>⭐ {org.rating}</Text>
                  <Text style={styles.employeeText}>{org.employeeCount} employees</Text>
                </View>
              </View>
              <View style={styles.orgStatus}>
                {org.isJoined ? (
                  <View style={styles.joinedBadge}>
                    <Text style={styles.joinedText}>Joined</Text>
                  </View>
                ) : org.isApplied ? (
                  <View style={styles.appliedBadge}>
                    <Text style={styles.appliedText}>Applied</Text>
                  </View>
                ) : null}
              </View>
            </View>
            
            <Text style={styles.orgDescription}>{org.description}</Text>
            
            <View style={styles.specializations}>
              {org.specializations.map((spec, index) => (
                <View key={index} style={styles.specializationTag}>
                  <Text style={styles.specializationText}>{spec}</Text>
                </View>
              ))}
            </View>

            <View style={styles.orgActions}>
              {!org.isJoined && !org.isApplied && (
                <TouchableOpacity
                  style={styles.applyButton}
                  onPress={() => handleApplyToOrganization(org.id)}
                >
                  <Text style={styles.applyButtonText}>Apply Now</Text>
                </TouchableOpacity>
              )}
              {org.isApplied && !org.isJoined && (
                <TouchableOpacity
                  style={styles.joinButton}
                  onPress={() => handleJoinOrganization(org.id)}
                >
                  <Text style={styles.joinButtonText}>Join Organization</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );

  const renderMyOrg = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>My Organizations</Text>
      {organizations.filter(org => org.isJoined).length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🏢</Text>
          <Text style={styles.emptyTitle}>No Organizations Joined</Text>
          <Text style={styles.emptySubtitle}>Join an organization to see it here</Text>
          <TouchableOpacity 
            style={styles.browseButton}
            onPress={() => handleTabPress('browse')}
          >
            <Text style={styles.browseButtonText}>Browse Organizations</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          {organizations.filter(org => org.isJoined).map((org) => (
            <View key={org.id} style={styles.orgCard}>
              <View style={styles.orgHeader}>
                <View style={styles.orgInfo}>
                  <Text style={styles.orgName}>{org.name}</Text>
                  <Text style={styles.orgLocation}>{org.location}</Text>
                  <View style={styles.orgRating}>
                    <Text style={styles.ratingText}>⭐ {org.rating}</Text>
                    <Text style={styles.employeeText}>{org.employeeCount} employees</Text>
                  </View>
                </View>
                <View style={styles.joinedBadge}>
                  <Text style={styles.joinedText}>Active</Text>
                </View>
              </View>
              
              <Text style={styles.orgDescription}>{org.description}</Text>
              
              <View style={styles.orgActions}>
                <TouchableOpacity style={styles.viewDetailsButton}>
                  <Text style={styles.viewDetailsButtonText}>View Details</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );

  const renderApplications = () => (
    <View style={styles.tabContent}>
      <Text style={styles.sectionTitle}>My Applications</Text>
      {applications.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>📋</Text>
          <Text style={styles.emptyTitle}>No Applications</Text>
          <Text style={styles.emptySubtitle}>Apply to organizations to see them here</Text>
          <TouchableOpacity 
            style={styles.browseButton}
            onPress={() => handleTabPress('browse')}
          >
            <Text style={styles.browseButtonText}>Browse Organizations</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          {applications.map((app) => (
            <View key={app.id} style={styles.applicationCard}>
              <View style={styles.applicationHeader}>
                <Text style={styles.applicationOrgName}>{app.organizationName}</Text>
                <View style={[
                  styles.statusBadge,
                  app.status === 'approved' && styles.approvedBadge,
                  app.status === 'rejected' && styles.rejectedBadge,
                  app.status === 'pending' && styles.pendingBadge,
                ]}>
                  <Text style={[
                    styles.statusText,
                    app.status === 'approved' && styles.approvedText,
                    app.status === 'rejected' && styles.rejectedText,
                    app.status === 'pending' && styles.pendingText,
                  ]}>
                    {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                  </Text>
                </View>
              </View>
              
              <Text style={styles.applicationPosition}>{app.position}</Text>
              <Text style={styles.applicationDate}>Applied: {app.appliedDate}</Text>
              
              {app.status === 'approved' && (
                <TouchableOpacity style={styles.acceptButton}>
                  <Text style={styles.acceptButtonText}>Accept Offer</Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverview();
      case 'browse':
        return renderBrowse();
      case 'my-org':
        return renderMyOrg();
      case 'applications':
        return renderApplications();
      default:
        return renderOverview();
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <LinearGradient
        colors={['#F97316', '#EA580C']}
        style={styles.header}
      >
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Organizations</Text>
        <View style={styles.headerSpacer} />
      </LinearGradient>

      {/* Navigation Tabs */}
      <View style={styles.navigationTabs}>
        <TouchableOpacity
          style={[styles.navTab, activeTab === 'overview' && styles.activeNavTab]}
          onPress={() => handleTabPress('overview')}
        >
          <Text style={styles.navTabIcon}>📊</Text>
          <Text style={[styles.navTabText, activeTab === 'overview' && styles.activeNavTabText]}>
            Overview
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.navTab, activeTab === 'browse' && styles.activeNavTab]}
          onPress={() => handleTabPress('browse')}
        >
          <Text style={styles.navTabIcon}>🔍</Text>
          <Text style={[styles.navTabText, activeTab === 'browse' && styles.activeNavTabText]}>
            Browse
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.navTab, activeTab === 'my-org' && styles.activeNavTab]}
          onPress={() => handleTabPress('my-org')}
        >
          <Text style={styles.navTabIcon}>🏢</Text>
          <Text style={[styles.navTabText, activeTab === 'my-org' && styles.activeNavTabText]}>
            My Org
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.navTab, activeTab === 'applications' && styles.activeNavTab]}
          onPress={() => handleTabPress('applications')}
        >
          <Text style={styles.navTabIcon}>📋</Text>
          <Text style={[styles.navTabText, activeTab === 'applications' && styles.activeNavTabText]}>
            Applications
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {renderContent()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  headerTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  navigationTabs: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  navTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 10,
    borderRadius: 8,
  },
  activeNavTab: {
    backgroundColor: '#3B82F6',
  },
  navTabIcon: {
    fontSize: 16,
    marginBottom: 4,
  },
  navTabText: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
  },
  activeNavTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
  },
  heroSection: {
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 24,
  },
  heroIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  heroTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#E0E7FF',
    textAlign: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    marginHorizontal: 4,
    alignItems: 'center',
    minHeight: 80,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#3B82F6',
    marginBottom: 6,
  },
  statLabel: {
    fontSize: 13,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
  quickActionsContainer: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  quickActions: {
    gap: 12,
  },
  quickActionCard: {
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    minHeight: 120,
  },
  quickActionGradient: {
    padding: 24,
    alignItems: 'center',
    minHeight: 120,
  },
  quickActionIcon: {
    fontSize: 36,
    marginBottom: 10,
  },
  quickActionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 6,
    textAlign: 'center',
  },
  quickActionSubtitle: {
    fontSize: 15,
    color: '#E0E7FF',
    textAlign: 'center',
    lineHeight: 20,
  },
  orgCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  orgHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  orgInfo: {
    flex: 1,
  },
  orgName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 6,
  },
  orgLocation: {
    fontSize: 15,
    color: '#6B7280',
    marginBottom: 10,
  },
  orgRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  ratingText: {
    fontSize: 14,
    color: '#F59E0B',
    fontWeight: '500',
  },
  employeeText: {
    fontSize: 14,
    color: '#6B7280',
  },
  orgStatus: {
    alignItems: 'flex-end',
  },
  joinedBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  joinedText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  appliedBadge: {
    backgroundColor: '#F59E0B',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  appliedText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  orgDescription: {
    fontSize: 15,
    color: '#4B5563',
    marginBottom: 16,
    lineHeight: 22,
  },
  specializations: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  specializationTag: {
    backgroundColor: '#E0E7FF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  specializationText: {
    fontSize: 12,
    color: '#3730A3',
    fontWeight: '500',
  },
  orgActions: {
    flexDirection: 'row',
    gap: 12,
  },
  applyButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
  },
  applyButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
  },
  joinButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
  },
  joinButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
  },
  viewDetailsButton: {
    backgroundColor: '#6B7280',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
  },
  viewDetailsButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
  },
  applicationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  applicationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  applicationOrgName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  approvedBadge: {
    backgroundColor: '#10B981',
  },
  rejectedBadge: {
    backgroundColor: '#EF4444',
  },
  pendingBadge: {
    backgroundColor: '#F59E0B',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  approvedText: {
    color: '#FFFFFF',
  },
  rejectedText: {
    color: '#FFFFFF',
  },
  pendingText: {
    color: '#FFFFFF',
  },
  applicationPosition: {
    fontSize: 16,
    color: '#4B5563',
    marginBottom: 8,
  },
  applicationDate: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 12,
  },
  acceptButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'center',
    marginBottom: 24,
  },
  browseButton: {
    backgroundColor: '#3B82F6',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  browseButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '500',
  },
});
