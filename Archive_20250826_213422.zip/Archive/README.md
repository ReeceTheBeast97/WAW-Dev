# 🚗 Wish a Wash (Waw) - Car Wash Service App

A comprehensive React Native car wash service application built with Expo, featuring real-time tracking, dynamic pricing, and seamless payment processing.

## ✨ Features

### 🚀 Core Features
- **User Authentication** - Driver and Owner user types
- **Real-time GPS Tracking** - Live driver location updates
- **Dynamic Pricing Engine** - Location and demand-based pricing
- **Job Management** - Complete job lifecycle management
- **Real-time Chat** - In-app messaging between users
- **Payment Processing** - Secure payment handling
- **Push Notifications** - Real-time updates and alerts

### 🎨 UI/UX Features
- **Beautiful Water-themed Design** - Modern, intuitive interface
- **Smooth Animations** - Engaging user experience
- **Responsive Design** - Works on all device sizes
- **Dark Theme** - Easy on the eyes

## 🏗️ Architecture

```
src/
├── components/     # Reusable UI components
├── utils/         # Utility services and helpers
├── hooks/         # Custom React hooks
├── services/      # API and external service integrations
└── types/         # TypeScript type definitions

app/               # Expo Router pages (routes)
├── _layout.tsx    # Root layout
├── index.tsx      # Home screen
├── login.tsx      # Authentication
└── ...           # Other route files
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm or yarn
- Expo CLI
- iOS Simulator or Android Emulator (optional)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd wish-a-wash
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp env.example .env
   # Edit .env with your configuration
   ```

4. **Start the development server**
   ```bash
   npm start
   ```

5. **Run on device/simulator**
   - Scan QR code with Expo Go app
   - Press `i` for iOS simulator
   - Press `a` for Android emulator
   - Press `w` for web browser

## 🧪 Testing

```bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
```

## 🔧 Development

### Code Quality
```bash
# Lint code
npm run lint

# Fix linting issues
npm run lint:fix

# Format code
npm run format

# Type checking
npm run type-check
```

### Available Scripts
- `npm start` - Start Expo development server
- `npm run android` - Run on Android
- `npm run ios` - Run on iOS
- `npm run web` - Run in web browser
- `npm test` - Run tests
- `npm run lint` - Check code quality
- `npm run format` - Format code
- `npm run type-check` - TypeScript type checking

## 📱 Demo Credentials

### Driver Account
- **Email**: `john@example.com`
- **Password**: `password123`

### Owner Account
- **Email**: `sarah@example.com`
- **Password**: `password123`

## 🛠️ Tech Stack

### Frontend
- **React Native** - Mobile app framework
- **Expo** - Development platform
- **TypeScript** - Type safety
- **Expo Router** - File-based routing
- **React Navigation** - Navigation library

### State Management
- **Zustand** - Lightweight state management
- **React Query** - Server state management

### UI/UX
- **React Native Elements** - UI components
- **Expo Linear Gradient** - Gradient effects
- **React Native Gesture Handler** - Touch interactions

### Services
- **Expo Notifications** - Push notifications
- **Expo Location** - GPS services
- **AsyncStorage** - Local data persistence

## 🔌 API Integration

The app is ready for backend integration with the following endpoints:

- **Authentication**: `/auth/*`
- **Users**: `/users/*`
- **Jobs**: `/jobs/*`
- **GPS Tracking**: `/tracking/*`
- **Pricing**: `/pricing/*`
- **Chat**: `/chat/*`
- **Notifications**: `/notifications/*`
- **Payments**: `/payments/*`

See `BACKEND_API_SPEC.md` for complete API documentation.

## 📊 Performance Optimizations

- **Code Splitting** - Lazy loading of components
- **Bundle Optimization** - Metro configuration
- **Image Optimization** - Efficient asset handling
- **Memory Management** - Proper cleanup and disposal

## 🔒 Security Features

- **JWT Authentication** - Secure token-based auth
- **Input Validation** - Client-side validation
- **Secure Storage** - Encrypted local storage
- **HTTPS Only** - Secure API communication

## 🚀 Deployment

### Development Build
```bash
npm run build
```

### Production Build
```bash
expo build:android
expo build:ios
```

## 📈 Monitoring & Analytics

- **Error Tracking** - Sentry integration ready
- **Performance Monitoring** - React Native Performance
- **User Analytics** - Usage tracking capabilities

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the API specification

## 🗺️ Roadmap

- [ ] Backend API implementation
- [ ] Real-time WebSocket integration
- [ ] Payment gateway integration
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Offline mode
- [ ] Advanced notifications
- [ ] Performance optimizations

---

**Built with ❤️ for the car wash industry**
