import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TextInput,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

interface BusinessAccount {
  id: string;
  businessName: string;
  email: string;
  phone: string;
  address: string;
  insuranceNumber: string;
  licenseNumber: string;
  employeeCount: number;
  totalRevenue: number;
  activeJobs: number;
}

export default function BusinessLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Mock business accounts
  const businessAccounts: BusinessAccount[] = [
    {
      id: 'business_1',
      businessName: 'Elite Valet Services Ltd',
      email: 'admin@elitevalet.com',
      phone: '+44 20 1234 5678',
      address: '123 Business Park, London, SW1A 1AA',
      insuranceNumber: 'INS-ELITE-2024-001',
      licenseNumber: 'LIC-ELITE-2024-001',
      employeeCount: 12,
      totalRevenue: 45678.90,
      activeJobs: 8,
    },
    {
      id: 'business_2',
      businessName: 'Premium Car Care Group',
      email: 'admin@premiumcarcare.com',
      phone: '+44 20 8765 4321',
      address: '456 Enterprise Way, Manchester, M1 1AA',
      insuranceNumber: 'INS-PREMIUM-2024-001',
      licenseNumber: 'LIC-PREMIUM-2024-001',
      employeeCount: 8,
      totalRevenue: 32456.78,
      activeJobs: 5,
    },
  ];

  const handleLogin = async () => {
    if (!email || !password) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    setIsLoading(true);

    try {
      // Simulate login delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      const business = businessAccounts.find(b => b.email === email);
      
      if (business && password === 'business123') {
        try {
          await hapticFeedback('medium');
        } catch (error) {
          console.log('Haptic feedback not available');
        }
        // Store business session
        // In a real app, you'd store this in secure storage
        router.push('/business-dashboard');
      } else {
        try {
          await hapticFeedback('heavy');
        } catch (error) {
          console.log('Haptic feedback not available');
        }
        Alert.alert('Login Failed', 'Invalid email or password');
      }
    } catch (error) {
      try {
        await hapticFeedback('heavy');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Error', 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };



  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.content}>
          <View style={styles.logoSection}>
            <Text style={styles.logo}>🚗</Text>
            <Text style={styles.title}>Valet Group Login</Text>
            <Text style={styles.subtitle}>Business Account Management</Text>
          </View>

          <View style={styles.formSection}>
            <Text style={styles.formTitle}>Business Account Access</Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Business Email</Text>
              <TextInput
                style={styles.input}
                value={email}
                onChangeText={setEmail}
                placeholder="admin@yourbusiness.com"
                placeholderTextColor="#9CA3AF"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Password</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="Enter your password"
                placeholderTextColor="#9CA3AF"
                secureTextEntry
              />
            </View>

            <TouchableOpacity
              style={[styles.loginButton, isLoading && styles.loginButtonDisabled]}
              onPress={handleLogin}
              disabled={isLoading}
            >
              <LinearGradient
                colors={['#1E3A8A', '#3B82F6']}
                style={styles.loginGradient}
              >
                <Text style={styles.loginButtonText}>
                  {isLoading ? 'Logging in...' : 'Login to Business Account'}
                </Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.demoButton}
              onPress={handleDemoLogin}
              disabled={isLoading}
            >
              <Text style={styles.demoButtonText}>Try Demo Account</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoSection}>
            <Text style={styles.infoTitle}>Business Account Benefits</Text>
            <View style={styles.benefitsList}>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>👥</Text>
                <Text style={styles.benefitText}>Manage all your valeters</Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>📊</Text>
                <Text style={styles.benefitText}>View detailed analytics</Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>💰</Text>
                <Text style={styles.benefitText}>Track revenue and payments</Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>🛡️</Text>
                <Text style={styles.benefitText}>Business insurance coverage</Text>
              </View>
              <View style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>🎯</Text>
                <Text style={styles.benefitText}>Reward system for employees</Text>
              </View>
            </View>
          </View>

          <View style={styles.demoSection}>
            <Text style={styles.demoTitle}>Demo Account Details</Text>
            <Text style={styles.demoText}>
              Email: admin@elitevalet.com{'\n'}
              Password: business123
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollContent: {
    flexGrow: 1,
  },
  header: {
    padding: 20,
  },
  backButton: {
    alignSelf: 'flex-start',
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    fontSize: 60,
    marginBottom: 16,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  subtitle: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
  },
  formSection: {
    marginBottom: 40,
  },
  formTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 24,
    textAlign: 'center',
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  loginButton: {
    marginBottom: 16,
  },
  loginButtonDisabled: {
    opacity: 0.6,
  },
  loginGradient: {
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  demoButton: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  demoButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  infoSection: {
    marginBottom: 30,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  benefitsList: {
    gap: 12,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
    borderRadius: 12,
    padding: 16,
  },
  benefitIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  benefitText: {
    color: '#F9FAFB',
    fontSize: 16,
    flex: 1,
  },
  demoSection: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  demoTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  demoText: {
    color: '#F9FAFB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
