import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  Modal,
  FlatList,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { AdminApprovalService, DocumentApproval, ValeterApprovalStatus, AdminUser } from '../src/services/AdminApprovalService';
import { PaymentCommissionService, ValeterEarnings, PlatformEarnings, PaymentSchedule } from '../src/services/PaymentCommissionService';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

export default function AdminDashboard() {
  const router = useRouter();
  const { user } = useAuth();
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [pendingApprovals, setPendingApprovals] = useState<DocumentApproval[]>([]);
  const [valeterStatuses, setValeterStatuses] = useState<ValeterApprovalStatus[]>([]);
  const [selectedApproval, setSelectedApproval] = useState<DocumentApproval | null>(null);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [activeTab, setActiveTab] = useState<'approvals' | 'valeters' | 'payments'>('approvals');

  const adminService = AdminApprovalService.getInstance();
  const paymentService = PaymentCommissionService.getInstance();

  useEffect(() => {
    // Simulate admin login (in real app, this would be proper authentication)
    const admin = adminService.authenticateAdmin('admin@wishawash.com', 'password');
    if (admin) {
      setAdminUser(admin);
      loadData();
    } else {
      Alert.alert('Access Denied', 'You do not have admin privileges.');
      router.back();
    }
  }, []);

  const loadData = () => {
    const approvals = adminService.getPendingApprovals();
    const statuses = adminService.getAllValeterApprovalStatuses();
    setPendingApprovals(approvals);
    setValeterStatuses(statuses);
  };

  const handleApproveDocument = async (approval: DocumentApproval) => {
    if (!adminUser) return;

    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Approve Document',
        `Are you sure you want to approve ${approval.documentName} for ${approval.valeterName}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Approve',
            onPress: () => {
              const success = adminService.approveDocument(
                approval.id,
                adminUser.id,
                adminUser.name
              );
              
              if (success) {
                Alert.alert('Success', 'Document approved successfully!');
                loadData();
                setShowApprovalModal(false);
              } else {
                Alert.alert('Error', 'Failed to approve document.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleRejectDocument = async (approval: DocumentApproval) => {
    if (!adminUser) return;

    try {
      await hapticFeedback('medium');
      setSelectedApproval(approval);
      setShowApprovalModal(true);
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleRejectWithReason = () => {
    if (!selectedApproval || !adminUser || !rejectionReason.trim()) {
      Alert.alert('Error', 'Please provide a rejection reason.');
      return;
    }

    const success = adminService.rejectDocument(
      selectedApproval.id,
      adminUser.id,
      adminUser.name,
      rejectionReason
    );

    if (success) {
      Alert.alert('Success', 'Document rejected successfully!');
      loadData();
      setShowApprovalModal(false);
      setRejectionReason('');
      setSelectedApproval(null);
    } else {
      Alert.alert('Error', 'Failed to reject document.');
    }
  };

  const handleAllowOnline = async (valeterStatus: ValeterApprovalStatus) => {
    if (!adminUser) return;

    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Allow Online',
        `Allow ${valeterStatus.valeterName} to go online?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Allow',
            onPress: () => {
              const success = adminService.allowValeterOnline(
                valeterStatus.valeterId,
                adminUser.id,
                adminUser.name
              );
              
              if (success) {
                Alert.alert('Success', `${valeterStatus.valeterName} can now go online!`);
                loadData();
              } else {
                Alert.alert('Error', 'Cannot allow online - documents still pending.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleForceOffline = async (valeterStatus: ValeterApprovalStatus) => {
    if (!adminUser) return;

    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Force Offline',
        `Force ${valeterStatus.valeterName} offline?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Force Offline',
            style: 'destructive',
            onPress: () => {
              const success = adminService.forceValeterOffline(
                valeterStatus.valeterId,
                adminUser.id,
                adminUser.name
              );
              
              if (success) {
                Alert.alert('Success', `${valeterStatus.valeterName} has been forced offline.`);
                loadData();
              } else {
                Alert.alert('Error', 'Failed to force offline.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const renderApprovalItem = ({ item }: { item: DocumentApproval }) => (
    <View style={styles.approvalCard}>
      <LinearGradient
        colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
        style={styles.approvalGradient}
      >
        <View style={styles.approvalHeader}>
          <Text style={styles.valeterName}>{item.valeterName}</Text>
          <Text style={styles.documentType}>{item.documentName}</Text>
        </View>
        
        <View style={styles.approvalDetails}>
          <Text style={styles.submittedDate}>
            Submitted: {item.submittedAt.toLocaleDateString()}
          </Text>
          <Text style={styles.documentType}>
            Type: {item.documentType}
          </Text>
        </View>

        <View style={styles.approvalActions}>
          <TouchableOpacity
            style={[styles.actionButton, styles.approveButton]}
            onPress={() => handleApproveDocument(item)}
          >
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.approveGradient}
            >
              <Text style={styles.actionButtonText}>✅ Approve</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.rejectButton]}
            onPress={() => handleRejectDocument(item)}
          >
            <LinearGradient
              colors={['#EF4444', '#DC2626']}
              style={styles.rejectGradient}
            >
              <Text style={styles.actionButtonText}>❌ Reject</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    </View>
  );

  const renderValeterStatus = ({ item }: { item: ValeterApprovalStatus }) => (
    <View style={styles.valeterCard}>
      <LinearGradient
        colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
        style={styles.valeterGradient}
      >
        <View style={styles.valeterHeader}>
          <Text style={styles.valeterName}>{item.valeterName}</Text>
          <View style={[
            styles.statusBadge,
            { backgroundColor: getStatusColor(item.overallStatus) }
          ]}>
            <Text style={styles.statusText}>{item.overallStatus.toUpperCase()}</Text>
          </View>
        </View>
        
        <View style={styles.valeterStats}>
          <Text style={styles.statText}>📄 Pending: {item.documentsPending}</Text>
          <Text style={styles.statText}>✅ Approved: {item.documentsApproved}</Text>
          <Text style={styles.statText}>❌ Rejected: {item.documentsRejected}</Text>
          <Text style={styles.statText}>
            {item.isOnline ? '🟢 Online' : '🔴 Offline'}
          </Text>
        </View>

        <View style={styles.valeterActions}>
          {!item.canGoOnline && item.documentsPending === 0 && (
            <TouchableOpacity
              style={[styles.actionButton, styles.approveButton]}
              onPress={() => handleAllowOnline(item)}
            >
              <LinearGradient
                colors={['#3B82F6', '#2563EB']}
                style={styles.approveGradient}
              >
                <Text style={styles.actionButtonText}>🟢 Allow Online</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
          
          {item.isOnline && (
            <TouchableOpacity
              style={[styles.actionButton, styles.rejectButton]}
              onPress={() => handleForceOffline(item)}
            >
              <LinearGradient
                colors={['#EF4444', '#DC2626']}
                style={styles.rejectGradient}
              >
                <Text style={styles.actionButtonText}>🔴 Force Offline</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </LinearGradient>
    </View>
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return '#10B981';
      case 'pending': return '#F59E0B';
      case 'rejected': return '#EF4444';
      case 'online': return '#3B82F6';
      default: return '#6B7280';
    }
  };

  const PaymentCommissionTab = () => {
    const platformEarnings = paymentService.getPlatformEarnings();
    const allValeterEarnings = paymentService.getAllValeterEarnings();
    const allPaymentSchedules = paymentService.getAllPaymentSchedules();

    return (
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Platform Earnings Summary */}
        <View style={styles.paymentSection}>
          <Text style={styles.paymentSectionTitle}>Platform Earnings</Text>
          <View style={styles.platformEarningsCard}>
            <LinearGradient
              colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
              style={styles.platformEarningsGradient}
            >
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>Total Revenue:</Text>
                <Text style={styles.earningsValue}>£{platformEarnings.totalRevenue.toFixed(2)}</Text>
              </View>
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>Total Commission (10%):</Text>
                <Text style={styles.earningsValue}>£{platformEarnings.totalCommission.toFixed(2)}</Text>
              </View>
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>Total Jobs:</Text>
                <Text style={styles.earningsValue}>{platformEarnings.totalJobs}</Text>
              </View>
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>Night Time Jobs:</Text>
                <Text style={styles.earningsValue}>{platformEarnings.nightTimeJobs}</Text>
              </View>
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>This Month Revenue:</Text>
                <Text style={styles.earningsValue}>£{platformEarnings.thisMonthRevenue.toFixed(2)}</Text>
              </View>
              <View style={styles.earningsRow}>
                <Text style={styles.earningsLabel}>This Month Commission:</Text>
                <Text style={styles.earningsValue}>£{platformEarnings.thisMonthCommission.toFixed(2)}</Text>
              </View>
            </LinearGradient>
          </View>
        </View>

        {/* Valeter Earnings */}
        <View style={styles.paymentSection}>
          <Text style={styles.paymentSectionTitle}>Top Earning Valeters</Text>
          {allValeterEarnings.slice(0, 5).map((valeter, index) => (
            <View key={valeter.valeterId} style={styles.valeterEarningsCard}>
              <LinearGradient
                colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
                style={styles.valeterEarningsGradient}
              >
                <View style={styles.valeterEarningsHeader}>
                  <Text style={styles.valeterEarningsRank}>#{index + 1}</Text>
                  <Text style={styles.valeterEarningsName}>{valeter.valeterName}</Text>
                  <Text style={styles.valeterEarningsTotal}>£{valeter.totalEarnings.toFixed(2)}</Text>
                </View>
                <View style={styles.valeterEarningsDetails}>
                  <Text style={styles.valeterEarningsDetail}>Jobs: {valeter.completedJobs}</Text>
                  <Text style={styles.valeterEarningsDetail}>Night Jobs: {valeter.nightTimeJobs}</Text>
                  <Text style={styles.valeterEarningsDetail}>This Month: £{valeter.thisMonthEarnings.toFixed(2)}</Text>
                </View>
              </LinearGradient>
            </View>
          ))}
        </View>

        {/* Payment Schedules */}
        <View style={styles.paymentSection}>
          <Text style={styles.paymentSectionTitle}>Recent Payment Schedules</Text>
          {allPaymentSchedules.slice(0, 5).map((schedule) => (
            <View key={`${schedule.valeterId}-${schedule.periodStart.getTime()}`} style={styles.paymentScheduleCard}>
              <LinearGradient
                colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
                style={styles.paymentScheduleGradient}
              >
                <View style={styles.paymentScheduleHeader}>
                  <Text style={styles.paymentScheduleName}>{schedule.valeterName}</Text>
                  <View style={[
                    styles.paymentStatusBadge,
                    { backgroundColor: schedule.status === 'paid' ? '#10B981' : schedule.status === 'processed' ? '#3B82F6' : '#F59E0B' }
                  ]}>
                    <Text style={styles.paymentStatusText}>{schedule.status.toUpperCase()}</Text>
                  </View>
                </View>
                <View style={styles.paymentScheduleDetails}>
                  <Text style={styles.paymentScheduleDetail}>
                    Period: {schedule.periodStart.toLocaleDateString()} - {schedule.periodEnd.toLocaleDateString()}
                  </Text>
                  <Text style={styles.paymentScheduleDetail}>
                    Net Payment: £{schedule.netPayment.toFixed(2)}
                  </Text>
                  <Text style={styles.paymentScheduleDetail}>
                    Unsociable Hours Bonus: £{schedule.unsociableHoursBonus.toFixed(2)}
                  </Text>
                </View>
              </LinearGradient>
            </View>
          ))}
        </View>
      </ScrollView>
    );
  };

  if (!adminUser) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading admin dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={() => router.back()}
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Admin Dashboard</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Admin Info */}
        <View style={styles.adminInfo}>
          <Text style={styles.adminName}>{adminUser.name}</Text>
          <Text style={styles.adminRole}>{adminUser.role.replace('_', ' ').toUpperCase()}</Text>
          <Text style={styles.adminEmail}>{adminUser.email}</Text>
        </View>

        {/* Tab Navigation */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'approvals' && styles.activeTab]}
            onPress={() => setActiveTab('approvals')}
          >
            <Text style={[styles.tabText, activeTab === 'approvals' && styles.activeTabText]}>
              📄 Document Approvals ({pendingApprovals.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'valeters' && styles.activeTab]}
            onPress={() => setActiveTab('valeters')}
          >
            <Text style={[styles.tabText, activeTab === 'valeters' && styles.activeTabText]}>
              👥 Valeter Management ({valeterStatuses.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.tab, activeTab === 'payments' && styles.activeTab]}
            onPress={() => setActiveTab('payments')}
          >
            <Text style={[styles.tabText, activeTab === 'payments' && styles.activeTabText]}>
              💰 Payments & Commission
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        {activeTab === 'approvals' ? (
          <View style={styles.content}>
            <Text style={styles.sectionTitle}>Pending Document Approvals</Text>
            {pendingApprovals.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>✅</Text>
                <Text style={styles.emptyTitle}>No Pending Approvals</Text>
                <Text style={styles.emptyText}>All documents have been reviewed.</Text>
              </View>
            ) : (
              <FlatList
                data={pendingApprovals}
                renderItem={renderApprovalItem}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
              />
            )}
          </View>
        ) : activeTab === 'valeters' ? (
          <View style={styles.content}>
            <Text style={styles.sectionTitle}>Valeter Management</Text>
            {valeterStatuses.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>👥</Text>
                <Text style={styles.emptyTitle}>No Valeters Found</Text>
                <Text style={styles.emptyText}>No valeters have submitted documents yet.</Text>
              </View>
            ) : (
              <FlatList
                data={valeterStatuses}
                renderItem={renderValeterStatus}
                keyExtractor={(item) => item.valeterId}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
              />
            )}
          </View>
        ) : (
          <View style={styles.content}>
            <Text style={styles.sectionTitle}>Payments & Commission</Text>
            <PaymentCommissionTab />
          </View>
        )}
      </ScrollView>

      {/* Rejection Modal */}
      <Modal
        visible={showApprovalModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowApprovalModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Reject Document</Text>
            <Text style={styles.modalSubtitle}>
              Rejecting: {selectedApproval?.documentName}
            </Text>
            
            <TextInput
              style={styles.reasonInput}
              placeholder="Enter rejection reason..."
              placeholderTextColor="#87CEEB"
              value={rejectionReason}
              onChangeText={setRejectionReason}
              multiline
              numberOfLines={3}
            />
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => {
                  setShowApprovalModal(false);
                  setRejectionReason('');
                  setSelectedApproval(null);
                }}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.rejectModalButton]}
                onPress={handleRejectWithReason}
              >
                <Text style={styles.modalButtonText}>Reject</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  adminInfo: {
    padding: 20,
    alignItems: 'center',
  },
  adminName: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  adminRole: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  adminEmail: {
    color: '#87CEEB',
    fontSize: 14,
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#3B82F6',
  },
  tabText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  approvalCard: {
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  approvalGradient: {
    padding: 16,
  },
  approvalHeader: {
    marginBottom: 12,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  documentType: {
    color: '#87CEEB',
    fontSize: 14,
  },
  approvalDetails: {
    marginBottom: 12,
  },
  submittedDate: {
    color: '#E0E7FF',
    fontSize: 12,
    marginBottom: 4,
  },
  approvalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  approveButton: {
    // Styles handled by gradient
  },
  rejectButton: {
    // Styles handled by gradient
  },
  approveGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  rejectGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  valeterCard: {
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  valeterGradient: {
    padding: 16,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  valeterStats: {
    marginBottom: 12,
  },
  statText: {
    color: '#E0E7FF',
    fontSize: 12,
    marginBottom: 2,
  },
  valeterActions: {
    flexDirection: 'row',
    gap: 12,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#0A1929',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  reasonInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginBottom: 20,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#6B7280',
  },
  rejectModalButton: {
    backgroundColor: '#EF4444',
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
});
