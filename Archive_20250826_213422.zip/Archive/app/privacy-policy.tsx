import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function PrivacyPolicy() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Privacy Policy</Text>
          <View style={styles.placeholder} />
        </View>

        <View style={styles.content}>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString()}</Text>

          <Text style={styles.sectionTitle}>1. Introduction</Text>
          <Text style={styles.text}>
            Wish a Wash ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application and services.
          </Text>

          <Text style={styles.sectionTitle}>2. Information We Collect</Text>
          
          <Text style={styles.subsectionTitle}>2.1 Personal Information</Text>
          <Text style={styles.text}>
            We collect information you provide directly to us:{'\n'}
            • Name, email, phone number, and address{'\n'}
            • Vehicle details (make, model, registration, color, type){'\n'}
            • Payment information (processed securely by third-party providers){'\n'}
            • Profile information and preferences{'\n'}
            • Communication history and messages{'\n'}
            • For valeters: insurance documents, licensing, background checks, and professional qualifications
          </Text>

          <Text style={styles.subsectionTitle}>2.2 Location Information</Text>
          <Text style={styles.text}>
            We collect location data to:{'\n'}
            • Provide accurate service delivery{'\n'}
            • Match customers with nearby valeters{'\n'}
            • Enable real-time tracking during service{'\n'}
            • Improve service quality and response times{'\n'}
            • For valeters: track work areas and service coverage{'\n'}
            • For customers: show valeter location and ETA
          </Text>

          <Text style={styles.subsectionTitle}>2.3 Usage Information</Text>
          <Text style={styles.text}>
            We automatically collect:{'\n'}
            • App usage patterns and preferences{'\n'}
            • Device information and identifiers{'\n'}
            • Log data and analytics{'\n'}
            • Performance and error information{'\n'}
            • Booking history and service preferences{'\n'}
            • For valeters: work hours, earnings data, and performance metrics{'\n'}
            • For customers: service history, ratings, and feedback
          </Text>

          <Text style={styles.sectionTitle}>3. How We Use Your Information</Text>
          <Text style={styles.text}>
            We use your information to:{'\n'}
            • Provide and improve our services{'\n'}
            • Process payments and transactions{'\n'}
            • Match customers with valeters{'\n'}
            • Send notifications and updates{'\n'}
            • Ensure platform security and safety{'\n'}
            • Comply with legal obligations{'\n'}
            • For valeters: calculate earnings, process payments, and provide performance analytics{'\n'}
            • For customers: provide service tracking, manage bookings, and offer personalized recommendations{'\n'}
            • Monitor service quality and resolve disputes{'\n'}
            • Conduct background checks and verification (valeters)
          </Text>

          <Text style={styles.sectionTitle}>4. Information Sharing</Text>
          
          <Text style={styles.subsectionTitle}>4.1 Service Providers</Text>
          <Text style={styles.text}>
            We share information with:{'\n'}
            • Valeters: customer contact details, vehicle information, and service location (only for active bookings){'\n'}
            • Customers: valeter name, photo, rating, and vehicle information (only for active bookings){'\n'}
            • Payment processors for secure transactions{'\n'}
            • Customer support providers{'\n'}
            • Analytics and security services{'\n'}
            • Background check providers (for valeter verification){'\n'}
            • Insurance providers (for valeter coverage verification)
          </Text>

          <Text style={styles.subsectionTitle}>4.2 Legal Requirements</Text>
          <Text style={styles.text}>
            We may disclose information when required by law, to protect rights and safety, or to investigate fraud or violations of our terms.
          </Text>

          <Text style={styles.subsectionTitle}>4.3 Business Transfers</Text>
          <Text style={styles.text}>
            In the event of a merger, acquisition, or sale of assets, your information may be transferred as part of the business transaction.
          </Text>

          <Text style={styles.sectionTitle}>5. Data Security</Text>
          <Text style={styles.text}>
            We implement industry-standard security measures to protect your information:{'\n'}
            • Encryption of sensitive data in transit and at rest{'\n'}
            • Secure payment processing through certified providers{'\n'}
            • Regular security audits and penetration testing{'\n'}
            • Access controls and monitoring{'\n'}
            • Employee training on data protection{'\n'}
            • Secure document storage for valeter verification{'\n'}
            • Two-factor authentication for account security{'\n'}
            • Regular backup and disaster recovery procedures
          </Text>

          <Text style={styles.sectionTitle}>6. Data Retention</Text>
          <Text style={styles.text}>
            We retain your information for as long as necessary to:{'\n'}
            • Provide our services{'\n'}
            • Comply with legal obligations{'\n'}
            • Resolve disputes{'\n'}
            • Enforce our agreements{'\n'}
            • Improve our services{'\n'}
            {'\n'}
            <Text style={styles.subsectionTitle}>Retention Periods:{'\n'}</Text>
            • Account data: 7 years after account closure{'\n'}
            • Transaction records: 7 years (legal requirement){'\n'}
            • Valeter verification documents: 5 years after account closure{'\n'}
            • Location data: 12 months{'\n'}
            • Communication logs: 2 years{'\n'}
            • Analytics data: 3 years (anonymized)
          </Text>

          <Text style={styles.sectionTitle}>7. Your Rights and Choices</Text>
          
          <Text style={styles.subsectionTitle}>7.1 Access and Control</Text>
          <Text style={styles.text}>
            You have the right to:{'\n'}
            • Access your personal information{'\n'}
            • Update or correct your data{'\n'}
            • Delete your account (subject to legal retention requirements){'\n'}
            • Export your data in a portable format{'\n'}
            • Opt out of marketing communications{'\n'}
            • Request data portability{'\n'}
            • Object to certain data processing{'\n'}
            • Withdraw consent for data processing
          </Text>

          <Text style={styles.subsectionTitle}>7.2 Location Services</Text>
          <Text style={styles.text}>
            You can control location permissions through your device settings. Disabling location services may limit app functionality.
          </Text>

          <Text style={styles.subsectionTitle}>7.3 Push Notifications</Text>
          <Text style={styles.text}>
            You can manage notification preferences in the app settings or through your device settings.
          </Text>

          <Text style={styles.sectionTitle}>8. Age Restrictions</Text>
          <Text style={styles.text}>
            Our services are not intended for children under 18. We do not knowingly collect personal information from children under 18. If we become aware of such collection, we will take steps to delete it. Valeters must be at least 18 years old and have valid driving licenses and insurance.
          </Text>

          <Text style={styles.sectionTitle}>9. International Data Transfers</Text>
          <Text style={styles.text}>
            Your information may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place to protect your data in accordance with this policy.
          </Text>

          <Text style={styles.sectionTitle}>10. Third-Party Services</Text>
          <Text style={styles.text}>
            Our app may contain links to third-party services. We are not responsible for the privacy practices of these services. Please review their privacy policies before using them.
          </Text>

          <Text style={styles.sectionTitle}>11. Changes to This Policy</Text>
          <Text style={styles.text}>
            We may update this Privacy Policy from time to time. We will notify you of any material changes through the app or by email. Your continued use of the app constitutes acceptance of the updated policy.
          </Text>

          <Text style={styles.sectionTitle}>12. Contact Us</Text>
          <Text style={styles.text}>
            If you have questions about this Privacy Policy or our data practices, contact us at:{'\n'}
            Email: privacy@wishawash.com{'\n'}
            Phone: +44 20 1234 5678{'\n'}
            Address: Wish a Wash Ltd, London, UK{'\n'}
            Data Protection Officer: dpo@wishawash.com
          </Text>

          <Text style={styles.sectionTitle}>13. Regulatory Compliance</Text>
          <Text style={styles.text}>
            We comply with applicable data protection laws, including the General Data Protection Regulation (GDPR) in the European Union and the Data Protection Act 2018 in the United Kingdom. We also comply with industry-specific regulations for valeting services and financial services regulations for payment processing.
          </Text>

          <View style={styles.footer}>
            <Text style={styles.footerText}>
              This Privacy Policy is effective as of the date listed above. By using Wish a Wash, you consent to the collection and use of your information as described in this policy.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  content: {
    padding: 20,
  },
  lastUpdated: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 20,
    fontStyle: 'italic',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  subsectionTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 15,
    marginBottom: 8,
  },
  text: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 15,
  },
  footer: {
    marginTop: 30,
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
  },
  footerText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});
