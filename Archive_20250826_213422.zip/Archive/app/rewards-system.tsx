import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from './enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { enhancedBookingService as BookingService } from '../src/services/EnhancedBookingService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function RewardsSystem() {
  const { user } = useAuth();
  const [selectedReward, setSelectedReward] = useState('');

  // Mock rewards data with proper availability logic
  const rewards = [
    {
      id: 'free-basic-wash',
      title: 'Free Basic Wash',
      description: 'Get a free basic car wash',
      points: 500,
      icon: '🚿',
      category: 'wash',
      available: (user?.tierPoints || 0) >= 500
    },
    {
      id: 'free-premium-wash',
      title: 'Free Premium Wash',
      description: 'Get a free premium car wash',
      points: 1000,
      icon: '✨',
      category: 'wash',
      available: (user?.tierPoints || 0) >= 1000
    },
    {
      id: 'free-valet',
      title: 'Free Full Valet',
      description: 'Get a free full valet service',
      points: 2000,
      icon: '👑',
      category: 'valet',
      available: (user?.tierPoints || 0) >= 2000
    },
    {
      id: 'discount-25',
      title: '25% Off Next Booking',
      description: 'Get 25% off your next booking',
      points: 750,
      icon: '💸',
      category: 'discount',
      available: (user?.tierPoints || 0) >= 750
    },
    {
      id: 'discount-50',
      title: '50% Off Next Booking',
      description: 'Get 50% off your next booking',
      points: 1500,
      icon: '💰',
      category: 'discount',
      available: (user?.tierPoints || 0) >= 1500
    },
    {
      id: 'priority-support',
      title: 'Priority Support',
      description: 'Get priority customer support for 30 days',
      points: 300,
      icon: '🎯',
      category: 'support',
      available: (user?.tierPoints || 0) >= 300
    },
    {
      id: 'eco-wash-upgrade',
      title: 'Eco Wash Upgrade',
      description: 'Free upgrade to eco-friendly wash',
      points: 200,
      icon: '🌱',
      category: 'upgrade',
      available: (user?.tierPoints || 0) >= 200
    },
    {
      id: 'express-service',
      title: 'Express Service',
      description: 'Skip the queue with express service',
      points: 400,
      icon: '⚡',
      category: 'service',
      available: (user?.tierPoints || 0) >= 400
    }
  ];

  const achievements = [
    {
      id: 'first-wash',
      title: 'First Wash',
      description: 'Complete your first car wash',
      icon: '🎉',
      unlocked: true,
      progress: 1,
      maxProgress: 1
    },
    {
      id: 'wash-streak',
      title: 'Wash Streak',
      description: 'Book 5 washes in a row',
      icon: '🔥',
      unlocked: false,
      progress: 3,
      maxProgress: 5
    },
    {
      id: 'referral-master',
      title: 'Referral Master',
      description: 'Refer 10 friends to the app',
      icon: '👥',
      unlocked: false,
      progress: 7,
      maxProgress: 10
    },
    {
      id: 'quality-rater',
      title: 'Quality Rater',
      description: 'Rate 20 valeter services',
      icon: '⭐',
      unlocked: false,
      progress: 15,
      maxProgress: 20
    },
    {
      id: 'eco-warrior',
      title: 'Eco Warrior',
      description: 'Book 10 eco-friendly washes',
      icon: '🌍',
      unlocked: false,
      progress: 6,
      maxProgress: 10
    },
    {
      id: 'loyal-customer',
      title: 'Loyal Customer',
      description: 'Complete 50 washes',
      icon: '👑',
      unlocked: false,
      progress: 32,
      maxProgress: 50
    }
  ];

  const tierBenefits = {
    bronze: {
      name: 'Bronze',
      icon: '🥉',
      color: ['#CD7F32', '#B8860B'],
      benefits: [
        'Earn 10 points per £1 spent',
        'Basic customer support',
        'Standard booking times'
      ]
    },
    silver: {
      name: 'Silver',
      icon: '🥈',
      color: ['#C0C0C0', '#A9A9A9'],
      benefits: [
        'Earn 12 points per £1 spent',
        'Priority customer support',
        'Faster booking times',
        '5% discount on all services'
      ]
    },
    gold: {
      name: 'Gold',
      icon: '🥇',
      color: ['#FFD700', '#FFA500'],
      benefits: [
        'Earn 15 points per £1 spent',
        'VIP customer support',
        'Express booking times',
        '10% discount on all services',
        'Free eco-wash upgrades'
      ]
    },
    platinum: {
      name: 'Platinum',
      icon: '💎',
      color: ['#E5E4E2', '#BCC6CC'],
      benefits: [
        'Earn 20 points per £1 spent',
        '24/7 dedicated support',
        'Instant booking times',
        '15% discount on all services',
        'Free express service',
        'Exclusive rewards'
      ]
    }
  };

  const handleRewardSelect = async (rewardId: string) => {
    try {
      await hapticFeedback('light');
      setSelectedReward(rewardId);
    } catch (error) {
      console.error('Error in handleRewardSelect:', error);
    }
  };

  const handleRedeemReward = async (reward: any) => {
    try {
      if (!reward.available) {
        Alert.alert(
          'Reward Locked',
          `You need ${reward.points} points to unlock this reward. You currently have ${user?.tierPoints || 0} points.`
        );
        return;
      }

      await hapticFeedback('medium');
      Alert.alert(
        'Redeem Reward',
        `Are you sure you want to redeem "${reward.title}" for ${reward.points} points?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Redeem',
            onPress: async () => {
              try {
                // Here you would normally make an API call to redeem the reward
                console.log('Redeeming reward:', reward.id);
                
                await hapticFeedback('success');
                Alert.alert(
                  'Reward Redeemed! 🎉',
                  `Your ${reward.title} has been added to your account. You can use it on your next booking!`,
                  [{ text: 'OK' }]
                );
              } catch (error) {
                console.error('Error redeeming reward:', error);
                Alert.alert('Error', 'Failed to redeem reward. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleRedeemReward:', error);
    }
  };

  const handleCreateSampleBookings = async () => {
    if (!user) return;
    
    try {
      await BookingService.createSampleBookings(user.id);
      Alert.alert('Success', 'Sample bookings created! Check your dashboard.');
    } catch (error) {
      console.error('Error creating sample bookings:', error);
      Alert.alert('Error', 'Failed to create sample bookings.');
    }
  };



  const getTierInfo = (tier: string) => {
    return tierBenefits[tier as keyof typeof tierBenefits] || tierBenefits.bronze;
  };

  const currentTier = getTierInfo(user?.tier || 'bronze');
  const nextTier = user?.tier === 'bronze' ? 'silver' : 
                   user?.tier === 'silver' ? 'gold' : 
                   user?.tier === 'gold' ? 'platinum' : null;

  const getNextTierPoints = () => {
    switch (user?.tier) {
      case 'bronze': return 501;
      case 'silver': return 1501;
      case 'gold': return 3001;
      default: return 0;
    }
  };

  const pointsToNextTier = getNextTierPoints() - (user?.tierPoints || 0);

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Rewards & Points</Text>
          <View style={styles.headerSpacer} />
        </View>

        {/* Points Summary */}
        <View style={styles.section}>
          <LinearGradient
            colors={currentTier.color}
            style={styles.pointsCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.pointsHeader}>
              <Text style={styles.tierIcon}>{currentTier.icon}</Text>
              <View style={styles.pointsInfo}>
                <Text style={styles.tierName}>{currentTier.name} Member</Text>
                <Text style={styles.pointsText}>{user?.tierPoints || 0} points</Text>
              </View>
            </View>
            
            {nextTier && (
              <View style={styles.progressContainer}>
                <Text style={styles.progressText}>
                  {pointsToNextTier} points to {getTierInfo(nextTier).name}
                </Text>
                <View style={styles.progressBar}>
                  <View 
                    style={[
                      styles.progressFill, 
                      { 
                        width: `${Math.min(100, ((user?.tierPoints || 0) / getNextTierPoints()) * 100)}%` 
                      }
                    ]} 
                  />
                </View>
              </View>
            )}
          </LinearGradient>
        </View>

        {/* Tier Benefits */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Your Tier Benefits</Text>
          <View style={styles.benefitsCard}>
            {currentTier.benefits.map((benefit, index) => (
              <View key={index} style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>✓</Text>
                <Text style={styles.benefitText}>{benefit}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Available Rewards */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Rewards</Text>
          <View style={styles.rewardsGrid}>
            {rewards.map((reward) => (
              <TouchableOpacity
                key={reward.id}
                style={[
                  styles.rewardCard,
                  selectedReward === reward.id && styles.selectedReward,
                  !reward.available && styles.rewardCardLocked
                ]}
                onPress={() => handleRewardSelect(reward.id)}
                disabled={!reward.available}
              >
                <View style={styles.rewardHeader}>
                  <Text style={styles.rewardIcon}>{reward.icon}</Text>
                  <View style={styles.rewardStatus}>
                    {reward.available ? (
                      <Text style={styles.unlockIcon}>🔓</Text>
                    ) : (
                      <Text style={styles.lockIcon}>🔒</Text>
                    )}
                  </View>
                </View>
                <Text style={[
                  styles.rewardTitle,
                  !reward.available && styles.rewardTitleLocked
                ]}>{reward.title}</Text>
                <Text style={[
                  styles.rewardDescription,
                  !reward.available && styles.rewardDescriptionLocked
                ]}>{reward.description}</Text>
                <View style={styles.rewardFooter}>
                  <Text style={[
                    styles.rewardPoints,
                    !reward.available && styles.rewardPointsLocked
                  ]}>{reward.points} points</Text>
                  {reward.available && (
                    <TouchableOpacity
                      style={styles.redeemButton}
                      onPress={() => handleRedeemReward(reward)}
                    >
                      <Text style={styles.redeemButtonText}>Redeem</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Achievements */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Achievements</Text>
          <View style={styles.achievementsGrid}>
            {achievements.map((achievement) => (
              <View key={achievement.id} style={styles.achievementCard}>
                <View style={styles.achievementHeader}>
                  <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                  <View style={styles.achievementInfo}>
                    <Text style={styles.achievementTitle}>{achievement.title}</Text>
                    <Text style={styles.achievementDescription}>{achievement.description}</Text>
                  </View>
                  {achievement.unlocked && (
                    <View style={styles.unlockedBadge}>
                      <Text style={styles.unlockedText}>✓</Text>
                    </View>
                  )}
                </View>
                
                {!achievement.unlocked && (
                  <View style={styles.progressContainer}>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill, 
                          { width: `${(achievement.progress / achievement.maxProgress) * 100}%` }
                        ]} 
                      />
                    </View>
                    <Text style={styles.progressText}>
                      {achievement.progress}/{achievement.maxProgress}
                    </Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* How to Earn Points */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How to Earn Points</Text>
          <View style={styles.earnCard}>
            <View style={styles.earnItem}>
              <Text style={styles.earnIcon}>💰</Text>
              <View style={styles.earnInfo}>
                <Text style={styles.earnTitle}>Book Services</Text>
                <Text style={styles.earnDescription}>
                  Earn {currentTier.name === 'Bronze' ? '10' : 
                        currentTier.name === 'Silver' ? '12' : 
                        currentTier.name === 'Gold' ? '15' : '20'} points per £1 spent
                </Text>
              </View>
            </View>
            
            <View style={styles.earnItem}>
              <Text style={styles.earnIcon}>⭐</Text>
              <View style={styles.earnInfo}>
                <Text style={styles.earnTitle}>Rate Valeters</Text>
                <Text style={styles.earnDescription}>Earn 5 points for each rating</Text>
              </View>
            </View>
            
            <View style={styles.earnItem}>
              <Text style={styles.earnIcon}>👥</Text>
              <View style={styles.earnInfo}>
                <Text style={styles.earnTitle}>Refer Friends</Text>
                <Text style={styles.earnDescription}>Earn 50 points per successful referral</Text>
              </View>
            </View>
            
            <View style={styles.earnItem}>
              <Text style={styles.earnIcon}>🎯</Text>
              <View style={styles.earnInfo}>
                <Text style={styles.earnTitle}>Complete Achievements</Text>
                <Text style={styles.earnDescription}>Earn bonus points for milestones</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Points History */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Activity</Text>
          <View style={styles.activityCard}>
            <View style={styles.activityItem}>
              <Text style={styles.activityIcon}>💰</Text>
              <View style={styles.activityInfo}>
                <Text style={styles.activityTitle}>Premium Wash Booking</Text>
                <Text style={styles.activityDescription}>Earned 350 points</Text>
              </View>
              <Text style={styles.activityPoints}>+350</Text>
            </View>
            
            <View style={styles.activityItem}>
              <Text style={styles.activityIcon}>⭐</Text>
              <View style={styles.activityInfo}>
                <Text style={styles.activityTitle}>Rated Valeter</Text>
                <Text style={styles.activityDescription}>Earned 5 points</Text>
              </View>
              <Text style={styles.activityPoints}>+5</Text>
            </View>
            
            <View style={styles.activityItem}>
              <Text style={styles.activityIcon}>🎁</Text>
              <View style={styles.activityInfo}>
                <Text style={styles.activityTitle}>Redeemed Free Basic Wash</Text>
                <Text style={styles.activityDescription}>Spent 500 points</Text>
              </View>
              <Text style={styles.activityPoints}>-500</Text>
            </View>
          </View>
        </View>


      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  section: {
    padding: isSmallScreen ? 16 : 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  pointsCard: {
    borderRadius: 16,
    padding: 20,
    flexDirection: 'column',
    alignItems: 'center',
  },
  pointsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  tierIcon: {
    fontSize: 36,
    marginRight: 12,
  },
  pointsInfo: {
    flex: 1,
  },
  tierName: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  pointsText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
  },
  progressContainer: {
    width: '100%',
    marginTop: 12,
  },
  progressText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 12 : 14,
    marginBottom: 8,
    opacity: 0.9,
  },
  progressBar: {
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 3,
  },
  benefitsCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  benefitIcon: {
    fontSize: 20,
    marginRight: 12,
    color: '#87CEEB',
  },
  benefitText: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
  },
  rewardsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  rewardCard: {
    width: (width - 64) / 2,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    padding: 16,
    alignItems: 'center',
  },
  rewardCardLocked: {
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
    opacity: 0.6,
  },
  rewardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 8,
  },
  rewardStatus: {
    position: 'absolute',
    top: 0,
    right: 0,
  },
  unlockIcon: {
    fontSize: 16,
  },
  lockIcon: {
    fontSize: 16,
    color: '#FF6B6B',
  },
  selectedReward: {
    borderColor: '#87CEEB',
    borderWidth: 2,
  },
  rewardIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  rewardTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'center',
  },
  rewardTitleLocked: {
    color: '#9CA3AF',
  },
  rewardDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
    opacity: 0.9,
    textAlign: 'center',
    marginBottom: 12,
  },
  rewardDescriptionLocked: {
    color: '#9CA3AF',
    opacity: 0.7,
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  rewardPoints: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  rewardPointsLocked: {
    color: '#9CA3AF',
  },
  redeemButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  redeemButtonDisabled: {
    backgroundColor: '#555555',
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  achievementsGrid: {
    gap: 12,
  },
  achievementCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'column',
    alignItems: 'flex-start',
  },
  achievementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  achievementIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  achievementDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
    marginBottom: 8,
  },
  unlockedBadge: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 8,
    marginTop: 8,
  },
  unlockedText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: 'bold',
  },
  earnCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  earnItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  earnIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  earnInfo: {
    flex: 1,
  },
  earnTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  earnDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
  },
  activityCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  activityIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  activityInfo: {
    flex: 1,
  },
  activityTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  activityDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
  },
  activityPoints: {
    color: '#10B981',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },

});
