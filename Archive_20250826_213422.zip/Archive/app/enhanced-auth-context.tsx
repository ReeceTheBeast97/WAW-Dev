import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../src/lib/api/real/supabaseClient';

export interface Organization {
  id: string;
  name: string;
  registrationNumber: string;
  address: string;
  contactEmail: string;
  contactPhone: string;
  isVerified: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  userType: 'customer' | 'valeter' | 'organization';
  organizationId?: string;
  organizationType?: 'independent' | 'registered';
  profilePicture?: string;
  isVerified: boolean;
  verificationType: 'none' | 'profile' | 'car';
  totalWashes: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  tierPoints: number;
  joinDate: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'isEmailVerified' | 'createdAt' | 'updatedAt'> & { 
    password: string;
    isIndividualValeter?: boolean;
    organizationId?: string;
  }) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
  
  // Organization specific methods
  isIndividualValeter: () => boolean;
  isOrganizationValeter: () => boolean;
  requiresIndividualDocuments: () => boolean;
  requiresOrganizationDocuments: () => boolean;
  getOrganization: () => Organization | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    checkUser();
    
    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        await loadUserProfile(session.user.id);
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const checkUser = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await loadUserProfile(session.user.id);
      }
    } catch (error) {
      console.error('Error checking user session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error loading user profile:', error);
        return;
      }

      if (data) {
        const userProfile: User = {
          id: data.id,
          name: data.name || '',
          email: data.email || '',
          phone: data.phone,
          userType: data.user_type || 'customer',
          organizationId: data.organization_id,
          organizationType: data.organization_type,
          profilePicture: data.profile_picture,
          isVerified: data.is_verified || false,
          verificationType: data.verification_type || 'none',
          totalWashes: data.total_washes || 0,
          tier: data.tier || 'bronze',
          tierPoints: data.tier_points || 0,
          joinDate: data.created_at || new Date().toISOString()
        };
        setUser(userProfile);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        console.error('Login error:', error);
        return false;
      }

      if (data.user) {
        await loadUserProfile(data.user.id);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      console.log('Logout: Starting logout process...');
      console.log('Logout: Current user before logout:', user);
      
      await AsyncStorage.clear();
      console.log('Logout: AsyncStorage cleared successfully');
      
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Logout error:', error);
      }
      
      setUser(null);
      console.log('Logout: User state set to null');
      console.log('Logout: Logout process completed successfully');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const register = async (userData: any): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password
      });

      if (error) {
        console.error('Registration error:', error);
        return false;
      }

      if (data.user) {
        // Create profile
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            id: data.user.id,
            name: userData.name,
            email: userData.email,
            phone: userData.phone,
            user_type: userData.userType,
            organization_id: userData.organizationId,
            organization_type: userData.organizationType,
            is_verified: false,
            verification_type: 'none',
            total_washes: 0,
            tier: 'bronze',
            tier_points: 0
          });

        if (profileError) {
          console.error('Profile creation error:', profileError);
          return false;
        }

        await loadUserProfile(data.user.id);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: updates.name,
          phone: updates.phone,
          profile_picture: updates.profilePicture,
          is_verified: updates.isVerified,
          verification_type: updates.verificationType,
          total_washes: updates.totalWashes,
          tier: updates.tier,
          tier_points: updates.tierPoints
        })
        .eq('id', user.id);

      if (error) {
        console.error('Update user error:', error);
        return;
      }

      setUser(prev => prev ? { ...prev, ...updates } : null);
    } catch (error) {
      console.error('Update user error:', error);
    }
  };

  const updatePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) {
        console.error('Password update error:', error);
        throw error;
      }
    } catch (error) {
      console.error('Password update error:', error);
      throw error;
    }
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => {
    await updateUser(updates);
  };

  const resetPassword = async (email: string): Promise<void> => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) {
        console.error('Password reset error:', error);
        throw error;
      }
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  };

  const autoLoginCustomer = async (): Promise<void> => {
    // For demo purposes, you can implement auto-login logic here
    console.log('Auto login customer requested');
  };

  const autoLoginValeter = async (): Promise<void> => {
    // For demo purposes, you can implement auto-login logic here
    console.log('Auto login valeter requested');
  };

  const hasAdminAccess = (): boolean => {
    return user?.email === 'admin@wishawash.com';
  };

  const isBusinessOwner = (): boolean => {
    return user?.userType === 'organization';
  };

  const markWelcomeSeen = async (userType: 'customer' | 'valeter'): Promise<void> => {
    try {
      const key = `${userType}_welcome_seen`;
      await AsyncStorage.setItem(key, 'true');
    } catch (error) {
      console.error('Error marking welcome seen:', error);
    }
  };

  const hasSeenWelcome = async (userType: 'customer' | 'valeter'): Promise<boolean> => {
    try {
      const key = `${userType}_welcome_seen`;
      const seen = await AsyncStorage.getItem(key);
      return seen === 'true';
    } catch (error) {
      console.error('Error checking welcome seen:', error);
      return false;
    }
  };

  const isIndividualValeter = (): boolean => {
    return user?.userType === 'valeter' && !user?.organizationId;
  };

  const isOrganizationValeter = (): boolean => {
    return user?.userType === 'valeter' && !!user?.organizationId;
  };

  const requiresIndividualDocuments = (): boolean => {
    return isIndividualValeter() && !user?.isVerified;
  };

  const requiresOrganizationDocuments = (): boolean => {
    return isOrganizationValeter() && !user?.isVerified;
  };

  const getOrganization = (): Organization | null => {
    // TODO: Implement organization fetching from Supabase
    return null;
  };

  const value: AuthContextType = {
    user,
    isLoading,
    login,
    logout,
    register,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
    isIndividualValeter,
    isOrganizationValeter,
    requiresIndividualDocuments,
    requiresOrganizationDocuments,
    getOrganization
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export default AuthProvider;
