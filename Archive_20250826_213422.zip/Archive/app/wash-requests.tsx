import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  FlatList,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface WashRequest {
  id: string;
  customerName: string;
  customerRating: number;
  vehicleType: string;
  vehicleModel: string;
  serviceType: string;
  location: string;
  distance: number;
  price: number;
  specialInstructions: string;
  requestedTime: string;
  urgency: 'low' | 'medium' | 'high';
  isAccepted: boolean;
  customerPhoto: string;
}

export default function WashRequests() {
  const router = useRouter();
  const { user } = useAuth();
  const [washRequests, setWashRequests] = useState<WashRequest[]>([]);
  const [workingRadius, setWorkingRadius] = useState(15);
  const [isLoading, setIsLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadWorkingRadius();
    loadWashRequests();
  }, []);

  const loadWorkingRadius = async () => {
    try {
      const radius = await AsyncStorage.getItem('workingRadius');
      if (radius) {
        setWorkingRadius(parseInt(radius));
      }
    } catch (error) {
      console.log('Error loading working radius:', error);
    }
  };

  const loadWashRequests = () => {
    // Simulate wash requests data
    const mockRequests: WashRequest[] = [
      {
        id: '1',
        customerName: 'Sarah Johnson',
        customerRating: 4.8,
        vehicleType: 'SUV',
        vehicleModel: 'Range Rover Sport',
        serviceType: 'Full Valet',
        location: 'Central London, W1',
        distance: 2.3,
        price: 85,
        specialInstructions: 'Please pay extra attention to the interior leather seats',
        requestedTime: 'Today, 2:30 PM',
        urgency: 'medium',
        isAccepted: false,
        customerPhoto: '👩',
      },
      {
        id: '2',
        customerName: 'Michael Chen',
        customerRating: 4.9,
        vehicleType: 'Sports Car',
        vehicleModel: 'Porsche 911',
        serviceType: 'Exterior Wash & Wax',
        location: 'Chelsea, SW3',
        distance: 4.1,
        price: 65,
        specialInstructions: 'Use premium wax products only',
        requestedTime: 'Today, 4:00 PM',
        urgency: 'high',
        isAccepted: false,
        customerPhoto: '👨',
      },
      {
        id: '3',
        customerName: 'Emma Wilson',
        customerRating: 4.7,
        vehicleType: 'Sedan',
        vehicleModel: 'BMW 5 Series',
        serviceType: 'Quick Wash',
        location: 'Kensington, W8',
        distance: 1.8,
        price: 35,
        specialInstructions: 'Focus on removing bird droppings from bonnet',
        requestedTime: 'Tomorrow, 10:00 AM',
        urgency: 'low',
        isAccepted: false,
        customerPhoto: '👩',
      },
      {
        id: '4',
        customerName: 'David Thompson',
        customerRating: 4.6,
        vehicleType: 'Van',
        vehicleModel: 'Mercedes Sprinter',
        serviceType: 'Interior Deep Clean',
        location: 'Camden, NW1',
        distance: 3.7,
        price: 120,
        specialInstructions: 'Remove food stains from seats and clean cargo area',
        requestedTime: 'Today, 6:00 PM',
        urgency: 'medium',
        isAccepted: false,
        customerPhoto: '👨',
      },
      {
        id: '5',
        customerName: 'Lisa Rodriguez',
        customerRating: 5.0,
        vehicleType: 'Luxury Car',
        vehicleModel: 'Rolls Royce Phantom',
        serviceType: 'Premium Valet',
        location: 'Mayfair, W1',
        distance: 2.9,
        price: 150,
        specialInstructions: 'Ultra premium service required, customer is VIP',
        requestedTime: 'Today, 3:30 PM',
        urgency: 'high',
        isAccepted: false,
        customerPhoto: '👩',
      },
    ];

    setWashRequests(mockRequests);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadWashRequests();
    setRefreshing(false);
  };

  const handleAcceptRequest = async (requestId: string) => {
    try {
      await hapticFeedback('medium');
      
      // Find the request details for better messaging
      const request = washRequests.find(req => req.id === requestId);
      
      Alert.alert(
        'Accept Wash Request',
        `Are you sure you want to accept this wash request?\n\nCustomer: ${request?.customerName}\nVehicle: ${request?.vehicleModel}\nService: ${request?.serviceType}\nPrice: £${request?.price}`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Accept Request',
            onPress: () => {
              setWashRequests(prev => 
                prev.map(req => 
                  req.id === requestId ? { ...req, isAccepted: true } : req
                )
              );
              
              // Success notification with trip start option
              Alert.alert(
                'Request Accepted! 🎉',
                `You have successfully accepted ${request?.customerName}'s wash request.\n\nService: ${request?.serviceType}\nLocation: ${request?.location}\nPrice: £${request?.price}\n\nThe customer has been notified and you can now start your trip.`,
                [
                  {
                    text: '🚗 Start Trip Now',
                    onPress: () => {
                      // Add a small delay for better UX
                      setTimeout(() => {
                        router.push(`/current-trip?bookingId=${requestId}`);
                      }, 500);
                    }
                  },
                  { text: 'Stay Here' }
                ]
              );
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleViewDetails = async (request: WashRequest) => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Wash Request Details',
        `Customer: ${request.customerName}\nVehicle: ${request.vehicleModel}\nService: ${request.serviceType}\nLocation: ${request.location}\nDistance: ${request.distance}km\nPrice: £${request.price}\nSpecial Instructions: ${request.specialInstructions}`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Accept Request', onPress: () => handleAcceptRequest(request.id) }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      case 'low': return '#10B981';
      default: return '#6B7280';
    }
  };

  const getUrgencyText = (urgency: string) => {
    switch (urgency) {
      case 'high': return '🔴 High Priority';
      case 'medium': return '🟡 Medium Priority';
      case 'low': return '🟢 Low Priority';
      default: return '⚪ Standard';
    }
  };

  const renderWashRequest = ({ item }: { item: WashRequest }) => (
    <View style={styles.requestCard}>
      <LinearGradient
        colors={['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']}
        style={styles.requestGradient}
      >
        {/* Header */}
        <View style={styles.requestHeader}>
          <View style={styles.customerInfo}>
            <Text style={styles.customerPhoto}>{item.customerPhoto}</Text>
            <View style={styles.customerDetails}>
              <Text style={styles.customerName}>{item.customerName}</Text>
              <View style={styles.ratingContainer}>
                <Text style={styles.ratingText}>⭐ {item.customerRating}</Text>
              </View>
            </View>
          </View>
          <View style={styles.urgencyContainer}>
            <Text style={[styles.urgencyText, { color: getUrgencyColor(item.urgency) }]}>
              {getUrgencyText(item.urgency)}
            </Text>
          </View>
        </View>

        {/* Vehicle & Service Info */}
        <View style={styles.vehicleSection}>
          <Text style={styles.vehicleInfo}>
            🚗 {item.vehicleType} • {item.vehicleModel}
          </Text>
          <Text style={styles.serviceInfo}>
            🧽 {item.serviceType}
          </Text>
        </View>

        {/* Location & Distance */}
        <View style={styles.locationSection}>
          <Text style={styles.locationText}>📍 {item.location}</Text>
          <Text style={styles.distanceText}>📏 {item.distance}km away</Text>
        </View>

        {/* Price & Time */}
        <View style={styles.priceTimeSection}>
          <Text style={styles.priceText}>💷 £{item.price}</Text>
          <Text style={styles.timeText}>⏰ {item.requestedTime}</Text>
        </View>

        {/* Special Instructions */}
        {item.specialInstructions && (
          <View style={styles.instructionsSection}>
            <Text style={styles.instructionsLabel}>📝 Special Instructions:</Text>
            <Text style={styles.instructionsText}>{item.specialInstructions}</Text>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.actionButton, styles.detailsButton]}
            onPress={() => handleViewDetails(item)}
          >
            <Text style={styles.actionButtonText}>View Details</Text>
          </TouchableOpacity>
          
          {!item.isAccepted ? (
            <TouchableOpacity
              style={[styles.actionButton, styles.acceptButton]}
              onPress={() => handleAcceptRequest(item.id)}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.acceptGradient}
              >
                <Text style={styles.acceptButtonText}>Accept Request</Text>
              </LinearGradient>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={[styles.actionButton, styles.acceptedButton]}
              onPress={() => router.push(`/current-trip?bookingId=${item.id}`)}
            >
              <LinearGradient
                colors={['#3B82F6', '#2563EB']}
                style={styles.acceptedGradient}
              >
                <Text style={styles.acceptedButtonText}>🚗 Start Trip</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </LinearGradient>
    </View>
  );

  const availableRequests = washRequests.filter(req => !req.isAccepted);
  const acceptedRequests = washRequests.filter(req => req.isAccepted);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Jobs</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{availableRequests.length}</Text>
            <Text style={styles.statLabel}>Available</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{acceptedRequests.length}</Text>
            <Text style={styles.statLabel}>Accepted</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{workingRadius}km</Text>
            <Text style={styles.statLabel}>Radius</Text>
          </View>
        </View>

        {/* Available Requests */}
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>
            Available Requests ({availableRequests.length})
          </Text>
          
          {availableRequests.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>🚗</Text>
              <Text style={styles.emptyTitle}>No Available Requests</Text>
              <Text style={styles.emptyText}>
                No wash requests available in your {workingRadius}km radius at the moment.
              </Text>
            </View>
          ) : (
            <FlatList
              data={availableRequests}
              renderItem={renderWashRequest}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          )}
        </View>

        {/* Accepted Requests */}
        {acceptedRequests.length > 0 && (
          <View style={styles.sectionContainer}>
            <Text style={styles.sectionTitle}>
              Accepted Requests ({acceptedRequests.length})
            </Text>
            <FlatList
              data={acceptedRequests}
              renderItem={renderWashRequest}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          </View>
        )}

        {/* Tips Section */}
        <View style={styles.tipsContainer}>
          <Text style={styles.tipsTitle}>💡 Tips for Success</Text>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Accept requests within your working radius for better efficiency</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• High priority requests often pay better and have urgent customers</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Read special instructions carefully to meet customer expectations</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Pull down to refresh for new requests</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginVertical: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  sectionContainer: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  requestCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  requestGradient: {
    padding: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  customerPhoto: {
    fontSize: 32,
    marginRight: 12,
  },
  customerDetails: {
    flex: 1,
  },
  customerName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: '#FFD700',
    fontSize: 14,
  },
  urgencyContainer: {
    alignItems: 'flex-end',
  },
  urgencyText: {
    fontSize: 12,
    fontWeight: '600',
  },
  vehicleSection: {
    marginBottom: 8,
  },
  vehicleInfo: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
  },
  serviceInfo: {
    color: '#E0E7FF',
    fontSize: 14,
  },
  locationSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  locationText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  distanceText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  priceTimeSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  priceText: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: 'bold',
  },
  timeText: {
    color: '#E0E7FF',
    fontSize: 14,
  },
  instructionsSection: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
  },
  instructionsLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  instructionsText: {
    color: '#E0E7FF',
    fontSize: 14,
    lineHeight: 18,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    borderRadius: 8,
    overflow: 'hidden',
  },
  detailsButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingVertical: 12,
    alignItems: 'center',
  },
  acceptButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  acceptGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  acceptedButton: {
    borderRadius: 8,
    overflow: 'hidden',
  },
  acceptedGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  acceptedButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  tipsContainer: {
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    margin: 20,
    borderRadius: 12,
  },
  tipsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  tipItem: {
    marginBottom: 8,
  },
  tipText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
});
