import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  Alert,
  Animated,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { enhancedBookingService as BookingService } from '../src/services/EnhancedBookingService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface ServiceOption {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  icon: string;
  features: string[];
  colors: string[]; // Added colors property
}

interface VehicleType {
  id: string;
  name: string;
  icon: string;
  basePrice: number;
  colors: string[];
}

interface LocationOption {
  id: string;
  name: string;
  icon: string;
  description?: string;
  colors: string[];
}

interface TimeSlot {
  id: string;
  name: string;
  icon: string;
  colors: string[];
}

interface Vehicle {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  isDefault: boolean;
}

export default function AutoServiceBooking() {
  const { user } = useAuth();
  const [selectedService, setSelectedService] = useState<ServiceOption | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<LocationOption | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [slideAnim] = useState(new Animated.Value(0));
  const [userVehicles, setUserVehicles] = useState<Vehicle[]>([]);
  const [selectedStoredVehicle, setSelectedStoredVehicle] = useState<Vehicle | null>(null);

  // Simplified UK Valet Market Research Pricing System
  const calculateDynamicPrice = (service: any, location: any, vehicle: any) => {
    // Base prices for different services (UK market research)
    const basePrices = {
      'basic-wash': 15,
      'premium-wash': 25,
      'full-valet': 45,
      'exterior-detail': 85,
      'interior-detail': 65,
      'premium-valet': 120
    };

    // Vehicle multipliers based on size and complexity
    const vehicleMultipliers = {
      'small': 1.0,    // Small cars (Fiat 500, Mini, etc.)
      'medium': 1.15,  // Medium cars (Ford Focus, VW Golf, etc.)
      'large': 1.35,   // Large cars (BMW 5 Series, Mercedes E-Class, etc.)
      'suv': 1.5,      // SUVs (Range Rover, BMW X5, etc.)
      'luxury': 1.75   // Luxury vehicles (Bentley, Rolls Royce, etc.)
    };

    // Location multipliers
    const locationMultipliers = {
      'current': 0.95,   // 5% discount for GPS location
      'home': 1.0,       // Standard pricing
      'work': 1.1,       // 10% premium for business location
      'gym': 1.05,       // 5% premium for leisure location
      'shopping': 1.15,  // 15% premium for high-traffic location
      'airport': 1.25,   // 25% premium for premium location
      'hotel': 1.15      // 15% premium for hospitality location
    };

    const basePrice = basePrices[service.id] || 25;
    const vehicleMultiplier = vehicleMultipliers[vehicle.id] || 1.15;
    const locationMultiplier = locationMultipliers[location.id] || 1.0;

    const finalPrice = basePrice * vehicleMultiplier * locationMultiplier;
    
    return Math.round(finalPrice);
  };

  // Simplified service options - only the most popular ones
  const serviceOptions = [
    {
      id: 'basic-wash',
      name: 'Basic Wash',
      description: 'Exterior wash & dry',
      details: '• Hand wash exterior\n• Dry with microfiber\n• Tire dressing\n• Basic interior wipe',
      duration: '15-20 min',
      features: ['Hand wash', 'Dry', 'Tire dressing', 'Basic interior'],
      colors: ['#10B981', '#059669']
    },
    {
      id: 'premium-wash',
      name: 'Premium Wash',
      description: 'Exterior + Interior clean',
      details: '• Hand wash exterior\n• Interior vacuum & wipe\n• Glass cleaning\n• Tire & wheel cleaning',
      duration: '25-30 min',
      features: ['Hand wash', 'Interior clean', 'Glass clean', 'Wheel clean'],
      colors: ['#3B82F6', '#1D4ED8']
    },
    {
      id: 'full-valet',
      name: 'Full Valet',
      description: 'Complete interior & exterior',
      details: '• Deep interior cleaning\n• Exterior wash & wax\n• Engine bay clean\n• Full detailing',
      duration: '45-60 min',
      features: ['Deep clean', 'Wax', 'Engine bay', 'Full detail'],
      colors: ['#8B5CF6', '#7C3AED']
    },
    {
      id: 'exterior-detail',
      name: 'Exterior Detail',
      description: 'Professional exterior detailing',
      details: '• Clay bar treatment\n• Paint correction\n• Ceramic coating\n• Wheel restoration',
      duration: '2-3 hours',
      features: ['Clay bar', 'Paint correction', 'Ceramic coat', 'Wheel restore'],
      colors: ['#F59E0B', '#D97706']
    },
    {
      id: 'interior-detail',
      name: 'Interior Detail',
      description: 'Deep interior restoration',
      details: '• Steam cleaning\n• Leather treatment\n• Odor removal\n• Fabric protection',
      duration: '1-2 hours',
      features: ['Steam clean', 'Leather care', 'Odor removal', 'Fabric protect'],
      colors: ['#EF4444', '#DC2626']
    },
    {
      id: 'premium-valet',
      name: 'Premium Valet',
      description: 'Luxury car specialist service',
      details: '• Premium products only\n• Multi-stage paint care\n• Interior sanitization\n• Paint protection',
      duration: '3-4 hours',
      features: ['Premium products', 'Multi-stage', 'Sanitization', 'Paint protection'],
      colors: ['#FFD700', '#FFA500']
    }
  ];

  const vehicleTypes = [
    {
      id: 'small',
      name: 'Small Car',
      description: 'Fiesta, Corsa, 208, Aygo, Up!',
      icon: '🚗',
      basePrice: 1.0,
      colors: ['#10B981', '#059669'] // Green
    },
    {
      id: 'medium', 
      name: 'Medium Car',
      description: 'Focus, Golf, Astra, Civic, Corolla',
      icon: '🚙',
      basePrice: 1.25,
      colors: ['#3B82F6', '#1D4ED8'] // Blue
    },
    {
      id: 'large',
      name: 'Large Car',
      description: 'Mondeo, Passat, Insignia, Accord',
      icon: '🏎️',
      basePrice: 1.5,
      colors: ['#EC4899', '#DB2777'] // Pink
    },
    {
      id: 'suv',
      name: 'SUV/4x4',
      description: 'Qashqai, Kuga, CR-V, RAV4, X3',
      icon: '🚐',
      basePrice: 1.75,
      colors: ['#8B5CF6', '#7C3AED'] // Purple
    },
    {
      id: 'luxury',
      name: 'Luxury Vehicle',
      description: 'BMW, Mercedes, Audi, Range Rover',
      icon: '🏁',
      basePrice: 2.0,
      colors: ['#FCD34D', '#F59E0B'] // Gold
    }
  ];

  const locations = [
    { id: 'current', name: 'Use Current Location', icon: '📍', description: 'GPS location for instant wash', colors: ['#10B981', '#059669'] }, // Green
    { id: 'home', name: 'Home Address', icon: '🏠', colors: ['#3B82F6', '#1D4ED8'] }, // Blue
    { id: 'work', name: 'Work/Office', icon: '🏢', colors: ['#8B5CF6', '#7C3AED'] }, // Purple
    { id: 'gym', name: 'Gym/Leisure', icon: '💪', colors: ['#F59E0B', '#D97706'] }, // Orange
    { id: 'shopping', name: 'Shopping Centre', icon: '🛍️', colors: ['#EC4899', '#DB2777'] }, // Pink
    { id: 'airport', name: 'Airport', icon: '✈️', colors: ['#FCD34D', '#F59E0B'] }, // Gold
    { id: 'hotel', name: 'Hotel', icon: '🏨', colors: ['#06B6D4', '#0891B2'] } // Cyan
  ];

  const timeSlots = [
    { id: 'on-demand', name: 'On-Demand (Instant)', icon: '⚡', colors: ['#10B981', '#059669'] }, // Green
    { id: 'morning', name: 'Morning (8AM-12PM)', icon: '🌅', colors: ['#F59E0B', '#D97706'] }, // Orange
    { id: 'afternoon', name: 'Afternoon (12PM-5PM)', icon: '☀️', colors: ['#FCD34D', '#F59E0B'] }, // Gold
    { id: 'evening', name: 'Evening (5PM-9PM)', icon: '🌆', colors: ['#8B5CF6', '#7C3AED'] }, // Purple
    { id: 'weekend', name: 'Weekend', icon: '🎉', colors: ['#EC4899', '#DB2777'] } // Pink
  ];

  useEffect(() => {
    // Load user's stored vehicles
    const mockUserVehicles: Vehicle[] = [
      {
        id: 'booking-1',
        type: 'Car',
        make: 'Toyota',
        model: 'Corolla',
        color: 'Silver',
        registration: 'AB12 CDE',
        isDefault: true
      },
      {
        id: 'booking-2',
        type: 'SUV',
        make: 'BMW',
        model: 'X5',
        color: 'Black',
        registration: 'XY34 FGH',
        isDefault: false
      }
    ];
    setUserVehicles(mockUserVehicles);
    
    // Set default vehicle if available
    const defaultVehicle = mockUserVehicles.find(v => v.isDefault);
    if (defaultVehicle) {
      setSelectedStoredVehicle(defaultVehicle);
    }
  }, []);

  const handleAddonToggle = async (addonId: string) => {
    await hapticFeedback('light');
    setSelectedAddons(prev => 
      prev.includes(addonId) 
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  const handleServiceSelect = async (service: ServiceOption) => {
    setSelectedService(service);
    await hapticFeedback('light');
    // Auto advance to next step
    setTimeout(() => {
      setCurrentStep(2);
    }, 300);
  };

  const handleVehicleSelect = async (vehicle: VehicleType) => {
    setSelectedVehicle(vehicle);
    await hapticFeedback('light');
    // Auto advance to next step
    setTimeout(() => {
      setCurrentStep(2);
    }, 300);
  };

  const handleStoredVehicleSelect = async (vehicle: Vehicle) => {
    setSelectedStoredVehicle(vehicle);
    setSelectedVehicle(null);
    await hapticFeedback('light');
    // Auto advance to next step
    setTimeout(() => {
      setCurrentStep(2);
    }, 300);
  };

  const handleLocationSelect = async (location: LocationOption) => {
    setSelectedLocation(location);
    await hapticFeedback('light');
    // Auto advance to payment step
    setTimeout(() => {
      setCurrentStep(4);
    }, 300);
  };

  const handlePaymentConfirm = async () => {
    if (!selectedService || (!selectedVehicle && !selectedStoredVehicle) || !selectedLocation) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please complete all selections before confirming');
      return;
    }

    setIsProcessing(true);
    await hapticFeedback('medium');

    // Mock Stripe payment processing
    setTimeout(async () => {
      try {
        // Simulate payment processing steps
        console.log('Processing payment with Stripe...');
        
        // Simulate successful payment
        const paymentSuccess = Math.random() > 0.1; // 90% success rate
        
        if (paymentSuccess) {
          Alert.alert(
            'Payment Successful! 🎉',
            'Your payment of £' + (selectedService && selectedLocation && (selectedVehicle || selectedStoredVehicle)
              ? calculateDynamicPrice(
                  selectedService,
                  selectedLocation,
                  selectedVehicle || { id: selectedStoredVehicle?.type.toLowerCase() || 'medium', name: '', description: '', icon: '', basePrice: 1.0, colors: [] }
                )
              : 0) + ' has been processed successfully.\n\nFinding your valeter now...',
            [
              {
                text: 'Continue',
                onPress: () => {
                  // Navigate to valeter search after successful payment
                  router.push('/valeter-search');
                }
              }
            ]
          );
        } else {
          // Simulate payment failure
          Alert.alert(
            'Payment Failed',
            'Your payment could not be processed. Please check your payment method and try again.',
            [
              { text: 'Try Again', onPress: () => setIsProcessing(false) },
              { text: 'Cancel', style: 'cancel', onPress: () => setIsProcessing(false) }
            ]
          );
        }
      } catch (error) {
        Alert.alert('Payment Error', 'An unexpected error occurred. Please try again.');
        setIsProcessing(false);
      }
    }, 2000);
  };

  const handleBack = async () => {
    await hapticFeedback('light');
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    } else {
      router.back();
    }
  };

  const handleConfirmBooking = async () => {
    if (!selectedService || (!selectedVehicle && !selectedStoredVehicle) || !selectedLocation) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please complete all selections before confirming');
      return;
    }

    if (!user) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please login to book a service');
      return;
    }

    setIsProcessing(true);
    await hapticFeedback('medium');

    try {
      // Calculate final price
      const service = serviceOptions.find(s => s.id === selectedService);
      const vehicle = selectedVehicle ? vehicleTypes.find(v => v.id === selectedVehicle) : null;
      const location = locations.find(l => l.id === selectedLocation);
      
      if (!service || !location) {
        throw new Error('Invalid service or location selection');
      }

      const finalPrice = calculateDynamicPrice(service, location, vehicle || { id: 'medium', basePrice: 1.15 });

      // Create booking in the service
      const booking = await BookingService.createBooking({
        customerId: user.id,
        serviceType: selectedService,
        serviceName: service.name,
        vehicleType: selectedVehicle || 'medium',
        vehicleInfo: selectedStoredVehicle ? `${selectedStoredVehicle.make} ${selectedStoredVehicle.model}` : undefined,
        location: {
          address: location.name,
          latitude: 51.5074, // Default London coordinates
          longitude: -0.1278,
        },
        price: finalPrice,
        status: 'pending',
        paymentStatus: 'pending',
        specialInstructions: '',
      });

      console.log('✅ Booking created:', booking.id);

      // Show confirmation and navigate to valeter search
      Alert.alert(
        'Booking Confirmed! 🎉',
        `Your ${service.name} has been booked!\n\nPrice: £${finalPrice}\nLocation: ${location.name}\n\nWe're finding you a valeter...`,
        [
          {
            text: 'Continue',
            onPress: () => {
              // Pass booking ID to valeter search
              router.push({
                pathname: '/valeter-search',
                params: { bookingId: booking.id }
              });
            }
          }
        ]
      );

    } catch (error) {
      console.error('Booking error:', error);
      Alert.alert('Booking Error', 'Failed to create booking. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const getSelectedService = () => serviceOptions.find(s => s.id === selectedService);
  const getSelectedVehicle = () => vehicleTypes.find(v => v.id === selectedVehicle);
  const getSelectedLocation = () => locations.find(l => l.id === selectedLocation);
  const getSelectedTime = () => timeSlots.find(t => t.id === selectedTime);

  const calculatePrice = () => {
    const service = getSelectedService();
    const vehicle = getSelectedVehicle();
    if (!service || !vehicle) return 0;
    return Math.round(service.price * vehicle.basePrice);
  };

  const renderStepIndicator = () => (
    <View style={styles.stepIndicator}>
      <View style={styles.stepContainer}>
        <View style={[
          styles.stepCircle,
          currentStep >= 1 ? styles.stepActive : styles.stepInactive
        ]}>
          <Text style={[
            styles.stepNumber,
            currentStep >= 1 ? styles.stepNumberActive : styles.stepNumberInactive
          ]}>
            1
          </Text>
        </View>
        <Text style={styles.stepLabel}>Vehicle</Text>
        <View style={[
          styles.stepLine,
          currentStep > 1 ? styles.stepLineActive : styles.stepLineInactive
        ]} />
      </View>
      
      <View style={styles.stepContainer}>
        <View style={[
          styles.stepCircle,
          currentStep >= 2 ? styles.stepActive : styles.stepInactive
        ]}>
          <Text style={[
            styles.stepNumber,
            currentStep >= 2 ? styles.stepNumberActive : styles.stepNumberInactive
          ]}>
            2
          </Text>
        </View>
        <Text style={styles.stepLabel}>Service</Text>
        <View style={[
          styles.stepLine,
          currentStep > 2 ? styles.stepLineActive : styles.stepLineInactive
        ]} />
      </View>
      
      <View style={styles.stepContainer}>
        <View style={[
          styles.stepCircle,
          currentStep >= 3 ? styles.stepActive : styles.stepInactive
        ]}>
          <Text style={[
            styles.stepNumber,
            currentStep >= 3 ? styles.stepNumberActive : styles.stepNumberInactive
          ]}>
            3
          </Text>
        </View>
        <Text style={styles.stepLabel}>Location</Text>
        <View style={[
          styles.stepLine,
          currentStep > 3 ? styles.stepLineActive : styles.stepLineInactive
        ]} />
      </View>
      
      <View style={styles.stepContainer}>
        <View style={[
          styles.stepCircle,
          currentStep >= 4 ? styles.stepActive : styles.stepInactive
        ]}>
          <Text style={[
            styles.stepNumber,
            currentStep >= 4 ? styles.stepNumberActive : styles.stepNumberInactive
          ]}>
            4
          </Text>
        </View>
        <Text style={styles.stepLabel}>Payment</Text>
      </View>
    </View>
  );

  const renderServiceSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Choose Your Service</Text>
      <Text style={styles.stepSubtitle}>Select the perfect wash for your vehicle</Text>
      
      <View style={styles.optionsContainer}>
        {serviceOptions.map((service) => {
          const dynamicPrice = selectedVehicle || selectedStoredVehicle
            ? calculateDynamicPrice(
                service,
                { id: 'home' }, // Default location for pricing preview
                selectedVehicle || { id: selectedStoredVehicle?.type.toLowerCase() || 'medium' }
              )
            : 0;
          
          return (
            <TouchableOpacity
              key={service.id}
              style={[
                styles.serviceCard,
                selectedService?.id === service.id && styles.selectedCard
              ]}
              onPress={async () => {
                setSelectedService(service);
                await hapticFeedback('light');
                // Auto advance to next step
                setTimeout(() => {
                  setCurrentStep(3);
                }, 300);
              }}
            >
              <LinearGradient
                colors={selectedService?.id === service.id ? service.colors : ['#1E3A8A', '#87CEEB']}
                style={styles.serviceGradient}
              >
                <View style={styles.serviceHeader}>
                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.servicePrice}>£{dynamicPrice}</Text>
                </View>
                
                <Text style={styles.serviceDescription}>{service.description}</Text>
                <Text style={styles.serviceDetails}>{service.details}</Text>
                
                <View style={styles.serviceFooter}>
                  <Text style={styles.serviceDuration}>⏱️ {service.duration}</Text>
                  <View style={styles.serviceFeatures}>
                    {service.features.slice(0, 2).map((feature, index) => (
                      <Text key={index} style={styles.serviceFeature}>• {feature}</Text>
                    ))}
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  const renderVehicleSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Vehicle Type</Text>
      <Text style={styles.stepSubtitle}>What type of vehicle do you have?</Text>
      
      {/* Stored Vehicles */}
      {userVehicles.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>Your Vehicles</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            style={styles.storedVehiclesContainer}
            contentContainerStyle={styles.storedVehiclesContent}
          >
            {userVehicles.map((vehicle) => (
              <TouchableOpacity
                key={vehicle.id}
                style={[
                  styles.storedVehicleCard,
                  selectedStoredVehicle?.id === vehicle.id && styles.selectedStoredVehicleCard
                ]}
                onPress={async () => {
                  setSelectedStoredVehicle(vehicle);
                  setSelectedVehicle(null);
                  await hapticFeedback('light');
                  // Auto advance to next step
                  setTimeout(() => {
                    setCurrentStep(2);
                  }, 300);
                }}
              >
                <LinearGradient
                  colors={selectedStoredVehicle?.id === vehicle.id ? ['#10B981', '#059669'] : ['#1E3A8A', '#87CEEB']}
                  style={styles.storedVehicleGradient}
                >
                  <Text style={styles.storedVehicleIcon}>🚗</Text>
                  <Text style={styles.storedVehicleName}>{vehicle.make} {vehicle.model}</Text>
                  <Text style={styles.storedVehicleReg}>{vehicle.registration}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>OR</Text>
            <View style={styles.dividerLine} />
          </View>
        </>
      )}
      
      {/* Vehicle Types */}
      <Text style={styles.sectionTitle}>Select Vehicle Type</Text>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.vehicleTypesContainer}
        contentContainerStyle={styles.vehicleTypesContent}
      >
        {vehicleTypes.map((vehicle) => (
          <TouchableOpacity
            key={vehicle.id}
            style={[
              styles.vehicleCard,
              selectedVehicle?.id === vehicle.id && styles.selectedCard
            ]}
            onPress={async () => {
              setSelectedVehicle(vehicle);
              setSelectedStoredVehicle(null);
              await hapticFeedback('light');
              // Auto advance to next step
              setTimeout(() => {
                setCurrentStep(2);
              }, 300);
            }}
          >
            <LinearGradient
              colors={selectedVehicle?.id === vehicle.id ? vehicle.colors : ['#1E3A8A', '#87CEEB']}
              style={styles.vehicleGradient}
            >
              <Text style={styles.vehicleIcon}>{vehicle.icon}</Text>
              <Text style={styles.vehicleName}>{vehicle.name}</Text>
              <Text style={styles.vehicleDescription}>{vehicle.description}</Text>
              <Text style={styles.vehicleMultiplier}>
                {vehicle.id === 'small' && 'Standard pricing'}
                {vehicle.id === 'medium' && '+15% medium vehicle'}
                {vehicle.id === 'large' && '+25% large vehicle'}
                {vehicle.id === 'suv' && '+35% SUV premium'}
                {vehicle.id === 'luxury' && '+50% luxury premium'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Next Button */}
      <TouchableOpacity
        style={[
          styles.nextButton,
          (!selectedVehicle && !selectedStoredVehicle) && styles.nextButtonDisabled
        ]}
        onPress={async () => {
          if (selectedVehicle || selectedStoredVehicle) {
            await hapticFeedback('light');
            setCurrentStep(2);
          }
        }}
        disabled={!selectedVehicle && !selectedStoredVehicle}
      >
        <LinearGradient
          colors={(!selectedVehicle && !selectedStoredVehicle) ? ['#6B7280', '#4B5563'] : ['#3B82F6', '#1D4ED8']}
          style={styles.nextButtonGradient}
        >
          <Text style={styles.nextButtonText}>
            {(!selectedVehicle && !selectedStoredVehicle) ? 'Select a Vehicle' : 'Next'}
          </Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );

  const renderLocationSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Service Location</Text>
      <Text style={styles.stepSubtitle}>Where should we come to you?</Text>
      <Text style={styles.pricingNote}>💡 Prices vary by location based on demand & accessibility</Text>
      
      <View style={styles.optionsContainer}>
        {locations.map((location) => (
          <TouchableOpacity
            key={location.id}
            style={[
              styles.locationCard,
              selectedLocation === location.id && styles.selectedCard
            ]}
            onPress={() => handleLocationSelect(location)}
          >
            <LinearGradient
              colors={selectedLocation === location.id ? location.colors : ['#1E3A8A', '#87CEEB']}
              style={styles.locationGradient}
            >
              <Text style={styles.locationIcon}>{location.icon}</Text>
              <Text style={styles.locationName}>{location.name}</Text>
              {location.id === 'current' && (
                <View style={styles.instantBadge}>
                  <Text style={styles.instantBadgeText}>⚡ INSTANT</Text>
                </View>
              )}
              {location.description && (
                <Text style={styles.locationDescription}>{location.description}</Text>
              )}
              <Text style={styles.locationPricing}>
                {location.id === 'current' && '5% discount for convenience'}
                {location.id === 'home' && 'Standard pricing'}
                {location.id === 'work' && '+10% business premium'}
                {location.id === 'gym' && '+5% leisure premium'}
                {location.id === 'shopping' && '+15% high-traffic premium'}
                {location.id === 'airport' && '+25% premium location'}
                {location.id === 'hotel' && '+15% hospitality premium'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderPaymentStep = () => {
    const finalPrice = selectedService && selectedLocation && (selectedVehicle || selectedStoredVehicle)
      ? calculateDynamicPrice(
          selectedService,
          selectedLocation,
          selectedVehicle || { id: selectedStoredVehicle?.type.toLowerCase() || 'medium', name: '', description: '', icon: '', basePrice: 1.0, colors: [] }
        )
      : 0;
    
    return (
      <View style={styles.stepContent}>
        <Text style={styles.stepTitle}>Payment & Confirmation</Text>
        <Text style={styles.stepSubtitle}>Complete your booking with secure payment</Text>
        
        {/* Booking Summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Booking Summary</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Service:</Text>
            <Text style={styles.summaryValue}>{selectedService?.name}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Vehicle:</Text>
            <Text style={styles.summaryValue}>
              {selectedStoredVehicle ? `${selectedStoredVehicle.make} ${selectedStoredVehicle.model}` : selectedVehicle?.name}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Location:</Text>
            <Text style={styles.summaryValue}>{selectedLocation?.name}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Total Price:</Text>
            <Text style={styles.summaryValue}>£{finalPrice}</Text>
          </View>
        </View>

        {/* Payment Method */}
        <View style={styles.paymentSection}>
          <Text style={styles.paymentTitle}>Payment Method</Text>
          
          {/* Mock Stripe Payment Methods */}
          <View style={styles.paymentMethods}>
            <TouchableOpacity style={[styles.paymentMethod, styles.selectedPaymentMethod]}>
              <Text style={styles.paymentIcon}>💳</Text>
              <Text style={styles.paymentText}>Card ending in ****1234</Text>
              <Text style={styles.paymentChange}>Default</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.paymentMethod}>
              <Text style={styles.paymentIcon}>🍎</Text>
              <Text style={styles.paymentText}>Apple Pay</Text>
              <Text style={styles.paymentChange}>Use</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.paymentMethod}>
              <Text style={styles.paymentIcon}>📱</Text>
              <Text style={styles.paymentText}>Google Pay</Text>
              <Text style={styles.paymentChange}>Use</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Mock Stripe Security Notice */}
        <View style={styles.securityNotice}>
          <Text style={styles.securityIcon}>🔒</Text>
          <Text style={styles.securityText}>Your payment is secured by Stripe</Text>
        </View>

        {/* Mock Stripe Processing Info */}
        <View style={styles.processingInfo}>
          <Text style={styles.processingText}>
            💳 Payment will be processed securely through Stripe
          </Text>
          <Text style={styles.processingText}>
            🔄 You'll be redirected to Stripe for payment confirmation
          </Text>
        </View>

        {/* Confirm Button */}
        <TouchableOpacity
          style={styles.confirmButton}
          onPress={handlePaymentConfirm}
          disabled={isProcessing}
        >
          <LinearGradient
            colors={['#10B981', '#059669']}
            style={styles.confirmButtonGradient}
          >
            <Text style={styles.confirmButtonText}>
              {isProcessing ? 'Processing Payment...' : `Pay £${finalPrice} & Book`}
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    );
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return renderVehicleSelection();
      case 2:
        return renderServiceSelection();
      case 3:
        return renderLocationSelection();
      case 4:
        return renderPaymentStep();
      default:
        return renderVehicleSelection();
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wish your wash? 🚿</Text>
        <View style={styles.headerSpacer} />
      </View>

      {/* Step Indicator */}
      {renderStepIndicator()}

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {renderCurrentStep()}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  stepIndicator: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  stepContainer: {
    alignItems: 'center',
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepActive: {
    backgroundColor: '#10B981',
  },
  stepInactive: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  stepNumber: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  stepNumberActive: {
    color: '#FFFFFF',
  },
  stepNumberInactive: {
    color: '#9CA3AF',
  },
  stepLine: {
    width: 40,
    height: 2,
    marginHorizontal: 8,
  },
  stepLineActive: {
    backgroundColor: '#10B981',
  },
  stepLineInactive: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  stepLabel: {
    color: '#1E3A8A',
    fontSize: isSmallScreen ? 12 : 14,
    marginTop: 8,
  },
  content: {
    flex: 1,
  },
  stepContent: {
    width: width,
    paddingHorizontal: isSmallScreen ? 16 : 20,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 16 : 18,
    textAlign: 'center',
    marginBottom: 32,
  },
  optionsContainer: {
    gap: 16,
  },
  serviceCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  selectedCard: {
    elevation: 12,
    shadowOpacity: 0.4,
  },
  serviceGradient: {
    padding: isSmallScreen ? 12 : 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  serviceName: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
  },
  servicePrice: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
  },
  serviceDescription: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 10 : 12,
    opacity: 0.9,
    textAlign: 'center',
    marginBottom: 8,
  },
  serviceDetails: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  serviceFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  serviceDuration: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 10 : 12,
    opacity: 0.9,
  },
  serviceFeatures: {
    gap: 2,
  },
  serviceFeature: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 9 : 10,
    opacity: 0.9,
  },
  vehicleCard: {
    width: 160,
    marginRight: 16,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  vehicleGradient: {
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 140,
  },
  vehicleIcon: {
    fontSize: isSmallScreen ? 32 : 36, // Increased from 24/28
    marginBottom: 10, // Increased from 8
  },
  vehicleName: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18, // Increased from 14/16
    fontWeight: 'bold',
    marginBottom: 6, // Increased from 4
    textAlign: 'center',
  },
  vehicleDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14, // Increased from 10/12
    textAlign: 'center',
    marginBottom: 8, // Increased from 6
  },
  vehicleMultiplier: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14, // Increased from 10/12
    opacity: 0.9,
    textAlign: 'center',
  },
  locationCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  locationGradient: {
    padding: isSmallScreen ? 12 : 16,
    alignItems: 'center',
  },
  locationIcon: {
    fontSize: isSmallScreen ? 24 : 28,
    marginBottom: 8,
  },
  locationName: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'center',
  },
  locationDescription: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 10 : 12,
    textAlign: 'center',
    marginBottom: 6,
  },
  locationPricing: {
    color: '#1E3A8A',
    fontSize: isSmallScreen ? 10 : 12,
    marginTop: 6,
    textAlign: 'center',
  },
  timeCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  timeGradient: {
    padding: isSmallScreen ? 12 : 16,
    alignItems: 'center',
  },
  timeIcon: {
    fontSize: isSmallScreen ? 24 : 28,
    marginBottom: 8,
  },
  timeName: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'center',
  },
  timePricing: {
    color: '#1E3A8A',
    fontSize: isSmallScreen ? 10 : 12,
    marginTop: 6,
    textAlign: 'center',
  },
  pricingNote: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    textAlign: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  bookingSummary: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryLabel: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '500',
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
  },
  summaryPrice: {
    color: '#10B981',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    textAlign: 'right',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    marginTop: 16,
  },
  paymentSection: {
    marginBottom: 24,
  },
  paymentTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginTop: 8,
  },
  paymentIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  paymentText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    flex: 1,
  },
  paymentChange: {
    color: '#3B82F6',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
  },
  paymentMethods: {
    gap: 12,
  },
  securityNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginTop: 16,
    alignItems: 'center',
  },
  securityIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  securityText: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
    flex: 1,
  },
  confirmButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
  },
  confirmButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
  },
  instantBadge: {
    backgroundColor: '#10B981',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginTop: 6,
  },
  instantBadgeText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 10 : 12,
    fontWeight: 'bold',
  },
  storedVehiclesSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  storedVehiclesList: {
    flexDirection: 'row',
  },
  storedVehiclesContainer: {
    marginBottom: 24,
  },
  storedVehiclesContent: {
    paddingHorizontal: 10, // Add some horizontal padding for the scroll view
  },
  storedVehicleCard: {
    width: 140,
    marginRight: 16,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  selectedStoredVehicleCard: {
    borderWidth: 2,
    borderColor: '#10B981',
  },
  storedVehicleGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
  },
  storedVehicleIcon: {
    fontSize: 28,
    marginBottom: 8,
  },
  storedVehicleName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  storedVehicleReg: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 9 : 10,
    marginBottom: 4,
  },
  vehicleTypesContainer: {
    marginBottom: 24,
  },
  vehicleTypesContent: {
    paddingHorizontal: 10, // Add some horizontal padding for the scroll view
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
    marginHorizontal: 10,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  dividerText: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginHorizontal: 10,
  },
  vehicleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    gap: 20,
  },
  selectedVehicleGradient: {
    borderWidth: 3,
    borderColor: '#10B981',
  },
  vehicleGradientInner: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16, // Increased from 12
  },
  selectedVehicleSummary: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
    alignItems: 'center',
  },
  summaryContent: {
    alignItems: 'center',
  },
  summaryText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  summarySubtext: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
  },
  summaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryLabel: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 14 : 16,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
  },
  nextButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
  },
  nextButtonDisabled: {
    opacity: 0.6,
  },
  nextButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
  },
  selectedPaymentMethod: {
    borderWidth: 2,
    borderColor: '#3B82F6', // Highlight the selected payment method
  },
  processingInfo: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    alignItems: 'center',
  },
  processingText: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    textAlign: 'center',
    marginBottom: 8,
  },
});
