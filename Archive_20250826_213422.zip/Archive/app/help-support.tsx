import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Modal,
  TextInput,
  FlatList,
  Linking,
  Dimensions,
} from 'react-native';
import { router } from 'expo-router';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function HelpSupport() {
  const { user } = useAuth();
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);
  const [showWebChat, setShowWebChat] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{id: string, message: string, isUser: boolean, timestamp: Date, type?: 'ai' | 'human' | 'system'}>>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<string>('');
  const [issueDescription, setIssueDescription] = useState('');

  const isValeter = user?.userType === 'valeter';

  // Comprehensive FAQ with smart responses
  const faqs = [
    {
      id: '1',
      question: 'How do I book a car wash service?',
      answer: 'Simply tap "Instant Wash" on your dashboard, select your vehicle type, choose your preferred service (Basic Wash, Premium Wash, Full Valet, etc.), set your location, and confirm payment. A valeter will be notified and can accept your job within minutes.',
      category: 'booking'
    },
    {
      id: '2',
      question: 'What is the cancellation policy?',
      answer: 'For instant bookings: Cancel within 5 minutes for full refund, within 15 minutes for 90% refund, within 30 minutes for 75% refund, within 1 hour for 50% refund, within 2 hours for 25% refund. After 2 hours, no refund is available. Refunds are processed within 24-48 hours to your original payment method.',
      category: 'refunds'
    },
    {
      id: '3',
      question: 'How do I track my valeter?',
      answer: 'Once a valeter accepts your job, you can track them in real-time through the tracking screen. You\'ll see their location, estimated arrival time, and can communicate directly through the app. The tracking updates every 30 seconds.',
      category: 'tracking'
    },
    {
      id: '4',
      question: 'What payment methods are accepted?',
      answer: 'We accept all major credit/debit cards (Visa, Mastercard, American Express), PayPal, Apple Pay, and Google Pay. All payments are processed securely through Stripe and your card details are never stored on our servers.',
      category: 'payments'
    },
    {
      id: '5',
      question: 'How do I become a valeter?',
      answer: 'To become a valeter, download the app and select "Join as Valeter". Complete our verification process including document upload (driving license, insurance, DBS check), background checks, and vehicle inspection. Verification typically takes 3-5 business days.',
      category: 'valeter'
    },
    {
      id: '6',
      question: 'What if I\'m not satisfied with the service?',
      answer: 'If you\'re not satisfied, please contact us within 24 hours of service completion. We\'ll investigate and may offer a full refund, partial refund, or free re-service. Your satisfaction is our priority and we aim to resolve all issues within 48 hours.',
      category: 'quality'
    },
    {
      id: '7',
      question: 'How do rewards and points work?',
      answer: 'Earn points for every booking (10 points per £1 spent), rating valeters (5 points), and referring friends (50 points per referral). Points can be redeemed for discounts, free services, and exclusive rewards. Bronze (0-500), Silver (501-1500), Gold (1501-3000), Platinum (3000+).',
      category: 'rewards'
    },
    {
      id: '8',
      question: 'Is my data secure?',
      answer: 'Yes, we use industry-standard encryption (256-bit SSL) and security measures to protect your personal and payment information. We never share your data with third parties without consent and comply with GDPR regulations.',
      category: 'security'
    },
    {
      id: '9',
      question: 'How do I report an issue?',
      answer: 'You can report issues through the "Report an Issue" button in Help & Support, or contact us directly. Include your booking ID, description of the issue, and any photos. We typically respond within 2 hours and resolve issues within 24 hours.',
      category: 'support'
    },
    {
      id: '10',
      question: 'What are the service areas?',
      answer: 'We currently operate in London, Manchester, Birmingham, Leeds, Liverpool, and surrounding areas. Service availability depends on valeter coverage. Enter your postcode to check if we\'re available in your area.',
      category: 'coverage'
    },
    {
      id: '11',
      question: 'How do I change my booking?',
      answer: 'You can modify your booking up to 1 hour before the scheduled time through the app. Changes include service type, location, and time. Cancellations follow our refund policy. Contact support for urgent changes.',
      category: 'booking'
    },
    {
      id: '12',
      question: 'What if my valeter doesn\'t show up?',
      answer: 'If your valeter doesn\'t arrive within 15 minutes of the scheduled time, contact us immediately. We\'ll find you another valeter or provide a full refund. You\'ll also receive compensation for the inconvenience.',
      category: 'service'
    }
  ];

  const contactOptions = [
    {
      id: '1',
      title: 'Customer Support',
      subtitle: 'General inquiries and account help',
      icon: '📞',
      action: () => handleCallSupport(),
      phone: '+44 20 1234 5678',
      email: 'support@wishawash.com'
    },
    {
      id: '2',
      title: 'Technical Support',
      subtitle: 'App issues and technical problems',
      icon: '🔧',
      action: () => handleTechnicalSupport(),
      phone: '+44 20 1234 5679',
      email: 'tech@wishawash.com'
    },
    {
      id: '3',
      title: 'Emergency Contact',
      subtitle: 'Urgent issues during service',
      icon: '🚨',
      action: () => handleEmergencyContact(),
      phone: '+44 20 1234 5680',
      email: 'emergency@wishawash.com'
    },
    {
      id: '4',
      title: 'Feedback & Suggestions',
      subtitle: 'Help us improve our service',
      icon: '💬',
      action: () => handleFeedback(),
      phone: null,
      email: 'feedback@wishawash.com'
    },
  ];

  const quickActions = [
    {
      id: '1',
      title: 'Report an Issue',
      subtitle: 'Report service problems',
      icon: '⚠️',
      action: () => handleReportIssue(),
    },
    {
      id: '2',
      title: 'Request Refund',
      subtitle: 'Cancel and get refund',
      icon: '💰',
      action: () => handleRequestRefund(),
    },
    {
      id: '3',
      title: 'Update Profile',
      subtitle: 'Change account details',
      icon: '👤',
      action: () => router.push('/owner-profile'),
    },
    {
      id: '4',
      title: 'Privacy Settings',
      subtitle: 'Manage data preferences',
      icon: '🔒',
      action: () => handlePrivacySettings(),
    },
  ];

  const handleCallSupport = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Contact Customer Support',
        'Choose your preferred contact method:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📞 Call Now', 
            onPress: () => Linking.openURL('tel:+442012345678')
          },
          { 
            text: '📧 Send Email', 
            onPress: () => Linking.openURL('mailto:support@wishawash.com?subject=Customer Support Request')
          },
          { 
            text: '💬 Live Chat', 
            onPress: () => handleWebChat()
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleCallSupport:', error);
    }
  };

  const handleTechnicalSupport = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Technical Support',
        'For app issues and technical problems:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📞 Call Tech Support', 
            onPress: () => Linking.openURL('tel:+442012345679')
          },
          { 
            text: '📧 Email Tech Team', 
            onPress: () => Linking.openURL('mailto:tech@wishawash.com?subject=Technical Issue Report')
          },
          { 
            text: '🤖 AI Assistant', 
            onPress: () => handleAIChat()
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleTechnicalSupport:', error);
    }
  };

  const handleEmergencyContact = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        '🚨 Emergency Contact',
        'For urgent issues during active service:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📞 Emergency Hotline', 
            onPress: () => Linking.openURL('tel:+442012345680'),
            style: 'destructive'
          },
          { 
            text: '📧 Emergency Email', 
            onPress: () => Linking.openURL('mailto:emergency@wishawash.com?subject=URGENT: Service Issue')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleEmergencyContact:', error);
    }
  };

  const handleFeedback = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Feedback & Suggestions',
        'We value your input! Choose how to send feedback:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📧 Send Email', 
            onPress: () => Linking.openURL('mailto:feedback@wishawash.com?subject=Feedback & Suggestions')
          },
          { 
            text: '⭐ Rate App', 
            onPress: () => Linking.openURL('https://apps.apple.com/app/wish-a-wash')
          },
          { 
            text: '📝 Survey', 
            onPress: () => router.push('/feedback-survey')
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleFeedback:', error);
    }
  };

  const handleReportIssue = async () => {
    try {
      await hapticFeedback('light');
      router.push('/report-issue');
    } catch (error) {
      console.error('Error in handleReportIssue:', error);
    }
  };

  const handleRequestRefund = async () => {
    try {
      await hapticFeedback('light');
      router.push('/request-refund');
    } catch (error) {
      console.error('Error in handleRequestRefund:', error);
    }
  };

  const handlePrivacySettings = async () => {
    try {
      await hapticFeedback('light');
      router.push('/privacy-settings');
    } catch (error) {
      console.error('Error in handlePrivacySettings:', error);
    }
  };

  const toggleFAQ = async (id: string) => {
    try {
      await hapticFeedback('light');
      setExpandedFAQ(expandedFAQ === id ? null : id);
    } catch (error) {
      console.error('Error in toggleFAQ:', error);
    }
  };

  const handleWebChat = async () => {
    try {
      await hapticFeedback('medium');
      setShowWebChat(true);
      const welcomeMessage = isValeter
        ? 'Hello! Welcome to Wish a Wash valeter support. A human agent will be with you shortly to assist with your valeter-specific needs. Average wait time: 2-3 minutes.'
        : 'Hello! Welcome to Wish a Wash support. How can I help you today? Average wait time: 1-2 minutes.';
      
      setChatHistory([{
        id: '1',
        message: welcomeMessage,
        isUser: false,
        timestamp: new Date(),
        type: 'human'
      }]);
    } catch (error) {
      console.error('Error in handleWebChat:', error);
    }
  };

  const handleAIChat = async () => {
    try {
      await hapticFeedback('medium');
      setShowAIChat(true);
      const welcomeMessage = isValeter 
        ? 'Hi! I\'m Wish a Wash AI Assistant for valeters. I can help you with document uploads, payments, job assignments, verification status, and more. What would you like to know?'
        : 'Hi! I\'m Wish a Wash AI Assistant. I can help you with booking services, payments, tracking, refunds, and more. What would you like to know?';
      
      setChatHistory([{
        id: '1',
        message: welcomeMessage,
        isUser: false,
        timestamp: new Date(),
        type: 'ai'
      }]);
    } catch (error) {
      console.error('Error in handleAIChat:', error);
    }
  };

  const sendMessage = async () => {
    if (!chatMessage.trim()) return;

    try {
      const userMessage = {
        id: Date.now().toString(),
        message: chatMessage,
        isUser: true,
        timestamp: new Date()
      };

      setChatHistory(prev => [...prev, userMessage]);
      setChatMessage('');
      setIsTyping(true);

      // AI response logic with intelligent escalation
      setTimeout(() => {
        const userMessageLower = chatMessage.toLowerCase();
        let aiResponse = '';
        let shouldEscalate = false;

        // Check if AI can handle the issue based on user type
        if (isValeter) {
          // Valeter-specific responses
          if (userMessageLower.includes('online') || userMessageLower.includes('go online')) {
            aiResponse = 'To go online, make sure all your documents are uploaded and verified. Check your Documents section in the app. If you\'re still having issues, I can help you check your verification status.';
          } else if (userMessageLower.includes('payment') || userMessageLower.includes('not received') || userMessageLower.includes('earnings')) {
            aiResponse = 'Payments are processed weekly on Fridays. If you haven\'t received your payment, please check your bank details in your profile. Payments can take 2-3 business days to appear. If it\'s been longer, I can escalate this to our payment team.';
          } else if (userMessageLower.includes('document') || userMessageLower.includes('upload')) {
            aiResponse = 'You can upload documents in the Documents section of your profile. Make sure files are clear and readable. Verification typically takes 24-48 hours. If you need help with specific documents, let me know!';
          } else if (userMessageLower.includes('insurance') || userMessageLower.includes('verification')) {
            aiResponse = 'Insurance verification is required for all valeters. Please upload your current insurance certificate. If you need help, I can guide you through the process or connect you with our verification team.';
          } else if (userMessageLower.includes('background') || userMessageLower.includes('check')) {
            aiResponse = 'Background checks are processed within 5-7 business days. You\'ll receive a notification when it\'s complete. If it\'s been longer, let me connect you with our verification team.';
          } else if (userMessageLower.includes('job') || userMessageLower.includes('assignment')) {
            aiResponse = 'Jobs are assigned based on your location and availability. Make sure your location services are enabled and you\'re in an active service area. If you\'re not receiving jobs, I can help troubleshoot.';
          } else if (userMessageLower.includes('rating') || userMessageLower.includes('review')) {
            aiResponse = 'Customer ratings are important for your profile. Maintain high quality service and respond promptly to customer messages. If you receive an unfair rating, you can appeal through the app.';
          } else if (userMessageLower.includes('emergency') || userMessageLower.includes('urgent')) {
            shouldEscalate = true;
            aiResponse = 'This sounds urgent. Let me connect you with a human agent immediately for faster assistance.';
          } else {
            aiResponse = 'I understand your question. While I can help with general information, for specific account issues, I recommend speaking with our support team. Would you like me to connect you with a human agent?';
            shouldEscalate = true;
          }
        } else {
          // Customer-specific responses
          if (userMessageLower.includes('booking') || userMessageLower.includes('book')) {
            aiResponse = 'To book a service, tap "Instant Wash" on your dashboard, select your vehicle type, choose your service, set your location, and confirm payment. The process takes about 2 minutes and a valeter will be assigned within 5-10 minutes.';
          } else if (userMessageLower.includes('refund') || userMessageLower.includes('cancel')) {
            aiResponse = 'You can request a refund through the "Request Refund" option in Help & Support. Include your booking ID and reason. Refunds are processed within 24-48 hours. For urgent cancellations, contact our emergency line.';
          } else if (userMessageLower.includes('tracking') || userMessageLower.includes('where')) {
            aiResponse = 'Once your valeter accepts the job, you can track them in real-time through the tracking screen. Updates every 30 seconds. If tracking isn\'t working, try refreshing the app or contact support.';
          } else if (userMessageLower.includes('payment') || userMessageLower.includes('charge')) {
            aiResponse = 'We accept all major cards, PayPal, Apple Pay, and Google Pay. Payments are processed securely through Stripe. If you see an unexpected charge, contact us immediately and we\'ll investigate.';
          } else if (userMessageLower.includes('quality') || userMessageLower.includes('satisfied')) {
            aiResponse = 'If you\'re not satisfied with the service, contact us within 24 hours. We\'ll investigate and may offer a refund or free re-service. Your satisfaction is our priority.';
          } else if (userMessageLower.includes('rewards') || userMessageLower.includes('points')) {
            aiResponse = 'Earn points for every booking (10 points per £1), rating valeters (5 points), and referring friends (50 points). Redeem for discounts and free services. Check your tier level in your profile.';
          } else if (userMessageLower.includes('emergency') || userMessageLower.includes('urgent')) {
            shouldEscalate = true;
            aiResponse = 'This sounds urgent. Let me connect you with a human agent immediately for faster assistance.';
          } else {
            aiResponse = 'I understand your question. While I can help with general information, for specific account issues, I recommend speaking with our support team. Would you like me to connect you with a human agent?';
            shouldEscalate = true;
          }
        }

        const aiMessage = {
          id: (Date.now() + 1).toString(),
          message: aiResponse,
          isUser: false,
          timestamp: new Date(),
          type: shouldEscalate ? 'human' : 'ai'
        };

        setChatHistory(prev => [...prev, aiMessage]);
        setIsTyping(false);

        if (shouldEscalate) {
          setTimeout(() => {
            const escalationMessage = {
              id: (Date.now() + 2).toString(),
              message: 'Connecting you with a human agent... Please wait.',
              isUser: false,
              timestamp: new Date(),
              type: 'system'
            };
            setChatHistory(prev => [...prev, escalationMessage]);
          }, 2000);
        }
      }, 1500);
    } catch (error) {
      console.error('Error in sendMessage:', error);
      setIsTyping(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Help & Support</Text>
          <View style={styles.headerSpacer} />
        </View>

        {/* Chat Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Get Help</Text>
          <View style={styles.chatOptionsGrid}>
            <TouchableOpacity style={styles.chatOption} onPress={handleWebChat}>
              <Text style={styles.chatOptionIcon}>👨‍💼</Text>
              <Text style={styles.chatOptionTitle}>Live Chat</Text>
              <Text style={styles.chatOptionSubtitle}>Speak with a human agent</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.chatOption} onPress={handleAIChat}>
              <Text style={styles.chatOptionIcon}>🤖</Text>
              <Text style={styles.chatOptionTitle}>AI Assistant</Text>
              <Text style={styles.chatOptionSubtitle}>Instant help with AI</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.quickActionsGrid}>
            {quickActions.map((action) => (
              <TouchableOpacity key={action.id} style={styles.quickAction} onPress={action.action}>
                <Text style={styles.quickActionIcon}>{action.icon}</Text>
                <Text style={styles.quickActionTitle}>{action.title}</Text>
                <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Contact Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contact Us</Text>
          <View style={styles.contactGrid}>
            {contactOptions.map((contact) => (
              <TouchableOpacity key={contact.id} style={styles.contactOption} onPress={contact.action}>
                <Text style={styles.contactIcon}>{contact.icon}</Text>
                <View style={styles.contactInfo}>
                  <Text style={styles.contactTitle}>{contact.title}</Text>
                  <Text style={styles.contactSubtitle}>{contact.subtitle}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* FAQ Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
          <View style={styles.faqContainer}>
            {faqs.map((faq) => (
              <TouchableOpacity
                key={faq.id}
                style={styles.faqItem}
                onPress={() => toggleFAQ(faq.id)}
              >
                <View style={styles.faqHeader}>
                  <Text style={styles.faqQuestion}>{faq.question}</Text>
                  <Text style={styles.faqToggle}>
                    {expandedFAQ === faq.id ? '−' : '+'}
                  </Text>
                </View>
                {expandedFAQ === faq.id && (
                  <Text style={styles.faqAnswer}>{faq.answer}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Troubleshooting */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Common Issues</Text>
          <View style={styles.troubleshootingCard}>
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>📱</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>App not working?</Text>
                <Text style={styles.issueDescription}>Try restarting the app or updating to the latest version</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>💳</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Payment issues?</Text>
                <Text style={styles.issueDescription}>Check your card details or try a different payment method</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>🚗</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>No valeters available?</Text>
                <Text style={styles.issueDescription}>Try adjusting your location or service time</Text>
              </View>
            </View>
            
            <View style={styles.issueItem}>
              <Text style={styles.issueIcon}>⏰</Text>
              <View style={styles.issueInfo}>
                <Text style={styles.issueTitle}>Long wait times?</Text>
                <Text style={styles.issueDescription}>Peak hours may have longer wait times. Try booking in advance</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Legal Links */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal</Text>
          <View style={styles.legalGrid}>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/terms-of-service')}>
              <Text style={styles.legalLinkText}>Terms of Service</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/privacy-policy')}>
              <Text style={styles.legalLinkText}>Privacy Policy</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.legalLink} onPress={() => router.push('/cookie-policy')}>
              <Text style={styles.legalLinkText}>Cookie Policy</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoCard}>
          <Text style={styles.appInfoTitle}>Wish a Wash</Text>
          <Text style={styles.appInfoVersion}>Version 1.0.0</Text>
          <Text style={styles.appInfoCopyright}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>

      {/* Web Chat Modal */}
      <Modal visible={showWebChat} animationType="slide">
        <SafeAreaView style={styles.chatContainer}>
          <View style={styles.chatHeader}>
            <TouchableOpacity onPress={() => setShowWebChat(false)} style={styles.chatBackButton}>
              <Text style={styles.chatBackButtonText}>←</Text>
            </TouchableOpacity>
            <Text style={styles.chatTitle}>
              Live Chat Support
            </Text>
          </View>
          
          <ScrollView style={styles.chatMessages}>
            {chatHistory.map((message) => (
              <View key={message.id} style={[
                styles.messageContainer,
                message.isUser ? styles.userMessage : styles.agentMessage
              ]}>
                <Text style={[
                  styles.messageText,
                  message.isUser ? styles.userMessageText : styles.agentMessageText
                ]}>
                  {message.message}
                </Text>
                <Text style={styles.messageTime}>
                  {message.timestamp.toLocaleTimeString()}
                </Text>
              </View>
            ))}
            {isTyping && (
              <View style={styles.typingIndicator}>
                <Text style={styles.typingText}>Agent is typing...</Text>
              </View>
            )}
          </ScrollView>
          
          <View style={styles.chatInputContainer}>
            <TextInput
              style={styles.chatInput}
              value={chatMessage}
              onChangeText={setChatMessage}
              placeholder="Type your message..."
              placeholderTextColor="#9CA3AF"
              multiline
            />
            <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>

      {/* AI Chat Modal */}
      <Modal visible={showAIChat} animationType="slide">
        <SafeAreaView style={styles.chatContainer}>
          <View style={styles.chatHeader}>
            <TouchableOpacity onPress={() => setShowAIChat(false)} style={styles.chatBackButton}>
              <Text style={styles.chatBackButtonText}>←</Text>
            </TouchableOpacity>
            <Text style={styles.chatTitle}>
              AI Assistant
            </Text>
          </View>
          
          <ScrollView style={styles.chatMessages}>
            {chatHistory.map((message) => (
              <View key={message.id} style={[
                styles.messageContainer,
                message.isUser ? styles.userMessage : styles.aiMessage
              ]}>
                <Text style={[
                  styles.messageText,
                  message.isUser ? styles.userMessageText : styles.aiMessageText
                ]}>
                  {message.message}
                </Text>
                <Text style={styles.messageTime}>
                  {message.timestamp.toLocaleTimeString()}
                </Text>
              </View>
            ))}
            {isTyping && (
              <View style={styles.typingIndicator}>
                <Text style={styles.typingText}>AI is thinking...</Text>
              </View>
            )}
          </ScrollView>
          
          <View style={styles.chatInputContainer}>
            <TextInput
              style={styles.chatInput}
              value={chatMessage}
              onChangeText={setChatMessage}
              placeholder="Ask me anything..."
              placeholderTextColor="#9CA3AF"
              multiline
            />
            <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
              <Text style={styles.sendButtonText}>Send</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 60,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickAction: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  contactGrid: {
    gap: 12,
  },
  contactOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  contactIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  contactInfo: {
    flex: 1,
  },
  contactTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  contactSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
  },
  faqContainer: {
    gap: 12,
  },
  faqItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  faqHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  faqQuestion: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    marginRight: 16,
  },
  faqToggle: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  faqAnswer: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
  troubleshootingCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  troubleshootingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  issueItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  issueIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  issueInfo: {
    flex: 1,
  },
  issueTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  issueDescription: {
    color: '#87CEEB',
    fontSize: 12,
    lineHeight: 16,
  },
  legalGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  legalLink: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  legalLinkText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  appInfoCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    marginHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  appInfoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  appInfoVersion: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
  },
  appInfoCopyright: {
    color: '#9CA3AF',
    fontSize: 10,
    textAlign: 'center',
  },
  // Chat styles
  chatOptionsGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  chatOption: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  chatOptionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  chatOptionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 4,
  },
  chatOptionSubtitle: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  chatContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  chatBackButton: {
    padding: 8,
  },
  chatBackButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  chatTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  chatMessages: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 12,
    maxWidth: '80%',
  },
  userMessage: {
    alignSelf: 'flex-end',
    backgroundColor: '#87CEEB',
    borderRadius: 16,
    padding: 12,
    borderBottomRightRadius: 4,
  },
  agentMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  aiMessage: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  userMessageText: {
    color: '#0A1929',
    fontWeight: '500',
  },
  agentMessageText: {
    color: '#F9FAFB',
  },
  aiMessageText: {
    color: '#F9FAFB',
  },
  messageTime: {
    fontSize: 10,
    color: '#9CA3AF',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  typingIndicator: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 12,
    borderBottomLeftRadius: 4,
  },
  typingText: {
    color: '#87CEEB',
    fontSize: 12,
    fontStyle: 'italic',
  },
  chatInputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
  },
  chatInput: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#F9FAFB',
    fontSize: 14,
    marginRight: 8,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  quickRepliesContainer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  quickReplyButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 8,
    marginRight: 8,
  },
  quickReplyText: {
    color: '#F9FAFB',
    fontSize: 14,
  },
});
