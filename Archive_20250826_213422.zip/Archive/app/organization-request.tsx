import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  Modal,
  Dimensions,
  Animated,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from '../src/lib/api/real/supabaseClient';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

interface Organization {
  id: string;
  name: string;
  description: string;
  location: string;
  verified: boolean;
  contactEmail: string;
}

export default function OrganizationRequest() {
  const { user, updateUser } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedOrganization, setSelectedOrganization] = useState<string | null>(null);
  const [showOrganizationModal, setShowOrganizationModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [requestSubmitted, setRequestSubmitted] = useState(false);
  
  // Form data
  const [formData, setFormData] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    experience: '',
    whyJoin: '',
    idDocument: null as any,
  });

  // Animation values
  const fadeAnim = useState(new Animated.Value(0))[0];
  const slideAnim = useState(new Animated.Value(50))[0];

  const organizations: Organization[] = [
    {
      id: 'org_1',
      name: 'Elite Valet Services Ltd',
      description: 'Premium car care services across London and surrounding areas',
      location: 'London, UK',
      verified: true,
      contactEmail: 'hr@elitevalet.com',
    },
    {
      id: 'org_2',
      name: 'Premium Car Care Ltd',
      description: 'Professional valeting services with mobile and fixed locations',
      location: 'Manchester, UK',
      verified: true,
      contactEmail: 'careers@premiumcarcare.co.uk',
    },
    {
      id: 'org_3',
      name: 'Quick Clean Pro Ltd',
      description: 'Fast and efficient car cleaning services',
      location: 'Birmingham, UK',
      verified: false,
      contactEmail: 'join@quickcleanpro.com',
    },
  ];

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleOrganizationSelect = (orgId: string) => {
    setSelectedOrganization(orgId);
    setShowOrganizationModal(false);
    setCurrentStep(1);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleIdUpload = async () => {
    try {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Please grant permission to access your media library');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setFormData(prev => ({ ...prev, idDocument: result.assets[0] }));
        Alert.alert('Success', 'ID document uploaded successfully!');
      }
    } catch (error) {
      console.error('Error uploading ID:', error);
      Alert.alert('Error', 'Failed to upload ID document');
    }
  };

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 0:
        return selectedOrganization !== null;
      case 1:
        return formData.fullName && formData.email && formData.phone;
      case 2:
        return formData.experience && formData.whyJoin;
      case 3:
        return formData.idDocument !== null;
      default:
        return false;
    }
  };

  const handleNextStep = () => {
    if (canProceedToNextStep()) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePreviousStep = () => {
    setCurrentStep(prev => Math.max(0, prev - 1));
  };

  const handleSubmitRequest = async () => {
    if (!selectedOrganization || !formData.idDocument) {
      Alert.alert('Error', 'Please complete all required fields');
      return;
    }

    setIsLoading(true);
    
    try {
      // Create organization request using Supabase
      const success = await SupabaseService.createOrganizationRequest({
        userId: user?.id || '',
        organizationId: selectedOrganization,
        status: 'pending',
        submittedAt: new Date().toISOString(),
      });

      if (!success) {
        throw new Error('Failed to create organization request');
      }

      // Update user profile
      if (user) {
        await updateUser({
          ...user,
          organizationRequest: {
            organizationId: selectedOrganization,
            status: 'pending',
            submittedAt: new Date().toISOString(),
          },
        });
      }

      setRequestSubmitted(true);
      
      // Set onboarding completion
      await AsyncStorage.setItem('organization_request_seen', 'true');
      await AsyncStorage.setItem('onboarding_seen', 'true');
      
    } catch (error) {
      console.error('Error submitting request:', error);
      Alert.alert('Error', 'Failed to submit request. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const selectedOrg = organizations.find(org => org.id === selectedOrganization);

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.stepTitle}>Choose Organization</Text>
            <Text style={styles.stepDescription}>
              Select the organization you'd like to join. You'll only need to provide basic ID verification.
            </Text>
            
            <TouchableOpacity
              style={styles.organizationSelector}
              onPress={() => setShowOrganizationModal(true)}
            >
              <Text style={styles.selectorText}>
                {selectedOrg ? selectedOrg.name : 'Select an organization...'}
              </Text>
              <Text style={styles.selectorIcon}>▼</Text>
            </TouchableOpacity>
          </View>
        );

      case 1:
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.stepTitle}>Personal Information</Text>
            <Text style={styles.stepDescription}>
              Provide your basic contact information.
            </Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Full Name *</Text>
              <TextInput
                style={styles.input}
                value={formData.fullName}
                onChangeText={(value) => handleInputChange('fullName', value)}
                placeholder="Enter your full name"
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Email *</Text>
              <TextInput
                style={styles.input}
                value={formData.email}
                onChangeText={(value) => handleInputChange('email', value)}
                placeholder="Enter your email"
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Phone Number *</Text>
              <TextInput
                style={styles.input}
                value={formData.phone}
                onChangeText={(value) => handleInputChange('phone', value)}
                placeholder="Enter your phone number"
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                keyboardType="phone-pad"
              />
            </View>
          </View>
        );

      case 2:
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.stepTitle}>Experience & Motivation</Text>
            <Text style={styles.stepDescription}>
              Tell us about your experience and why you want to join.
            </Text>
            
            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Experience *</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.experience}
                onChangeText={(value) => handleInputChange('experience', value)}
                placeholder="Describe your valeting experience..."
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Why Join This Organization? *</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={formData.whyJoin}
                onChangeText={(value) => handleInputChange('whyJoin', value)}
                placeholder="Explain why you want to join this organization..."
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                multiline
                numberOfLines={4}
              />
            </View>
          </View>
        );

      case 3:
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.stepTitle}>ID Verification</Text>
            <Text style={styles.stepDescription}>
              Upload a photo of your ID (passport, driving license, or national ID).
            </Text>
            
            <TouchableOpacity
              style={styles.uploadButton}
              onPress={handleIdUpload}
            >
              <Text style={styles.uploadIcon}>📷</Text>
              <Text style={styles.uploadText}>
                {formData.idDocument ? 'ID Document Uploaded ✓' : 'Upload ID Document'}
              </Text>
            </TouchableOpacity>

            {formData.idDocument && (
              <View style={styles.uploadedFile}>
                <Text style={styles.uploadedFileText}>✓ Document uploaded successfully</Text>
              </View>
            )}
          </View>
        );

      case 4:
        return (
          <View style={styles.stepContainer}>
            <Text style={styles.stepTitle}>Review & Submit</Text>
            <Text style={styles.stepDescription}>
              Review your information before submitting your request.
            </Text>
            
            <View style={styles.reviewCard}>
              <Text style={styles.reviewTitle}>Request Summary</Text>
              
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Organization:</Text>
                <Text style={styles.reviewValue}>{selectedOrg?.name}</Text>
              </View>
              
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Name:</Text>
                <Text style={styles.reviewValue}>{formData.fullName}</Text>
              </View>
              
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Email:</Text>
                <Text style={styles.reviewValue}>{formData.email}</Text>
              </View>
              
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>Phone:</Text>
                <Text style={styles.reviewValue}>{formData.phone}</Text>
              </View>
              
              <View style={styles.reviewItem}>
                <Text style={styles.reviewLabel}>ID Document:</Text>
                <Text style={styles.reviewValue}>✓ Uploaded</Text>
              </View>
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  if (requestSubmitted) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={styles.gradient}
        >
          <View style={styles.successContainer}>
            <Text style={styles.successIcon}>✅</Text>
            <Text style={styles.successTitle}>Request Submitted!</Text>
            <Text style={styles.successDescription}>
              Your request to join {selectedOrg?.name} has been submitted successfully.
            </Text>
            <Text style={styles.successInfo}>
              The organization will review your application and contact you within 2-3 business days.
            </Text>
            
            <TouchableOpacity
              style={styles.successButton}
              onPress={() => router.replace('/owner-dashboard')}
            >
              <Text style={styles.successButtonText}>Go to Dashboard</Text>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={styles.gradient}
      >
        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => router.back()}
            >
              <Text style={styles.backButtonText}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Join Organization</Text>
            <View style={styles.headerSpacer} />
          </View>

          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${((currentStep + 1) / 5) * 100}%` },
                ]}
              />
            </View>
            <Text style={styles.progressText}>
              Step {currentStep + 1} of 5
            </Text>
          </View>

          {/* Step Content */}
          <ScrollView style={styles.scrollContent} showsVerticalScrollIndicator={false}>
            {renderStepContent()}
          </ScrollView>

          {/* Navigation Buttons */}
          <View style={styles.navigationContainer}>
            {currentStep > 0 && (
              <TouchableOpacity
                style={styles.navButton}
                onPress={handlePreviousStep}
              >
                <Text style={styles.navButtonText}>Previous</Text>
              </TouchableOpacity>
            )}
            
            {currentStep < 4 ? (
              <TouchableOpacity
                style={[
                  styles.navButton,
                  styles.primaryButton,
                  !canProceedToNextStep() && styles.disabledButton,
                ]}
                onPress={handleNextStep}
                disabled={!canProceedToNextStep()}
              >
                <Text style={styles.primaryButtonText}>Next</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={[
                  styles.navButton,
                  styles.primaryButton,
                  (isLoading || !canProceedToNextStep()) && styles.disabledButton,
                ]}
                onPress={handleSubmitRequest}
                disabled={isLoading || !canProceedToNextStep()}
              >
                <Text style={styles.primaryButtonText}>
                  {isLoading ? 'Submitting...' : 'Submit Request'}
                </Text>
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>

        {/* Organization Selection Modal */}
        <Modal
          visible={showOrganizationModal}
          animationType="slide"
          presentationStyle="pageSheet"
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Organization</Text>
              <TouchableOpacity onPress={() => setShowOrganizationModal(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.modalContent}>
              {organizations.map((org) => (
                <TouchableOpacity
                  key={org.id}
                  style={styles.orgCard}
                  onPress={() => handleOrganizationSelect(org.id)}
                >
                  <View style={styles.orgHeader}>
                    <Text style={styles.orgName}>{org.name}</Text>
                    {org.verified && (
                      <Text style={styles.verifiedBadge}>✓ Verified</Text>
                    )}
                  </View>
                  <Text style={styles.orgDescription}>{org.description}</Text>
                  <Text style={styles.orgLocation}>📍 {org.location}</Text>
                  <Text style={styles.orgContact}>📧 {org.contactEmail}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </Modal>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 15,
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 60,
  },
  progressContainer: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#0EA5E9',
    borderRadius: 2,
  },
  progressText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
  },
  scrollContent: {
    flex: 1,
    paddingHorizontal: 20,
  },
  stepContainer: {
    marginBottom: 30,
  },
  stepTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  stepDescription: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 16,
    marginBottom: 25,
    lineHeight: 22,
  },
  organizationSelector: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  selectorText: {
    color: '#FFFFFF',
    fontSize: 16,
    flex: 1,
  },
  selectorIcon: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    color: '#FFFFFF',
    fontSize: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  uploadButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderStyle: 'dashed',
  },
  uploadIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  uploadText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  uploadedFile: {
    backgroundColor: 'rgba(0, 255, 0, 0.1)',
    borderRadius: 8,
    padding: 12,
    marginTop: 12,
    borderWidth: 1,
    borderColor: 'rgba(0, 255, 0, 0.3)',
  },
  uploadedFileText: {
    color: '#4ADE80',
    fontSize: 14,
    textAlign: 'center',
  },
  reviewCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  reviewTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  reviewItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  reviewLabel: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 14,
  },
  reviewValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  navButton: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  primaryButton: {
    backgroundColor: '#0EA5E9',
  },
  disabledButton: {
    opacity: 0.5,
  },
  navButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  successContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  successIcon: {
    fontSize: 80,
    marginBottom: 20,
  },
  successTitle: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  successDescription: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 24,
  },
  successInfo: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 20,
  },
  successButton: {
    backgroundColor: '#0EA5E9',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  successButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  modalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  modalClose: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  orgCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  orgHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  orgName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  verifiedBadge: {
    color: '#4ADE80',
    fontSize: 12,
    fontWeight: '600',
  },
  orgDescription: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 14,
    marginBottom: 8,
    lineHeight: 20,
  },
  orgLocation: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 12,
    marginBottom: 4,
  },
  orgContact: {
    color: 'rgba(255, 255, 255, 0.7)',
    fontSize: 12,
  },
});
