import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';

interface Message {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderType: 'customer' | 'valeter' | 'admin';
  timestamp: Date;
  isRead: boolean;
}

interface ChatRoom {
  id: string;
  participants: string[];
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
}

export default function ChatScreen() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const flatListRef = useRef<FlatList>(null);

  // Mock chat rooms
  useEffect(() => {
    if (user?.userType === 'customer') {
      setChatRooms([
        {
          id: 'chat_1',
          participants: ['customer_1', 'valeter_1'],
          lastMessage: 'I\'ll be there in 10 minutes',
          lastMessageTime: new Date(),
          unreadCount: 2,
        },
        {
          id: 'chat_2',
          participants: ['customer_1', 'valeter_2'],
          lastMessage: 'Service completed successfully',
          lastMessageTime: new Date(Date.now() - 3600000),
          unreadCount: 0,
        },
      ]);
    } else if (user?.userType === 'valeter') {
      setChatRooms([
        {
          id: 'chat_1',
          participants: ['valeter_1', 'customer_1'],
          lastMessage: 'I\'ll be there in 10 minutes',
          lastMessageTime: new Date(),
          unreadCount: 0,
        },
        {
          id: 'chat_3',
          participants: ['valeter_1', 'customer_2'],
          lastMessage: 'What time will you arrive?',
          lastMessageTime: new Date(Date.now() - 1800000),
          unreadCount: 1,
        },
      ]);
    }
  }, [user]);

  // Mock messages for selected chat
  useEffect(() => {
    if (selectedChat) {
      const mockMessages: Message[] = [
        {
          id: '1',
          text: 'Hi! I\'m your assigned valeter for today.',
          senderId: user?.userType === 'customer' ? 'valeter_1' : 'customer_1',
          senderName: user?.userType === 'customer' ? 'Mike Valeter' : 'John Customer',
          senderType: user?.userType === 'customer' ? 'valeter' : 'customer',
          timestamp: new Date(Date.now() - 300000),
          isRead: true,
        },
        {
          id: '2',
          text: 'Great! What time will you arrive?',
          senderId: user?.id || '',
          senderName: user?.name || '',
          senderType: user?.userType as 'customer' | 'valeter',
          timestamp: new Date(Date.now() - 240000),
          isRead: true,
        },
        {
          id: '3',
          text: 'I\'ll be there in about 10 minutes. Is that okay?',
          senderId: user?.userType === 'customer' ? 'valeter_1' : 'customer_1',
          senderName: user?.userType === 'customer' ? 'Mike Valeter' : 'John Customer',
          senderType: user?.userType === 'customer' ? 'valeter' : 'customer',
          timestamp: new Date(Date.now() - 180000),
          isRead: true,
        },
        {
          id: '4',
          text: 'Perfect! I\'ll be ready.',
          senderId: user?.id || '',
          senderName: user?.name || '',
          senderType: user?.userType as 'customer' | 'valeter',
          timestamp: new Date(Date.now() - 120000),
          isRead: true,
        },
      ];
      setMessages(mockMessages);
    }
  }, [selectedChat, user]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedChat) return;

    // await hapticFeedback.impact('light'); // Removed haptic feedback

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage.trim(),
      senderId: user?.id || '',
      senderName: user?.name || '',
      senderType: user?.userType as 'customer' | 'valeter',
      timestamp: new Date(),
      isRead: false,
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');

    // Simulate typing indicator
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      // Simulate response
      const response: Message = {
        id: (Date.now() + 1).toString(),
        text: user?.userType === 'customer' 
          ? 'Thanks! I\'ll keep you updated on my progress.'
          : 'Got it! I\'ll let you know when I\'m on my way.',
        senderId: user?.userType === 'customer' ? 'valeter_1' : 'customer_1',
        senderName: user?.userType === 'customer' ? 'Mike Valeter' : 'John Customer',
        senderType: user?.userType === 'customer' ? 'valeter' : 'customer',
        timestamp: new Date(),
        isRead: false,
      };
      setMessages(prev => [...prev, response]);
    }, 2000);

    // Scroll to bottom
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const sendQuickReply = (quickReply: string) => {
    setNewMessage(quickReply);
    sendMessage();
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isOwnMessage = item.senderId === user?.id;

    return (
      <View style={[
        styles.messageContainer,
        isOwnMessage ? styles.ownMessage : styles.otherMessage
      ]}>
        {!isOwnMessage && (
          <Text style={styles.senderName}>{item.senderName}</Text>
        )}
        <View style={[
          styles.messageBubble,
          isOwnMessage ? styles.ownBubble : styles.otherBubble
        ]}>
          <Text style={[
            styles.messageText,
            isOwnMessage ? styles.ownMessageText : styles.otherMessageText
          ]}>
            {item.text}
          </Text>
        </View>
        <Text style={styles.messageTime}>
          {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  const renderChatRoom = ({ item }: { item: ChatRoom }) => (
    <TouchableOpacity
      style={[
        styles.chatRoomItem,
        selectedChat === item.id && styles.selectedChatRoom
      ]}
      onPress={() => {
        setSelectedChat(item.id);
        // hapticFeedback.selection(); // Removed haptic feedback
      }}
    >
      <View style={styles.chatRoomInfo}>
        <Text style={styles.chatRoomName}>
          {user?.userType === 'customer' ? 'Mike Valeter' : 'John Customer'}
        </Text>
        <Text style={styles.lastMessage} numberOfLines={1}>
          {item.lastMessage}
        </Text>
      </View>
      <View style={styles.chatRoomMeta}>
        <Text style={styles.lastMessageTime}>
          {item.lastMessageTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
        {item.unreadCount > 0 && (
          <View style={styles.unreadBadge}>
            <Text style={styles.unreadCount}>{item.unreadCount}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );

  if (!selectedChat) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Messages</Text>
          <View style={styles.placeholder} />
        </View>

        <FlatList
          data={chatRooms}
          renderItem={renderChatRoom}
          keyExtractor={(item) => item.id}
          style={styles.chatRoomsList}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setSelectedChat(null)} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          {user?.userType === 'customer' ? 'Mike Valeter' : 'John Customer'}
        </Text>
        <TouchableOpacity style={styles.callButton}>
          <Text style={styles.callButtonText}>📞</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView 
        style={styles.chatContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessage}
          keyExtractor={(item) => item.id}
          style={styles.messagesList}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        />

        {isTyping && (
          <View style={styles.typingIndicator}>
            <Text style={styles.typingText}>
              {user?.userType === 'customer' ? 'Mike is typing...' : 'John is typing...'}
            </Text>
          </View>
        )}

        {/* Quick Reply Buttons for Customers */}
        {user?.userType === 'customer' && messages.length === 0 && (
          <View style={styles.quickRepliesContainer}>
            <Text style={styles.quickRepliesTitle}>Quick Messages</Text>
            <View style={styles.quickRepliesGrid}>
              <TouchableOpacity 
                style={styles.quickReplyButton}
                onPress={() => sendQuickReply("What time will you arrive?")}
              >
                <Text style={styles.quickReplyText}>What time will you arrive?</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.quickReplyButton}
                onPress={() => sendQuickReply("I'm ready for the service")}
              >
                <Text style={styles.quickReplyText}>I'm ready for the service</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.quickReplyButton}
                onPress={() => sendQuickReply("Please call when you arrive")}
              >
                <Text style={styles.quickReplyText}>Please call when you arrive</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.quickReplyButton}
                onPress={() => sendQuickReply("Any special instructions?")}
              >
                <Text style={styles.quickReplyText}>Any special instructions?</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.textInput}
            value={newMessage}
            onChangeText={setNewMessage}
            placeholder="Type a message..."
            placeholderTextColor="#9CA3AF"
            multiline
            maxLength={500}
          />
          <TouchableOpacity
            style={[styles.sendButton, !newMessage.trim() && styles.sendButtonDisabled]}
            onPress={sendMessage}
            disabled={!newMessage.trim()}
          >
            <Text style={styles.sendButtonText}>Send</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  callButton: {
    padding: 8,
  },
  callButtonText: {
    fontSize: 20,
  },
  chatRoomsList: {
    flex: 1,
  },
  chatRoomItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  selectedChatRoom: {
    backgroundColor: 'rgba(59, 130, 246, 0.1)',
  },
  chatRoomInfo: {
    flex: 1,
  },
  chatRoomName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  lastMessage: {
    color: '#87CEEB',
    fontSize: 14,
  },
  chatRoomMeta: {
    alignItems: 'flex-end',
  },
  lastMessageTime: {
    color: '#9CA3AF',
    fontSize: 12,
    marginBottom: 4,
  },
  unreadBadge: {
    backgroundColor: '#EF4444',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unreadCount: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  chatContainer: {
    flex: 1,
  },
  messagesList: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    marginBottom: 16,
    maxWidth: '80%',
  },
  ownMessage: {
    alignSelf: 'flex-end',
  },
  otherMessage: {
    alignSelf: 'flex-start',
  },
  senderName: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 4,
    marginLeft: 8,
  },
  messageBubble: {
    borderRadius: 18,
    padding: 12,
    marginBottom: 4,
  },
  ownBubble: {
    backgroundColor: '#3B82F6',
  },
  otherBubble: {
    backgroundColor: '#1E3A8A',
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  ownMessageText: {
    color: '#FFFFFF',
  },
  otherMessageText: {
    color: '#F9FAFB',
  },
  messageTime: {
    fontSize: 12,
    color: '#9CA3AF',
    textAlign: 'right',
  },
  typingIndicator: {
    padding: 16,
    alignItems: 'center',
  },
  typingText: {
    color: '#87CEEB',
    fontSize: 14,
    fontStyle: 'italic',
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    backgroundColor: '#1E3A8A',
  },
  textInput: {
    flex: 1,
    backgroundColor: '#0A1929',
    borderRadius: 20,
    padding: 12,
    marginRight: 8,
    color: '#F9FAFB',
    fontSize: 16,
    maxHeight: 100,
  },
  sendButton: {
    backgroundColor: '#10B981',
    borderRadius: 20,
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 60,
  },
  sendButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  quickRepliesContainer: {
    padding: 16,
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    marginTop: 16,
    marginBottom: 16,
  },
  quickRepliesTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  quickRepliesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  quickReplyButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 15,
    marginVertical: 8,
    minWidth: '45%',
    alignItems: 'center',
  },
  quickReplyText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
});
