import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  Alert,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { LinearGradient } from 'expo-linear-gradient';
import { enhancedBookingService as BookingService, EnhancedBookingData as Booking } from '../src/services/EnhancedBookingService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;

interface TrackingData {
  valeterName: string;
  valeterPhoto: string;
  vehicleInfo: string;
  estimatedArrival: string;
  currentLocation: {
    latitude: number;
    longitude: number;
    address: string;
  };
  destination: {
    latitude: number;
    longitude: number;
    address: string;
  };
  serviceType: string;
  price: number;
  status: 'en_route' | 'arriving' | 'arrived' | 'in_progress' | 'completed';
}

export default function UberTracking() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  
  const [trackingData, setTrackingData] = useState<TrackingData | null>(null);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loadBookingData = async () => {
      if (bookingId && user) {
        try {
          const bookingData = await BookingService.getBooking(bookingId, user.id);
          if (bookingData) {
            setBooking(bookingData);
            
            // Update tracking data with real booking information
            setTrackingData({
              valeterName: bookingData.valeterName || 'Mike Johnson',
              valeterPhoto: bookingData.valeterPhoto || '👨‍🔧',
              vehicleInfo: bookingData.vehicleInfo || 'White Transit Van • ABC123',
              estimatedArrival: bookingData.estimatedArrival || '5 min',
              currentLocation: {
                latitude: bookingData.location.latitude + 0.002,
                longitude: bookingData.location.longitude + 0.002,
                address: 'Oxford Street, London'
              },
              destination: {
                latitude: bookingData.location.latitude,
                longitude: bookingData.location.longitude,
                address: bookingData.location.address
              },
              serviceType: bookingData.serviceName,
              price: bookingData.price,
              status: bookingData.status as any
            });

            // Update booking status to en_route if it's still valeter_assigned
            if (bookingData.status === 'valeter_assigned') {
              await BookingService.updateValeterLocation(bookingId, user.id, '5 min');
            }
          }
        } catch (error) {
          console.error('Error loading booking:', error);
        }
      } else {
        // Fallback to mock data if no booking ID
        setTrackingData({
          valeterName: 'Mike Johnson',
          valeterPhoto: '👨‍🔧',
          vehicleInfo: 'White Transit Van • ABC123',
          estimatedArrival: '5 min',
          currentLocation: {
            latitude: 51.5074 + 0.002,
            longitude: -0.1278 + 0.002,
            address: 'Oxford Street, London'
          },
          destination: {
            latitude: 51.5074,
            longitude: -0.1278,
            address: 'Your Location'
          },
          serviceType: 'Express Wash',
          price: 15.00,
          status: 'en_route'
        });
      }
    };

    loadBookingData();

    // Start pulse animation
    const startPulse = () => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.1,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    };

    startPulse();
  }, []);

  const handleBack = () => {
    router.back();
  };

  const handleCall = () => {
    Alert.alert('Call Valeter', 'Calling Mike Johnson...');
  };

  const handleMessage = () => {
    router.push('/chat-screen');
  };

  const handleExpand = () => {
    setIsExpanded(!isExpanded);
    Animated.timing(slideAnim, {
      toValue: isExpanded ? 0 : 1,
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'en_route': return '#10B981';
      case 'arriving': return '#F59E0B';
      case 'arrived': return '#3B82F6';
      case 'in_progress': return '#8B5CF6';
      case 'completed': return '#059669';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'en_route': return 'On the way!';
      case 'arriving': return 'Nearly there!';
      case 'arrived': return 'Arrived!';
      case 'in_progress': return 'Washing in progress';
      case 'completed': return 'Wash completed!';
      default: return 'On the way!';
    }
  };

  if (!trackingData) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading tracking...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={handleBack}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Live Tracking</Text>
        <View style={styles.headerSpacer} />
      </View>

      {/* Map Section */}
      <View style={styles.mapSection}>
        {/* Map Holder - Replace with Mapbox during testing */}
        <View style={styles.mapHolder}>
          <View style={styles.mapPlaceholder}>
            <Text style={styles.mapPlaceholderIcon}>🗺️</Text>
            <Text style={styles.mapPlaceholderText}>Map Holder</Text>
            <Text style={styles.mapPlaceholderSubtext}>Replace with Mapbox</Text>
          </View>
        </View>
        
        {/* Map Overlay Controls */}
        <View style={styles.mapOverlay}>
          <TouchableOpacity style={styles.expandButton} onPress={handleExpand}>
            <Text style={styles.expandIcon}>{isExpanded ? '↓' : '↑'}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Tracking Card */}
      <Animated.View 
        style={[
          styles.trackingCard,
          {
            transform: [{
              translateY: slideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0, -200],
              })
            }]
          }
        ]}
      >
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          style={styles.trackingGradient}
        >
          {/* Status Bar */}
          <View style={styles.statusBar}>
            <Animated.View 
              style={[
                styles.statusIndicator,
                { 
                  backgroundColor: getStatusColor(trackingData.status),
                  transform: [{ scale: pulseAnim }]
                }
              ]}
            />
            <Text style={styles.statusText}>{getStatusText(trackingData.status)}</Text>
            <Text style={styles.etaText}>ETA: {trackingData.estimatedArrival}</Text>
          </View>

          {/* Valeter Info */}
          <View style={styles.valeterSection}>
            <View style={styles.valeterInfo}>
              <Text style={styles.valeterPhoto}>{trackingData.valeterPhoto}</Text>
              <View style={styles.valeterDetails}>
                <Text style={styles.valeterName}>{trackingData.valeterName}</Text>
                <Text style={styles.vehicleInfo}>{trackingData.vehicleInfo}</Text>
                <Text style={styles.serviceInfo}>
                  {trackingData.serviceType} • £{trackingData.price}
                </Text>
              </View>
            </View>
            
            <View style={styles.actionButtons}>
              <TouchableOpacity style={styles.actionButton} onPress={handleCall}>
                <Text style={styles.actionIcon}>📞</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton} onPress={handleMessage}>
                <Text style={styles.actionIcon}>💬</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressSection}>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill,
                  { 
                    width: `${trackingData.status === 'en_route' ? 30 : 
                           trackingData.status === 'arriving' ? 60 : 
                           trackingData.status === 'arrived' ? 80 : 
                           trackingData.status === 'in_progress' ? 90 : 100}%`,
                    backgroundColor: getStatusColor(trackingData.status)
                  }
                ]} 
              />
            </View>
            <View style={styles.progressLabels}>
              <Text style={styles.progressLabel}>On the way</Text>
              <Text style={styles.progressLabel}>Nearly there</Text>
              <Text style={styles.progressLabel}>Washing</Text>
              <Text style={styles.progressLabel}>Complete</Text>
            </View>
          </View>
        </LinearGradient>
      </Animated.View>

      {/* Expanded Details */}
      {isExpanded && (
        <Animated.View 
          style={[
            styles.expandedDetails,
            {
              opacity: slideAnim,
              transform: [{
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [50, 0],
                })
              }]
            }
          ]}
        >
          <View style={styles.detailCard}>
            <Text style={styles.detailTitle}>Service Details</Text>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Service Type:</Text>
              <Text style={styles.detailValue}>{trackingData.serviceType}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Price:</Text>
              <Text style={styles.detailValue}>£{trackingData.price}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Vehicle:</Text>
              <Text style={styles.detailValue}>{trackingData.vehicleInfo}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Current Location:</Text>
              <Text style={styles.detailValue}>{trackingData.currentLocation.address}</Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Destination:</Text>
              <Text style={styles.detailValue}>{trackingData.destination.address}</Text>
            </View>
          </View>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 40,
  },
  mapSection: {
    flex: 1,
    position: 'relative',
  },
  mapHolder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1E3A8A', // Placeholder background
    borderRadius: 12,
    overflow: 'hidden',
  },
  mapPlaceholder: {
    alignItems: 'center',
    padding: 20,
  },
  mapPlaceholderIcon: {
    fontSize: 60,
    marginBottom: 10,
  },
  mapPlaceholderText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  mapPlaceholderSubtext: {
    color: '#87CEEB',
    fontSize: 14,
  },
  mapOverlay: {
    position: 'absolute',
    top: 20,
    right: 20,
  },
  expandButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  expandIcon: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  trackingCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    overflow: 'hidden',
  },
  trackingGradient: {
    padding: isSmallScreen ? 20 : 24,
  },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  statusText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
    flex: 1,
  },
  etaText: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
  },
  valeterSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  valeterInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  valeterPhoto: {
    fontSize: 48,
    marginRight: 16,
  },
  valeterDetails: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  vehicleInfo: {
    color: '#E5E7EB',
    fontSize: isSmallScreen ? 12 : 14,
    marginBottom: 2,
  },
  serviceInfo: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
    fontWeight: '500',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionIcon: {
    fontSize: 20,
  },
  progressSection: {
    marginBottom: 8,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginBottom: 12,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressLabel: {
    color: '#E5E7EB',
    fontSize: 10,
    textAlign: 'center',
    flex: 1,
  },
  expandedDetails: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#0A1929',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: isSmallScreen ? 20 : 24,
    paddingTop: 32,
  },
  detailCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
  },
  detailTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  detailLabel: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '500',
  },
  detailValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
    marginLeft: 16,
  },
});
