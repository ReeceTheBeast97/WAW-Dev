import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';

const { width, height } = Dimensions.get('window');

export default function CustomerOnboarding() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const steps = [
    {
      title: "Welcome to Wish a Wash! 🚗✨",
      subtitle: "Your journey to premium car care starts here",
      description: "You're now part of a community that values quality, convenience, and exceptional service. Get ready to experience car washing like never before.",
      icon: "🌟",
      color: "#10B981"
    },
    {
      title: "Premium Service at Your Fingertips 📱",
      subtitle: "Book washes with just a few taps",
      description: "Our app makes booking car washes effortless. Choose from instant washes, priority services, or schedule ahead - all from your phone.",
      icon: "📱",
      color: "#3B82F6"
    },
    {
      title: "Professional Valeters You Can Trust 👨‍🔧",
      subtitle: "Vetted and certified professionals",
      description: "Every valeter on our platform is thoroughly vetted, trained, and insured. Your vehicle is in safe, professional hands.",
      icon: "👨‍🔧",
      color: "#8B5CF6"
    },
    {
      title: "Earn Rewards as You Wash 🎁",
      subtitle: "Points, discounts, and exclusive perks",
      description: "Every wash earns you points towards free services, discounts, and exclusive rewards. The more you wash, the more you save!",
      icon: "🎁",
      color: "#F59E0B"
    },
    {
      title: "Real-Time Tracking & Updates 📍",
      subtitle: "Know exactly what's happening",
      description: "Track your valeter's location, get real-time updates, and see photos of your completed wash. Complete transparency throughout the process.",
      icon: "📍",
      color: "#EF4444"
    },
    {
      title: "You're All Set! 🎉",
      subtitle: "Ready to experience premium car care",
      description: "Your account is ready! Start by booking your first wash and discover why thousands of customers choose Wish a Wash for their car care needs.",
      icon: "🎉",
      color: "#10B981"
    }
  ];

  React.useEffect(() => {
    animateStep();
  }, [currentStep]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      // Mark customer onboarding as seen
      await AsyncStorage.setItem('customer_onboarding_seen', 'true');
      await AsyncStorage.setItem('onboarding_seen', 'true');
      router.replace('/owner-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      router.replace('/owner-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete onboarding
      completeOnboarding();
    }
  };

  const skipOnboarding = () => {
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
        
        <View style={styles.progressContainer}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentStep && styles.progressDotActive,
                index < currentStep && styles.progressDotCompleted
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.iconContainer}>
            <Text style={styles.stepIcon}>{currentStepData.icon}</Text>
          </View>

          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStepData.subtitle}</Text>
          
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

          {/* Step-specific content */}
          {currentStep === 0 && (
            <View style={styles.welcomeCard}>
              <Text style={styles.welcomeText}>
                Hello, {user?.name || 'Valued Customer'}! 👋
              </Text>
              <Text style={styles.welcomeSubtext}>
                We're excited to have you join our community of car care enthusiasts.
              </Text>
            </View>
          )}

          {currentStep === 1 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>What You Can Do:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⚡</Text>
                <Text style={styles.featureText}>Book instant washes</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⭐</Text>
                <Text style={styles.featureText}>Choose priority service</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📅</Text>
                <Text style={styles.featureText}>Schedule future appointments</Text>
              </View>
            </View>
          )}

          {currentStep === 2 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Our Valeters:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>✅</Text>
                <Text style={styles.featureText}>Background checked</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🎓</Text>
                <Text style={styles.featureText}>Professionally trained</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🛡️</Text>
                <Text style={styles.featureText}>Fully insured</Text>
              </View>
            </View>
          )}

          {currentStep === 3 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Rewards Include:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>🎁</Text>
                <Text style={styles.featureText}>Free washes</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>💰</Text>
                <Text style={styles.featureText}>Exclusive discounts</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>⭐</Text>
                <Text style={styles.featureText}>Priority booking</Text>
              </View>
            </View>
          )}

          {currentStep === 4 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Track Everything:</Text>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📍</Text>
                <Text style={styles.featureText}>Real-time location</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>📸</Text>
                <Text style={styles.featureText}>Before & after photos</Text>
              </View>
              <View style={styles.featureItem}>
                <Text style={styles.featureIcon}>💬</Text>
                <Text style={styles.featureText}>Direct communication</Text>
              </View>
            </View>
          )}

          {currentStep === 5 && (
            <View style={styles.finalCard}>
              <Text style={styles.finalTitle}>Ready to Get Started?</Text>
              <Text style={styles.finalText}>
                Your first wash is just a tap away. Experience the difference that professional car care makes.
              </Text>
            </View>
          )}
        </Animated.View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
        >
          <Text style={styles.nextButtonText}>
            {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  skipText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: '#FFFFFF',
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  progressDotCompleted: {
    backgroundColor: '#10B981',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  stepContainer: {
    alignItems: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  stepIcon: {
    fontSize: 60,
  },
  stepTitle: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: 36,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 24,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 40,
    opacity: 0.9,
  },
  welcomeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  welcomeText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  welcomeSubtext: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    width: '100%',
  },
  featureTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  featureIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  featureText: {
    color: '#FFFFFF',
    fontSize: 16,
    flex: 1,
  },
  finalCard: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 16,
    padding: 24,
    marginTop: 20,
    alignItems: 'center',
  },
  finalTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  finalText: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  footer: {
    paddingHorizontal: 30,
    paddingBottom: 60,
  },
  nextButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
