import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, FlatList, Alert, ActivityIndicator, RefreshControl
} from 'react-native';
import { supabase } from '../src/lib/api/real/supabaseClient';
import { useAuth } from './enhanced-auth-context';

type DbStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  service_type: string;
  scheduled_at: string;
  status: DbStatus;
  price: number;
  location_address: string | null;
  location_lat: number | null;
  location_lng: number | null;
  valeter_id: string | null;
  progress_percent: number | null;
  eta_minutes: number | null;
  created_at: string;
  updated_at: string;
};

export default function ValeterJobsScreen() {
  const { user } = useAuth();
  const uid = user?.id ?? null;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [openJobs, setOpenJobs] = useState<DbBooking[]>([]);
  const [myJobs, setMyJobs] = useState<DbBooking[]>([]);

  const load = useCallback(async () => {
    if (!uid) return;
    setLoading(true);
    try {
      // Open = scheduled & unassigned
      const { data: openData, error: openErr } = await supabase
        .from('bookings')
        .select('*')
        .eq('status', 'scheduled')
        .is('valeter_id', null)
        .order('created_at', { ascending: true })
        .limit(50);

      if (openErr) throw openErr;

      // My active = assigned to me and not completed/cancelled
      const { data: myData, error: myErr } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', uid)
        .in('status', ['scheduled', 'in_progress'])
        .order('created_at', { ascending: false })
        .limit(50);

      if (myErr) throw myErr;

      setOpenJobs(openData ?? []);
      setMyJobs(myData ?? []);
    } catch (e: any) {
      console.log('[valeter] load error:', e?.message || e);
      Alert.alert('Error', 'Could not load jobs.');
    } finally {
      setLoading(false);
    }
  }, [uid]);

  useEffect(() => {
    load();
  }, [load]);

  // Realtime updates on bookings table (simple)
  useEffect(() => {
    const channel = supabase
      .channel('valeter-jobs-all')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' }, () => {
        // Just reload lists; you can optimize with payload if needed
        load();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [load]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }, [load]);

  /** Accept job (race-safe): only succeed if still unassigned & scheduled */
  const acceptJob = async (bookingId: string) => {
    if (!uid) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .update({
          valeter_id: uid,
          // optional: set an initial ETA + progress when accepting
          eta_minutes: 12,
          progress_percent: 30,
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingId)
        .eq('status', 'scheduled')
        .is('valeter_id', null)
        .select('*')
        .maybeSingle<DbBooking>();

      if (error) throw error;

      if (!data) {
        Alert.alert('Too late', 'Another valeter accepted this job.');
        await load();
        return;
      }

      Alert.alert('Accepted ✅', 'You are now assigned to this job.');
      await load();
    } catch (e: any) {
      console.log('[valeter] accept error:', e?.message || e);
      Alert.alert('Error', e?.message || 'Could not accept job.');
    }
  };

  /** Mark en route (keep status scheduled but update ETA/progress) */
  const markEnRoute = async (bookingId: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          // staying 'scheduled' is fine — customer UI shows en_route when valeter_id is set
          eta_minutes: 7,
          progress_percent: 40,
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingId)
        .select()
        .single();

      if (error) throw error;
      await load();
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to update.');
    }
  };

  /** Start job (in_progress) */
  const startJob = async (bookingId: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'in_progress',
          eta_minutes: 0,
          progress_percent: 70,
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingId)
        .select()
        .single();

      if (error) throw error;
      await load();
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to start job.');
    }
  };

  /** Complete job */
  const completeJob = async (bookingId: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'completed',
          eta_minutes: 0,
          progress_percent: 100,
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingId)
        .select()
        .single();

      if (error) throw error;
      await load();
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to complete job.');
    }
  };

  const JobCard = ({ item, action }: { item: DbBooking; action?: React.ReactNode }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <Text style={styles.service}>{item.service_type}</Text>
        <Text style={[
          styles.status,
          item.status === 'in_progress' ? { color: '#FFD700' } :
          item.status === 'completed'  ? { color: '#10B981' } :
          { color: '#87CEEB' }
        ]}>
          {item.status.toUpperCase()}
        </Text>
      </View>
      <Text style={styles.address}>{item.location_address ?? 'No address'}</Text>
      <Text style={styles.meta}>£{Number(item.price || 0).toFixed(2)}</Text>
      {typeof item.eta_minutes === 'number' && <Text style={styles.meta}>ETA: {item.eta_minutes} min</Text>}
      {typeof item.progress_percent === 'number' && <Text style={styles.meta}>Progress: {item.progress_percent}%</Text>}
      <View style={styles.actionsRow}>{action}</View>
    </View>
  );

  if (!uid) {
    return (
      <View style={styles.containerCentered}>
        <Text style={{ color: '#fff' }}>Please log in as a valeter.</Text>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={styles.containerCentered}>
        <ActivityIndicator />
        <Text style={{ color: '#87CEEB', marginTop: 8 }}>Loading jobs…</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Open Jobs */}
      <Text style={styles.sectionTitle}>Open Jobs</Text>
      <FlatList
        data={openJobs}
        keyExtractor={(b) => b.id}
        renderItem={({ item }) => (
          <JobCard
            item={item}
            action={
              <TouchableOpacity style={styles.primaryBtn} onPress={() => acceptJob(item.id)}>
                <Text style={styles.primaryBtnText}>Accept</Text>
              </TouchableOpacity>
            }
          />
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No open jobs right now.</Text>}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />}
        contentContainerStyle={{ paddingBottom: 16 }}
      />

      {/* My Active Jobs */}
      <Text style={[styles.sectionTitle, { marginTop: 12 }]}>My Active Jobs</Text>
      <FlatList
        data={myJobs}
        keyExtractor={(b) => b.id}
        renderItem={({ item }) => (
          <JobCard
            item={item}
            action={
              <View style={{ flexDirection: 'row', gap: 8 }}>
                <TouchableOpacity style={styles.secondaryBtn} onPress={() => markEnRoute(item.id)}>
                  <Text style={styles.secondaryBtnText}>En Route</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.secondaryBtn} onPress={() => startJob(item.id)}>
                  <Text style={styles.secondaryBtnText}>Start</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.completeBtn} onPress={() => completeJob(item.id)}>
                  <Text style={styles.completeBtnText}>Complete</Text>
                </TouchableOpacity>
              </View>
            }
          />
        )}
        ListEmptyComponent={<Text style={styles.emptyText}>No active jobs yet.</Text>}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#fff" />}
        contentContainerStyle={{ paddingBottom: 40 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929', padding: 16 },
  containerCentered: { flex: 1, backgroundColor: '#0A1929', alignItems: 'center', justifyContent: 'center' },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  emptyText: { color: '#B0E0E6', paddingVertical: 12 },
  card: { backgroundColor: '#1E3A8A', borderRadius: 12, padding: 16, marginBottom: 10 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  service: { color: '#87CEEB', fontSize: 16, fontWeight: '700' },
  status: { fontSize: 12 },
  address: { color: '#F9FAFB', marginBottom: 4 },
  meta: { color: '#B0E0E6', fontSize: 12 },
  actionsRow: { marginTop: 12, flexDirection: 'row', gap: 8 },

  primaryBtn: { backgroundColor: '#10B981', paddingVertical: 10, paddingHorizontal: 14, borderRadius: 8 },
  primaryBtnText: { color: '#0B1A2B', fontWeight: '800' },

  secondaryBtn: { backgroundColor: '#375A9E', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  secondaryBtnText: { color: '#fff', fontWeight: '700' },

  completeBtn: { backgroundColor: '#4CAF50', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  completeBtnText: { color: '#0B1A2B', fontWeight: '800' },
});