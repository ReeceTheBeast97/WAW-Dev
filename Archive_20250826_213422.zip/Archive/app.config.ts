export default {
  name: "Wish a Wash",
  slug: "wish-a-wash",
  scheme: "waw",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./assets/icon.png",
  userInterfaceStyle: "automatic",
  splash: {
    image: "./assets/splash.png",
    resizeMode: "contain",
    backgroundColor: "#1E3A8A"
  },
  assetBundlePatterns: [
    "**/*"
  ],
  experiments: { 
    typedRoutes: true,
    tsconfigPaths: true
  },
  ios: {
    supportsTablet: false,
    bundleIdentifier: "com.wishawash.app",
    buildNumber: "1",
    infoPlist: {
      NSLocationWhenInUseUsageDescription: "We use your location to find nearby valeters and show your service location.",
      NSLocationAlwaysAndWhenInUseUsageDescription: "We use your location to provide real-time tracking and service updates.",
      NSCameraUsageDescription: "We use your camera to take photos of your vehicle for service documentation.",
      NSMicrophoneUsageDescription: "We use your microphone for voice booking and communication features.",
      NSPhotoLibraryUsageDescription: "We use your photo library to select vehicle photos for service documentation.",
      UIBackgroundModes: ["location", "fetch", "remote-notification"],
      CFBundleDisplayName: "Wish a Wash"
    }
  },
  android: {
    package: "com.wishawash.app",
    versionCode: 1,
    permissions: [
      "ACCESS_FINE_LOCATION",
      "ACCESS_COARSE_LOCATION",
      "CAMERA",
      "RECORD_AUDIO",
      "READ_EXTERNAL_STORAGE",
      "WRITE_EXTERNAL_STORAGE",
      "INTERNET",
      "ACCESS_NETWORK_STATE",
      "VIBRATE",
      "WAKE_LOCK"
    ],
    adaptiveIcon: {
      foregroundImage: "./assets/adaptive-icon.png",
      backgroundColor: "#1E3A8A"
    }
  },
  web: {
    favicon: "./assets/favicon.png",
    bundler: "metro"
  },
  plugins: [
    "expo-router",
    "expo-location",
    "expo-notifications",
    "expo-image-picker",
    "expo-camera",
    "expo-media-library",
    "expo-file-system"
  ],
  extra: {
    eas: {
      projectId: "your-project-id-here"
    }
  }
};

