import { supabase } from '../lib/api/real/supabaseClient';

export interface VehicleDetails {
  registration: string;
  make: string;
  model: string;
  year: number;
  color: string;
  size: 'small' | 'medium' | 'large' | 'luxury';
  type: 'car' | 'van' | 'bike' | 'coach' | 'truck';
  photo?: string;
}

export interface ServiceCustomization {
  cleaningProducts: string[];
  specialInstructions: string;
  interiorFocus: boolean;
  exteriorFocus: boolean;
  engineBay: boolean;
  wheels: boolean;
  windows: boolean;
  upholstery: boolean;
}

export interface AddressSuggestion {
  placeId: string;
  description: string;
  mainText: string;
  secondaryText: string;
  location: {
    latitude: number;
    longitude: number;
  };
}

export interface EnhancedBookingData {
  id: string;
  customerId: string;
  serviceType: string;
  vehicleDetails: VehicleDetails;
  location: {
    address: string;
    latitude: number;
    longitude: number;
    placeId?: string;
  };
  serviceCustomization: ServiceCustomization;
  scheduledTime?: Date;
  priority: boolean;
  estimatedPrice: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export class EnhancedBookingService {
  private static instance: EnhancedBookingService;

  static getInstance(): EnhancedBookingService {
    if (!EnhancedBookingService.instance) {
      EnhancedBookingService.instance = new EnhancedBookingService();
    }
    return EnhancedBookingService.instance;
  }

  // Create a new booking
  async createBooking(
    customerId: string,
    serviceType: string,
    vehicleDetails: VehicleDetails,
    location: { address: string; latitude: number; longitude: number; placeId?: string },
    serviceCustomization: ServiceCustomization,
    scheduledTime?: Date,
    priority: boolean = false
  ): Promise<EnhancedBookingData> {
    const estimatedPrice = this.calculatePrice(serviceType, vehicleDetails, serviceCustomization, priority);
    
    const { data, error } = await supabase
      .from('bookings')
      .insert({
        customer_id: customerId,
        service_type: serviceType,
        vehicle_details: vehicleDetails,
        location: location,
        service_customization: serviceCustomization,
        scheduled_time: scheduledTime?.toISOString(),
        priority: priority,
        estimated_price: estimatedPrice,
        status: 'pending'
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create booking: ${error.message}`);

    return this.mapBookingFromDatabase(data);
  }

  // Get booking by ID
  async getBooking(bookingId: string): Promise<EnhancedBookingData | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('id', bookingId)
      .single();

    if (error) {
      console.error('Error fetching booking:', error);
      return null;
    }

    return data ? this.mapBookingFromDatabase(data) : null;
  }

  // Get all bookings for a user
  async getUserBookings(userId: string): Promise<EnhancedBookingData[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('customer_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching user bookings:', error);
      return [];
    }

    return data?.map(booking => this.mapBookingFromDatabase(booking)) || [];
  }

  // Update booking status
  async updateBookingStatus(bookingId: string, status: EnhancedBookingData['status']): Promise<boolean> {
    const { error } = await supabase
      .from('bookings')
      .update({ 
        status: status,
        updated_at: new Date().toISOString()
      })
      .eq('id', bookingId);

    if (error) {
      console.error('Error updating booking status:', error);
      return false;
    }

    return true;
  }

  // Cancel booking
  async cancelBooking(bookingId: string, reason?: string): Promise<boolean> {
    const { error } = await supabase
      .from('bookings')
      .update({ 
        status: 'cancelled',
        cancellation_reason: reason,
        updated_at: new Date().toISOString()
      })
      .eq('id', bookingId);

    if (error) {
      console.error('Error cancelling booking:', error);
      return false;
    }

    return true;
  }

  // Search addresses using Google Places API (placeholder for real implementation)
  async searchAddresses(query: string): Promise<AddressSuggestion[]> {
    // TODO: Implement real Google Places API integration
    // For now, return empty array - this should be replaced with actual API call
    console.log('Address search requested for:', query);
    return [];
  }

  // Validate vehicle registration
  validateVehicleRegistration(registration: string): { isValid: boolean; error?: string } {
    // UK registration format validation
    const ukFormat = /^[A-Z]{2}[0-9]{2}\s?[A-Z]{3}$|^[A-Z][0-9]{3}\s?[A-Z]{3}$|^[A-Z]{3}[0-9]{3}$/;
    
    if (!registration) {
      return { isValid: false, error: 'Registration number is required' };
    }
    
    if (!ukFormat.test(registration.replace(/\s/g, ''))) {
      return { isValid: false, error: 'Invalid UK registration format' };
    }
    
    return { isValid: true };
  }

  // Detect vehicle details from photo (placeholder for AI integration)
  async detectVehicleFromPhoto(photoBase64: string): Promise<Partial<VehicleDetails>> {
    // TODO: Implement real AI vehicle detection
    // For now, return empty object - this should be replaced with actual AI service
    console.log('Vehicle detection requested for photo');
    return {};
  }

  // Get available cleaning products
  getCleaningProducts(): string[] {
    return [
      'Premium Car Shampoo',
      'Microfiber Wash Mitts',
      'Clay Bar Kit',
      'Wax & Polish',
      'Tire Shine',
      'Glass Cleaner',
      'Interior Cleaner',
      'Leather Conditioner',
      'Engine Bay Cleaner',
      'Wheel Cleaner',
      'Odor Eliminator',
      'UV Protection Spray'
    ];
  }

  // Calculate booking price
  private calculatePrice(
    serviceType: string,
    vehicleDetails: VehicleDetails,
    serviceCustomization: ServiceCustomization,
    priority: boolean
  ): number {
    let basePrice = this.getBasePrice(serviceType, vehicleDetails.size);
    
    // Add customization costs
    if (serviceCustomization.engineBay) basePrice += 15;
    if (serviceCustomization.wheels) basePrice += 10;
    if (serviceCustomization.windows) basePrice += 5;
    if (serviceCustomization.upholstery) basePrice += 20;
    
    // Priority surcharge
    if (priority) basePrice *= 1.3;
    
    return Math.round(basePrice);
  }

  // Get base price for service and vehicle size
  private getBasePrice(serviceType: string, vehicleSize: string): number {
    const basePrices: Record<string, Record<string, number>> = {
      'exterior_only': {
        'small': 25,
        'medium': 35,
        'large': 45,
        'luxury': 60
      },
      'standard': {
        'small': 40,
        'medium': 55,
        'large': 70,
        'luxury': 95
      },
      'luxury_exterior': {
        'small': 50,
        'medium': 65,
        'large': 80,
        'luxury': 110
      },
      'luxury_full': {
        'small': 75,
        'medium': 95,
        'large': 115,
        'luxury': 150
      }
    };
    
    return basePrices[serviceType]?.[vehicleSize] || 40;
  }

  // Get active booking for a user
  async getActiveBooking(userId: string): Promise<EnhancedBookingData | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('customer_id', userId)
      .not('status', 'in', ['completed', 'cancelled'])
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error) {
      console.error('Error fetching active booking:', error);
      return null;
    }

    return data ? this.mapBookingFromDatabase(data) : null;
  }

  // Get booking statistics
  async getBookingStats(userId: string): Promise<{
    totalBookings: number;
    totalSpent: number;
    averageRating: number;
    completedServices: number;
    savings: number;
  }> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('customer_id', userId);

    if (error) {
      console.error('Error fetching booking stats:', error);
      return {
        totalBookings: 0,
        totalSpent: 0,
        averageRating: 0,
        completedServices: 0,
        savings: 0
      };
    }

    const bookings = data || [];
    const completedBookings = bookings.filter(b => b.status === 'completed');
    
    return {
      totalBookings: bookings.length,
      totalSpent: completedBookings.reduce((sum, b) => sum + (b.estimated_price || 0), 0),
      averageRating: 0, // TODO: Implement rating system
      completedServices: completedBookings.length,
      savings: completedBookings.reduce((sum, b) => sum + ((b.estimated_price || 0) * 0.1), 0) // 10% savings
    };
  }

  // Subscribe to booking updates using Supabase realtime
  subscribeToBookings(userId: string, callback: (bookings: EnhancedBookingData[]) => void): () => void {
    const subscription = supabase
      .channel('bookings')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `customer_id=eq.${userId}`
        },
        async () => {
          // Fetch updated bookings when changes occur
          const updatedBookings = await this.getUserBookings(userId);
          callback(updatedBookings);
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }

  // Map database record to EnhancedBookingData
  private mapBookingFromDatabase(dbRecord: any): EnhancedBookingData {
    return {
      id: dbRecord.id,
      customerId: dbRecord.customer_id,
      serviceType: dbRecord.service_type,
      vehicleDetails: dbRecord.vehicle_details,
      location: dbRecord.location,
      serviceCustomization: dbRecord.service_customization,
      scheduledTime: dbRecord.scheduled_time ? new Date(dbRecord.scheduled_time) : undefined as any,
      priority: dbRecord.priority,
      estimatedPrice: dbRecord.estimated_price,
      status: dbRecord.status,
      createdAt: new Date(dbRecord.created_at),
      updatedAt: new Date(dbRecord.updated_at)
    };
  }

  // Cleanup
  cleanup(): void {
    // No cleanup needed for Supabase
  }
}

export const enhancedBookingService = EnhancedBookingService.getInstance();
