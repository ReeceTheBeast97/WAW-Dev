import { SimpleNotificationService } from '../utils/SimpleNotificationService';

export interface SimulationUser {
  id: string;
  name: string;
  email: string;
  userType: 'customer' | 'valeter';
  location: { lat: number; lng: number };
  isOnline: boolean;
  rating: number;
  jobsCompleted: number;
  phone: string;
  isVerified?: boolean;
  documentsUploaded?: boolean;
  insuranceVerified?: boolean;
  licenseVerified?: boolean;
  backgroundCheckPassed?: boolean;
}

export interface SimulationJob {
  id: string;
  customerId: string;
  valeterId?: string;
  serviceType: 'wash' | 'valet' | 'priority_wash';
  location: { lat: number; lng: number; address: string };
  price: number;
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: number;
  estimatedTime: number;
}

class SimulationService {
  private users: Map<string, SimulationUser> = new Map();
  private jobs: Map<string, SimulationJob> = new Map();
  private subscribers: Map<string, (data: any) => void> = new Map();
  private jobCounter = 1;

  constructor() {
    console.log('🔍 Initializing SimulationService');
    this.initializeSimulationData();
    console.log('🔍 SimulationService initialized');
  }

  private initializeSimulationData() {
    // Add some mock users
    const mockCustomer: SimulationUser = {
      id: 'customer-1',
      name: 'John Customer',
      email: 'customer@test.com',
      userType: 'customer',
      location: { lat: 51.5074, lng: -0.1278 },
      isOnline: true,
      rating: 4.8,
      jobsCompleted: 0,
      phone: '+44 7700 900000'
    };

    const mockValeter: SimulationUser = {
      id: 'valeter-1',
      name: 'Mike Valeter',
      email: 'valeter@test.com',
      userType: 'valeter',
      location: { lat: 51.5074, lng: -0.1278 },
      isOnline: false,
      rating: 4.9,
      jobsCompleted: 127,
      phone: '+44 7700 900123',
      isVerified: true,
      documentsUploaded: true,
      insuranceVerified: true,
      licenseVerified: true,
      backgroundCheckPassed: true
    };

    this.users.set(mockCustomer.id, mockCustomer);
    this.users.set(mockValeter.id, mockValeter);
  }

  addUser(user: SimulationUser): void {
    console.log('🔍 Adding user to simulation service:', user.id, user.name);
    this.users.set(user.id, user);
    this.notifySubscribers(user.id, { type: 'user_updated', user });
  }

  getUser(userId: string): SimulationUser | undefined {
    return this.users.get(userId);
  }

  updateUserLocation(userId: string, location: { lat: number; lng: number }): void {
    const user = this.users.get(userId);
    if (user) {
      user.location = location;
      this.users.set(userId, user);
      this.notifySubscribers(userId, { type: 'location_updated', location });
    }
  }

  setUserOnlineStatus(userId: string, isOnline: boolean): void {
    const user = this.users.get(userId);
    if (user) {
      user.isOnline = isOnline;
      this.users.set(userId, user);
      this.notifySubscribers(userId, { type: 'status_updated', isOnline });
    }
  }

  createJob(customerId: string, serviceType: 'wash' | 'valet' | 'priority_wash', location: { lat: number; lng: number; address: string }, price: number): string {
    const jobId = `job-${this.jobCounter++}`;
    const job: SimulationJob = {
      id: jobId,
      customerId,
      serviceType,
      location,
      price,
      status: 'pending',
      createdAt: Date.now(),
      estimatedTime: serviceType === 'priority_wash' ? 15 : serviceType === 'valet' ? 45 : 30
    };

    this.jobs.set(jobId, job);
    this.notifySubscribers(customerId, { type: 'job_created', job });
    this.notifyNearbyValeters(job);
    return jobId;
  }

  getJob(jobId: string): SimulationJob | undefined {
    return this.jobs.get(jobId);
  }

  getJobsForUser(userId: string, userType: 'customer' | 'valeter'): SimulationJob[] {
    const jobs = Array.from(this.jobs.values());
    if (userType === 'customer') {
      return jobs.filter(job => job.customerId === userId);
    } else {
      return jobs.filter(job => job.valeterId === userId);
    }
  }

  getAvailableJobs(): SimulationJob[] {
    return Array.from(this.jobs.values()).filter(job => job.status === 'pending');
  }

  acceptJob(jobId: string, valeterId: string): boolean {
    const job = this.jobs.get(jobId);
    if (job && job.status === 'pending') {
      job.valeterId = valeterId;
      job.status = 'accepted';
      this.jobs.set(jobId, job);
      this.notifySubscribers(job.customerId, { type: 'job_accepted', job });
      this.notifySubscribers(valeterId, { type: 'job_accepted', job });
      return true;
    }
    return false;
  }

  startJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (job && job.status === 'accepted') {
      job.status = 'in_progress';
      this.jobs.set(jobId, job);
      this.notifySubscribers(job.customerId, { type: 'job_started', job });
      this.notifySubscribers(job.valeterId!, { type: 'job_started', job });
      return true;
    }
    return false;
  }

  completeJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (job && job.status === 'in_progress') {
      job.status = 'completed';
      this.jobs.set(jobId, job);
      this.notifySubscribers(job.customerId, { type: 'job_completed', job });
      this.notifySubscribers(job.valeterId!, { type: 'job_completed', job });
      return true;
    }
    return false;
  }

  private notifyNearbyValeters(job: SimulationJob): void {
    const onlineValeters = Array.from(this.users.values()).filter(user => 
      user.userType === 'valeter' && user.isOnline
    );

    onlineValeters.forEach(valeter => {
      SimpleNotificationService.getInstance().showNotification({
        title: 'New Job Available',
        message: `${job.serviceType.replace('_', ' ')} - £${job.price} at ${job.location.address}`,
        type: 'info'
      });
    });
  }

  private notifyCustomer(job: SimulationJob, message: string): void {
    SimpleNotificationService.getInstance().showNotification({
      title: 'Job Update',
      message,
      type: 'info'
    });
  }

  subscribeToUpdates(userId: string, callback: (data: any) => void): () => void {
    this.subscribers.set(userId, callback);
    return () => {
      this.subscribers.delete(userId);
    };
  }

  private notifySubscribers(userId: string, data: any): void {
    const callback = this.subscribers.get(userId);
    if (callback) {
      callback(data);
    }
  }
}

export const simulationService = new SimulationService(); 