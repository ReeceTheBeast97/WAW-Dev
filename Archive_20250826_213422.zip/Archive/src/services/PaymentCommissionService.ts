export interface JobPayment {
  jobId: string;
  valeterId: string;
  customerId: string;
  basePrice: number;
  commission: number; // 10% of base price
  valeterEarnings: number; // 90% of base price
  unsociableHoursBonus: number; // Double pay for night time
  totalValeterPay: number; // valeterEarnings + unsociableHoursBonus
  jobDateTime: Date;
  isNightTime: boolean;
  serviceType: string;
  vehicleType: string;
  location: string;
  status: 'pending' | 'completed' | 'paid' | 'cancelled';
  paymentDate?: Date;
}

export interface ValeterEarnings {
  valeterId: string;
  valeterName: string;
  totalEarnings: number;
  totalCommission: number; // Total commission paid to platform
  totalJobs: number;
  completedJobs: number;
  cancelledJobs: number;
  nightTimeJobs: number;
  unsociableHoursBonus: number;
  averagePerJob: number;
  thisMonthEarnings: number;
  thisMonthJobs: number;
  lastPaymentDate?: Date;
  pendingPayment: number;
}

export interface PlatformEarnings {
  totalRevenue: number;
  totalCommission: number;
  totalJobs: number;
  averageCommissionPerJob: number;
  thisMonthRevenue: number;
  thisMonthCommission: number;
  thisMonthJobs: number;
  nightTimeJobs: number;
  dayTimeJobs: number;
}

export interface PaymentSchedule {
  valeterId: string;
  valeterName: string;
  periodStart: Date;
  periodEnd: Date;
  totalEarnings: number;
  commission: number;
  unsociableHoursBonus: number;
  netPayment: number;
  status: 'pending' | 'processed' | 'paid';
  paymentDate?: Date;
  paymentMethod: 'bank_transfer' | 'paypal' | 'stripe';
}

export class PaymentCommissionService {
  private static instance: PaymentCommissionService;
  private jobPayments: Map<string, JobPayment> = new Map();
  private valeterEarnings: Map<string, ValeterEarnings> = new Map();
  private paymentSchedules: Map<string, PaymentSchedule> = new Map();

  // Night time hours (unsociable hours)
  private readonly NIGHT_START_HOUR = 22; // 10 PM
  private readonly NIGHT_END_HOUR = 6; // 6 AM
  private readonly COMMISSION_RATE = 0.10; // 10%
  private readonly UNSOCIABLE_HOURS_MULTIPLIER = 2.0; // Double pay

  static getInstance(): PaymentCommissionService {
    if (!PaymentCommissionService.instance) {
      PaymentCommissionService.instance = new PaymentCommissionService();
    }
    return PaymentCommissionService.instance;
  }

  // Calculate payment for a new job
  calculateJobPayment(
    jobId: string,
    valeterId: string,
    customerId: string,
    basePrice: number,
    jobDateTime: Date,
    serviceType: string,
    vehicleType: string,
    location: string
  ): JobPayment {
    const isNightTime = this.isNightTime(jobDateTime);
    const commission = basePrice * this.COMMISSION_RATE;
    const valeterEarnings = basePrice - commission;
    const unsociableHoursBonus = isNightTime ? valeterEarnings : 0; // Double the valeter's portion
    const totalValeterPay = valeterEarnings + unsociableHoursBonus;

    const jobPayment: JobPayment = {
      jobId,
      valeterId,
      customerId,
      basePrice,
      commission,
      valeterEarnings,
      unsociableHoursBonus,
      totalValeterPay,
      jobDateTime,
      isNightTime,
      serviceType,
      vehicleType,
      location,
      status: 'pending'
    };

    this.jobPayments.set(jobId, jobPayment);
    this.updateValeterEarnings(valeterId, jobPayment);

    return jobPayment;
  }

  // Check if job is during unsociable hours
  private isNightTime(dateTime: Date): boolean {
    const hour = dateTime.getHours();
    return hour >= this.NIGHT_START_HOUR || hour < this.NIGHT_END_HOUR;
  }

  // Update valeter earnings when a job is completed
  updateValeterEarnings(valeterId: string, jobPayment: JobPayment) {
    const existing = this.valeterEarnings.get(valeterId);
    
    if (existing) {
      existing.totalEarnings += jobPayment.totalValeterPay;
      existing.totalCommission += jobPayment.commission;
      existing.totalJobs += 1;
      
      if (jobPayment.status === 'completed') {
        existing.completedJobs += 1;
      } else if (jobPayment.status === 'cancelled') {
        existing.cancelledJobs += 1;
      }

      if (jobPayment.isNightTime) {
        existing.nightTimeJobs += 1;
        existing.unsociableHoursBonus += jobPayment.unsociableHoursBonus;
      }

      existing.averagePerJob = existing.totalEarnings / existing.totalJobs;
      
      // Update this month's earnings
      const now = new Date();
      const jobMonth = jobPayment.jobDateTime.getMonth();
      const jobYear = jobPayment.jobDateTime.getFullYear();
      
      if (now.getMonth() === jobMonth && now.getFullYear() === jobYear) {
        existing.thisMonthEarnings += jobPayment.totalValeterPay;
        existing.thisMonthJobs += 1;
      }
    } else {
      // Create new valeter earnings record
      const newEarnings: ValeterEarnings = {
        valeterId,
        valeterName: 'Unknown', // Would be populated from valeter profile
        totalEarnings: jobPayment.totalValeterPay,
        totalCommission: jobPayment.commission,
        totalJobs: 1,
        completedJobs: jobPayment.status === 'completed' ? 1 : 0,
        cancelledJobs: jobPayment.status === 'cancelled' ? 1 : 0,
        nightTimeJobs: jobPayment.isNightTime ? 1 : 0,
        unsociableHoursBonus: jobPayment.unsociableHoursBonus,
        averagePerJob: jobPayment.totalValeterPay,
        thisMonthEarnings: jobPayment.totalValeterPay,
        thisMonthJobs: 1,
        pendingPayment: jobPayment.totalValeterPay
      };
      
      this.valeterEarnings.set(valeterId, newEarnings);
    }
  }

  // Complete a job and finalize payment
  completeJob(jobId: string): boolean {
    const jobPayment = this.jobPayments.get(jobId);
    if (!jobPayment || jobPayment.status !== 'pending') {
      return false;
    }

    jobPayment.status = 'completed';
    jobPayment.paymentDate = new Date();
    
    // Update valeter earnings
    this.updateValeterEarnings(jobPayment.valeterId, jobPayment);
    
    return true;
  }

  // Cancel a job and handle payment
  cancelJob(jobId: string, reason: string): boolean {
    const jobPayment = this.jobPayments.get(jobId);
    if (!jobPayment || jobPayment.status !== 'pending') {
      return false;
    }

    jobPayment.status = 'cancelled';
    
    // Update valeter earnings (no payment for cancelled jobs)
    this.updateValeterEarnings(jobPayment.valeterId, jobPayment);
    
    return true;
  }

  // Get valeter earnings
  getValeterEarnings(valeterId: string): ValeterEarnings | null {
    return this.valeterEarnings.get(valeterId) || null;
  }

  // Get all valeter earnings
  getAllValeterEarnings(): ValeterEarnings[] {
    return Array.from(this.valeterEarnings.values())
      .sort((a, b) => b.totalEarnings - a.totalEarnings);
  }

  // Get platform earnings summary
  getPlatformEarnings(): PlatformEarnings {
    const allPayments = Array.from(this.jobPayments.values());
    const completedPayments = allPayments.filter(p => p.status === 'completed');
    
    const totalRevenue = completedPayments.reduce((sum, p) => sum + p.basePrice, 0);
    const totalCommission = completedPayments.reduce((sum, p) => sum + p.commission, 0);
    const totalJobs = completedPayments.length;
    const nightTimeJobs = completedPayments.filter(p => p.isNightTime).length;
    const dayTimeJobs = totalJobs - nightTimeJobs;

    const now = new Date();
    const thisMonthPayments = completedPayments.filter(p => 
      p.jobDateTime.getMonth() === now.getMonth() && 
      p.jobDateTime.getFullYear() === now.getFullYear()
    );

    const thisMonthRevenue = thisMonthPayments.reduce((sum, p) => sum + p.basePrice, 0);
    const thisMonthCommission = thisMonthPayments.reduce((sum, p) => sum + p.commission, 0);
    const thisMonthJobs = thisMonthPayments.length;

    return {
      totalRevenue,
      totalCommission,
      totalJobs,
      averageCommissionPerJob: totalJobs > 0 ? totalCommission / totalJobs : 0,
      thisMonthRevenue,
      thisMonthCommission,
      thisMonthJobs,
      nightTimeJobs,
      dayTimeJobs
    };
  }

  // Create payment schedule for valeter
  createPaymentSchedule(
    valeterId: string,
    valeterName: string,
    periodStart: Date,
    periodEnd: Date,
    paymentMethod: 'bank_transfer' | 'paypal' | 'stripe' = 'bank_transfer'
  ): PaymentSchedule {
    const valeterEarnings = this.getValeterEarnings(valeterId);
    if (!valeterEarnings) {
      throw new Error('Valeter earnings not found');
    }

    // Calculate earnings for the period
    const periodPayments = Array.from(this.jobPayments.values())
      .filter(p => 
        p.valeterId === valeterId &&
        p.status === 'completed' &&
        p.jobDateTime >= periodStart &&
        p.jobDateTime <= periodEnd
      );

    const totalEarnings = periodPayments.reduce((sum, p) => sum + p.totalValeterPay, 0);
    const commission = periodPayments.reduce((sum, p) => sum + p.commission, 0);
    const unsociableHoursBonus = periodPayments.reduce((sum, p) => sum + p.unsociableHoursBonus, 0);

    const paymentSchedule: PaymentSchedule = {
      valeterId,
      valeterName,
      periodStart,
      periodEnd,
      totalEarnings,
      commission,
      unsociableHoursBonus,
      netPayment: totalEarnings,
      status: 'pending',
      paymentMethod
    };

    const scheduleId = `schedule-${valeterId}-${periodStart.getTime()}`;
    this.paymentSchedules.set(scheduleId, paymentSchedule);

    return paymentSchedule;
  }

  // Process payment for valeter
  processPayment(scheduleId: string): boolean {
    const schedule = this.paymentSchedules.get(scheduleId);
    if (!schedule || schedule.status !== 'pending') {
      return false;
    }

    schedule.status = 'processed';
    schedule.paymentDate = new Date();

    // Update valeter earnings to reflect payment
    const valeterEarnings = this.getValeterEarnings(schedule.valeterId);
    if (valeterEarnings) {
      valeterEarnings.pendingPayment = Math.max(0, valeterEarnings.pendingPayment - schedule.netPayment);
      valeterEarnings.lastPaymentDate = new Date();
    }

    return true;
  }

  // Get payment schedules for valeter
  getValeterPaymentSchedules(valeterId: string): PaymentSchedule[] {
    return Array.from(this.paymentSchedules.values())
      .filter(s => s.valeterId === valeterId)
      .sort((a, b) => b.periodStart.getTime() - a.periodStart.getTime());
  }

  // Get all payment schedules
  getAllPaymentSchedules(): PaymentSchedule[] {
    return Array.from(this.paymentSchedules.values())
      .sort((a, b) => b.periodStart.getTime() - a.periodStart.getTime());
  }

  // Get job payment details
  getJobPayment(jobId: string): JobPayment | null {
    return this.jobPayments.get(jobId) || null;
  }

  // Get all job payments
  getAllJobPayments(): JobPayment[] {
    return Array.from(this.jobPayments.values())
      .sort((a, b) => b.jobDateTime.getTime() - a.jobDateTime.getTime());
  }

  // Get night time jobs for a valeter
  getNightTimeJobs(valeterId: string): JobPayment[] {
    return Array.from(this.jobPayments.values())
      .filter(p => p.valeterId === valeterId && p.isNightTime && p.status === 'completed')
      .sort((a, b) => b.jobDateTime.getTime() - a.jobDateTime.getTime());
  }

  // Calculate potential earnings for a job
  calculatePotentialEarnings(basePrice: number, jobDateTime: Date): {
    basePrice: number;
    commission: number;
    valeterEarnings: number;
    isNightTime: boolean;
    unsociableHoursBonus: number;
    totalValeterPay: number;
  } {
    const isNightTime = this.isNightTime(jobDateTime);
    const commission = basePrice * this.COMMISSION_RATE;
    const valeterEarnings = basePrice - commission;
    const unsociableHoursBonus = isNightTime ? valeterEarnings : 0;
    const totalValeterPay = valeterEarnings + unsociableHoursBonus;

    return {
      basePrice,
      commission,
      valeterEarnings,
      isNightTime,
      unsociableHoursBonus,
      totalValeterPay
    };
  }

  // Get commission rate
  getCommissionRate(): number {
    return this.COMMISSION_RATE;
  }

  // Get unsociable hours multiplier
  getUnsociableHoursMultiplier(): number {
    return this.UNSOCIABLE_HOURS_MULTIPLIER;
  }

  // Get night time hours
  getNightTimeHours(): { start: number; end: number } {
    return {
      start: this.NIGHT_START_HOUR,
      end: this.NIGHT_END_HOUR
    };
  }
}
