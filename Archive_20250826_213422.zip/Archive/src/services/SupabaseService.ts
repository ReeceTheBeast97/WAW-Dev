import { supabase, Database, User, Booking, ValeterProfile, Organization } from '../lib/supabase';
import { Alert } from 'react-native';

export class SupabaseService {
  // User Management
  static async getUser(userId: string): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        console.error('Error fetching user:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in getUser:', error);
      return null;
    }
  }

  static async updateUser(userId: string, updates: Partial<User>): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating user:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in updateUser:', error);
      return null;
    }
  }

  static async createUser(userData: Database['public']['Tables']['users']['Insert']): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .insert(userData)
        .select()
        .single();

      if (error) {
        console.error('Error creating user:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in createUser:', error);
      return null;
    }
  }

  // Booking Management
  static async getBookings(userId: string, userType: 'customer' | 'valeter'): Promise<Booking[]> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq(userType === 'customer' ? 'customer_id' : 'valeter_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching bookings:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error in getBookings:', error);
      return [];
    }
  }

  static async getActiveBooking(userId: string, userType: 'customer' | 'valeter'): Promise<Booking | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq(userType === 'customer' ? 'customer_id' : 'valeter_id', userId)
        .in('status', ['confirmed', 'en_route', 'arrived', 'in_progress'])
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error) {
        console.error('Error fetching active booking:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in getActiveBooking:', error);
      return null;
    }
  }

  static async createBooking(bookingData: Database['public']['Tables']['bookings']['Insert']): Promise<Booking | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .insert(bookingData)
        .select()
        .single();

      if (error) {
        console.error('Error creating booking:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in createBooking:', error);
      return null;
    }
  }

  static async updateBooking(bookingId: string, updates: Partial<Booking>): Promise<Booking | null> {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', bookingId)
        .select()
        .single();

      if (error) {
        console.error('Error updating booking:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in updateBooking:', error);
      return null;
    }
  }

  // Valeter Profile Management
  static async getValeterProfile(userId: string): Promise<ValeterProfile | null> {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error) {
        console.error('Error fetching valeter profile:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in getValeterProfile:', error);
      return null;
    }
  }

  static async createValeterProfile(profileData: Database['public']['Tables']['valeter_profiles']['Insert']): Promise<ValeterProfile | null> {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .insert(profileData)
        .select()
        .single();

      if (error) {
        console.error('Error creating valeter profile:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in createValeterProfile:', error);
      return null;
    }
  }

  static async updateValeterProfile(userId: string, updates: Partial<ValeterProfile>): Promise<ValeterProfile | null> {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('user_id', userId)
        .select()
        .single();

      if (error) {
        console.error('Error updating valeter profile:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in updateValeterProfile:', error);
      return null;
    }
  }

  // Organization Management
  static async getOrganizations(): Promise<Organization[]> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .order('name', { ascending: true });

      if (error) {
        console.error('Error fetching organizations:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('Error in getOrganizations:', error);
      return [];
    }
  }

  static async getOrganization(orgId: string): Promise<Organization | null> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', orgId)
        .single();

      if (error) {
        console.error('Error fetching organization:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in getOrganization:', error);
      return null;
    }
  }

  static async createOrganization(orgData: Database['public']['Tables']['organizations']['Insert']): Promise<Organization | null> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .insert(orgData)
        .select()
        .single();

      if (error) {
        console.error('Error creating organization:', error);
        return null;
      }

      return data;
    } catch (error) {
      console.error('Error in createOrganization:', error);
      return null;
    }
  }

  // Analytics and Statistics
  static async getUserStats(userId: string, userType: 'customer' | 'valeter'): Promise<any> {
    try {
      let stats = {};

      if (userType === 'customer') {
        // Get customer stats
        const { data: bookings, error: bookingsError } = await supabase
          .from('bookings')
          .select('*')
          .eq('customer_id', userId);

        if (!bookingsError && bookings) {
          const totalBookings = bookings.length;
          const completedBookings = bookings.filter(b => b.status === 'completed').length;
          const totalSpent = bookings
            .filter(b => b.status === 'completed')
            .reduce((sum, b) => sum + (b.price || 0), 0);
          const averageRating = bookings
            .filter(b => b.rating)
            .reduce((sum, b) => sum + (b.rating || 0), 0) / 
            bookings.filter(b => b.rating).length;

          stats = {
            totalBookings,
            completedBookings,
            totalSpent,
            averageRating: averageRating || 0,
            savings: totalSpent * 0.15, // 15% savings estimate
          };
        }
      } else {
        // Get valeter stats
        const { data: bookings, error: bookingsError } = await supabase
          .from('bookings')
          .select('*')
          .eq('valeter_id', userId);

        if (!bookingsError && bookings) {
          const totalJobs = bookings.length;
          const completedJobs = bookings.filter(b => b.status === 'completed').length;
          const totalEarnings = bookings
            .filter(b => b.status === 'completed')
            .reduce((sum, b) => sum + (b.price || 0), 0);
          const averageRating = bookings
            .filter(b => b.rating)
            .reduce((sum, b) => sum + (b.rating || 0), 0) / 
            bookings.filter(b => b.rating).length;

          stats = {
            totalJobs,
            completedJobs,
            totalEarnings,
            averageRating: averageRating || 0,
            completionRate: totalJobs > 0 ? (completedJobs / totalJobs) * 100 : 0,
          };
        }
      }

      return stats;
    } catch (error) {
      console.error('Error in getUserStats:', error);
      return {};
    }
  }

  // Nearby Valeters
  static async getNearbyValeters(latitude: number, longitude: number, radius: number = 10): Promise<User[]> {
    try {
      // Get all online valeters
      const { data: valeterProfiles, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, current_location, is_online')
        .eq('is_online', true);

      if (profilesError || !valeterProfiles) {
        console.error('Error fetching valeter profiles:', profilesError);
        return [];
      }

      // Filter by distance (simplified - in production, use PostGIS for proper geospatial queries)
      const nearbyValeters = valeterProfiles
        .filter(profile => {
          if (!profile.current_location) return false;
          
          const distance = this.calculateDistance(
            latitude,
            longitude,
            profile.current_location.latitude,
            profile.current_location.longitude
          );
          
          return distance <= radius;
        })
        .map(profile => profile.user_id);

      if (nearbyValeters.length === 0) return [];

      // Get user details for nearby valeters
      const { data: users, error: usersError } = await supabase
        .from('users')
        .select('*')
        .in('id', nearbyValeters)
        .eq('user_type', 'valeter');

      if (usersError) {
        console.error('Error fetching nearby valeters:', usersError);
        return [];
      }

      return users || [];
    } catch (error) {
      console.error('Error in getNearbyValeters:', error);
      return [];
    }
  }

  // Document Upload
  static async uploadDocument(userId: string, documentType: string, fileUrl: string): Promise<boolean> {
    try {
      // Update valeter profile with document
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          documents: supabase.sql`jsonb_set(documents, '{${documentType}}', '${fileUrl}'::jsonb)`,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', userId);

      if (error) {
        console.error('Error uploading document:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in uploadDocument:', error);
      return false;
    }
  }

  // Organization Requests
  static async createOrganizationRequest(requestData: {
    userId: string;
    organizationId: string;
    status: 'pending' | 'approved' | 'rejected';
    submittedAt: string;
  }): Promise<boolean> {
    try {
      // This would typically go to a separate organization_requests table
      // For now, we'll update the user's organization_id
      const { error } = await supabase
        .from('users')
        .update({
          organization_id: requestData.organizationId,
          updated_at: new Date().toISOString(),
        })
        .eq('id', requestData.userId);

      if (error) {
        console.error('Error creating organization request:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error in createOrganizationRequest:', error);
      return false;
    }
  }

  // Utility function to calculate distance between two points
  private static calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distance in kilometers
    return distance;
  }

  private static deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }

  // Error handling
  static handleError(error: any, context: string) {
    console.error(`Error in ${context}:`, error);
    Alert.alert('Error', `An error occurred: ${error.message || 'Unknown error'}`);
  }
}
