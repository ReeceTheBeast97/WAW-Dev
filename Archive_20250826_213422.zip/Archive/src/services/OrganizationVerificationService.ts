import { supabase } from '../lib/api/real/supabaseClient';

// Organization Verification Service for Wish a Wash
export interface OrganizationDocument {
  id: string;
  type: 'business_license' | 'insurance_certificate' | 'tax_registration' | 'disclaimer_signed';
  name: string;
  description: string;
  required: boolean;
  uploaded: boolean;
  fileUrl?: string;
  uploadedAt?: Date;
  verified: boolean;
  verifiedAt?: Date;
}

export interface OrganizationValeter {
  id: string;
  name: string;
  email: string;
  phone: string;
  profilePicture?: string;
  idProof?: string;
  selfie?: string;
  status: 'pending' | 'approved' | 'rejected' | 'active';
  joinedAt: Date;
  approvedAt?: Date;
  documents: {
    idProof: boolean;
    selfie: boolean;
    detailsCompleted: boolean;
  };
}

export interface Organization {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  businessType: 'car_wash' | 'detailing' | 'valeting' | 'multi_service';
  documents: OrganizationDocument[];
  valeters: OrganizationValeter[];
  status: 'pending' | 'verified' | 'suspended' | 'active';
  createdAt: Date;
  verifiedAt?: Date;
  disclaimerSigned: boolean;
  disclaimerSignedAt?: Date;
}

class OrganizationVerificationService {
  private static instance: OrganizationVerificationService;

  static getInstance(): OrganizationVerificationService {
    if (!OrganizationVerificationService.instance) {
      OrganizationVerificationService.instance = new OrganizationVerificationService();
    }
    return OrganizationVerificationService.instance;
  }

  // Required documents for organizations
  private getRequiredDocuments(): OrganizationDocument[] {
    return [
      {
        id: 'business_license',
        type: 'business_license',
        name: 'Business License',
        description: 'Valid business license or registration certificate',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'insurance_certificate',
        type: 'insurance_certificate',
        name: 'Public Liability Insurance',
        description: 'Certificate of public liability insurance (minimum £2M coverage)',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'tax_registration',
        type: 'tax_registration',
        name: 'Tax Registration',
        description: 'VAT registration or tax identification number',
        required: true,
        uploaded: false,
        verified: false,
      },
      {
        id: 'disclaimer_signed',
        type: 'disclaimer_signed',
        name: 'Terms & Conditions Agreement',
        description: 'Signed agreement to Wish a Wash terms and conditions',
        required: true,
        uploaded: false,
        verified: false,
      },
    ];
  }

  // Create a new organization
  async createOrganization(orgData: Partial<Organization>): Promise<Organization> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .insert({
          name: orgData.name,
          email: orgData.email,
          phone: orgData.phone,
          address: orgData.address,
          business_type: orgData.businessType,
          status: 'pending',
          disclaimer_signed: false
        })
        .select()
        .single();

      if (error) throw new Error(`Failed to create organization: ${error.message}`);

      return this.mapOrganizationFromDatabase(data);
    } catch (error) {
      console.error('Error creating organization:', error);
      throw error;
    }
  }

  // Get organization by ID
  async getOrganization(orgId: string): Promise<Organization | null> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', orgId)
        .single();

      if (error) {
        console.error('Error fetching organization:', error);
        return null;
      }

      return data ? this.mapOrganizationFromDatabase(data) : null;
    } catch (error) {
      console.error('Error fetching organization:', error);
      return null;
    }
  }

  // Upload document for organization
  async uploadDocument(orgId: string, documentType: string, fileUrl: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('organization_documents')
        .insert({
          organization_id: orgId,
          document_type: documentType,
          file_url: fileUrl,
          uploaded_at: new Date().toISOString(),
          verified: false
        });

      if (error) {
        console.error('Error uploading document:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error uploading document:', error);
      return false;
    }
  }

  // Verify document
  async verifyDocument(orgId: string, documentType: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('organization_documents')
        .update({
          verified: true,
          verified_at: new Date().toISOString()
        })
        .eq('organization_id', orgId)
        .eq('document_type', documentType);

      if (error) {
        console.error('Error verifying document:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error verifying document:', error);
      return false;
    }
  }

  // Check if organization can operate
  async canOrganizationOperate(orgId: string): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('status')
        .eq('id', orgId)
        .single();

      if (error) {
        console.error('Error checking organization status:', error);
        return false;
      }

      return data?.status === 'active';
    } catch (error) {
      console.error('Error checking organization status:', error);
      return false;
    }
  }

  // Add valeter to organization
  async addValeter(orgId: string, valeterData: Partial<OrganizationValeter>): Promise<OrganizationValeter | null> {
    try {
      const { data, error } = await supabase
        .from('organization_valeters')
        .insert({
          organization_id: orgId,
          name: valeterData.name,
          email: valeterData.email,
          phone: valeterData.phone,
          status: 'pending',
          joined_at: new Date().toISOString()
        })
        .select()
        .single();

      if (error) {
        console.error('Error adding valeter:', error);
        return null;
      }

      return this.mapValeterFromDatabase(data);
    } catch (error) {
      console.error('Error adding valeter:', error);
      return null;
    }
  }

  // Update valeter documents
  async updateValeterDocuments(orgId: string, valeterId: string, updates: Partial<OrganizationValeter>): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('organization_valeters')
        .update({
          id_proof: updates.idProof,
          selfie: updates.selfie,
          details_completed: updates.documents?.detailsCompleted
        })
        .eq('id', valeterId)
        .eq('organization_id', orgId);

      if (error) {
        console.error('Error updating valeter documents:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error updating valeter documents:', error);
      return false;
    }
  }

  // Check if valeter can work
  async canValeterWork(orgId: string, valeterId: string): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .from('organization_valeters')
        .select('status')
        .eq('id', valeterId)
        .eq('organization_id', orgId)
        .single();

      if (error) {
        console.error('Error checking valeter status:', error);
        return false;
      }

      return data?.status === 'active';
    } catch (error) {
      console.error('Error checking valeter status:', error);
      return false;
    }
  }

  // Get all organizations
  async getAllOrganizations(): Promise<Organization[]> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching organizations:', error);
        return [];
      }

      return data?.map(org => this.mapOrganizationFromDatabase(org)) || [];
    } catch (error) {
      console.error('Error fetching organizations:', error);
      return [];
    }
  }

  // Get organizations by status
  async getOrganizationsByStatus(status: Organization['status']): Promise<Organization[]> {
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('status', status)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching organizations by status:', error);
        return [];
      }

      return data?.map(org => this.mapOrganizationFromDatabase(org)) || [];
    } catch (error) {
      console.error('Error fetching organizations by status:', error);
      return [];
    }
  }

  // Get pending verifications
  async getPendingVerifications(): Promise<Organization[]> {
    return this.getOrganizationsByStatus('pending');
  }

  // Activate organization
  async activateOrganization(orgId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          status: 'active',
          verified_at: new Date().toISOString()
        })
        .eq('id', orgId);

      if (error) {
        console.error('Error activating organization:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error activating organization:', error);
      return false;
    }
  }

  // Suspend organization
  async suspendOrganization(orgId: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          status: 'suspended'
        })
        .eq('id', orgId);

      if (error) {
        console.error('Error suspending organization:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error suspending organization:', error);
      return false;
    }
  }

  // Get organization statistics
  async getOrganizationStats(orgId: string): Promise<{
    totalValeters: number;
    activeValeters: number;
    totalBookings: number;
    totalRevenue: number;
    averageRating: number;
  }> {
    try {
      // Get valeter stats
      const { data: valeters, error: valeterError } = await supabase
        .from('organization_valeters')
        .select('status')
        .eq('organization_id', orgId);

      if (valeterError) {
        console.error('Error fetching valeter stats:', valeterError);
        return {
          totalValeters: 0,
          activeValeters: 0,
          totalBookings: 0,
          totalRevenue: 0,
          averageRating: 0
        };
      }

      const totalValeters = valeters?.length || 0;
      const activeValeters = valeters?.filter(v => v.status === 'active').length || 0;

      // TODO: Implement booking and revenue stats
      return {
        totalValeters,
        activeValeters,
        totalBookings: 0, // TODO: Implement
        totalRevenue: 0, // TODO: Implement
        averageRating: 0 // TODO: Implement
      };
    } catch (error) {
      console.error('Error fetching organization stats:', error);
      return {
        totalValeters: 0,
        activeValeters: 0,
        totalBookings: 0,
        totalRevenue: 0,
        averageRating: 0
      };
    }
  }

  // Map database record to Organization
  private mapOrganizationFromDatabase(dbRecord: any): Organization {
    return {
      id: dbRecord.id,
      name: dbRecord.name,
      email: dbRecord.email,
      phone: dbRecord.phone,
      address: dbRecord.address,
      businessType: dbRecord.business_type,
      documents: [], // TODO: Load documents
      valeters: [], // TODO: Load valeters
      status: dbRecord.status,
      createdAt: new Date(dbRecord.created_at),
      verifiedAt: dbRecord.verified_at ? new Date(dbRecord.verified_at) : undefined as any,
      disclaimerSigned: dbRecord.disclaimer_signed || false,
      disclaimerSignedAt: dbRecord.disclaimer_signed_at ? new Date(dbRecord.disclaimer_signed_at) : undefined as any
    };
  }

  // Map database record to OrganizationValeter
  private mapValeterFromDatabase(dbRecord: any): OrganizationValeter {
    return {
      id: dbRecord.id,
      name: dbRecord.name,
      email: dbRecord.email,
      phone: dbRecord.phone,
      profilePicture: dbRecord.profile_picture,
      idProof: dbRecord.id_proof,
      selfie: dbRecord.selfie,
      status: dbRecord.status,
      joinedAt: new Date(dbRecord.joined_at),
      approvedAt: dbRecord.approved_at ? new Date(dbRecord.approved_at) : undefined as any,
      documents: {
        idProof: !!dbRecord.id_proof,
        selfie: !!dbRecord.selfie,
        detailsCompleted: dbRecord.details_completed || false
      }
    };
  }
}

export const organizationVerificationService = OrganizationVerificationService.getInstance();
