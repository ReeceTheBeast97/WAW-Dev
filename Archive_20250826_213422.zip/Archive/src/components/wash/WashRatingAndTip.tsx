import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Animated,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { washCompletionService, WashCompletion } from '../../services/WashCompletionService';
import { useAuth } from '../../../app/enhanced-auth-context';

const { width, height } = Dimensions.get('window');

interface WashRatingAndTipProps {
  washCompletionId: string;
  onComplete?: () => void;
  onClose?: () => void;
}

export default function WashRatingAndTip({ 
  washCompletionId, 
  onComplete, 
  onClose 
}: WashRatingAndTipProps) {
  const { user } = useAuth();
  const [washCompletion, setWashCompletion] = useState<WashCompletion | null>(null);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  const starAnimations = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];

  useEffect(() => {
    loadWashCompletion();
  }, []);

  const loadWashCompletion = async () => {
    try {
      const completion = await washCompletionService.getWashCompletion(washCompletionId);
      setWashCompletion(completion);
    } catch (error) {
      Alert.alert('Error', 'Failed to load wash completion details');
    } finally {
      setLoading(false);
    }
  };

  const animateStars = (selectedRating: number) => {
    starAnimations.forEach((anim, index) => {
      Animated.spring(anim, {
        toValue: index < selectedRating ? 1 : 0,
        useNativeDriver: true,
        tension: 100,
        friction: 8,
      }).start();
    });
  };

  const handleStarPress = (starIndex: number) => {
    const newRating = starIndex + 1;
    setRating(newRating);
    animateStars(newRating);
  };

  const handleTipSelect = (amount: number) => {
    setTipAmount(amount);
  };

  const handleSubmit = async () => {
    if (rating === 0) {
      Alert.alert('Rating Required', 'Please select a star rating');
      return;
    }

    if (review.trim().length === 0) {
      Alert.alert('Review Required', 'Please write a review');
      return;
    }

    setIsSubmitting(true);
    try {
      await washCompletionService.submitRating(
        washCompletionId,
        rating,
        review,
        tipAmount
      );

      Alert.alert(
        'Thank You!',
        'Your rating and tip have been submitted successfully.',
        [
          {
            text: 'OK',
            onPress: () => {
              onComplete?.();
              onClose?.();
            }
          }
        ]
      );
    } catch (error) {
      Alert.alert('Submission Failed', 'Please try again');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
        <Text style={styles.loadingText}>Loading wash details...</Text>
      </View>
    );
  }

  if (!washCompletion) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Wash completion not found</Text>
        <TouchableOpacity style={styles.errorButton} onPress={onClose}>
          <Text style={styles.errorButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Rate Your Wash</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>✨ Rate Your Experience</Text>
          <Text style={styles.sectionSubtitle}>
            How was your car wash service today?
          </Text>

          <View style={styles.starsContainer}>
            {[0, 1, 2, 3, 4].map((starIndex) => (
              <TouchableOpacity
                key={starIndex}
                style={styles.starButton}
                onPress={() => handleStarPress(starIndex)}
              >
                <Animated.Text
                  style={[
                    styles.starIcon,
                    {
                      transform: [
                        {
                          scale: starAnimations[starIndex].interpolate({
                            inputRange: [0, 1],
                            outputRange: [1, 1.2],
                          }),
                        },
                      ],
                      color: starIndex < rating ? '#FFD700' : '#6B7280',
                    },
                  ]}
                >
                  ⭐
                </Animated.Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.ratingText}>
            {rating === 0 && 'Tap the stars to rate'}
            {rating === 1 && 'Poor'}
            {rating === 2 && 'Fair'}
            {rating === 3 && 'Good'}
            {rating === 4 && 'Very Good'}
            {rating === 5 && 'Excellent!'}
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📝 Write a Review</Text>
          <Text style={styles.sectionSubtitle}>
            Share your experience with the valeter
          </Text>

          <TextInput
            style={styles.reviewInput}
            placeholder="Tell us about your experience... (e.g., Great service, car looks amazing, very professional)"
            placeholderTextColor="#87CEEB"
            value={review}
            onChangeText={setReview}
            multiline
            numberOfLines={4}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>💰 Leave a Tip (Optional)</Text>
          <Text style={styles.sectionSubtitle}>
            Show appreciation for excellent service
          </Text>

          <View style={styles.tipOptions}>
            {[0, 2, 5, 10, 15, 20].map((amount) => (
              <TouchableOpacity
                key={amount}
                style={[
                  styles.tipOption,
                  tipAmount === amount && styles.tipOptionSelected
                ]}
                onPress={() => handleTipSelect(amount)}
              >
                <Text style={[
                  styles.tipAmount,
                  tipAmount === amount && styles.tipAmountSelected
                ]}>
                  £{amount}
                </Text>
                {amount === 0 && (
                  <Text style={[
                    styles.tipLabel,
                    tipAmount === amount && styles.tipLabelSelected
                  ]}>
                    No Tip
                  </Text>
                )}
              </TouchableOpacity>
            ))}
          </View>

          {tipAmount > 0 && (
            <View style={styles.tipMessage}>
              <Text style={styles.tipMessageText}>
                💝 Thank you for your generosity! Your tip will be sent directly to the valeter.
              </Text>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📸 Wash Photos</Text>
          <Text style={styles.sectionSubtitle}>
            Photos from your completed wash
          </Text>

          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {washCompletion.photos.map((photo, index) => (
              <View key={index} style={styles.photoContainer}>
                <View style={styles.photoPlaceholder}>
                  <Text style={styles.photoPlaceholderText}>📸</Text>
                  <Text style={styles.photoPlaceholderLabel}>Photo {index + 1}</Text>
                </View>
              </View>
            ))}
          </ScrollView>

          {washCompletion.notes && (
            <View style={styles.notesContainer}>
              <Text style={styles.notesTitle}>Valeter Notes:</Text>
              <Text style={styles.notesText}>{washCompletion.notes}</Text>
            </View>
          )}
        </View>

        <TouchableOpacity
          style={[styles.submitButton, isSubmitting && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator color="#0A1929" />
          ) : (
            <>
              <Text style={styles.submitButtonIcon}>⭐</Text>
              <Text style={styles.submitButtonText}>
                Submit Rating {tipAmount > 0 && `& £${tipAmount} Tip`}
              </Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginTop: 16,
  },
  errorContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  errorText: {
    color: '#FFFFFF',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
  },
  errorButton: {
    backgroundColor: '#EF4444',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  errorButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginVertical: 20,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  starButton: {
    padding: 8,
    marginHorizontal: 4,
  },
  starIcon: {
    fontSize: 40,
  },
  ratingText: {
    color: '#FFFFFF',
    fontSize: 18,
    textAlign: 'center',
    fontWeight: '600',
  },
  reviewInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#FFFFFF',
    fontSize: 16,
    textAlignVertical: 'top',
    minHeight: 100,
  },
  tipOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
  tipOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
    width: '30%',
    marginBottom: 12,
  },
  tipOptionSelected: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  tipAmount: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tipAmountSelected: {
    color: '#FFFFFF',
  },
  tipLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
  },
  tipLabelSelected: {
    color: '#FFFFFF',
  },
  tipMessage: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
  },
  tipMessageText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
  },
  photoContainer: {
    marginRight: 12,
  },
  photoPlaceholder: {
    width: 100,
    height: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  photoPlaceholderText: {
    fontSize: 24,
    marginBottom: 4,
  },
  photoPlaceholderLabel: {
    color: '#87CEEB',
    fontSize: 12,
  },
  notesContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  notesTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  notesText: {
    color: '#87CEEB',
    fontSize: 14,
    lineHeight: 20,
  },
  submitButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  submitButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  submitButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
