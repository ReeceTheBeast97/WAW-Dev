import React from 'react';
import { useAuth } from '../../app/enhanced-auth-context';

interface AdminGateProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export const AdminGate: React.FC<AdminGateProps> = ({ children, fallback = null }) => {
  const { hasAdminAccess } = useAuth();

  if (!hasAdminAccess()) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

export default AdminGate;
