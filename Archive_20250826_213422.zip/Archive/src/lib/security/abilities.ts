// CASL abilities for client-side authorization
import { AbilityBuilder, Ability } from "@casl/ability";

export type Actions = "create" | "read" | "update" | "delete" | "manage";
export type Subjects = "Job" | "Location" | "Message" | "Service" | "all";

export function defineAbilitiesFor(role: "customer" | "valeter" | "admin") {
  const { can, cannot, build } = new AbilityBuilder<Ability<[Actions, Subjects]>>(Ability as any);

  if (role === "customer") {
    can("create", "Job");
    can("read", "Job");
    can("update", "Job"); // own job UI gating
    can("create", "Message");
    can("read", "Message");
  }
  
  if (role === "valeter") {
    can("read", "Job");
    can("update", "Job"); // accept/advance assigned
    can("create", "Location");
    can("create", "Message");
  }
  
  if (role === "admin") {
    can("manage", "all");
  }

  return build();
}
