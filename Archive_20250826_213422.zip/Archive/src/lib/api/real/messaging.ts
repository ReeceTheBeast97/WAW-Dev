// Real messaging implementation using Supabase
import { supabase } from "./supabaseClient";

export function subscribeChat(jobId: number, cb: (m: { id: number; from: string; text: string; created_at: string }) => void) {
  const channel = supabase
    .channel(`chat-${jobId}`)
    .on("postgres_changes",
      { event: "INSERT", schema: "public", table: "messages", filter: `job_id=eq.${jobId}` },
      (payload) => cb(payload.new)
    )
    .subscribe();
  
  return () => supabase.removeChannel(channel);
}

export async function sendChat(jobId: number, from: 'customer' | 'valeter', text: string) {
  const { error } = await supabase
    .from("messages")
    .insert({ job_id: jobId, from_role: from, text });
  
  if (error) throw error;
}
