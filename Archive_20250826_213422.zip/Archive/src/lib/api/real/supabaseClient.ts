import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
//import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';


const SUPABASE_URL = 'https://rmhlnfqgjipeawaddwor.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtaGxuZnFnamlwZWF3YWRkd29yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU5NTY4NDcsImV4cCI6MjA3MTUzMjg0N30.zhriJZhHMwwO4Q3iTsbIXN4EHeu89Vn8xo-yte9X-y4';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: AsyncStorage,          // <-- recommended for RN
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,      // <-- required on native
    storageKey: 'sb-waw-auth',      // optional: namespaced key
  },
});