// Mock Locations API - Static car wash locations
import { 
  LocationsAPI, 
  StaticLocation, 
  TimeSlot, 
  CreateLocationData, 
  Service,
  ApiException, 
  ErrorCodes 
} from '../types';

// Mock services for locations
const mockServices: Service[] = [
  {
    id: 1,
    name: 'Basic Wash',
    description: 'Exterior wash and interior vacuum',
    price: 2500, // £25.00
    duration_min: 30,
    is_active: true,
  },
  {
    id: 2,
    name: 'Premium Wash',
    description: 'Basic wash plus interior cleaning and tire shine',
    price: 3500, // £35.00
    duration_min: 45,
    is_active: true,
  },
  {
    id: 3,
    name: 'Luxury Wash',
    description: 'Premium wash plus wax and full interior detail',
    price: 5000, // £50.00
    duration_min: 60,
    is_active: true,
  },
];

// Mock static locations data
const mockStaticLocations: StaticLocation[] = [
  {
    id: 'wash_1',
    name: 'Elite Car Wash',
    description: 'Premium car wash and valeting service in central London',
    lat: 51.5074,
    lng: -0.1278,
    address: '123 Oxford Street, London W1D 1BS',
    isActive: true,
    services: [mockServices[0], mockServices[1], mockServices[2]],
  },
  {
    id: 'wash_2',
    name: 'Premium Valet',
    description: 'Professional valeting service with attention to detail',
    lat: 51.5075,
    lng: -0.1279,
    address: '456 Regent Street, London W1B 4HA',
    isActive: true,
    services: [mockServices[1], mockServices[2]],
  },
  {
    id: 'wash_3',
    name: 'Express Car Wash',
    description: 'Quick and efficient car wash service',
    lat: 51.5076,
    lng: -0.1280,
    address: '789 Bond Street, London W1S 1BE',
    isActive: true,
    services: [mockServices[0]],
  },
  {
    id: 'wash_4',
    name: 'Luxury Auto Spa',
    description: 'Ultimate car care experience with premium services',
    lat: 51.5077,
    lng: -0.1281,
    address: '321 Mayfair, London W1J 8LQ',
    isActive: false, // Temporarily closed
    services: [mockServices[2]],
  },
];

// Mock time slots data
const mockTimeSlots: TimeSlot[] = [
  // Elite Car Wash slots
  {
    id: 'slot_1',
    locationId: 'wash_1',
    startTime: '09:00',
    endTime: '10:00',
    isAvailable: true,
    price: 2500,
  },
  {
    id: 'slot_2',
    locationId: 'wash_1',
    startTime: '10:00',
    endTime: '11:00',
    isAvailable: false, // Booked
    price: 2500,
  },
  {
    id: 'slot_3',
    locationId: 'wash_1',
    startTime: '11:00',
    endTime: '12:00',
    isAvailable: true,
    price: 2500,
  },
  {
    id: 'slot_4',
    locationId: 'wash_1',
    startTime: '12:00',
    endTime: '13:00',
    isAvailable: true,
    price: 2500,
  },
  // Premium Valet slots
  {
    id: 'slot_5',
    locationId: 'wash_2',
    startTime: '09:00',
    endTime: '10:00',
    isAvailable: true,
    price: 3500,
  },
  {
    id: 'slot_6',
    locationId: 'wash_2',
    startTime: '10:00',
    endTime: '11:00',
    isAvailable: true,
    price: 3500,
  },
  {
    id: 'slot_7',
    locationId: 'wash_2',
    startTime: '11:00',
    endTime: '12:00',
    isAvailable: false, // Booked
    price: 3500,
  },
];

// Mock implementation
export const locations: LocationsAPI = {
  // Static locations
  async getStaticLocations(): Promise<StaticLocation[]> {
    console.log('🏢 Mock Locations: Get static locations');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Return active locations only
    const activeLocations = mockStaticLocations.filter(location => location.isActive);
    
    console.log('🏢 Mock Locations: Retrieved locations', { count: activeLocations.length });
    
    return activeLocations;
  },

  async getAvailableSlots(locationId: string, date: string): Promise<TimeSlot[]> {
    console.log('🏢 Mock Locations: Get available slots', { locationId, date });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Mock validation
    if (!locationId || !date) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Location ID and date are required');
    }
    
    // Check if location exists
    const location = mockStaticLocations.find(loc => loc.id === locationId);
    if (!location) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Location not found');
    }
    
    // Return slots for the location
    const locationSlots = mockTimeSlots.filter(slot => slot.locationId === locationId);
    
    console.log('🏢 Mock Locations: Retrieved slots', { 
      locationId, 
      date, 
      count: locationSlots.length 
    });
    
    return locationSlots;
  },

  // Location management (admin functions)
  async createStaticLocation(locationData: CreateLocationData): Promise<StaticLocation> {
    console.log('🏢 Mock Locations: Create static location', locationData);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (!locationData.name || !locationData.address) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Name and address are required');
    }
    
    if (typeof locationData.lat !== 'number' || typeof locationData.lng !== 'number') {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Valid coordinates are required');
    }
    
    // Validate coordinates
    if (locationData.lat < -90 || locationData.lat > 90 || 
        locationData.lng < -180 || locationData.lng > 180) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid coordinates');
    }
    
    // Check if location already exists
    const existingLocation = mockStaticLocations.find(loc => 
      loc.name.toLowerCase() === locationData.name.toLowerCase()
    );
    if (existingLocation) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Location with this name already exists');
    }
    
    // Create new location
    const newLocation: StaticLocation = {
      id: `wash_${Date.now()}`,
      name: locationData.name,
      description: locationData.description || '',
      lat: locationData.lat,
      lng: locationData.lng,
      address: locationData.address,
      isActive: true,
      services: locationData.services.map(serviceId => 
        mockServices.find(service => service.id === serviceId)
      ).filter(Boolean) as Service[],
    };
    
    // Add to mock data
    mockStaticLocations.push(newLocation);
    
    console.log('🏢 Mock Locations: Location created successfully', { locationId: newLocation.id });
    
    return newLocation;
  },

  async updateStaticLocation(locationId: string, updates: Partial<StaticLocation>): Promise<StaticLocation> {
    console.log('🏢 Mock Locations: Update static location', { locationId, updates });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Find location
    const locationIndex = mockStaticLocations.findIndex(loc => loc.id === locationId);
    if (locationIndex === -1) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Location not found');
    }
    
    // Update location
    const updatedLocation = {
      ...mockStaticLocations[locationIndex],
      ...updates,
    };
    
    // Validate coordinates if updated
    if (updates.lat !== undefined || updates.lng !== undefined) {
      const lat = updates.lat ?? updatedLocation.lat;
      const lng = updates.lng ?? updatedLocation.lng;
      
      if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid coordinates');
      }
    }
    
    // Update in mock data
    mockStaticLocations[locationIndex] = updatedLocation;
    
    console.log('🏢 Mock Locations: Location updated successfully', { locationId });
    
    return updatedLocation;
  },
};
