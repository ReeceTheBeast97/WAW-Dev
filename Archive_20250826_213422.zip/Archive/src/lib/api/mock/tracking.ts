// Mock Tracking API - Wraps existing EnhancedLiveTrackingService functionality
import { 
  TrackingAPI, 
  Ping, 
  ApiException, 
  ErrorCodes 
} from '../types';

// Import existing tracking service
import { EnhancedLiveTrackingService } from '../../../services/EnhancedLiveTrackingService';

// Mock tracking data
const mockPings: Ping[] = [
  {
    id: 1,
    userId: 'valeter_1',
    jobId: 1,
    lat: 51.5074,
    lng: -0.1278,
    heading: 90,
    speed: 25,
    timestampIso: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
  },
  {
    id: 2,
    userId: 'valeter_1',
    jobId: 1,
    lat: 51.5075,
    lng: -0.1279,
    heading: 90,
    speed: 30,
    timestampIso: new Date(Date.now() - 4 * 60 * 1000).toISOString(),
  },
  {
    id: 3,
    userId: 'valeter_1',
    jobId: 1,
    lat: 51.5076,
    lng: -0.1280,
    heading: 90,
    speed: 0,
    timestampIso: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
  },
];

// Mock implementation that wraps EnhancedLiveTrackingService
export const tracking: TrackingAPI = {
  // Location tracking
  async sendPing(userId: string, lat: number, lng: number, jobId?: number): Promise<void> {
    console.log('📍 Mock Tracking: Send ping', { userId, lat, lng, jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock validation
    if (!userId || typeof lat !== 'number' || typeof lng !== 'number') {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid ping data');
    }
    
    // Validate coordinates
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid coordinates');
    }
    
    // Create ping
    const ping: Ping = {
      id: mockPings.length + 1,
      userId,
      jobId,
      lat,
      lng,
      heading: Math.random() * 360, // Mock heading
      speed: Math.random() * 50, // Mock speed
      timestampIso: new Date().toISOString(),
    };
    
    // Add to mock data
    mockPings.push(ping);
    
    console.log('📍 Mock Tracking: Ping sent successfully', { pingId: ping.id });
  },

  async getPingsForJob(jobId: number): Promise<Ping[]> {
    console.log('📍 Mock Tracking: Get pings for job', { jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Return pings for the job
    const jobPings = mockPings.filter(ping => ping.jobId === jobId);
    
    // Sort by timestamp (newest first)
    jobPings.sort((a, b) => new Date(b.timestampIso).getTime() - new Date(a.timestampIso).getTime());
    
    return jobPings;
  },

  // Real-time subscriptions
  subscribeToPings(jobId: number, callback: (ping: Ping) => void): () => void {
    console.log('📍 Mock Tracking: Subscribe to pings', { jobId });
    
    // Mock real-time subscription using setInterval
    const interval = setInterval(() => {
      // Generate mock ping
      const mockPing: Ping = {
        id: Date.now(),
        userId: 'valeter_1',
        jobId,
        lat: 51.5074 + (Math.random() - 0.5) * 0.001, // Small random movement
        lng: -0.1278 + (Math.random() - 0.5) * 0.001,
        heading: Math.random() * 360,
        speed: Math.random() * 50,
        timestampIso: new Date().toISOString(),
      };
      
      callback(mockPing);
    }, 10000); // Update every 10 seconds
    
    // Return unsubscribe function
    return () => {
      console.log('📍 Mock Tracking: Unsubscribe from pings', { jobId });
      clearInterval(interval);
    };
  },

  // ETA calculation
  async calculateETA(fromLat: number, fromLng: number, toLat: number, toLng: number): Promise<number> {
    console.log('📍 Mock Tracking: Calculate ETA', { fromLat, fromLng, toLat, toLng });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (typeof fromLat !== 'number' || typeof fromLng !== 'number' || 
        typeof toLat !== 'number' || typeof toLng !== 'number') {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Invalid coordinates');
    }
    
    // Calculate distance using Haversine formula (simplified)
    const R = 6371; // Earth's radius in km
    const dLat = (toLat - fromLat) * Math.PI / 180;
    const dLng = (toLng - fromLng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(fromLat * Math.PI / 180) * Math.cos(toLat * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c; // Distance in km
    
    // Mock ETA calculation (assume average speed of 30 km/h)
    const averageSpeed = 30; // km/h
    const etaHours = distance / averageSpeed;
    const etaMinutes = Math.round(etaHours * 60);
    
    // Clamp ETA between 5 and 60 minutes
    const clampedEta = Math.max(5, Math.min(60, etaMinutes));
    
    console.log('📍 Mock Tracking: ETA calculated', { 
      distance: distance.toFixed(2), 
      etaMinutes: clampedEta 
    });
    
    return clampedEta;
  },
};
