// Mock Jobs API - Wraps existing SimulationService functionality
import { 
  JobsAPI, 
  Job, 
  Service, 
  CreateJobData, 
  UserType, 
  JobStatus,
  ApiException, 
  ErrorCodes 
} from '../types';

// Import existing simulation service
import { simulationService } from '../../../services/SimulationService';

// Mock services data
const mockServices: Service[] = [
  {
    id: 1,
    name: 'Basic Wash',
    description: 'Exterior wash and interior vacuum',
    price: 2500, // £25.00
    duration_min: 30,
    is_active: true,
  },
  {
    id: 2,
    name: 'Premium Wash',
    description: 'Basic wash plus interior cleaning and tire shine',
    price: 3500, // £35.00
    duration_min: 45,
    is_active: true,
  },
  {
    id: 3,
    name: 'Luxury Wash',
    description: 'Premium wash plus wax and full interior detail',
    price: 5000, // £50.00
    duration_min: 60,
    is_active: true,
  },
  {
    id: 4,
    name: 'Express Wash',
    description: 'Quick exterior wash only',
    price: 1500, // £15.00
    duration_min: 15,
    is_active: true,
  },
];

// Mock jobs data
const mockJobs: Job[] = [
  {
    id: 1,
    customerId: 'customer_1',
    valeterId: 'valeter_1',
    serviceId: 1,
    serviceName: 'Basic Wash',
    price: 2500,
    pickupLat: 51.5074,
    pickupLng: -0.1278,
    pickupAddress: '123 Main Street, London',
    status: 'COMPLETED',
    etaMinutes: 15,
    createdAtIso: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    updatedAtIso: new Date(Date.now() - 23 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 2,
    customerId: 'customer_1',
    serviceId: 2,
    serviceName: 'Premium Wash',
    price: 3500,
    pickupLat: 51.5074,
    pickupLng: -0.1278,
    pickupAddress: '456 High Street, London',
    status: 'REQUESTED',
    createdAtIso: new Date().toISOString(),
    updatedAtIso: new Date().toISOString(),
  },
];

// Mock implementation that wraps SimulationService
export const jobs: JobsAPI = {
  // Job management
  async createJob(jobData: CreateJobData): Promise<Job> {
    console.log('📋 Mock Jobs: Create job', jobData);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock validation
    if (!jobData.customerId || !jobData.serviceId || !jobData.pickupAddress) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Missing required job data');
    }
    
    // Find service
    const service = mockServices.find(s => s.id === jobData.serviceId);
    if (!service) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Service not found');
    }
    
    // Create job using SimulationService
    const jobId = simulationService.createJob(
      jobData.customerId,
      service.name.toLowerCase().replace(' ', '_') as 'wash' | 'valet' | 'priority_wash',
      {
        lat: jobData.pickupLat,
        lng: jobData.pickupLng,
        address: jobData.pickupAddress,
      },
      jobData.price
    );
    
    // Create job object
    const newJob: Job = {
      id: parseInt(jobId.replace('job-', '')),
      customerId: jobData.customerId,
      serviceId: jobData.serviceId,
      serviceName: service.name,
      price: jobData.price,
      pickupLat: jobData.pickupLat,
      pickupLng: jobData.pickupLng,
      pickupAddress: jobData.pickupAddress,
      status: 'REQUESTED',
      createdAtIso: new Date().toISOString(),
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('📋 Mock Jobs: Job created successfully', { jobId: newJob.id });
    
    return newJob;
  },

  async getJob(jobId: number): Promise<Job> {
    console.log('📋 Mock Jobs: Get job', { jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Find job in mock data
    const job = mockJobs.find(j => j.id === jobId);
    if (!job) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Job not found');
    }
    
    return job;
  },

  async getJobsForUser(userId: string, userType: UserType): Promise<Job[]> {
    console.log('📋 Mock Jobs: Get jobs for user', { userId, userType });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Get jobs from SimulationService
    const simulationJobs = simulationService.getJobsForUser(userId, userType);
    
    // Convert to API format
    const jobs: Job[] = simulationJobs.map(simJob => ({
      id: parseInt(simJob.id.replace('job-', '')),
      customerId: simJob.customerId,
      valeterId: simJob.valeterId,
      serviceId: 1, // Mock service ID
      serviceName: simJob.serviceType.replace('_', ' '),
      price: simJob.price,
      pickupLat: simJob.location.lat,
      pickupLng: simJob.location.lng,
      pickupAddress: simJob.location.address,
      status: simJob.status.toUpperCase() as JobStatus,
      etaMinutes: simJob.estimatedTime,
      createdAtIso: new Date(simJob.createdAt).toISOString(),
      updatedAtIso: new Date(simJob.createdAt).toISOString(),
    }));
    
    return jobs;
  },

  async getAvailableJobs(): Promise<Job[]> {
    console.log('📋 Mock Jobs: Get available jobs');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Get available jobs from SimulationService
    const simulationJobs = simulationService.getAvailableJobs();
    
    // Convert to API format
    const jobs: Job[] = simulationJobs.map(simJob => ({
      id: parseInt(simJob.id.replace('job-', '')),
      customerId: simJob.customerId,
      serviceId: 1, // Mock service ID
      serviceName: simJob.serviceType.replace('_', ' '),
      price: simJob.price,
      pickupLat: simJob.location.lat,
      pickupLng: simJob.location.lng,
      pickupAddress: simJob.location.address,
      status: 'REQUESTED',
      etaMinutes: simJob.estimatedTime,
      createdAtIso: new Date(simJob.createdAt).toISOString(),
      updatedAtIso: new Date(simJob.createdAt).toISOString(),
    }));
    
    return jobs;
  },

  // Job actions
  async acceptJob(jobId: number, valeterId: string): Promise<Job> {
    console.log('📋 Mock Jobs: Accept job', { jobId, valeterId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Accept job using SimulationService
    const success = simulationService.acceptJob(`job-${jobId}`, valeterId);
    
    if (!success) {
      throw new ApiException(ErrorCodes.JOB_ALREADY_ACCEPTED, 'Job is no longer available');
    }
    
    // Get updated job
    const simJob = simulationService.getJob(`job-${jobId}`);
    if (!simJob) {
      throw new ApiException(ErrorCodes.JOB_NOT_FOUND, 'Job not found');
    }
    
    const job: Job = {
      id: jobId,
      customerId: simJob.customerId,
      valeterId: simJob.valeterId,
      serviceId: 1, // Mock service ID
      serviceName: simJob.serviceType.replace('_', ' '),
      price: simJob.price,
      pickupLat: simJob.location.lat,
      pickupLng: simJob.location.lng,
      pickupAddress: simJob.location.address,
      status: 'ACCEPTED',
      etaMinutes: simJob.estimatedTime,
      createdAtIso: new Date(simJob.createdAt).toISOString(),
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('📋 Mock Jobs: Job accepted successfully');
    
    return job;
  },

  async startJob(jobId: number): Promise<Job> {
    console.log('📋 Mock Jobs: Start job', { jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Start job using SimulationService
    const success = simulationService.startJob(`job-${jobId}`);
    
    if (!success) {
      throw new ApiException(ErrorCodes.INVALID_STATUS_TRANSITION, 'Cannot start job in current status');
    }
    
    // Get updated job
    const simJob = simulationService.getJob(`job-${jobId}`);
    if (!simJob) {
      throw new ApiException(ErrorCodes.JOB_NOT_FOUND, 'Job not found');
    }
    
    const job: Job = {
      id: jobId,
      customerId: simJob.customerId,
      valeterId: simJob.valeterId,
      serviceId: 1, // Mock service ID
      serviceName: simJob.serviceType.replace('_', ' '),
      price: simJob.price,
      pickupLat: simJob.location.lat,
      pickupLng: simJob.location.lng,
      pickupAddress: simJob.location.address,
      status: 'IN_PROGRESS',
      etaMinutes: simJob.estimatedTime,
      createdAtIso: new Date(simJob.createdAt).toISOString(),
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('📋 Mock Jobs: Job started successfully');
    
    return job;
  },

  async completeJob(jobId: number): Promise<Job> {
    console.log('📋 Mock Jobs: Complete job', { jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Complete job using SimulationService
    const success = simulationService.completeJob(`job-${jobId}`);
    
    if (!success) {
      throw new ApiException(ErrorCodes.INVALID_STATUS_TRANSITION, 'Cannot complete job in current status');
    }
    
    // Get updated job
    const simJob = simulationService.getJob(`job-${jobId}`);
    if (!simJob) {
      throw new ApiException(ErrorCodes.JOB_NOT_FOUND, 'Job not found');
    }
    
    const job: Job = {
      id: jobId,
      customerId: simJob.customerId,
      valeterId: simJob.valeterId,
      serviceId: 1, // Mock service ID
      serviceName: simJob.serviceType.replace('_', ' '),
      price: simJob.price,
      pickupLat: simJob.location.lat,
      pickupLng: simJob.location.lng,
      pickupAddress: simJob.location.address,
      status: 'COMPLETED',
      etaMinutes: simJob.estimatedTime,
      createdAtIso: new Date(simJob.createdAt).toISOString(),
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('📋 Mock Jobs: Job completed successfully');
    
    return job;
  },

  async cancelJob(jobId: number, reason: string): Promise<Job> {
    console.log('📋 Mock Jobs: Cancel job', { jobId, reason });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock job cancellation
    const job = mockJobs.find(j => j.id === jobId);
    if (!job) {
      throw new ApiException(ErrorCodes.JOB_NOT_FOUND, 'Job not found');
    }
    
    if (job.status === 'COMPLETED') {
      throw new ApiException(ErrorCodes.INVALID_STATUS_TRANSITION, 'Cannot cancel completed job');
    }
    
    const updatedJob: Job = {
      ...job,
      status: 'CANCELLED',
      updatedAtIso: new Date().toISOString(),
    };
    
    console.log('📋 Mock Jobs: Job cancelled successfully');
    
    return updatedJob;
  },

  // Real-time subscriptions
  subscribeToJob(jobId: number, callback: (job: Job) => void): () => void {
    console.log('📋 Mock Jobs: Subscribe to job', { jobId });
    
    // Subscribe to SimulationService updates
    const unsubscribe = simulationService.subscribeToUpdates(`job-${jobId}`, (data) => {
      if (data.type === 'job_updated' || data.type === 'job_accepted' || data.type === 'job_started' || data.type === 'job_completed') {
        const simJob = data.job;
        const job: Job = {
          id: parseInt(simJob.id.replace('job-', '')),
          customerId: simJob.customerId,
          valeterId: simJob.valeterId,
          serviceId: 1, // Mock service ID
          serviceName: simJob.serviceType.replace('_', ' '),
          price: simJob.price,
          pickupLat: simJob.location.lat,
          pickupLng: simJob.location.lng,
          pickupAddress: simJob.location.address,
          status: simJob.status.toUpperCase() as JobStatus,
          etaMinutes: simJob.estimatedTime,
          createdAtIso: new Date(simJob.createdAt).toISOString(),
          updatedAtIso: new Date().toISOString(),
        };
        
        callback(job);
      }
    });
    
    return unsubscribe;
  },

  subscribeToUserJobs(userId: string, callback: (jobs: Job[]) => void): () => void {
    console.log('📋 Mock Jobs: Subscribe to user jobs', { userId });
    
    // Subscribe to SimulationService updates
    const unsubscribe = simulationService.subscribeToUpdates(userId, (data) => {
      if (data.type === 'job_created' || data.type === 'job_updated') {
        // Get all jobs for user
        this.getJobsForUser(userId, 'customer').then(callback);
      }
    });
    
    return unsubscribe;
  },

  // Services
  async getServices(): Promise<Service[]> {
    console.log('📋 Mock Jobs: Get services');
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    return mockServices;
  },

  async getService(serviceId: number): Promise<Service> {
    console.log('📋 Mock Jobs: Get service', { serviceId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const service = mockServices.find(s => s.id === serviceId);
    if (!service) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Service not found');
    }
    
    return service;
  },
};
