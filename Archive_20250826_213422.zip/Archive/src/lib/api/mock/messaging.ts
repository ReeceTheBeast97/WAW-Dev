// Mock Messaging API - Wraps existing ChatService functionality
import { 
  MessagingAPI, 
  ChatMessage, 
  ApiException, 
  ErrorCodes 
} from '../types';

// Import existing chat service
import { ChatService } from '../../../utils/ChatService';

// Mock messages data
const mockMessages: ChatMessage[] = [
  {
    id: 'msg_001',
    jobId: 1,
    senderId: 'customer_1',
    receiverId: 'valeter_1',
    content: 'Hi, I\'ve booked a deep clean for my BMW X5',
    isRead: true,
    createdAtIso: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
  },
  {
    id: 'msg_002',
    jobId: 1,
    senderId: 'valeter_1',
    receiverId: 'customer_1',
    content: 'Hello Sarah! I\'ve accepted your booking. I\'ll be there in 10 minutes',
    isRead: true,
    createdAtIso: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
  },
  {
    id: 'msg_003',
    jobId: 2,
    senderId: 'customer_1',
    receiverId: 'valeter_1',
    content: 'Can you do an interior clean for my Audi A3?',
    isRead: true,
    createdAtIso: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'msg_004',
    jobId: 2,
    senderId: 'valeter_1',
    receiverId: 'customer_1',
    content: 'Absolutely! I\'ll start with the interior clean',
    isRead: true,
    createdAtIso: new Date(Date.now() - 2.5 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'msg_005',
    jobId: 2,
    senderId: 'valeter_1',
    receiverId: 'customer_1',
    content: 'Wash completed successfully! Your Audi looks great',
    isRead: false,
    createdAtIso: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
];

// Mock implementation that wraps ChatService
export const messaging: MessagingAPI = {
  // Chat management
  async sendMessage(jobId: number, senderId: string, receiverId: string, content: string): Promise<ChatMessage> {
    console.log('💬 Mock Messaging: Send message', { jobId, senderId, receiverId, content });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Mock validation
    if (!jobId || !senderId || !receiverId || !content) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Missing required message data');
    }
    
    if (content.trim().length === 0) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Message content cannot be empty');
    }
    
    if (content.length > 1000) {
      throw new ApiException(ErrorCodes.VALIDATION_ERROR, 'Message too long (max 1000 characters)');
    }
    
    // Create message
    const message: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      jobId,
      senderId,
      receiverId,
      content: content.trim(),
      isRead: false,
      createdAtIso: new Date().toISOString(),
    };
    
    // Add to mock data
    mockMessages.push(message);
    
    console.log('💬 Mock Messaging: Message sent successfully', { messageId: message.id });
    
    return message;
  },

  async getMessagesForJob(jobId: number): Promise<ChatMessage[]> {
    console.log('💬 Mock Messaging: Get messages for job', { jobId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Return messages for the job
    const jobMessages = mockMessages.filter(message => message.jobId === jobId);
    
    // Sort by timestamp (oldest first for chat)
    jobMessages.sort((a, b) => new Date(a.createdAtIso).getTime() - new Date(b.createdAtIso).getTime());
    
    return jobMessages;
  },

  // Real-time subscriptions
  subscribeToMessages(jobId: number, callback: (message: ChatMessage) => void): () => void {
    console.log('💬 Mock Messaging: Subscribe to messages', { jobId });
    
    // Mock real-time subscription - in real implementation this would use WebSocket
    // For now, we'll just return a no-op unsubscribe function
    const unsubscribe = () => {
      console.log('💬 Mock Messaging: Unsubscribe from messages', { jobId });
    };
    
    return unsubscribe;
  },

  // Message status
  async markMessageAsRead(messageId: string): Promise<void> {
    console.log('💬 Mock Messaging: Mark message as read', { messageId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Find and update message
    const message = mockMessages.find(msg => msg.id === messageId);
    if (!message) {
      throw new ApiException(ErrorCodes.NOT_FOUND, 'Message not found');
    }
    
    message.isRead = true;
    
    console.log('💬 Mock Messaging: Message marked as read');
  },

  async getUnreadCount(userId: string): Promise<number> {
    console.log('💬 Mock Messaging: Get unread count', { userId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 200));
    
    // Count unread messages for the user
    const unreadCount = mockMessages.filter(message => 
      message.receiverId === userId && !message.isRead
    ).length;
    
    console.log('💬 Mock Messaging: Unread count', { userId, unreadCount });
    
    return unreadCount;
  },
};
