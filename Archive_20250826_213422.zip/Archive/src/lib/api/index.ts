// API Facade - Single point of entry for all API calls
// Switches between mock and real implementations based on environment flag

const USE_REAL = process.env.EXPO_PUBLIC_USE_REAL === "true";

// Export all API modules based on environment flag
export * as auth from USE_REAL ? "./real/auth" : "./mock/auth";
export * as jobs from USE_REAL ? "./real/jobs" : "./mock/jobs";
export * as payments from USE_REAL ? "./real/payments" : "./mock/payments";
export * as tracking from USE_REAL ? "./real/tracking" : "./mock/tracking";
export * as messaging from USE_REAL ? "./real/messaging" : "./mock/messaging";
export * as locations from USE_REAL ? "./real/locations" : "./mock/locations";

// Export types
export * from "./types";

// Export environment info for debugging
export const API_CONFIG = {
  useReal: USE_REAL,
  environment: process.env.EXPO_PUBLIC_ENVIRONMENT || 'development',
  supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL,
  hasSupabaseConfig: !!(process.env.EXPO_PUBLIC_SUPABASE_URL && process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY),
};

// Log configuration on startup
console.log(`🔧 API Facade initialized:`, {
  useReal: USE_REAL,
  environment: API_CONFIG.environment,
  hasSupabaseConfig: API_CONFIG.hasSupabaseConfig,
});

// Validation function to ensure all required environment variables are set
export function validateApiConfig() {
  if (USE_REAL) {
    const requiredVars = [
      'EXPO_PUBLIC_SUPABASE_URL',
      'EXPO_PUBLIC_SUPABASE_ANON_KEY',
    ];
    
    const missingVars = requiredVars.filter(varName => !process.env[varName]);
    
    if (missingVars.length > 0) {
      console.warn(`⚠️ Missing required environment variables for real API:`, missingVars);
      console.warn(`🔄 Falling back to mock API`);
      return false;
    }
    
    console.log(`✅ Real API configuration validated`);
    return true;
  }
  
  console.log(`✅ Mock API configuration validated`);
  return true;
}

// Initialize configuration validation
validateApiConfig();
