# Current Architecture Documentation

## Entry Points & Navigation

### Expo Router Structure
- **Root Layout**: `app/_layout.tsx` - Main app wrapper with AuthProvider
- **Index**: `app/index.tsx` - Entry point with role-based routing
- **Navigation**: Uses Expo Router with Stack navigation

### Role-Based Routing
```typescript
// From app/index.tsx
if (user) {
  if (user.userType === 'valeter') {
    router.replace('/driver-dashboard');
  } else {
    router.replace('/owner-dashboard');
  }
} else {
  if (hasSeenOnboarding) {
    router.replace('/login');
  } else {
    router.replace('/onboarding');
  }
}
```

## Portal Structure

### Customer Portal
1. **Login**: `app/login.tsx` - Customer login with auto-login options
2. **Dashboard**: `app/owner-dashboard.tsx` → `src/components/dashboard/PowerfulDashboard.tsx`
3. **Booking**: `app/booking.tsx` - Service selection and booking
4. **Tracking**: `app/tracking.tsx` - Live service tracking
5. **Profile**: `app/owner-profile.tsx` - Customer profile management
6. **Welcome**: `app/customer-welcome.tsx` - Customer onboarding

### Valeter Portal
1. **Login**: `app/organization-login.tsx` - Valeter/business login
2. **Dashboard**: `app/driver-dashboard.tsx` - Valeter job management
3. **Profile**: `app/valeter-profile.tsx` - Valeter profile and documents
4. **Welcome**: `app/valeter-welcome.tsx` - Valeter onboarding

### Admin Portal (Hidden)
1. **Dashboard**: `app/admin-dashboard.tsx` - Admin analytics and management
2. **Layout Guard**: `app/admin/_layout.tsx` - Admin access control

## Job Lifecycle

### Status Flow
```typescript
// From SimulationService.ts
status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled'
```

### Status Transitions
1. **pending** → Created when customer books service
2. **accepted** → When valeter accepts job
3. **in_progress** → When valeter starts service
4. **completed** → When service is finished
5. **cancelled** → When customer cancels

### Transition Locations
- **Job Creation**: `app/booking.tsx:85` - `simulationService.createJob()`
- **Job Acceptance**: `SimulationService.ts:108` - `acceptJob()`
- **Job Start**: `SimulationService.ts:120` - `startJob()`
- **Job Completion**: `SimulationService.ts:132` - `completeJob()`

## Simulation Data Locations

### Core Simulation Service
**File**: `src/services/SimulationService.ts`
- **Mock Users**: Lines 40-65 - Customer and valeter mock data
- **Mock Jobs**: Lines 85-100 - Job creation with fake data
- **Status Updates**: Lines 108-140 - Job status transitions
- **Notifications**: Lines 150-170 - Fake job notifications

### Pricing Engine
**File**: `src/services/EnhancedVehiclePricingService.ts`
- **Dynamic Pricing**: Lines 50-100 - AI-powered pricing calculations
- **Market Analysis**: Lines 120-150 - Fake market data
- **Demand Zones**: Lines 180-220 - Simulated demand patterns

### Live Tracking
**File**: `src/services/EnhancedLiveTrackingService.ts`
- **GPS Simulation**: Lines 30-80 - Fake location updates
- **ETA Calculation**: Lines 100-130 - Simulated travel times
- **Route Generation**: Lines 150-200 - Fake route data

### Payment System
**File**: `src/services/PaymentSystem.ts`
- **Mock Payments**: Lines 40-80 - Simulated payment processing
- **Refund Handling**: Lines 100-140 - Fake refund logic
- **Commission Calculation**: Lines 160-200 - Simulated commission

### Chat Service
**File**: `src/utils/ChatService.ts`
- **Mock Conversations**: Lines 35-130 - Fake chat data
- **Message History**: Lines 66-129 - Simulated message history

## API/Service Modules

### Authentication
- **AuthContext**: `app/auth-context.tsx` - User state management
- **Mock Users**: Lines 25-85 - Hardcoded user data
- **Role Management**: Lines 200-220 - Admin access control

### Job Management
- **SimulationService**: `src/services/SimulationService.ts` - Core job simulation
- **Job Creation**: Lines 85-100
- **Job Updates**: Lines 108-140
- **Job Queries**: Lines 75-85

### Tracking & Location
- **EnhancedLiveTrackingService**: `src/services/EnhancedLiveTrackingService.ts`
- **GPS Updates**: Lines 30-80
- **ETA Calculation**: Lines 100-130
- **Route Simulation**: Lines 150-200

### Payments
- **PaymentSystem**: `src/services/PaymentSystem.ts`
- **Payment Processing**: Lines 40-80
- **Refund Handling**: Lines 100-140
- **Commission**: Lines 160-200

### Chat & Messaging
- **ChatService**: `src/utils/ChatService.ts`
- **Conversations**: Lines 35-130
- **Messages**: Lines 66-129
- **Real-time Updates**: Lines 132-150

### Notifications
- **SimpleNotificationService**: `src/utils/SimpleNotificationService.ts`
- **Push Notifications**: Lines 20-60
- **In-app Alerts**: Lines 80-120

## Configuration & Feature Flags

### Environment Variables
**File**: `env.example`
- **Migration Control**: `EXPO_PUBLIC_USE_REAL=false`
- **Supabase**: `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_ANON_KEY`
- **Stripe**: `EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY`
- **Google Maps**: `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY`
- **Feature Flags**: Lines 25-35 - Various feature toggles

### Timeouts & Intervals
- **Job Expiry**: `SimulationService.ts:150` - 15-minute job timeout
- **GPS Updates**: `EnhancedLiveTrackingService.ts:50` - 10-15 second intervals
- **ETA Updates**: `EnhancedLiveTrackingService.ts:100` - Real-time ETA calculation

### Service Radius & Limits
- **Service Radius**: `EnhancedLiveTrackingService.ts:180` - 5km default radius
- **ETA Clamps**: `EnhancedLiveTrackingService.ts:120` - Min 5min, Max 60min
- **Price Limits**: `EnhancedVehiclePricingService.ts:200` - Dynamic pricing bounds

## Data Flow Patterns

### Real-time Updates
1. **SimulationService**: Central hub for all job updates
2. **Subscribers**: Map-based subscription system (Lines 180-200)
3. **Notifications**: Immediate updates via SimpleNotificationService

### State Management
1. **AuthContext**: Global user state
2. **Local State**: Component-level state for UI
3. **Service State**: SimulationService maintains job/user state

### Data Persistence
- **AsyncStorage**: User sessions and preferences
- **In-Memory**: All simulation data (lost on app restart)
- **No Database**: Currently no persistent storage

## Security & Access Control

### Admin Access
- **Email Whitelist**: `app/auth-context.tsx:25-30` - Only specific emails
- **Role Checking**: `app/auth-context.tsx:200-220` - `hasAdminAccess()`
- **UI Protection**: `src/components/AdminGate.tsx` - Component-level protection
- **Route Guards**: `app/admin/_layout.tsx` - Navigation-level protection

### User Isolation
- **Customer Data**: Filtered by customerId
- **Valeter Data**: Filtered by valeterId
- **Admin Access**: Can view all data

## Current Limitations

### Simulation Constraints
1. **No Persistence**: All data lost on app restart
2. **Single Instance**: No multi-user simulation
3. **Fake Data**: No real GPS, payments, or chat
4. **Limited Scale**: Only handles basic scenarios

### Missing Real Features
1. **Database**: No persistent storage
2. **Real-time**: No WebSocket connections
3. **Payments**: No Stripe integration
4. **Push Notifications**: No Expo Push setup
5. **Location Services**: No real GPS tracking

### Performance Issues
1. **Memory Usage**: All data in memory
2. **Battery Drain**: Continuous GPS simulation
3. **Network**: No real API calls
4. **Scalability**: Limited to single device
