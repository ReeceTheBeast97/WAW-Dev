# Simulation Data Map

## Overview
This document maps all simulated data in the current app and outlines how each will be replaced with real data during migration.

## Authentication & Users

### Current Simulation
**Location**: `app/auth-context.tsx:25-85`
```typescript
const mockUsers: User[] = [
  { id: 'customer_1', email: 'customer@test.com', name: 'John Customer', ... },
  { id: 'valeter_1', email: 'valeter@test.com', name: 'Mike Valeter', ... },
  { id: 'reece_admin', email: 'reece@wishawash.com', name: 'Reece Dixon', ... },
  // ... more mock users
];
```

### Real Replacement
**Target**: Supabase Auth + Profiles table
- **Auth**: Supabase Auth for login/registration
- **Profiles**: `profiles` table with role-based access
- **Admin**: Email whitelist in database
- **Session**: JWT tokens with role claims

### Migration Impact
- **Files**: `app/auth-context.tsx`, `app/login.tsx`, `app/organization-login.tsx`
- **Data**: User sessions, role management, admin access
- **UI**: No changes required

## Job Management

### Current Simulation
**Location**: `src/services/SimulationService.ts:85-140`
```typescript
createJob(customerId: string, serviceType: string, location: object, price: number): string
acceptJob(jobId: string, valeterId: string): boolean
startJob(jobId: string): boolean
completeJob(jobId: string): boolean
```

### Real Replacement
**Target**: Supabase Jobs table + Edge Functions
- **Jobs Table**: `jobs` table with status enum
- **Status Flow**: REQUESTED → ACCEPTED → EN_ROUTE → ARRIVED → IN_PROGRESS → COMPLETED
- **Edge Functions**: `create-job`, `accept-job`, `advance-status`
- **Real-time**: Supabase Realtime subscriptions

### Migration Impact
- **Files**: `app/booking.tsx`, `app/tracking.tsx`, `app/driver-dashboard.tsx`
- **Data**: Job creation, status updates, valeter assignment
- **UI**: No changes required

## Live Tracking & GPS

### Current Simulation
**Location**: `src/services/EnhancedLiveTrackingService.ts:30-80`
```typescript
// Fake GPS updates every 10-15 seconds
private simulateLocationUpdates(): void {
  setInterval(() => {
    // Generate fake coordinates
    const newLat = currentLat + (Math.random() - 0.5) * 0.001;
    const newLng = currentLng + (Math.random() - 0.5) * 0.001;
    // Update location
  }, 10000);
}
```

### Real Replacement
**Target**: Supabase Locations table + Real GPS
- **GPS**: React Native Location API
- **Database**: `locations` table with user_id, job_id, lat, lng, timestamp
- **Real-time**: Supabase Realtime for live updates
- **Edge Function**: `ping` for location updates

### Migration Impact
- **Files**: `app/tracking.tsx`, `app/track-vehicle.tsx`, `app/follow-valeter.tsx`
- **Data**: Real GPS coordinates, ETA calculations, route optimization
- **UI**: No changes required

## Pricing & Payments

### Current Simulation
**Location**: `src/services/EnhancedVehiclePricingService.ts:50-100`
```typescript
calculatePrice(factors: PricingFactors): PriceBreakdown {
  // AI-powered fake pricing
  const basePrice = this.getBasePrice(factors.serviceType);
  const demandMultiplier = this.getDemandMultiplier(factors.location, factors.timeOfDay);
  const weatherMultiplier = this.getWeatherMultiplier(factors.weather);
  // ... more fake calculations
}
```

### Real Replacement
**Target**: Stripe + Real Pricing Logic
- **Payments**: Stripe PaymentIntents
- **Pricing**: Service-based pricing with real market data
- **Edge Functions**: `confirm-payment`, `process-refund`
- **Database**: `payments` table for transaction history

### Migration Impact
- **Files**: `app/booking.tsx`, `app/tracking.tsx`, `src/services/PaymentSystem.ts`
- **Data**: Real payment processing, refunds, commission calculations
- **UI**: No changes required

## Chat & Messaging

### Current Simulation
**Location**: `src/utils/ChatService.ts:35-130`
```typescript
private loadMockMessages() {
  this.messages.set('conv_001', [
    { id: 'msg_001', senderId: 'a7b9c2d4e6f8g0h2', message: 'Hi, I\'ve booked...', ... },
    { id: 'msg_002', senderId: '126546fghfdsvvfg', message: 'Hello Sarah! I\'ve accepted...', ... }
  ]);
}
```

### Real Replacement
**Target**: Supabase Messages table + Real-time
- **Database**: `messages` table with job_id, sender_id, receiver_id
- **Real-time**: Supabase Realtime for instant messaging
- **Edge Function**: `send-message` for message creation
- **Job-scoped**: Messages tied to specific jobs

### Migration Impact
- **Files**: `app/live-chat.tsx`, `app/customer-network.tsx`
- **Data**: Real chat history, message delivery, read receipts
- **UI**: No changes required

## Notifications

### Current Simulation
**Location**: `src/utils/SimpleNotificationService.ts:20-60`
```typescript
showNotification(notification: NotificationData): void {
  // In-app alerts only
  Alert.alert(notification.title, notification.message);
}
```

### Real Replacement
**Target**: Expo Push Notifications + Supabase
- **Push**: Expo Push API
- **Database**: `device_tokens` table, `notif_outbox` table
- **Edge Functions**: `save-device-token`, `send-push`
- **Scheduling**: Supabase cron jobs

### Migration Impact
- **Files**: All screens with notifications
- **Data**: Push notification delivery, device token management
- **UI**: No changes required

## Admin Dashboard

### Current Simulation
**Location**: `app/admin-dashboard.tsx:100-200`
```typescript
// Mock analytics data
const mockAnalytics = {
  totalJobs: 1247,
  totalRevenue: 45678,
  activeValeters: 23,
  customerSatisfaction: 4.8
};
```

### Real Replacement
**Target**: Supabase Queries + Real Analytics
- **Analytics**: Real-time database queries
- **Reports**: `system_reports` table
- **Refunds**: `refund_requests` table
- **Edge Functions**: Admin-only functions with role checks

### Migration Impact
- **Files**: `app/admin-dashboard.tsx`
- **Data**: Real business metrics, user management, financial data
- **UI**: No changes required

## File Uploads

### Current Simulation
**Location**: `src/services/FileUploadService.ts:30-80`
```typescript
uploadDocument(file: File, userId: string): Promise<UploadResult> {
  // Simulate file upload
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({ success: true, filePath: `/uploads/${userId}/${file.name}` });
    }, 2000);
  });
}
```

### Real Replacement
**Target**: Supabase Storage + Real File Handling
- **Storage**: Supabase Storage buckets
- **Database**: File metadata in `valeter_profiles` table
- **Security**: RLS policies for file access
- **Validation**: File type and size validation

### Migration Impact
- **Files**: `app/valeter-profile.tsx`, `app/owner-profile.tsx`
- **Data**: Real file storage, document verification
- **UI**: No changes required

## Static Locations (Car Washes)

### Current Simulation
**Location**: `src/services/PriorityWashService.ts:40-80`
```typescript
getStaticLocations(): StaticLocation[] {
  return [
    { id: 'wash_1', name: 'Elite Car Wash', lat: 51.5074, lng: -0.1278, ... },
    { id: 'wash_2', name: 'Premium Valet', lat: 51.5074, lng: -0.1278, ... }
  ];
}
```

### Real Replacement
**Target**: Supabase Locations table (keep mock initially)
- **Database**: `static_locations` table
- **Slots**: `location_slots` table for time slots
- **Availability**: Real-time slot management
- **Pricing**: Location-specific pricing

### Migration Impact
- **Files**: `app/priority-wash.tsx`
- **Data**: Real location data, slot availability
- **UI**: No changes required

## Detailed Data Mapping

### User Data
| Current | Real | Migration |
|---------|------|-----------|
| `mockUsers` array | `profiles` table | AuthContext update |
| `userType` field | `role` enum | Database migration |
| `isVerified` boolean | `valeter_profiles` table | Profile extension |
| Session storage | JWT tokens | Auth flow update |

### Job Data
| Current | Real | Migration |
|---------|------|-----------|
| `SimulationJob` interface | `jobs` table | Service layer update |
| `status` string | `job_status` enum | Database schema |
| `estimatedTime` number | Real ETA calculation | Tracking service update |
| In-memory storage | Database persistence | Data layer update |

### Location Data
| Current | Real | Migration |
|---------|------|-----------|
| Fake GPS coordinates | Real GPS API | Location service update |
| Simulated movement | Real location tracking | Tracking component update |
| `setInterval` updates | Supabase Realtime | Real-time subscription |
| In-memory locations | `locations` table | Database storage |

### Payment Data
| Current | Real | Migration |
|---------|------|-----------|
| Mock payment processing | Stripe PaymentIntents | Payment service update |
| Fake refunds | Stripe refunds | Refund handling update |
| Simulated commission | Real commission calculation | Admin dashboard update |
| No transaction history | `payments` table | Database schema |

### Chat Data
| Current | Real | Migration |
|---------|------|-----------|
| Mock conversations | `messages` table | Chat service update |
| Fake message history | Real chat persistence | Database storage |
| In-app alerts only | Push notifications | Notification service update |
| No read receipts | Real message status | Chat UI update |

## Migration Strategy

### Phase 1: Foundation
1. **API Facade**: Create `src/lib/api/index.ts`
2. **Database Schema**: Deploy Supabase schema
3. **Auth Migration**: Replace mock auth with Supabase

### Phase 2: Core Features
1. **Job Management**: Replace SimulationService
2. **Live Tracking**: Implement real GPS
3. **Payments**: Integrate Stripe

### Phase 3: Real-time Features
1. **Chat**: Real-time messaging
2. **Notifications**: Push notifications
3. **Admin**: Real analytics

### Phase 4: Polish
1. **File Uploads**: Real document storage
2. **Static Locations**: Real location data
3. **Performance**: Optimization and caching

## Rollback Strategy

### Environment Flag
```typescript
const USE_REAL = process.env.EXPO_PUBLIC_USE_REAL === "true";
export * as auth from USE_REAL ? "./real/auth" : "./mock/auth";
```

### Gradual Migration
- Keep mock services intact
- Switch consumers one by one
- Test each migration step
- Rollback capability at each step

### Data Preservation
- Export mock data before migration
- Backup user preferences
- Preserve UI state during migration
