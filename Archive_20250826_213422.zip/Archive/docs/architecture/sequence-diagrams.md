# Sequence Diagrams

## 1. Customer Booking Flow: Book → Searching → Assigned → Track → Complete

```mermaid
sequenceDiagram
    participant C as Customer
    participant BD as Booking Dashboard
    participant SS as SimulationService
    participant PE as PricingEngine
    participant TS as Tracking Screen
    participant LTS as LiveTrackingService
    participant V as Valeter
    participant VD as Valeter Dashboard

    C->>BD: Select service & location
    BD->>PE: Calculate dynamic pricing
    PE-->>BD: Return price breakdown
    BD->>SS: createJob(customerId, serviceType, location, price)
    SS-->>BD: Return jobId
    BD->>TS: Navigate to tracking
    TS->>LTS: Start location tracking
    LTS-->>TS: Return initial ETA
    
    Note over SS: Job status: pending
    
    loop Every 10-15 seconds
        LTS->>TS: Update valeter location
        TS->>C: Show live map updates
    end
    
    V->>VD: Go online
    VD->>SS: getAvailableJobs()
    SS-->>VD: Return pending jobs
    V->>VD: Accept job
    VD->>SS: acceptJob(jobId, valeterId)
    SS->>TS: Notify job accepted
    TS->>C: Show valeter details
    
    Note over SS: Job status: accepted
    
    V->>VD: Start navigation
    VD->>LTS: Start GPS sharing
    LTS->>TS: Real-time location updates
    TS->>C: Show valeter en route
    
    Note over SS: Job status: in_progress
    
    V->>VD: Arrive at location
    VD->>SS: startJob(jobId)
    SS->>TS: Notify job started
    TS->>C: Show "Service in progress"
    
    V->>VD: Complete service
    VD->>SS: completeJob(jobId)
    SS->>TS: Notify job completed
    TS->>C: Show completion & rating
```

## 2. Valeter Job Flow: Go Online → Accept → Navigate → Share GPS → Complete

```mermaid
sequenceDiagram
    participant V as Valeter
    participant VD as Valeter Dashboard
    participant SS as SimulationService
    participant LTS as LiveTrackingService
    participant C as Customer
    participant TS as Tracking Screen
    participant PS as PaymentSystem

    V->>VD: Login & go online
    VD->>SS: setUserOnlineStatus(valeterId, true)
    SS-->>VD: Confirm online status
    
    loop Monitor for jobs
        SS->>VD: Notify new job available
        VD->>V: Show job notification
    end
    
    V->>VD: Accept job
    VD->>SS: acceptJob(jobId, valeterId)
    SS->>C: Notify job accepted
    SS-->>VD: Confirm job accepted
    
    V->>VD: Start navigation
    VD->>LTS: Start GPS sharing
    LTS->>TS: Send location updates
    TS->>C: Show valeter location
    
    V->>VD: Arrive at location
    VD->>SS: startJob(jobId)
    SS->>C: Notify service started
    SS-->>VD: Confirm job started
    
    V->>VD: Complete service
    VD->>SS: completeJob(jobId)
    SS->>PS: Process payment
    PS-->>SS: Payment confirmed
    SS->>C: Notify completion
    SS-->>VD: Confirm job completed
```

## 3. Cancel Pre-IN_PROGRESS (Refund Path)

```mermaid
sequenceDiagram
    participant C as Customer
    participant TS as Tracking Screen
    participant SS as SimulationService
    participant PS as PaymentSystem
    participant V as Valeter
    participant VD as Valeter Dashboard
    participant AS as Admin System

    C->>TS: Cancel service
    TS->>C: Show cancellation options
    C->>TS: Confirm cancellation
    
    TS->>SS: cancelJob(jobId)
    SS->>V: Notify job cancelled
    SS->>VD: Update job status
    SS->>PS: Initiate refund
    
    alt Job not started (pending/accepted)
        PS->>PS: Full refund
        PS-->>C: Refund processed
    else Job in progress
        PS->>PS: Partial refund
        PS-->>C: Partial refund
    end
    
    SS->>AS: Log cancellation
    AS->>AS: Update analytics
    
    TS->>C: Show cancellation confirmation
    TS->>C: Navigate to dashboard
```

## 4. Auto-Expire When No Valeter Accepts (Timeout)

```mermaid
sequenceDiagram
    participant SS as SimulationService
    participant TS as Tracking Screen
    participant C as Customer
    participant PS as PaymentSystem
    participant AS as Admin System

    Note over SS: Job created with 15-minute timeout
    
    loop Every minute
        SS->>SS: Check job timeout
    end
    
    Note over SS: 15 minutes elapsed
    
    SS->>SS: expireJob(jobId)
    SS->>TS: Notify job expired
    TS->>C: Show expiration message
    
    SS->>PS: Process full refund
    PS-->>C: Refund processed
    
    SS->>AS: Log expiration
    AS->>AS: Update analytics
    
    TS->>C: Show refund confirmation
    TS->>C: Navigate to dashboard
```

## 5. Static Car Wash: List → Detail → Slot Book

```mermaid
sequenceDiagram
    participant C as Customer
    participant CD as Customer Dashboard
    participant PW as Priority Wash Screen
    participant SS as SimulationService
    participant PE as PricingEngine
    participant PS as PaymentSystem
    participant TS as Tracking Screen

    C->>CD: Select "Priority Wash"
    CD->>PW: Navigate to priority wash
    
    PW->>SS: getStaticLocations()
    SS-->>PW: Return car wash locations
    
    C->>PW: Select car wash location
    PW->>SS: getAvailableSlots(locationId)
    SS-->>PW: Return available time slots
    
    C->>PW: Select time slot
    PW->>PE: Calculate priority pricing
    PE-->>PW: Return enhanced pricing
    
    C->>PW: Confirm booking
    PW->>SS: createPriorityJob(customerId, locationId, slotId, price)
    SS-->>PW: Return jobId
    
    PW->>PS: Process payment
    PS-->>PW: Payment confirmed
    
    PW->>TS: Navigate to tracking
    TS->>C: Show booking confirmation
    
    Note over SS: Priority job with guaranteed slot
```

## Data Flow Patterns

### Real-time Updates
```mermaid
sequenceDiagram
    participant UI as UI Component
    participant SS as SimulationService
    participant LTS as LiveTrackingService
    participant NS as NotificationService

    UI->>SS: subscribeToUpdates(userId, callback)
    SS-->>UI: Return unsubscribe function
    
    loop Real-time updates
        SS->>UI: Job status updates
        LTS->>UI: Location updates
        NS->>UI: Push notifications
    end
    
    UI->>SS: unsubscribe()
```

### Payment Processing
```mermaid
sequenceDiagram
    participant C as Customer
    participant PS as PaymentSystem
    participant SS as SimulationService
    participant V as Valeter

    C->>PS: Initiate payment
    PS->>PS: Validate payment method
    PS->>PS: Process payment
    PS-->>C: Payment confirmed
    
    PS->>SS: Update job payment status
    SS->>V: Notify payment received
    
    alt Service completed
        PS->>PS: Release payment to valeter
        PS->>PS: Calculate commission
    end
```

### Error Handling
```mermaid
sequenceDiagram
    participant UI as UI Component
    participant API as API Layer
    participant SS as SimulationService
    participant EH as ErrorHandler

    UI->>API: API call
    API->>SS: Service call
    
    alt Success
        SS-->>API: Success response
        API-->>UI: Data returned
    else Error
        SS->>EH: Log error
        EH->>UI: Show error message
        UI->>UI: Handle gracefully
    end
```
