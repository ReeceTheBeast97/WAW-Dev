# Migration Checklist

## Overview
This checklist outlines the step-by-step migration from mock data to real backend integration. Each step includes acceptance criteria and rollback procedures.

## Phase 1: Foundation (Week 1)

### Step 1: Create API Facade
**Goal**: Establish single point of entry for all API calls

**Tasks**:
- [ ] Create `src/lib/api/index.ts` facade
- [ ] Create `src/lib/api/types.ts` with shared interfaces
- [ ] Create mock adapters in `src/lib/api/mock/`
- [ ] Update all imports to use facade
- [ ] Add environment flag `EXPO_PUBLIC_USE_REAL`

**Acceptance Criteria**:
- [ ] App boots without errors
- [ ] All screens import from facade instead of direct services
- [ ] Environment flag controls mock vs real
- [ ] No direct service imports found in app code

**Rollback**: Revert to direct service imports

**Files Modified**:
- `src/lib/api/index.ts` (new)
- `src/lib/api/types.ts` (new)
- `src/lib/api/mock/auth.ts` (new)
- `src/lib/api/mock/jobs.ts` (new)
- `src/lib/api/mock/payments.ts` (new)
- `src/lib/api/mock/tracking.ts` (new)
- `src/lib/api/mock/messaging.ts` (new)
- `src/lib/api/mock/locations.ts` (new)

### Step 2: Deploy Database Schema
**Goal**: Set up Supabase database with proper schema

**Tasks**:
- [ ] Deploy `supabase-schema.sql` to Supabase
- [ ] Verify all tables created correctly
- [ ] Test RLS policies
- [ ] Insert default services
- [ ] Create admin user profiles

**Acceptance Criteria**:
- [ ] All tables exist in Supabase
- [ ] RLS policies working correctly
- [ ] Admin function `is_admin()` working
- [ ] Default services inserted
- [ ] Admin users can access admin features

**Rollback**: Drop and recreate database

**Files Modified**:
- `supabase-schema.sql` (deploy)

### Step 3: Auth Migration
**Goal**: Replace mock auth with Supabase Auth

**Tasks**:
- [ ] Create `src/lib/api/real/auth.ts`
- [ ] Implement Supabase Auth integration
- [ ] Update AuthContext to use real auth
- [ ] Test login/logout flows
- [ ] Verify admin access control

**Acceptance Criteria**:
- [ ] Users can login with Supabase
- [ ] Admin access restricted to whitelisted emails
- [ ] Session persistence working
- [ ] Role-based routing working
- [ ] No regression in existing flows

**Rollback**: Switch back to mock auth via environment flag

**Files Modified**:
- `src/lib/api/real/auth.ts` (new)
- `app/auth-context.tsx`
- `app/login.tsx`
- `app/organization-login.tsx`

## Phase 2: Core Features (Week 2-3)

### Step 4: Job Management
**Goal**: Replace SimulationService with real job management

**Tasks**:
- [ ] Create `src/lib/api/real/jobs.ts`
- [ ] Implement job CRUD operations
- [ ] Add real-time subscriptions
- [ ] Update booking flow
- [ ] Update tracking screens

**Acceptance Criteria**:
- [ ] Jobs created in database
- [ ] Real-time job updates working
- [ ] Job status transitions working
- [ ] Valeter job assignment working
- [ ] No regression in booking flow

**Rollback**: Switch back to mock jobs via environment flag

**Files Modified**:
- `src/lib/api/real/jobs.ts` (new)
- `app/booking.tsx`
- `app/tracking.tsx`
- `app/driver-dashboard.tsx`

### Step 5: Live Tracking
**Goal**: Replace fake GPS with real location tracking

**Tasks**:
- [ ] Create `src/lib/api/real/tracking.ts`
- [ ] Implement React Native Location API
- [ ] Add location permissions handling
- [ ] Update tracking screens
- [ ] Implement ETA calculation

**Acceptance Criteria**:
- [ ] Real GPS coordinates captured
- [ ] Location updates sent to database
- [ ] ETA calculations working
- [ ] Battery optimization implemented
- [ ] No regression in tracking UI

**Rollback**: Switch back to mock tracking via environment flag

**Files Modified**:
- `src/lib/api/real/tracking.ts` (new)
- `app/tracking.tsx`
- `app/track-vehicle.tsx`
- `app/follow-valeter.tsx`

### Step 6: Payment Integration
**Goal**: Replace mock payments with Stripe

**Tasks**:
- [ ] Create `src/lib/api/real/payments.ts`
- [ ] Implement Stripe PaymentIntents
- [ ] Add payment confirmation flow
- [ ] Implement refund handling
- [ ] Update payment UI

**Acceptance Criteria**:
- [ ] Stripe payments processing
- [ ] Payment confirmation working
- [ ] Refund requests working
- [ ] Payment history available
- [ ] No regression in payment flow

**Rollback**: Switch back to mock payments via environment flag

**Files Modified**:
- `src/lib/api/real/payments.ts` (new)
- `app/booking.tsx`
- `app/tracking.tsx`
- `src/services/PaymentSystem.ts`

## Phase 3: Real-time Features (Week 4-6)

### Step 7: Chat System
**Goal**: Replace mock chat with real-time messaging

**Tasks**:
- [ ] Create `src/lib/api/real/messaging.ts`
- [ ] Implement Supabase Realtime subscriptions
- [ ] Add message persistence
- [ ] Update chat UI
- [ ] Add read receipts

**Acceptance Criteria**:
- [ ] Real-time messages working
- [ ] Message history persisted
- [ ] Read receipts working
- [ ] Job-scoped conversations
- [ ] No regression in chat UI

**Rollback**: Switch back to mock messaging via environment flag

**Files Modified**:
- `src/lib/api/real/messaging.ts` (new)
- `app/live-chat.tsx`
- `app/customer-network.tsx`

### Step 8: Push Notifications
**Goal**: Add real push notifications

**Tasks**:
- [ ] Create `src/lib/api/real/notifications.ts`
- [ ] Implement Expo Push API
- [ ] Add device token management
- [ ] Create notification triggers
- [ ] Test notification delivery

**Acceptance Criteria**:
- [ ] Push notifications received
- [ ] Device tokens saved
- [ ] Job notifications working
- [ ] Notification preferences working
- [ ] No regression in notification flow

**Rollback**: Switch back to mock notifications via environment flag

**Files Modified**:
- `src/lib/api/real/notifications.ts` (new)
- All screens with notifications

### Step 9: Admin Analytics
**Goal**: Replace mock analytics with real data

**Tasks**:
- [ ] Create `src/lib/api/real/admin.ts`
- [ ] Implement real database queries
- [ ] Add real-time analytics
- [ ] Update admin dashboard
- [ ] Add export functionality

**Acceptance Criteria**:
- [ ] Real analytics data displayed
- [ ] Real-time updates working
- [ ] Export functionality working
- [ ] Admin actions working
- [ ] No regression in admin UI

**Rollback**: Switch back to mock analytics via environment flag

**Files Modified**:
- `src/lib/api/real/admin.ts` (new)
- `app/admin-dashboard.tsx`

## Phase 4: Polish (Week 7+)

### Step 10: File Uploads
**Goal**: Replace mock uploads with real file storage

**Tasks**:
- [ ] Create `src/lib/api/real/storage.ts`
- [ ] Implement Supabase Storage
- [ ] Add file validation
- [ ] Update upload UI
- [ ] Add progress indicators

**Acceptance Criteria**:
- [ ] Files uploaded to Supabase Storage
- [ ] File validation working
- [ ] Progress indicators working
- [ ] File access controls working
- [ ] No regression in upload UI

**Rollback**: Switch back to mock uploads via environment flag

**Files Modified**:
- `src/lib/api/real/storage.ts` (new)
- `app/valeter-profile.tsx`
- `app/owner-profile.tsx`

### Step 11: Static Locations
**Goal**: Replace mock locations with real data

**Tasks**:
- [ ] Create `src/lib/api/real/locations.ts`
- [ ] Implement location CRUD
- [ ] Add slot management
- [ ] Update location UI
- [ ] Add availability tracking

**Acceptance Criteria**:
- [ ] Real location data displayed
- [ ] Slot management working
- [ ] Availability tracking working
- [ ] Location CRUD working
- [ ] No regression in location UI

**Rollback**: Switch back to mock locations via environment flag

**Files Modified**:
- `src/lib/api/real/locations.ts` (new)
- `app/priority-wash.tsx`

### Step 12: Performance Optimization
**Goal**: Optimize app performance

**Tasks**:
- [ ] Implement caching strategies
- [ ] Add lazy loading
- [ ] Optimize database queries
- [ ] Add error boundaries
- [ ] Performance monitoring

**Acceptance Criteria**:
- [ ] App performance improved
- [ ] Memory usage optimized
- [ ] Battery usage optimized
- [ ] Error handling improved
- [ ] No regression in functionality

**Rollback**: Revert performance changes

**Files Modified**:
- Various performance optimizations

## Testing Strategy

### Manual Testing Plan
**File**: `docs/testing/manual-test-plan.md`

**Test Scenarios**:
1. **Customer Flow**: Login → Book → Track → Complete
2. **Valeter Flow**: Login → Accept → Navigate → Complete
3. **Admin Flow**: Login → Dashboard → Analytics
4. **Error Scenarios**: Network errors, validation errors
5. **Edge Cases**: Cancellations, timeouts, refunds

### Automated Testing
**Tasks**:
- [ ] Unit tests for API adapters
- [ ] Integration tests for real-time features
- [ ] E2E tests for critical flows
- [ ] Performance tests
- [ ] Security tests

## Deployment Strategy

### Staging Environment
**Tasks**:
- [ ] Set up staging Supabase project
- [ ] Deploy staging Edge Functions
- [ ] Configure staging environment variables
- [ ] Test full migration in staging
- [ ] Performance testing in staging

### Production Deployment
**Tasks**:
- [ ] Set up production Supabase project
- [ ] Deploy production Edge Functions
- [ ] Configure production environment variables
- [ ] Gradual rollout with feature flags
- [ ] Monitor production metrics

## Monitoring & Alerting

### Metrics to Track
- **API Response Times**: < 200ms average
- **Real-time Latency**: < 1s for updates
- **Error Rates**: < 1% for all endpoints
- **User Engagement**: Track key user actions
- **Business Metrics**: Bookings, completions, revenue

### Alerting Setup
- [ ] API error rate alerts
- [ ] Real-time connection alerts
- [ ] Payment failure alerts
- [ ] Database performance alerts
- [ ] User experience alerts

## Rollback Procedures

### Environment Flag Rollback
```bash
# Switch back to mock data
EXPO_PUBLIC_USE_REAL=false
```

### Database Rollback
```sql
-- Restore from backup
pg_restore --clean --if-exists backup.sql
```

### Code Rollback
```bash
# Revert to previous commit
git revert <commit-hash>
```

### Feature Flag Rollback
```typescript
// Disable specific features
const FEATURE_FLAGS = {
  realAuth: false,
  realJobs: false,
  realTracking: false,
  // ... etc
};
```

## Success Criteria

### Technical Success
- [ ] All API endpoints responding < 200ms
- [ ] Real-time updates < 1s latency
- [ ] Zero data loss during migration
- [ ] 99.9% uptime maintained
- [ ] All tests passing

### Business Success
- [ ] No regression in user experience
- [ ] Booking success rate maintained
- [ ] Customer satisfaction maintained
- [ ] Revenue tracking working
- [ ] Admin insights available

### Security Success
- [ ] All data properly secured
- [ ] Admin access properly controlled
- [ ] Payment data PCI compliant
- [ ] User data GDPR compliant
- [ ] No security vulnerabilities

## Post-Migration Tasks

### Cleanup
- [ ] Remove mock services
- [ ] Clean up unused code
- [ ] Update documentation
- [ ] Archive old backups
- [ ] Update deployment scripts

### Optimization
- [ ] Performance tuning
- [ ] Database optimization
- [ ] Caching strategies
- [ ] CDN setup
- [ ] Monitoring improvements

### Documentation
- [ ] Update API documentation
- [ ] Update deployment guides
- [ ] Update troubleshooting guides
- [ ] Update user guides
- [ ] Update admin guides
