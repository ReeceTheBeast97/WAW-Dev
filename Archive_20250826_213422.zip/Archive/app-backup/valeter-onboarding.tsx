import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
  ScrollView,
  Animated,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

interface OnboardingSlide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  icon: string;
  gradient: string[];
  benefits: string[];
  stats?: {
    value: string;
    label: string;
  };
}

const onboardingSlides: OnboardingSlide[] = [
  {
    id: 1,
    title: "Welcome to the Future of Car Valeting",
    subtitle: "Revolutionary Platform for Professional Valeters",
    description: "Join thousands of successful valeters who've transformed their business with Wish a Wash. We're not just another booking app - we're your business partner.",
    icon: "🚀",
    gradient: ['#1E3A8A', '#3B82F6'],
    benefits: [
      "Access to premium customers",
      "No more cold calling or marketing",
      "Instant job notifications",
      "Secure payment processing"
    ]
  },
  {
    id: 2,
    title: "Earn More, Work Smarter",
    subtitle: "Up to 40% Higher Earnings",
    description: "Our dynamic pricing model and premium customer base means you can charge what you're worth. No more undercutting or price wars.",
    icon: "💰",
    gradient: ['#059669', '#10B981'],
    benefits: [
      "Dynamic pricing based on demand",
      "Premium customer base",
      "No commission fees",
      "Tips and bonuses included"
    ],
    stats: {
      value: "£2,500+",
      label: "Average Monthly Earnings"
    }
  },
  {
    id: 3,
    title: "Your Schedule, Your Rules",
    subtitle: "Complete Flexibility & Control",
    description: "Go online when you want, accept jobs that fit your schedule, and build your business around your life - not the other way around.",
    icon: "⏰",
    gradient: ['#7C3AED', '#A855F7'],
    benefits: [
      "Choose your working hours",
      "Accept or decline any job",
      "Set your service areas",
      "Work as much or little as you want"
    ]
  },
  {
    id: 4,
    title: "Professional Tools & Support",
    subtitle: "Everything You Need to Succeed",
    description: "From GPS navigation to customer management, we provide all the tools you need to deliver exceptional service and grow your business.",
    icon: "🛠️",
    gradient: ['#DC2626', '#EF4444'],
    benefits: [
      "Live GPS navigation",
      "Customer communication tools",
      "Job history and analytics",
      "24/7 support team"
    ]
  },
  {
    id: 5,
    title: "Build Your Reputation",
    subtitle: "Verified Professional Status",
    description: "Stand out from the competition with our verification system. Customers trust verified valeters and are willing to pay premium rates.",
    icon: "✅",
    gradient: ['#D97706', '#F59E0B'],
    benefits: [
      "Verified valeter badge",
      "Customer reviews and ratings",
      "Professional profile showcase",
      "Trust and credibility boost"
    ]
  },
  {
    id: 6,
    title: "Join the Valeter Community",
    subtitle: "Network & Collaborate",
    description: "Connect with other professional valeters, share tips, collaborate on large jobs, and be part of a growing community.",
    icon: "👥",
    gradient: ['#0891B2', '#06B6D4'],
    benefits: [
      "Joint wash opportunities",
      "Knowledge sharing network",
      "Referral bonuses",
      "Community support"
    ]
  },
  {
    id: 7,
    title: "Ready to Transform Your Business?",
    subtitle: "Start Your Journey Today",
    description: "Join thousands of successful valeters who've already transformed their business. Your future starts now.",
    icon: "🎯",
    gradient: ['#1F2937', '#374151'],
    benefits: [
      "Quick setup process",
      "Immediate job access",
      "No upfront costs",
      "Start earning today"
    ]
  }
];

export default function ValeterOnboarding() {
  const router = useRouter();
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const nextSlide = () => {
    if (currentSlide < onboardingSlides.length - 1) {
      fadeAnim.setValue(0);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
      
      setCurrentSlide(currentSlide + 1);
      scrollViewRef.current?.scrollTo({
        x: (currentSlide + 1) * width,
        animated: true,
      });
    }
  };

  const previousSlide = () => {
    if (currentSlide > 0) {
      fadeAnim.setValue(0);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
      
      setCurrentSlide(currentSlide - 1);
      scrollViewRef.current?.scrollTo({
        x: (currentSlide - 1) * width,
        animated: true,
      });
    }
  };

  const skipOnboarding = () => {
    router.push('/driver-dashboard');
  };

  const completeOnboarding = async () => {
    try {
      await AsyncStorage.setItem('valeter_onboarding_completed', 'true');
    } catch (error) {
      console.log('Error saving onboarding status:', error);
    }
    router.push('/driver-dashboard');
  };

  const renderSlide = (slide: OnboardingSlide) => (
    <View key={slide.id} style={styles.slide}>
      <LinearGradient
        colors={slide.gradient}
        style={styles.gradientBackground}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.slideContent}>
          {/* Icon */}
          <View style={styles.iconContainer}>
            <Text style={styles.icon}>{slide.icon}</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>{slide.title}</Text>
          
          {/* Subtitle */}
          <Text style={styles.subtitle}>{slide.subtitle}</Text>

          {/* Description */}
          <Text style={styles.description}>{slide.description}</Text>

          {/* Stats */}
          {slide.stats && (
            <View style={styles.statsContainer}>
              <Text style={styles.statsValue}>{slide.stats.value}</Text>
              <Text style={styles.statsLabel}>{slide.stats.label}</Text>
            </View>
          )}

          {/* Benefits */}
          <View style={styles.benefitsContainer}>
            {slide.benefits.map((benefit, index) => (
              <View key={index} style={styles.benefitItem}>
                <Text style={styles.benefitIcon}>✓</Text>
                <Text style={styles.benefitText}>{benefit}</Text>
              </View>
            ))}
          </View>
        </View>
      </LinearGradient>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipButtonText}>Skip</Text>
        </TouchableOpacity>
        
        {/* Progress Dots */}
        <View style={styles.progressContainer}>
          {onboardingSlides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentSlide && styles.progressDotActive
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
      </View>

      {/* Slides */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={(event) => {
          const newIndex = Math.round(event.nativeEvent.contentOffset.x / width);
          setCurrentSlide(newIndex);
        }}
        style={styles.scrollView}
      >
        {onboardingSlides.map(renderSlide)}
      </ScrollView>

      {/* Navigation */}
      <View style={styles.navigation}>
        <View style={styles.navigationButtons}>
          {currentSlide > 0 && (
            <TouchableOpacity onPress={previousSlide} style={styles.navButton}>
              <Text style={styles.navButtonText}>Previous</Text>
            </TouchableOpacity>
          )}
          
          {currentSlide < onboardingSlides.length - 1 ? (
            <TouchableOpacity onPress={nextSlide} style={styles.nextButton}>
              <Text style={styles.nextButtonText}>Next</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity onPress={completeOnboarding} style={styles.getStartedButton}>
              <Text style={styles.getStartedButtonText}>Get Started</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    paddingTop: 10,
  },
  skipButton: {
    padding: 8,
  },
  skipButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: '#87CEEB',
    width: 24,
  },
  placeholder: {
    width: 60,
  },
  scrollView: {
    flex: 1,
  },
  slide: {
    width,
    height: height - 200,
  },
  gradientBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  slideContent: {
    alignItems: 'center',
    maxWidth: 320,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  icon: {
    fontSize: 60,
  },
  title: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 34,
  },
  subtitle: {
    color: '#E5E7EB',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '600',
  },
  description: {
    color: '#F9FAFB',
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 30,
  },
  statsContainer: {
    alignItems: 'center',
    marginBottom: 30,
    padding: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  statsValue: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  statsLabel: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  benefitsContainer: {
    width: '100%',
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    paddingHorizontal: 10,
  },
  benefitIcon: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 12,
  },
  benefitText: {
    color: '#F9FAFB',
    fontSize: 16,
    flex: 1,
    lineHeight: 22,
  },
  navigation: {
    padding: 20,
    paddingBottom: 40,
  },
  navigationButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  navButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  navButtonText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  nextButton: {
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 8,
    backgroundColor: '#87CEEB',
  },
  nextButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  getStartedButton: {
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 8,
    backgroundColor: '#10B981',
  },
  getStartedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
