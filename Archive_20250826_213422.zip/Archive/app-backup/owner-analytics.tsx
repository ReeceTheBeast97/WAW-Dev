import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { supabase } from '../src/lib/api/real/supabaseClient';

type DbStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type DbBooking = {
  id: string;
  user_id: string;
  service_type: string;
  scheduled_at: string | null;
  created_at: string;
  status: DbStatus;
  price: number | null;
  valeter_rating: number | null;
};

type Stats = {
  totalSpent: number;
  totalBookings: number;
  averageRating: number;
  completedServices: number;
  cancelledServices: number;
  favoriteService: string | null;
  monthlySpending: { label: string; amount: number }[]; // last 6 months (oldest -> newest)
};

export default function OwnerAnalytics() {
      console.log('📍 Rendering owner analytcics');

  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<Stats | null>(null);

  // Build month labels for last 6 months once
  const last6 = useMemo(() => {
    const arr: { key: string; label: string; year: number; month: number }[] = [];
    const d = new Date();
    d.setDate(1);
    for (let i = 5; i >= 0; i--) {
      const copy = new Date(d);
      copy.setMonth(d.getMonth() - i);
      const year = copy.getFullYear();
      const month = copy.getMonth(); // 0..11
      const key = `${year}-${String(month + 1).padStart(2, '0')}`;
      const label = copy.toLocaleString('en-GB', { month: 'short' });
      arr.push({ key, label, year, month });
    }
    return arr;
  }, []);

  useEffect(() => {
    const load = async () => {
      if (!user?.id) return;
      setLoading(true);
      try {
        // Pull enough rows (you can paginate later if needed)
        const { data, error } = await supabase
          .from('bookings')
          .select('id, user_id, service_type, scheduled_at, created_at, status, price, valeter_rating')
          .eq('user_id', user.id)
          .order('scheduled_at', { ascending: false })
          .limit(500);

        if (error) throw error;
        const rows = (data || []) as DbBooking[];

        // --- Aggregate ---
        const totalBookings = rows.length;

        let totalSpent = 0;
        let completedServices = 0;
        let cancelledServices = 0;

        const ratingBucket: number[] = [];
        const serviceCounts: Record<string, number> = {};
        const monthSpend: Record<string, number> = Object.fromEntries(last6.map(m => [m.key, 0]));

        for (const r of rows) {
          // completed revenue
          if (r.status === 'completed') {
            completedServices += 1;
            totalSpent += Number(r.price || 0);
          }
          if (r.status === 'cancelled') cancelledServices += 1;

          // ratings
          if (typeof r.valeter_rating === 'number') ratingBucket.push(Number(r.valeter_rating));

          // favourite service
          if (r.service_type) {
            serviceCounts[r.service_type] = (serviceCounts[r.service_type] || 0) + 1;
          }

          // monthly spending (completed only)
          const whenStr = r.scheduled_at || r.created_at;
          if (whenStr) {
            const when = new Date(whenStr);
            const key = `${when.getFullYear()}-${String(when.getMonth() + 1).padStart(2, '0')}`;
            if (monthSpend[key] != null && r.status === 'completed') {
              monthSpend[key] += Number(r.price || 0);
            }
          }
        }

        // average rating
        const averageRating = ratingBucket.length
          ? Math.round((ratingBucket.reduce((a, b) => a + b, 0) / ratingBucket.length) * 10) / 10
          : 0;

        // favourite service
        let favoriteService: string | null = null;
        let maxCount = 0;
        Object.entries(serviceCounts).forEach(([svc, count]) => {
          if (count > maxCount) {
            maxCount = count;
            favoriteService = svc;
          }
        });

        // monthly spending array in order (oldest -> newest)
        const monthlySpending = last6.map(m => ({
          label: m.label,
          amount: Math.round((monthSpend[m.key] || 0) * 100) / 100,
        }));

        setStats({
          totalSpent: Math.round(totalSpent * 100) / 100,
          totalBookings,
          averageRating,
          completedServices,
          cancelledServices,
          favoriteService,
          monthlySpending,
        });
      } catch (e: any) {
        console.log('analytics load error:', e?.message || e);
        setStats(null);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [user?.id, last6]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator />
          <Text style={{ color: '#87CEEB', marginTop: 12 }}>Loading analytics…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!stats) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#F9FAFB', marginBottom: 10 }}>No analytics available.</Text>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={{ color: '#87CEEB', textDecorationLine: 'underline' }}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const maxBar = Math.max(1, ...stats.monthlySpending.map(m => m.amount));

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{stats.totalSpent.toFixed(2)}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating ? `${stats.averageRating}⭐` : '—'}</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
          </View>
        </View>

        {/* Service Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Service Breakdown</Text>
          <View style={styles.serviceCard}>
            <Text style={styles.serviceTitle}>Favourite Service</Text>
            <Text style={styles.serviceValue}>{stats.favoriteService ?? '—'}</Text>
          </View>
          <View style={styles.serviceCard}>
            <Text style={styles.serviceTitle}>Cancelled Services</Text>
            <Text style={styles.serviceValue}>{stats.cancelledServices}</Text>
          </View>
        </View>

        {/* Monthly Spending */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Spending (last 6 months)</Text>
          <View style={styles.chartContainer}>
            {stats.monthlySpending.map((m, i) => {
              const hPct = (m.amount / maxBar) * 100; // relative height
              return (
                <View key={`${m.label}-${i}`} style={styles.barContainer}>
                  <View style={[styles.bar, { height: Math.max(6, hPct) }]} />
                  <Text style={styles.barAmount}>£{m.amount.toFixed(0)}</Text>
                  <Text style={styles.barLabel}>{m.label}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/unified-booking')}
          >
            <Text style={styles.actionButtonText}>📅 Book New Service</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/owner-profile')}
          >
            <Text style={styles.actionButtonText}>👤 View Profile</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: 20, borderBottomWidth: 1, borderBottomColor: '#1E3A8A',
  },
  backButton: { padding: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16 },
  headerTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: 'bold' },
  placeholder: { width: 50 },

  section: { padding: 20 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '600', marginBottom: 15 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  statCard: {
    width: '48%', backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12,
    marginBottom: 10, alignItems: 'center',
  },
  statNumber: { fontSize: 20, fontWeight: 'bold', color: '#F9FAFB', marginBottom: 4 },
  statLabel: { fontSize: 12, color: '#87CEEB', textAlign: 'center' },

  serviceCard: {
    backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 10,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
  },
  serviceTitle: { color: '#F9FAFB', fontSize: 16 },
  serviceValue: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },

  chartContainer: {
    flexDirection: 'row', justifyContent: 'space-around', alignItems: 'flex-end',
    height: 160, backgroundColor: '#1E3A8A', paddingHorizontal: 10, paddingVertical: 16,
    borderRadius: 12,
  },
  barContainer: { alignItems: 'center', width: 40 },
  bar: { width: 22, backgroundColor: '#87CEEB', borderRadius: 10, marginBottom: 6 },
  barAmount: { color: '#F9FAFB', fontSize: 11, marginBottom: 2 },
  barLabel: { color: '#B0E0E6', fontSize: 12 },

  actionButton: {
    backgroundColor: '#1E3A8A', padding: 15, borderRadius: 12, marginBottom: 10, alignItems: 'center',
  },
  actionButtonText: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
});