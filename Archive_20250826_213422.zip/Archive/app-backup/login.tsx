import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { supabase } from '../src/lib/api/real/supabaseClient';

const { height } = Dimensions.get('window');

export default function LoginScreen() {
  const { login } = useAuth();
  const [userType, setUserType] = useState<'driver' | 'owner'>('driver');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Animations
  const backgroundColorAnim = useRef(new Animated.Value(0)).current;
  const waterDrop1Anim = useRef(new Animated.Value(0)).current;
  const waterDrop2Anim = useRef(new Animated.Value(0)).current;
  const waterDrop3Anim = useRef(new Animated.Value(0)).current;
  const waterDrop4Anim = useRef(new Animated.Value(0)).current;
  const waterDrop5Anim = useRef(new Animated.Value(0)).current;
  const waveAnim = useRef(new Animated.Value(0)).current;
  const rippleAnim = useRef(new Animated.Value(0)).current;

  // Navigate when Supabase confirms SIGNED_IN
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange(async (event) => {
      if (event === 'SIGNED_IN') {
        router.replace('/');
      }
    });
    return () => {
      sub.subscription.unsubscribe();
    };
  }, []);

  // Demo autofill by type (safe to remove)
  useEffect(() => {
    if (userType === 'driver') {
      setEmail('valeter@test.com');
      setPassword('password123');
    } else {
      setEmail('customer@test.com');
      setPassword('password123');
    }
  }, [userType]);

  // Animate background + water effects
  useEffect(() => {
    Animated.timing(backgroundColorAnim, {
      toValue: userType === 'driver' ? 0 : 1,
      duration: 500,
      useNativeDriver: false,
    }).start();

    const startWater = () => {
      Animated.loop(Animated.timing(waterDrop1Anim, { toValue: 1, duration: 4000, useNativeDriver: true })).start();
      Animated.loop(Animated.timing(waterDrop2Anim, { toValue: 1, duration: 3500, useNativeDriver: true })).start();
      Animated.loop(Animated.timing(waterDrop3Anim, { toValue: 1, duration: 4500, useNativeDriver: true })).start();
      Animated.loop(Animated.timing(waterDrop4Anim, { toValue: 1, duration: 3800, useNativeDriver: true })).start();
      Animated.loop(Animated.timing(waterDrop5Anim, { toValue: 1, duration: 4200, useNativeDriver: true })).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(waveAnim, { toValue: 1, duration: 3000, useNativeDriver: true }),
          Animated.timing(waveAnim, { toValue: 0, duration: 3000, useNativeDriver: true }),
        ])
      ).start();

      Animated.loop(
        Animated.sequence([
          Animated.timing(rippleAnim, { toValue: 1, duration: 2000, useNativeDriver: true }),
          Animated.timing(rippleAnim, { toValue: 0, duration: 2000, useNativeDriver: true }),
        ])
      ).start();
    };

    startWater();
  }, [userType, backgroundColorAnim]);

  const handleLogin = async () => {
    if (isLoading) return;
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setIsLoading(true);
    const normalizedEmail = email.trim().toLowerCase();

    try {
      const result = await Promise.race([
        login(normalizedEmail, password), // <- keep your Supabase-backed auth
        new Promise<{ ok: boolean; message?: string }>((resolve) =>
          setTimeout(() => resolve({ ok: false, message: 'Network timeout' }), 12000)
        ),
      ]);

      if (result.ok) return; // auth listener will navigate

      // double-check session just in case
      const { data: s } = await supabase.auth.getSession();
      if (s.session) {
        router.replace('/');
        return;
      }

      Alert.alert('Login Failed', result.message || 'Invalid credentials or network issue.');
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <KeyboardAvoidingView
        style={styles.keyboardAvoidingView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <Animated.View
          style={[
            styles.container,
            {
              backgroundColor: backgroundColorAnim.interpolate({
                inputRange: [0, 1],
                outputRange: ['#0A1929', '#1E3A8A'],
              }),
            },
          ]}
        >
          {/* Animated BG */}
          <View style={styles.waterBackground}>
            {[waterDrop1Anim, waterDrop2Anim, waterDrop3Anim, waterDrop4Anim, waterDrop5Anim].map((anim, i) => (
              <Animated.View
                key={i}
                style={[
                  styles.waterDrop,
                  styles[`waterDrop${i + 1}` as const],
                  {
                    transform: [
                      { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [-50, height + 50] }) },
                      { translateX: anim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, (i % 2 ? -1 : 1) * (10 + i * 5), 0] }) },
                    ],
                    opacity: anim.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 0.7, 0.7, 0] }),
                  },
                ]}
              />
            ))}

            <Animated.View
              style={[
                styles.wave,
                {
                  transform: [{ translateY: waveAnim.interpolate({ inputRange: [0, 1], outputRange: [0, -10] }) }],
                  opacity: waveAnim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.3, 0.6, 0.3] }),
                },
              ]}
            />
            <Animated.View
              style={[
                styles.ripple,
                {
                  transform: [{ scale: rippleAnim.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.2] }) }],
                  opacity: rippleAnim.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0.4, 0.8, 0.4] }),
                },
              ]}
            />
          </View>

          {/* Brand */}
          <View style={styles.logoContainer}>
            <View style={styles.logoWrapper}>
              <View style={styles.logoInnerCircle}>
                <View style={styles.logoIcon}>
                  <Text style={styles.mainIcon}>🧽</Text>
                </View>
              </View>
              <View style={styles.vehicleIndicators}>
                <View style={[styles.vehicleIcon, styles.topLeft]}><Text style={styles.smallVehicle}>🚗</Text></View>
                <View style={[styles.vehicleIcon, styles.topRight]}><Text style={styles.smallVehicle}>🚛</Text></View>
                <View style={[styles.vehicleIcon, styles.bottomRight]}><Text style={styles.smallVehicle}>🏍️</Text></View>
              </View>
            </View>
            <View style={styles.logoTextContainer}>
              <Text style={styles.logoText}>Waw</Text>
              <Text style={styles.logoSubtext}>Your Wish Our Wash</Text>
            </View>
          </View>

          {/* Content */}
          <ScrollView
            style={styles.scrollView}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            <View style={styles.contentContainer}>
              <View style={styles.headerContainer}>
                <Text style={styles.subtitle}>Wish a Wash</Text>
                <Text style={styles.tagline}>
                  {userType === 'driver' ? 'Wash, Earn, Succeed' : 'Professional Car Care at Your Doorstep'}
                </Text>
              </View>

              {/* Toggle */}
              <View style={styles.toggleContainer}>
                <TouchableOpacity
                  style={[styles.toggleButton, userType === 'driver' && styles.activeToggle]}
                  onPress={() => setUserType('driver')}
                  activeOpacity={0.7}
                  disabled={isLoading}
                >
                  <Text style={[styles.toggleText, userType === 'driver' && styles.activeToggleText]}>🧽 Valeter</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.toggleButton, userType === 'owner' && styles.activeToggle]}
                  onPress={() => setUserType('owner')}
                  activeOpacity={0.7}
                  disabled={isLoading}
                >
                  <Text style={[styles.toggleText, userType === 'owner' && styles.activeToggleText]}>👤 Car Owner</Text>
                </TouchableOpacity>
              </View>

              {/* Form */}
              <View style={styles.formContainer}>
                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Email</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your email"
                    placeholderTextColor="#87CEEB"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                    editable={!isLoading}
                    returnKeyType="next"
                  />
                </View>

                <View style={styles.inputContainer}>
                  <Text style={styles.inputLabel}>Password</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your password"
                    placeholderTextColor="#87CEEB"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                    autoCapitalize="none"
                    autoCorrect={false}
                    editable={!isLoading}
                    returnKeyType="done"
                    onSubmitEditing={handleLogin}
                  />
                </View>

                <TouchableOpacity
                  style={[styles.loginButton, isLoading && styles.loginButtonDisabled]}
                  onPress={handleLogin}
                  disabled={isLoading}
                  activeOpacity={0.8}
                >
                  <Text style={styles.loginButtonText}>{isLoading ? 'Signing In...' : 'Sign In'}</Text>
                </TouchableOpacity>

                <TouchableOpacity style={styles.forgotPassword} onPress={() => Alert.alert('Forgotten Password', 'Password reset flow coming soon.')}>
                  <Text style={styles.forgotPasswordText}>Forgotten Password?</Text>
                </TouchableOpacity>
              </View>

              {/* Org login */}
              <View style={styles.businessContainer}>
                <Text style={styles.businessTitle}>Organization Access</Text>
                <TouchableOpacity
                  style={styles.businessButton}
                  onPress={() => router.push('/organization-login')}
                  activeOpacity={0.7}
                  disabled={isLoading}
                >
                  <Text style={styles.businessButtonText}>🏢 Organization Login</Text>
                </TouchableOpacity>
              </View>

              {/* Signup link */}
              <View style={styles.signupContainer}>
                <Text style={styles.signupText}>Don't have an account? </Text>
                <TouchableOpacity onPress={() => router.push('/signup')} activeOpacity={0.7} disabled={isLoading}>
                  <Text style={styles.signupLink}>Sign Up</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#0A1929' },
  keyboardAvoidingView: { flex: 1 },
  container: { flex: 1 },

  // Brand
  logoContainer: { position: 'absolute', top: 40, left: 20, flexDirection: 'row', alignItems: 'center', zIndex: 1000 },
  logoWrapper: { width: 60, height: 60, borderRadius: 30, backgroundColor: 'rgba(255, 255, 255, 0.1)', justifyContent: 'center', alignItems: 'center', marginRight: 15, position: 'relative', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 6, elevation: 8 },
  logoInnerCircle: { width: 45, height: 45, borderRadius: 22.5, backgroundColor: '#87CEEB', justifyContent: 'center', alignItems: 'center' },
  logoIcon: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#0A1929', justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.2, shadowRadius: 2, elevation: 3 },
  mainIcon: { fontSize: 20, fontWeight: 'bold', color: '#87CEEB' },
  vehicleIndicators: { position: 'absolute', width: 60, height: 60, borderRadius: 30 },
  vehicleIcon: { position: 'absolute', width: 16, height: 16, borderRadius: 8, backgroundColor: 'rgba(135, 206, 235, 0.9)', justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.3, shadowRadius: 2, elevation: 3 },
  topLeft: { top: 2, left: 8 },
  topRight: { top: 2, right: 8 },
  bottomRight: { bottom: 8, right: 2 },
  smallVehicle: { fontSize: 8 },
  logoTextContainer: { flexDirection: 'column' },
  logoText: { fontSize: 26, fontWeight: 'bold', color: '#87CEEB', marginBottom: -2, letterSpacing: 1 },
  logoSubtext: { fontSize: 11, fontWeight: '600', color: '#B0E0E6', letterSpacing: 0.5, opacity: 0.9 },

  // Scroll
  scrollView: { flex: 1 },
  scrollContent: { flexGrow: 1, paddingBottom: 50 },
  contentContainer: { paddingHorizontal: 30, paddingTop: 120, paddingBottom: 50, zIndex: 10 },

  // Headline
  headerContainer: { alignItems: 'center', marginBottom: 40 },
  subtitle: { fontSize: 24, color: '#87CEEB', fontWeight: '600', marginBottom: 8 },
  tagline: { fontSize: 16, color: '#B0E0E6', textAlign: 'center', lineHeight: 22 },

  // Toggle
  toggleContainer: { flexDirection: 'row', backgroundColor: 'rgba(135, 206, 235, 0.1)', borderRadius: 25, padding: 4, marginBottom: 30, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.2, shadowRadius: 4, elevation: 4 },
  toggleButton: { flex: 1, paddingVertical: 14, paddingHorizontal: 20, borderRadius: 21, alignItems: 'center', justifyContent: 'center', minHeight: 50 },
  activeToggle: { backgroundColor: '#87CEEB', shadowColor: '#87CEEB', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 4, elevation: 4 },
  toggleText: { fontSize: 16, color: '#87CEEB', fontWeight: '600', textAlign: 'center' },
  activeToggleText: { color: '#0A1929', fontWeight: 'bold' },

  // Form
  formContainer: { marginBottom: 30 },
  inputContainer: { marginBottom: 20 },
  inputLabel: { fontSize: 16, color: '#87CEEB', marginBottom: 8, fontWeight: '600' },
  input: { backgroundColor: 'rgba(135, 206, 235, 0.1)', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 15, fontSize: 16, color: '#fff', borderWidth: 1, borderColor: 'rgba(135, 206, 235, 0.3)' },

  loginButton: { backgroundColor: '#87CEEB', borderRadius: 12, paddingVertical: 16, alignItems: 'center', marginTop: 10, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8 },
  loginButtonDisabled: { opacity: 0.7 },
  loginButtonText: { fontSize: 18, fontWeight: 'bold', color: '#0A1929' },

  forgotPassword: { alignItems: 'center', marginTop: 20 },
  forgotPasswordText: { color: '#87CEEB', fontSize: 16, textDecorationLine: 'underline' },

  businessContainer: { marginTop: 20, marginBottom: 20, alignItems: 'center' },
  businessTitle: { fontSize: 16, color: '#87CEEB', marginBottom: 10, fontWeight: '600' },
  businessButton: { backgroundColor: 'rgba(135, 206, 235, 0.1)', borderWidth: 2, borderColor: '#87CEEB', borderRadius: 10, paddingVertical: 12, paddingHorizontal: 20, alignItems: 'center' },
  businessButtonText: { fontSize: 14, fontWeight: 'bold', color: '#87CEEB' },

  signupContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  signupText: { color: '#B0E0E6', fontSize: 16 },
  signupLink: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold', textDecorationLine: 'underline' },

  // Water FX
  waterBackground: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0 },
  waterDrop: { position: 'absolute', width: 8, height: 8, borderRadius: 4, backgroundColor: 'rgba(135, 206, 235, 0.6)', shadowColor: '#87CEEB', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.8, shadowRadius: 4, elevation: 4 },
  waterDrop1: { left: '15%', top: -20 },
  waterDrop2: { left: '35%', top: -30 },
  waterDrop3: { left: '55%', top: -25 },
  waterDrop4: { left: '75%', top: -35 },
  waterDrop5: { left: '85%', top: -15 },
  wave: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 60, backgroundColor: 'rgba(135, 206, 235, 0.1)', borderTopLeftRadius: 30, borderTopRightRadius: 30 },
  ripple: { position: 'absolute', top: '50%', left: '50%', width: 200, height: 200, borderRadius: 100, backgroundColor: 'rgba(135, 206, 235, 0.05)', marginLeft: -100, marginTop: -100 },
});