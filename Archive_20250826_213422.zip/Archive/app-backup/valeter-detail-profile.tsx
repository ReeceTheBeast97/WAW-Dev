import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Dimensions,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useAuth } from './auth-context';

const { width } = Dimensions.get('window');

interface ValeterDetailProfile {
  id: string;
  name: string;
  rating: number;
  totalRatings: number;
  jobsCompleted: number;
  totalEarnings: number;
  experience: string;
  specializations: string[];
  certifications: string[];
  isOnline: boolean;
  lastSeen: string;
  isConnected: boolean;
  bio: string;
  location: string;
  joinDate: string;
  averageJobTime: string;
  customerSatisfaction: number;
  responseTime: string;
  cancellationRate: number;
  recentJobs: {
    id: string;
    customerName: string;
    serviceType: string;
    date: string;
    rating: number;
    amount: number;
  }[];
  reviews: {
    id: string;
    customerName: string;
    rating: number;
    comment: string;
    date: string;
  }[];
}

export default function ValeterDetailProfile() {
  const router = useRouter();
  const { valeterId } = useLocalSearchParams();
  const { user } = useAuth();
  const [valeter, setValeter] = useState<ValeterDetailProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadValeterProfile();
  }, [valeterId]);

  const loadValeterProfile = () => {
    // Simulate loading valeter profile data
    setTimeout(() => {
      const mockValeter: ValeterDetailProfile = {
        id: valeterId as string,
        name: 'John Smith',
        rating: 4.8,
        totalRatings: 156,
        jobsCompleted: 203,
        totalEarnings: 15420,
        experience: '5 years',
        specializations: ['Luxury Cars', 'Interior Detailing', 'Ceramic Coating', 'Paint Correction'],
        certifications: ['Professional Valeting Certificate', 'Ceramic Coating Specialist', 'Paint Protection Film Installer'],
        isOnline: true,
        lastSeen: '2 minutes ago',
        isConnected: true,
        bio: 'Professional valeter with over 5 years of experience specializing in luxury vehicles and premium detailing services. Committed to delivering exceptional results and customer satisfaction.',
        location: 'London, UK',
        joinDate: 'March 2019',
        averageJobTime: '45 minutes',
        customerSatisfaction: 98,
        responseTime: '2 minutes',
        cancellationRate: 2,
        recentJobs: [
          {
            id: '1',
            customerName: 'Sarah M.',
            serviceType: 'Full Valet',
            date: '2024-01-15',
            rating: 5,
            amount: 85,
          },
          {
            id: '2',
            customerName: 'Michael R.',
            serviceType: 'Interior Detailing',
            date: '2024-01-14',
            rating: 4,
            amount: 65,
          },
          {
            id: '3',
            customerName: 'Emma L.',
            serviceType: 'Exterior Wash',
            date: '2024-01-13',
            rating: 5,
            amount: 35,
          },
        ],
        reviews: [
          {
            id: '1',
            customerName: 'David K.',
            rating: 5,
            comment: 'Excellent service! John was professional, thorough, and my car looks brand new. Highly recommend!',
            date: '2024-01-10',
          },
          {
            id: '2',
            customerName: 'Lisa P.',
            rating: 4,
            comment: 'Great work on my luxury car. Very detailed and professional. Will definitely use again.',
            date: '2024-01-08',
          },
          {
            id: '3',
            customerName: 'Robert T.',
            rating: 5,
            comment: 'Outstanding service! John went above and beyond. My car has never looked better.',
            date: '2024-01-05',
          },
        ],
      };
      setValeter(mockValeter);
      setLoading(false);
    }, 1000);
  };

  const handleMessage = () => {
    if (valeter) {
      // Navigate to chat with this valeter
      router.push({
        pathname: '/chat-screen',
        params: { 
          recipientId: valeter.id,
          recipientName: valeter.name,
          recipientType: 'valeter'
        }
      });
    }
  };

  const handleConnect = () => {
    if (valeter) {
      setValeter(prev => prev ? { ...prev, isConnected: true } : null);
      Alert.alert('Connected!', `You are now connected with ${valeter.name}.`);
    }
  };

  const handleDisconnect = () => {
    if (valeter) {
      Alert.alert(
        'Disconnect',
        `Are you sure you want to disconnect from ${valeter.name}?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Disconnect',
            style: 'destructive',
            onPress: () => {
              setValeter(prev => prev ? { ...prev, isConnected: false } : null);
            }
          }
        ]
      );
    }
  };



  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!valeter) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Valeter not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Valeter Profile</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.profileInfo}>
            <View style={styles.profilePicture}>
              <Text style={styles.profileInitial}>{valeter.name.charAt(0)}</Text>
            </View>
            <View style={styles.profileDetails}>
              <Text style={styles.valeterName}>{valeter.name}</Text>
              <View style={styles.ratingRow}>
                <Text style={styles.ratingText}>⭐ {valeter.rating}</Text>
                <Text style={styles.ratingCount}>({valeter.totalRatings} reviews)</Text>
              </View>
              <View style={styles.statusRow}>
                <View style={[
                  styles.onlineIndicator,
                  { backgroundColor: valeter.isOnline ? '#4CAF50' : '#666' }
                ]} />
                <Text style={styles.statusText}>
                  {valeter.isOnline ? 'Online' : valeter.lastSeen}
                </Text>
              </View>
            </View>
          </View>
          
          <View style={styles.actionButtons}>
            {valeter.isConnected ? (
              <>
                <TouchableOpacity style={[styles.actionButton, styles.messageButton]} onPress={handleMessage}>
                  <Text style={styles.actionButtonText}>Message</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionButton, styles.disconnectButton]} onPress={handleDisconnect}>
                  <Text style={styles.actionButtonText}>Disconnect</Text>
                </TouchableOpacity>
              </>
            ) : (
              <TouchableOpacity style={[styles.actionButton, styles.connectButton]} onPress={handleConnect}>
                <Text style={styles.actionButtonText}>Connect</Text>
              </TouchableOpacity>
            )}

          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeter.jobsCompleted}</Text>
            <Text style={styles.statLabel}>Jobs Completed</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>£{valeter.totalEarnings.toLocaleString()}</Text>
            <Text style={styles.statLabel}>Total Earnings</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeter.experience}</Text>
            <Text style={styles.statLabel}>Experience</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeter.customerSatisfaction}%</Text>
            <Text style={styles.statLabel}>Satisfaction</Text>
          </View>
        </View>

        {/* Performance Metrics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Performance Metrics</Text>
          <View style={styles.metricsContainer}>
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Average Response Time</Text>
              <Text style={styles.metricValue}>{valeter.responseTime}</Text>
            </View>
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Average Job Time</Text>
              <Text style={styles.metricValue}>{valeter.averageJobTime}</Text>
            </View>
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Cancellation Rate</Text>
              <Text style={styles.metricValue}>{valeter.cancellationRate}%</Text>
            </View>
            <View style={styles.metricItem}>
              <Text style={styles.metricLabel}>Member Since</Text>
              <Text style={styles.metricValue}>{valeter.joinDate}</Text>
            </View>
          </View>
        </View>

        {/* Bio */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>
          <Text style={styles.bioText}>{valeter.bio}</Text>
        </View>

        {/* Specializations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Specializations</Text>
          <View style={styles.specializationsContainer}>
            {valeter.specializations.map((spec, index) => (
              <View key={index} style={styles.specializationTag}>
                <Text style={styles.specializationText}>{spec}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Certifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Certifications</Text>
          <View style={styles.certificationsContainer}>
            {valeter.certifications.map((cert, index) => (
              <View key={index} style={styles.certificationItem}>
                <Text style={styles.certificationIcon}>🏆</Text>
                <Text style={styles.certificationText}>{cert}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recent Jobs */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Jobs</Text>
          {valeter.recentJobs.map((job) => (
            <View key={job.id} style={styles.jobItem}>
              <View style={styles.jobHeader}>
                <Text style={styles.jobCustomer}>{job.customerName}</Text>
                <Text style={styles.jobAmount}>£{job.amount}</Text>
              </View>
              <View style={styles.jobDetails}>
                <Text style={styles.jobService}>{job.serviceType}</Text>
                <Text style={styles.jobDate}>{job.date}</Text>
                <Text style={styles.jobRating}>⭐ {job.rating}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Reviews */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Customer Reviews</Text>
          {valeter.reviews.map((review) => (
            <View key={review.id} style={styles.reviewItem}>
              <View style={styles.reviewHeader}>
                <Text style={styles.reviewCustomer}>{review.customerName}</Text>
                <Text style={styles.reviewRating}>⭐ {review.rating}</Text>
              </View>
              <Text style={styles.reviewComment}>{review.comment}</Text>
              <Text style={styles.reviewDate}>{review.date}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: '#EF4444',
    fontSize: 18,
  },
  profileHeader: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  profileInfo: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  profileInitial: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#0A1929',
  },
  profileDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingText: {
    color: '#FFD700',
    fontSize: 16,
    marginRight: 8,
  },
  ratingCount: {
    color: '#87CEEB',
    fontSize: 14,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  connectButton: {
    backgroundColor: '#4CAF50',
  },
  disconnectButton: {
    backgroundColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#2196F3',
  },

  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 20,
    gap: 12,
  },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  metricsContainer: {
    gap: 12,
  },
  metricItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
  },
  metricLabel: {
    color: '#87CEEB',
    fontSize: 14,
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  bioText: {
    color: '#E5E7EB',
    fontSize: 16,
    lineHeight: 24,
  },
  specializationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  specializationTag: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  specializationText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '500',
  },
  certificationsContainer: {
    gap: 12,
  },
  certificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  certificationIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  certificationText: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
  },
  jobItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  jobCustomer: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  jobAmount: {
    color: '#4CAF50',
    fontSize: 14,
    fontWeight: 'bold',
  },
  jobDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobService: {
    color: '#87CEEB',
    fontSize: 12,
  },
  jobDate: {
    color: '#87CEEB',
    fontSize: 12,
  },
  jobRating: {
    color: '#FFD700',
    fontSize: 12,
  },
  reviewItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  reviewCustomer: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  reviewRating: {
    color: '#FFD700',
    fontSize: 14,
  },
  reviewComment: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 8,
  },
  reviewDate: {
    color: '#87CEEB',
    fontSize: 12,
  },
});
