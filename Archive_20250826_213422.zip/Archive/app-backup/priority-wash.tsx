import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  ActivityIndicator,
  Dimensions,
  TextInput,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';
import { priorityWashService, CarWashLocation, PriorityWashBooking } from '../src/services/PriorityWashService';
import { paymentSystem } from '../src/services/PaymentSystem';

const { width } = Dimensions.get('window');

interface VehicleType {
  id: string;
  name: string;
  icon: string;
  description: string;
  baseMultiplier: number;
}

interface ServiceType {
  id: string;
  name: string;
  description: string;
  duration: string;
  multiplier: number;
}

export default function PriorityWash() {
  const router = useRouter();
  const { user } = useAuth();
  const [carWashLocations, setCarWashLocations] = useState<CarWashLocation[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<CarWashLocation | null>(null);
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>('');
  const [selectedServiceType, setSelectedServiceType] = useState<string>('');
  const [priorityLevel, setPriorityLevel] = useState<'standard' | 'priority'>('standard');
  const [isLoading, setIsLoading] = useState(false);
  const [pricing, setPricing] = useState<{
    basePrice: number;
    priorityFee: number;
    totalPrice: number;
    estimatedWaitTime: number;
    canSkipQueue: boolean;
  } | null>(null);
  const [vehicleDetails, setVehicleDetails] = useState({
    make: '',
    model: '',
    registration: '',
    photo: ''
  });

  const vehicleTypes: VehicleType[] = [
    { id: 'bike', name: 'Motorcycle', icon: '🏍️', description: 'Motorcycles and scooters', baseMultiplier: 0.6 },
    { id: 'small_car', name: 'Small Car', icon: '🚗', description: 'Hatchbacks and small sedans', baseMultiplier: 1.0 },
    { id: 'large_car', name: 'Large Car', icon: '🚙', description: 'Saloon cars and estates', baseMultiplier: 1.3 },
    { id: 'suv', name: 'SUV', icon: '🚙', description: 'Sports Utility Vehicles', baseMultiplier: 1.5 },
    { id: 'van', name: 'Van', icon: '🚐', description: 'Commercial vans and minibuses', baseMultiplier: 1.8 },
    { id: 'coach', name: 'Coach', icon: '🚌', description: 'Large coaches and buses', baseMultiplier: 3.0 },
    { id: 'luxury', name: 'Luxury Vehicle', icon: '🏎️', description: 'High-end and sports cars', baseMultiplier: 2.0 },
  ];

  const serviceTypes: ServiceType[] = [
    { id: 'exterior_only', name: 'Exterior Only', description: 'Wash exterior only', duration: '15 min', multiplier: 0.7 },
    { id: 'standard', name: 'Standard Wash', description: 'Exterior and interior clean', duration: '30 min', multiplier: 1.0 },
    { id: 'premium', name: 'Premium Wash', description: 'Deep clean with wax', duration: '45 min', multiplier: 1.4 },
    { id: 'luxury', name: 'Luxury Detail', description: 'Full detail and protection', duration: '90 min', multiplier: 2.0 },
  ];

  useEffect(() => {
    loadCarWashLocations();
  }, []);

  useEffect(() => {
    if (selectedLocation && selectedVehicleType && selectedServiceType) {
      calculatePricing();
    }
  }, [selectedLocation, selectedVehicleType, selectedServiceType, priorityLevel]);

  const loadCarWashLocations = () => {
    const locations = priorityWashService.getCarWashLocations();
    setCarWashLocations(locations);
  };

  const calculatePricing = () => {
    if (!selectedLocation || !selectedVehicleType || !selectedServiceType) return;

    try {
      const pricing = priorityWashService.calculatePriorityPrice(
        selectedLocation.id,
        selectedVehicleType,
        selectedServiceType
      );
      setPricing(pricing);
    } catch (error) {
      console.error('Error calculating pricing:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green': return '#4CAF50';
      case 'yellow': return '#FF9800';
      case 'orange': return '#FF5722';
      case 'red': return '#F44336';
      default: return '#9E9E9E';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'green': return 'Low Wait';
      case 'yellow': return 'Moderate Wait';
      case 'orange': return 'High Wait';
      case 'red': return 'Very Busy';
      default: return 'Unknown';
    }
  };

  const handleBookPriorityWash = async () => {
    if (!user || !selectedLocation || !selectedVehicleType || !selectedServiceType || !pricing) {
      Alert.alert('Error', 'Please complete all selections');
      return;
    }

    if (!vehicleDetails.make || !vehicleDetails.model || !vehicleDetails.registration) {
      Alert.alert('Error', 'Please enter vehicle details');
      return;
    }

    setIsLoading(true);

    try {
      // Check if user has payment methods
      const paymentMethods = paymentSystem.getUserPaymentMethods(user.id);
      if (paymentMethods.length === 0) {
        Alert.alert(
          'No Payment Method',
          'Please add a payment method before booking.',
          [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Add Payment Method', onPress: () => router.push('/payment-methods') }
          ]
        );
        return;
      }

      // Create booking
      const booking = priorityWashService.bookPriorityWash(
        user.id,
        selectedLocation.id,
        selectedVehicleType,
        selectedServiceType,
        priorityLevel,
        {
          make: vehicleDetails.make,
          model: vehicleDetails.model,
          size: vehicleTypes.find(v => v.id === selectedVehicleType)?.name || '',
          registration: vehicleDetails.registration,
          photo: vehicleDetails.photo
        }
      );

      // Process payment
      const defaultPaymentMethod = paymentMethods.find(m => m.isDefault) || paymentMethods[0];
      const payment = paymentSystem.processPayment(
        booking.id,
        booking.totalPrice,
        defaultPaymentMethod.id,
        user.id
      );

      Alert.alert(
        'Booking Confirmed! 🎉',
        `Your priority wash has been booked at ${selectedLocation.name}.\n\n` +
        `Total: £${booking.totalPrice}\n` +
        `Estimated wait: ${booking.estimatedWaitTime} minutes\n` +
        `Arrival time: ${booking.estimatedArrivalTime.toLocaleTimeString()}`,
        [
          { text: 'View Booking', onPress: () => router.push('/priority-wash-tracking') },
          { text: 'Back to Dashboard', onPress: () => router.push('/owner-dashboard') }
        ]
      );

      // Reset form
      setSelectedLocation(null);
      setSelectedVehicleType('');
      setSelectedServiceType('');
      setPriorityLevel('standard');
      setVehicleDetails({ make: '', model: '', registration: '', photo: '' });
      setPricing(null);

    } catch (error) {
      Alert.alert('Error', 'Failed to book priority wash. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleTakePhoto = () => {
    Alert.alert(
      'Vehicle Photo',
      'This would open camera to take a photo of your vehicle for AI recognition.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Take Photo', onPress: () => {
          // Simulate photo capture
          setVehicleDetails(prev => ({ ...prev, photo: 'vehicle_photo.jpg' }));
          Alert.alert('Success', 'Vehicle photo captured! AI will analyze make and model.');
        }}
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Priority Wash</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Car Wash Locations */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Car Wash Location</Text>
          <Text style={styles.sectionSubtitle}>Choose from nearby car washes</Text>
          
          {carWashLocations.map((location) => (
            <TouchableOpacity
              key={location.id}
              style={[
                styles.locationCard,
                selectedLocation?.id === location.id && styles.selectedLocationCard
              ]}
              onPress={() => setSelectedLocation(location)}
            >
              <View style={styles.locationHeader}>
                <View style={styles.locationInfo}>
                  <Text style={styles.locationName}>{location.name}</Text>
                  <Text style={styles.locationAddress}>{location.address}</Text>
                  <View style={styles.locationRating}>
                    <Text style={styles.ratingText}>⭐ {location.rating} ({location.totalReviews} reviews)</Text>
                  </View>
                </View>
                
                <View style={styles.statusContainer}>
                  <View style={[styles.statusDot, { backgroundColor: getStatusColor(location.status) }]} />
                  <Text style={styles.statusText}>{getStatusText(location.status)}</Text>
                </View>
              </View>

              <View style={styles.locationDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Current Wait:</Text>
                  <Text style={styles.detailValue}>{location.currentWaitTime} min</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Priority Fee:</Text>
                  <Text style={styles.detailValue}>£{location.priorityPrice}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Organization:</Text>
                  <Text style={styles.detailValue}>{location.organization}</Text>
                </View>
              </View>

              {selectedLocation?.id === location.id && (
                <View style={styles.selectedIndicator}>
                  <Text style={styles.selectedIcon}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Vehicle Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Type</Text>
          <View style={styles.vehicleGrid}>
            {vehicleTypes.map((vehicle) => (
              <TouchableOpacity
                key={vehicle.id}
                style={[
                  styles.vehicleCard,
                  selectedVehicleType === vehicle.id && styles.selectedVehicleCard
                ]}
                onPress={() => setSelectedVehicleType(vehicle.id)}
              >
                <Text style={styles.vehicleIcon}>{vehicle.icon}</Text>
                <Text style={styles.vehicleName}>{vehicle.name}</Text>
                <Text style={styles.vehicleDescription}>{vehicle.description}</Text>
                {selectedVehicleType === vehicle.id && (
                  <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedIcon}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Service Type Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Service Type</Text>
          <View style={styles.serviceGrid}>
            {serviceTypes.map((service) => (
              <TouchableOpacity
                key={service.id}
                style={[
                  styles.serviceCard,
                  selectedServiceType === service.id && styles.selectedServiceCard
                ]}
                onPress={() => setSelectedServiceType(service.id)}
              >
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDescription}>{service.description}</Text>
                <Text style={styles.serviceDuration}>{service.duration}</Text>
                {selectedServiceType === service.id && (
                  <View style={styles.selectedIndicator}>
                    <Text style={styles.selectedIcon}>✓</Text>
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Vehicle Details */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Details</Text>
          
          <View style={styles.vehicleDetailsForm}>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder="Make (e.g., BMW)"
                value={vehicleDetails.make}
                onChangeText={(text) => setVehicleDetails(prev => ({ ...prev, make: text }))}
              />
              <TextInput
                style={styles.input}
                placeholder="Model (e.g., X5)"
                value={vehicleDetails.model}
                onChangeText={(text) => setVehicleDetails(prev => ({ ...prev, model: text }))}
              />
            </View>
            
            <TextInput
              style={styles.input}
              placeholder="Registration Number"
              value={vehicleDetails.registration}
              onChangeText={(text) => setVehicleDetails(prev => ({ ...prev, registration: text.toUpperCase() }))}
              autoCapitalize="characters"
            />

            <TouchableOpacity style={styles.photoButton} onPress={handleTakePhoto}>
              <Text style={styles.photoButtonIcon}>📷</Text>
              <Text style={styles.photoButtonText}>
                {vehicleDetails.photo ? 'Photo Captured ✓' : 'Take Vehicle Photo'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Priority Level Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Priority Level</Text>
          
          <View style={styles.priorityOptions}>
            <TouchableOpacity
              style={[
                styles.priorityCard,
                priorityLevel === 'standard' && styles.selectedPriorityCard
              ]}
              onPress={() => setPriorityLevel('standard')}
            >
              <Text style={styles.priorityTitle}>Standard Queue</Text>
              <Text style={styles.priorityDescription}>
                Join the regular queue
              </Text>
              {priorityLevel === 'standard' && (
                <View style={styles.selectedIndicator}>
                  <Text style={styles.selectedIcon}>✓</Text>
                </View>
              )}
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.priorityCard,
                priorityLevel === 'priority' && styles.selectedPriorityCard
              ]}
              onPress={() => setPriorityLevel('priority')}
            >
              <Text style={styles.priorityTitle}>Priority Queue</Text>
              <Text style={styles.priorityDescription}>
                Skip the queue for faster service
              </Text>
              {priorityLevel === 'priority' && (
                <View style={styles.selectedIndicator}>
                  <Text style={styles.selectedIcon}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* Pricing Summary */}
        {pricing && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Pricing Summary</Text>
            <View style={styles.pricingCard}>
              <View style={styles.pricingRow}>
                <Text style={styles.pricingLabel}>Base Price:</Text>
                <Text style={styles.pricingValue}>£{pricing.basePrice}</Text>
              </View>
              {priorityLevel === 'priority' && (
                <View style={styles.pricingRow}>
                  <Text style={styles.pricingLabel}>Priority Fee:</Text>
                  <Text style={styles.pricingValue}>£{pricing.priorityFee}</Text>
                </View>
              )}
              <View style={styles.pricingDivider} />
              <View style={styles.pricingRow}>
                <Text style={styles.pricingLabelTotal}>Total:</Text>
                <Text style={styles.pricingValueTotal}>£{pricing.totalPrice}</Text>
              </View>
              <View style={styles.pricingRow}>
                <Text style={styles.pricingLabel}>Estimated Wait:</Text>
                <Text style={styles.pricingValue}>{pricing.estimatedWaitTime} minutes</Text>
              </View>
              {priorityLevel === 'priority' && pricing.canSkipQueue && (
                <View style={styles.skipQueueBadge}>
                  <Text style={styles.skipQueueText}>🚀 Skip Queue Available</Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Book Button */}
        <View style={styles.section}>
          <TouchableOpacity
            style={[styles.bookButton, (!pricing || isLoading) && styles.bookButtonDisabled]}
            onPress={handleBookPriorityWash}
            disabled={!pricing || isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.bookButtonText}>
                Book Priority Wash - £{pricing?.totalPrice || 0}
              </Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    fontSize: 16,
    color: '#87CEEB',
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1E3A8A',
  },
  placeholder: {
    width: 60,
  },
  section: {
    padding: 20,
    backgroundColor: '#FFFFFF',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 16,
  },
  locationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    position: 'relative',
  },
  selectedLocationCard: {
    borderColor: '#87CEEB',
    backgroundColor: '#F0F8FF',
  },
  locationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 4,
  },
  locationAddress: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  locationRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 12,
    color: '#FF9800',
  },
  statusContainer: {
    alignItems: 'center',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  locationDetails: {
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingTop: 12,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  detailLabel: {
    fontSize: 14,
    color: '#666666',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E3A8A',
  },
  vehicleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  vehicleCard: {
    width: (width - 64) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    alignItems: 'center',
    position: 'relative',
  },
  selectedVehicleCard: {
    borderColor: '#87CEEB',
    backgroundColor: '#F0F8FF',
  },
  vehicleIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  vehicleName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 4,
    textAlign: 'center',
  },
  vehicleDescription: {
    fontSize: 12,
    color: '#666666',
    textAlign: 'center',
  },
  serviceGrid: {
    gap: 12,
  },
  serviceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    position: 'relative',
  },
  selectedServiceCard: {
    borderColor: '#87CEEB',
    backgroundColor: '#F0F8FF',
  },
  serviceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 4,
  },
  serviceDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  serviceDuration: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  vehicleDetailsForm: {
    gap: 16,
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
  },
  photoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#87CEEB',
    borderRadius: 8,
    padding: 16,
    justifyContent: 'center',
  },
  photoButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  photoButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  priorityOptions: {
    gap: 12,
  },
  priorityCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    position: 'relative',
  },
  selectedPriorityCard: {
    borderColor: '#87CEEB',
    backgroundColor: '#F0F8FF',
  },
  priorityTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E3A8A',
    marginBottom: 4,
  },
  priorityDescription: {
    fontSize: 14,
    color: '#666666',
  },
  selectedIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  pricingCard: {
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
  },
  pricingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  pricingLabel: {
    fontSize: 16,
    color: '#666666',
  },
  pricingValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E3A8A',
  },
  pricingLabelTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1E3A8A',
  },
  pricingValueTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  pricingDivider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 8,
  },
  skipQueueBadge: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    padding: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  skipQueueText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  bookButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    backgroundColor: '#E0E0E0',
  },
  bookButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
});
