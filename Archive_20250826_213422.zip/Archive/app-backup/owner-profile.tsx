import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';
import { fileUploadService } from '../src/services/FileUploadService';
import AdminGate from '../src/components/AdminGate';

export default function OwnerProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [adminMode, setAdminMode] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false); // NEW

  useEffect(() => {
    loadProfileData();
  }, []);

  const loadProfileData = () => {
    if (user?.id) {
      const userProfilePicture = fileUploadService.getUserProfilePicture(user.id);
      if (userProfilePicture) {
        setProfilePicture(userProfilePicture.filePath);
      }
    }
  };

  const handleUploadProfilePicture = () => {
    Alert.alert(
      'Upload Profile Picture',
      'This would open camera/gallery to select a profile picture.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Upload', onPress: () => {
          Alert.alert('Success', 'Profile picture uploaded successfully!');
        }}
      ]
    );
  };

  const handleEditProfile = () => {
    Alert.alert('Edit Profile', 'This would open profile editing form.');
  };

  const handleChangePassword = () => {
    Alert.alert('Change Password', 'This would open password change form.');
  };

  const handlePrivacySettings = () => {
    router.push('/privacy-settings');
  };

  const handleHelpSupport = () => {
    router.push('/help-support');
  };

  const handleLogout = () => {
    if (isLoggingOut) return; // guard against double taps
    console.log('Owner Profile: Logout button pressed');
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            if (isLoggingOut) return;
            setIsLoggingOut(true);
            console.log('Owner Profile: Logout confirmed, calling logout()');
            try {
              // This calls supabase.auth.signOut() in your context and clears local user
              await logout();

              console.log('Owner Profile: Logout successful, routing to /login');
              // Send them to the login screen and replace history
              router.replace('/login');
            } catch (error) {
              console.error('Owner Profile: Logout error:', error);
              Alert.alert('Logout Error', 'Failed to logout. Please try again.');
            } finally {
              setIsLoggingOut(false);
            }
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Profile</Text>
        </View>

        {/* Profile Picture Section */}
        <View style={styles.section}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                {/* Profile picture would be displayed here */}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Text style={styles.profilePictureText}>👤</Text>
              </View>
            )}
            <TouchableOpacity
              style={[styles.uploadButton, isLoggingOut && { opacity: 0.6 }]}
              onPress={handleUploadProfilePicture}
              disabled={isLoggingOut}
            >
              <Text style={styles.uploadButtonText}>Upload Photo</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <Text style={styles.userName}>{user?.name || 'User Name'}</Text>
            <Text style={styles.userEmail}>{user?.email || 'user@example.com'}</Text>
            <Text style={styles.userPhone}>{user?.phone || '+44 7700 900000'}</Text>
          </View>
        </View>

        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>

          <TouchableOpacity style={styles.settingItem} onPress={handleEditProfile} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>✏️</Text>
              <Text style={styles.settingText}>Edit Profile</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={handleChangePassword} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🔒</Text>
              <Text style={styles.settingText}>Change Password</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={handlePrivacySettings} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🔒</Text>
              <Text style={styles.settingText}>Privacy & Security</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🔔</Text>
              <Text style={styles.settingText}>Push Notifications</Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              disabled={isLoggingOut}
              trackColor={{ false: '#767577', true: '#87CEEB' }}
              thumbColor={notificationsEnabled ? '#1E3A8A' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>📧</Text>
              <Text style={styles.settingText}>Email Notifications</Text>
            </View>
            <Switch
              value={emailNotifications}
              onValueChange={setEmailNotifications}
              disabled={isLoggingOut}
              trackColor={{ false: '#767577', true: '#87CEEB' }}
              thumbColor={emailNotifications ? '#1E3A8A' : '#f4f3f4'}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>📱</Text>
              <Text style={styles.settingText}>SMS Notifications</Text>
            </View>
            <Switch
              value={smsNotifications}
              onValueChange={setSmsNotifications}
              disabled={isLoggingOut}
              trackColor={{ false: '#767577', true: '#87CEEB' }}
              thumbColor={smsNotifications ? '#1E3A8A' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* Admin Access - Only for founders */}
        <AdminGate>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>👑 Founder Access</Text>

            <View style={styles.settingItem}>
              <View style={styles.settingLeftWithSubtext}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Text style={styles.settingIcon}>🔐</Text>
                  <Text style={styles.settingText}>Admin Dashboard Mode</Text>
                </View>
                <Text style={styles.settingSubtext}>Switch to founder dashboard view</Text>
              </View>
              <Switch
                value={adminMode}
                onValueChange={setAdminMode}
                disabled={isLoggingOut}
                trackColor={{ false: '#767577', true: '#87CEEB' }}
                thumbColor={adminMode ? '#1E3A8A' : '#f4f3f4'}
              />
            </View>

            {adminMode && (
              <TouchableOpacity
                style={styles.settingItem}
                onPress={() => router.push('/admin-dashboard')}
                disabled={isLoggingOut}
              >
                <View style={styles.settingLeft}>
                  <Text style={styles.settingIcon}>📊</Text>
                  <Text style={styles.settingText}>Open Founder Dashboard</Text>
                </View>
                <Text style={styles.settingArrow}>›</Text>
              </TouchableOpacity>
            )}
          </View>
        </AdminGate>

        {/* Support & Help */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support & Help</Text>

          <TouchableOpacity style={styles.settingItem} onPress={handleHelpSupport} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🆘</Text>
              <Text style={styles.settingText}>Help & Support</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/live-chat')} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>💬</Text>
              <Text style={styles.settingText}>Live Chat</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/terms-of-service')} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>📄</Text>
              <Text style={styles.settingText}>Terms of Service</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/privacy-policy')} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🔒</Text>
              <Text style={styles.settingText}>Privacy Policy</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={() => router.push('/privacy-settings')} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>⚙️</Text>
              <Text style={styles.settingText}>Privacy & Security Settings</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* Logout */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.settingItem} onPress={handleLogout} disabled={isLoggingOut}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🚪</Text>
              <Text style={[styles.settingText, styles.logoutText]}>
                {isLoggingOut ? 'Logging out…' : 'Logout'}
              </Text>
            </View>
            {isLoggingOut ? (
              <ActivityIndicator />
            ) : (
              <Text style={styles.settingArrow}>›</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash Ltd</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  editButton: {
    padding: 8,
  },
  editButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  profileSection: {
    padding: 20,
    alignItems: 'center',
  },
  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profilePicture: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#1E3A8A',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  profilePicturePlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  profilePictureText: {
    fontSize: 40,
  },
  uploadButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 8,
  },
  uploadButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  profileInfo: {
    alignItems: 'center',
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  userEmail: {
    color: '#87CEEB',
    fontSize: 16,
    marginBottom: 2,
  },
  userPhone: {
    color: '#87CEEB',
    fontSize: 16,
  },
  section: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLeftWithSubtext: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 16,
    width: 24,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 16,
    flex: 1,
  },
  settingSubtext: {
    color: '#B0E0E6',
    fontSize: 12,
    marginTop: 2,
  },
  logoutText: {
    color: '#EF4444',
  },
  deleteText: {
    color: '#EF4444',
  },
  settingArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  appInfoSection: {
    padding: 20,
    alignItems: 'center',
  },
  appInfoText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
  },
});