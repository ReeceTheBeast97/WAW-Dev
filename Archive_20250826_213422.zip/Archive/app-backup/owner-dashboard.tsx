import React from 'react';
import PowerfulDashboard from '../src/components/dashboard/PowerfulDashboard';

export default function OwnerDashboard() {
  return <PowerfulDashboard />;
}
