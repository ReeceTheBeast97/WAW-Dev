import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  TextInput,
  FlatList,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useAuth } from './auth-context';

interface ValeterContact {
  id: string;
  name: string;
  rating: number;
  jobsCompleted: number;
  specializations: string[];
  isOnline: boolean;
  lastSeen: string;
  isConnected: boolean;
}

export default function ValeterNetwork() {
  const router = useRouter();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'online' | 'connected'>('all');
  const [valeters, setValeters] = useState<ValeterContact[]>([]);

  useEffect(() => {
    loadValeterNetwork();
  }, []);

  const loadValeterNetwork = () => {
    // Simulate valeter network data
    const mockValeters: ValeterContact[] = [
      {
        id: '1',
        name: 'John Smith',
        rating: 4.8,
        jobsCompleted: 156,
        specializations: ['Luxury Cars', 'Interior Detailing'],
        isOnline: true,
        lastSeen: '2 minutes ago',
        isConnected: true,
      },
      {
        id: '2',
        name: 'Sarah Johnson',
        rating: 4.9,
        jobsCompleted: 203,
        specializations: ['Exterior Wash', 'Waxing'],
        isOnline: true,
        lastSeen: '5 minutes ago',
        isConnected: false,
      },
      {
        id: '3',
        name: 'Mike Wilson',
        rating: 4.7,
        jobsCompleted: 89,
        specializations: ['Quick Wash', 'Tire Shine'],
        isOnline: false,
        lastSeen: '1 hour ago',
        isConnected: true,
      },
      {
        id: '4',
        name: 'Emma Davis',
        rating: 4.6,
        jobsCompleted: 134,
        specializations: ['Full Valet', 'Ceramic Coating'],
        isOnline: true,
        lastSeen: '10 minutes ago',
        isConnected: false,
      },
      {
        id: '5',
        name: 'David Brown',
        rating: 4.5,
        jobsCompleted: 67,
        specializations: ['Standard Wash', 'Interior Clean'],
        isOnline: false,
        lastSeen: '3 hours ago',
        isConnected: false,
      },
    ];

    setValeters(mockValeters);
  };

  const filteredValeters = valeters.filter(valeter => {
    const matchesSearch = valeter.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedFilter === 'online') {
      return matchesSearch && valeter.isOnline;
    } else if (selectedFilter === 'connected') {
      return matchesSearch && valeter.isConnected;
    }
    
    return matchesSearch;
  });

  const handleConnect = (valeterId: string) => {
    setValeters(prev => 
      prev.map(v => 
        v.id === valeterId ? { ...v, isConnected: true } : v
      )
    );
    Alert.alert('Connected!', 'You are now connected with this valeter.');
  };

  const handleDisconnect = (valeterId: string) => {
    Alert.alert(
      'Disconnect',
      'Are you sure you want to disconnect from this valeter?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Disconnect',
          style: 'destructive',
          onPress: () => {
            setValeters(prev => 
              prev.map(v => 
                v.id === valeterId ? { ...v, isConnected: false } : v
              )
            );
          }
        }
      ]
    );
  };

  const handleMessage = (valeter: ValeterContact) => {
    Alert.alert('Message', `This would open a chat with ${valeter.name}`);
  };

  const handleViewProfile = (valeter: ValeterContact) => {
    Alert.alert('Profile', `This would show ${valeter.name}'s detailed profile`);
  };

  const renderValeterCard = ({ item }: { item: ValeterContact }) => (
    <View style={styles.valeterCard}>
      <View style={styles.valeterHeader}>
        <View style={styles.valeterInfo}>
          <Text style={styles.valeterName}>{item.name}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>⭐ {item.rating}</Text>
            <Text style={styles.jobsText}>• {item.jobsCompleted} jobs</Text>
          </View>
        </View>
        <View style={styles.statusContainer}>
          <View style={[
            styles.onlineIndicator,
            { backgroundColor: item.isOnline ? '#4CAF50' : '#666' }
          ]} />
          <Text style={styles.statusText}>
            {item.isOnline ? 'Online' : item.lastSeen}
          </Text>
        </View>
      </View>

      <View style={styles.specializationsContainer}>
        {item.specializations.map((spec, index) => (
          <View key={index} style={styles.specializationTag}>
            <Text style={styles.specializationText}>{spec}</Text>
          </View>
        ))}
      </View>

      <View style={styles.actionButtons}>
        {item.isConnected ? (
          <>
            <TouchableOpacity
              style={[styles.actionButton, styles.messageButton]}
              onPress={() => handleMessage(item)}
            >
              <Text style={styles.actionButtonText}>Message</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, styles.disconnectButton]}
              onPress={() => handleDisconnect(item.id)}
            >
              <Text style={styles.actionButtonText}>Disconnect</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity
            style={[styles.actionButton, styles.connectButton]}
            onPress={() => handleConnect(item.id)}
          >
            <Text style={styles.actionButtonText}>Connect</Text>
          </TouchableOpacity>
        )}
        
        <TouchableOpacity
          style={[styles.actionButton, styles.profileButton]}
          onPress={() => handleViewProfile(item)}
        >
          <Text style={styles.actionButtonText}>View Profile</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Valeter Network</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search valeters..."
            placeholderTextColor="#87CEEB"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Filter Buttons */}
        <View style={styles.filterContainer}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'all' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('all')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'all' && styles.filterButtonTextActive
            ]}>
              All ({valeters.length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'online' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('online')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'online' && styles.filterButtonTextActive
            ]}>
              Online ({valeters.filter(v => v.isOnline).length})
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              selectedFilter === 'connected' && styles.filterButtonActive
            ]}
            onPress={() => setSelectedFilter('connected')}
          >
            <Text style={[
              styles.filterButtonText,
              selectedFilter === 'connected' && styles.filterButtonTextActive
            ]}>
              Connected ({valeters.filter(v => v.isConnected).length})
            </Text>
          </TouchableOpacity>
        </View>

        {/* Network Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total Valeters</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.filter(v => v.isOnline).length}</Text>
            <Text style={styles.statLabel}>Online Now</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{valeters.filter(v => v.isConnected).length}</Text>
            <Text style={styles.statLabel}>Your Connections</Text>
          </View>
        </View>

        {/* Valeters List */}
        <View style={styles.listContainer}>
          <Text style={styles.listTitle}>
            {selectedFilter === 'all' ? 'All Valeters' : 
             selectedFilter === 'online' ? 'Online Valeters' : 'Your Connections'}
          </Text>
          
          {filteredValeters.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>👥</Text>
              <Text style={styles.emptyTitle}>No Valeters Found</Text>
              <Text style={styles.emptyText}>
                Try adjusting your search or filters
              </Text>
            </View>
          ) : (
            <FlatList
              data={filteredValeters}
              renderItem={renderValeterCard}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              showsVerticalScrollIndicator={false}
            />
          )}
        </View>

        {/* Network Tips */}
        <View style={styles.tipsContainer}>
          <Text style={styles.tipsTitle}>💡 Network Tips</Text>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Connect with valeters in your area for job referrals</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Share tips and best practices with your network</Text>
          </View>
          <View style={styles.tipItem}>
            <Text style={styles.tipText}>• Build relationships for collaborative projects</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 60,
  },
  searchContainer: {
    padding: 20,
  },
  searchInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    color: '#F9FAFB',
    fontSize: 16,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    alignItems: 'center',
  },
  filterButtonActive: {
    backgroundColor: '#87CEEB',
  },
  filterButtonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  filterButtonTextActive: {
    color: '#0A1929',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  listContainer: {
    padding: 20,
  },
  listTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  valeterCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  valeterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  valeterInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    color: '#FFD700',
    fontSize: 14,
    marginRight: 8,
  },
  jobsText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  statusText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  specializationsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 12,
  },
  specializationTag: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 4,
  },
  specializationText: {
    color: '#87CEEB',
    fontSize: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  connectButton: {
    backgroundColor: '#4CAF50',
  },
  disconnectButton: {
    backgroundColor: '#EF4444',
  },
  messageButton: {
    backgroundColor: '#2196F3',
  },
  profileButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyText: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  tipsContainer: {
    padding: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    margin: 20,
    borderRadius: 12,
  },
  tipsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  tipItem: {
    marginBottom: 8,
  },
  tipText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
});
