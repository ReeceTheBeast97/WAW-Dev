import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  SafeAreaView,
  Animated,
  Dimensions,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import ExpoMap from './components/ExpoMap';

const { width, height } = Dimensions.get('window');

interface ValeterProfile {
  id: string;
  name: string;
  photo: string;
  rating: number;
  totalJobs: number;
  vehicle: string;
  specialties: string[];
  experience: string;
  isOnline: boolean;
  currentLocation: string;
  eta: string;
  phone: string;
  email: string;
}

export default function LiveTracking() {
  const [valeterProfile] = useState<ValeterProfile>({
    id: 'val_001',
    name: 'John Smith',
    photo: '👨‍💼',
    rating: 4.8,
    totalJobs: 247,
    vehicle: 'Toyota Camry • ABC-1234',
    specialties: ['Premium Wash', 'Interior Detailing', 'Ceramic Coating'],
    experience: '3 years',
    isOnline: true,
    currentLocation: 'En route to your location',
    eta: '8 minutes',
    phone: '+44 7911 123456',
    email: 'john.smith@wishawash.com'
  });

  const [isTracking, setIsTracking] = useState(true);
  const [trackingProgress, setTrackingProgress] = useState(35);
  const [serviceStatus, setServiceStatus] = useState('en_route');
  
  // Animation values
  const slideAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Start animations
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();

    // Initialize tracking
    initializeTracking();

    // Simulate tracking progress
    const progressInterval = setInterval(() => {
      setTrackingProgress(prev => {
        if (prev < 100) {
          const newProgress = prev + Math.random() * 5;
          if (newProgress > 50 && serviceStatus === 'en_route') {
            setServiceStatus('arriving');
          }
          if (newProgress > 75 && serviceStatus === 'arriving') {
            setServiceStatus('arrived');
          }
          return Math.min(newProgress, 100);
        }
        return 100;
      });
    }, 3000);

    return () => clearInterval(progressInterval);
  }, []);

  const initializeTracking = () => {
    setIsTracking(true);
    console.log('🗺️ Live tracking initialized successfully');
  };

  const handleCallValeter = () => {
    Alert.alert(
      'Call Valeter',
      `Call ${valeterProfile.name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Call', onPress: () => {
          Alert.alert('Calling...', `Calling ${valeterProfile.phone}`);
        }}
      ]
    );
  };

  const handleMessageValeter = () => {
    Alert.alert(
      'Message Valeter',
      'Chat feature coming soon!',
      [{ text: 'OK' }]
    );
  };

  const handleCancelService = () => {
    Alert.alert(
      'Cancel Service',
      'Are you sure you want to cancel this service?',
      [
        { text: 'No', style: 'cancel' },
        { 
          text: 'Yes, Cancel', 
          style: 'destructive',
          onPress: () => router.back()
        }
      ]
    );
  };

  const handleViewReceipt = () => {
    router.push('/owner-dashboard');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'en_route': return '#87CEEB';
      case 'arriving': return '#FFD700';
      case 'arrived': return '#32CD32';
      case 'working': return '#FFA500';
      case 'completed': return '#4CAF50';
      default: return '#87CEEB';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'en_route': return 'En Route';
      case 'arriving': return 'Arriving';
      case 'arrived': return 'Arrived';
      case 'working': return 'Working';
      case 'completed': return 'Completed';
      default: return 'En Route';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.headerContent}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Follow Your Valeter</Text>
          <View style={styles.headerRight}>
            <View style={[styles.statusDot, { backgroundColor: getStatusColor(serviceStatus) }]} />
            <Text style={styles.statusText}>{getStatusText(serviceStatus)}</Text>
          </View>
        </View>
      </Animated.View>

      {/* Main Content - Split Screen */}
      <View style={styles.mainContent}>
        {/* Top Half - Map */}
        <View style={styles.mapSection}>
          <ExpoMap
            valeterLocation={{
              latitude: 51.5074 + (Math.random() - 0.5) * 0.01,
              longitude: -0.1278 + (Math.random() - 0.5) * 0.01,
              address: valeterProfile.currentLocation
            }}
            userLocation={{
              latitude: 51.5074 + 0.002,
              longitude: -0.1278 + 0.002,
              address: 'Your Location'
            }}
            showMap={true}
            isCustomerView={true}
          />
        </View>

        {/* Bottom Half - Valeter Profile & Details */}
        <Animated.View style={[styles.profileSection, { 
          opacity: fadeAnim,
          transform: [{ translateY: slideAnim.interpolate({
            inputRange: [0, 1],
            outputRange: [30, 0],
          })}]
        }]}>
          <ScrollView style={styles.profileScroll} showsVerticalScrollIndicator={false}>
            {/* Progress Bar */}
            <View style={styles.progressSection}>
              <View style={styles.progressHeader}>
                <Text style={styles.progressTitle}>Service Progress</Text>
                <Text style={styles.progressPercentage}>{Math.round(trackingProgress)}%</Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={[styles.progressBar, { width: `${trackingProgress}%` }]} />
              </View>
              <Text style={styles.progressStatus}>
                {getStatusText(serviceStatus)} • ETA: {valeterProfile.eta}
              </Text>
            </View>

            {/* Valeter Profile Card */}
            <View style={styles.profileCard}>
              <View style={styles.profileHeader}>
                <View style={styles.profilePhoto}>
                  <Text style={styles.profilePhotoText}>{valeterProfile.photo}</Text>
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{valeterProfile.name}</Text>
                  <View style={styles.ratingContainer}>
                    <Text style={styles.ratingText}>⭐ {valeterProfile.rating}</Text>
                    <Text style={styles.jobsText}>• {valeterProfile.totalJobs} jobs</Text>
                  </View>
                  <Text style={styles.vehicleText}>{valeterProfile.vehicle}</Text>
                </View>
                <View style={styles.statusIndicator}>
                  <View style={[styles.onlineDot, { backgroundColor: valeterProfile.isOnline ? '#10B981' : '#6B7280' }]} />
                  <Text style={styles.onlineText}>{valeterProfile.isOnline ? 'Online' : 'Offline'}</Text>
                </View>
              </View>

              <View style={styles.profileDetails}>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Experience:</Text>
                  <Text style={styles.detailValue}>{valeterProfile.experience}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Specialties:</Text>
                  <Text style={styles.detailValue}>{valeterProfile.specialties.join(', ')}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Current Location:</Text>
                  <Text style={styles.detailValue}>{valeterProfile.currentLocation}</Text>
                </View>
              </View>

              <View style={styles.actionButtons}>
                <TouchableOpacity style={styles.actionButton} onPress={handleCallValeter}>
                  <Text style={styles.actionButtonIcon}>📞</Text>
                  <Text style={styles.actionButtonText}>Call</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={handleMessageValeter}>
                  <Text style={styles.actionButtonIcon}>💬</Text>
                  <Text style={styles.actionButtonText}>Message</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.actionButton} onPress={() => router.push('/valeter-detail-profile')}>
                  <Text style={styles.actionButtonIcon}>👤</Text>
                  <Text style={styles.actionButtonText}>Profile</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Service Details */}
            <View style={styles.serviceCard}>
              <Text style={styles.serviceCardTitle}>Service Details</Text>
              <View style={styles.serviceDetails}>
                <View style={styles.serviceRow}>
                  <Text style={styles.serviceLabel}>Service Type:</Text>
                  <Text style={styles.serviceValue}>Premium Wash</Text>
                </View>
                <View style={styles.serviceRow}>
                  <Text style={styles.serviceLabel}>Vehicle:</Text>
                  <Text style={styles.serviceValue}>Toyota Camry</Text>
                </View>
                <View style={styles.serviceRow}>
                  <Text style={styles.serviceLabel}>Price:</Text>
                  <Text style={styles.serviceValue}>£29.99</Text>
                </View>
                <View style={styles.serviceRow}>
                  <Text style={styles.serviceLabel}>Estimated Duration:</Text>
                  <Text style={styles.serviceValue}>30-35 minutes</Text>
                </View>
              </View>
            </View>

            {/* Action Buttons */}
            <View style={styles.bottomActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancelService}>
                <Text style={styles.cancelButtonText}>Cancel Service</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.receiptButton} onPress={handleViewReceipt}>
                <Text style={styles.receiptButtonText}>View Receipt</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  mainContent: {
    flex: 1,
  },
  mapSection: {
    height: height * 0.5, // Half screen for map
    backgroundColor: '#1E3A8A',
  },
  profileSection: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  profileScroll: {
    flex: 1,
  },
  progressSection: {
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  progressTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
  },
  progressPercentage: {
    fontSize: 18,
    color: '#F9FAFB',
    fontWeight: 'bold',
  },
  progressBarContainer: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 10,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 4,
  },
  progressStatus: {
    fontSize: 14,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  profileCard: {
    backgroundColor: '#1E3A8A',
    margin: 20,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profilePhoto: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  profilePhotoText: {
    fontSize: 24,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    color: '#F9FAFB',
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  ratingText: {
    fontSize: 14,
    color: '#FFC107',
    fontWeight: '600',
  },
  jobsText: {
    fontSize: 14,
    color: '#B0E0E6',
    marginLeft: 8,
  },
  vehicleText: {
    fontSize: 14,
    color: '#87CEEB',
  },
  statusIndicator: {
    alignItems: 'center',
  },
  onlineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginBottom: 4,
  },
  onlineText: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  profileDetails: {
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  detailLabel: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  detailValue: {
    fontSize: 14,
    color: '#F9FAFB',
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  actionButton: {
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 5,
  },
  actionButtonIcon: {
    fontSize: 20,
    marginBottom: 5,
  },
  actionButtonText: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  serviceCard: {
    backgroundColor: '#1E3A8A',
    margin: 20,
    marginTop: 0,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  serviceCardTitle: {
    fontSize: 18,
    color: '#87CEEB',
    fontWeight: 'bold',
    marginBottom: 15,
  },
  serviceDetails: {
    gap: 12,
  },
  serviceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceLabel: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  serviceValue: {
    fontSize: 14,
    color: '#F9FAFB',
    fontWeight: '600',
  },
  bottomActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 15,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: 'rgba(244, 67, 54, 0.2)',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#F44336',
  },
  cancelButtonText: {
    color: '#F44336',
    fontSize: 16,
    fontWeight: 'bold',
  },
  receiptButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  receiptButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

