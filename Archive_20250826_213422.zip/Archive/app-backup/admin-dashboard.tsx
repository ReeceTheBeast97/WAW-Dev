import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Animated,
  Modal,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

interface AdminStats {
  totalRevenue: number;
  totalJobs: number;
  activeValeters: number;
  totalCustomers: number;
  pendingApplications: number;
  averageRating: number;
  monthlyGrowth: number;
  trustpilotRating: number;
}

interface ValeterApplication {
  id: string;
  name: string;
  email: string;
  phone: string;
  experience: string;
  documents: string[];
  status: 'pending' | 'approved' | 'rejected';
  submittedDate: string;
  vehicleInfo: string;
  insuranceStatus: boolean;
  backgroundCheck: boolean;
}

interface FinancialData {
  totalEarnings: number;
  platformFees: number;
  valeterPayouts: number;
  pendingWithdrawals: number;
  monthlyRevenue: number[];
  topEarningValeters: Array<{
    name: string;
    earnings: number;
    jobs: number;
  }>;
}

interface RefundRequest {
  id: string;
  customerName: string;
  customerEmail: string;
  jobId: string;
  amount: number;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  priority: 1 | 2 | 3; // 1=Low, 2=Medium, 3=Critical
  submittedDate: string;
  valeterName: string;
  serviceType: string;
}

interface Report {
  id: string;
  title: string;
  description: string;
  priority: 1 | 2 | 3;
  status: 'open' | 'investigating' | 'resolved' | 'closed';
  reportedBy: string;
  reportedDate: string;
  category: 'fraud' | 'service_quality' | 'payment_issue' | 'safety' | 'technical' | 'other';
  assignedTo?: string;
  resolution?: string;
}

interface CommissionRate {
  serviceType: string;
  vehicleSize: string;
  baseRate: number; // Percentage
  minRate: number;
  maxRate: number;
  description: string;
}

export default function AdminDashboard() {
  const [userFilter, setUserFilter] = useState<'all' | 'customers' | 'valeters'>('all');
  
  // Mock user data for demonstration
  const mockUsers = [
    {
      id: 'customer_1',
      name: 'John Customer',
      email: 'customer@test.com',
      userType: 'customer' as const,
      isEmailVerified: true,
    },
    {
      id: 'valeter_1',
      name: 'Mike Valeter',
      email: 'valeter@test.com',
      userType: 'valeter' as const,
      isEmailVerified: true,
    },
    {
      id: 'customer_2',
      name: 'Sarah Wilson',
      email: 'sarah@example.com',
      userType: 'customer' as const,
      isEmailVerified: true,
    },
    {
      id: 'valeter_2',
      name: 'David Brown',
      email: 'david@example.com',
      userType: 'valeter' as const,
      isEmailVerified: false,
    },
  ];

  const [adminStats, setAdminStats] = useState<AdminStats>({
    totalRevenue: 125847.50,
    totalJobs: 3421,
    activeValeters: 156,
    totalCustomers: 2847,
    pendingApplications: 23,
    averageRating: 4.7,
    monthlyGrowth: 23.5,
    trustpilotRating: 4.8,
  });

  const [financialData, setFinancialData] = useState<FinancialData>({
    totalEarnings: 125847.50,
    platformFees: 18877.13,
    valeterPayouts: 106970.37,
    pendingWithdrawals: 15420.00,
    monthlyRevenue: [89000, 95000, 102000, 115000, 108000, 125847],
    topEarningValeters: [
      { name: 'John Smith', earnings: 2847.50, jobs: 89 },
      { name: 'Sarah Johnson', earnings: 2654.30, jobs: 76 },
      { name: 'Mike Wilson', earnings: 2432.10, jobs: 67 },
      { name: 'Emma Davis', earnings: 2218.90, jobs: 58 },
      { name: 'David Brown', earnings: 1987.60, jobs: 52 },
    ],
  });

  const [pendingApplications, setPendingApplications] = useState<ValeterApplication[]>([
    {
      id: 'app_001',
      name: 'Alex Thompson',
      email: 'alex.thompson@email.com',
      phone: '+44 7911 123456',
      experience: '5 years',
      documents: ['Driving License', 'Insurance Certificate', 'DBS Check'],
      status: 'pending',
      submittedDate: '2024-01-15',
      vehicleInfo: 'Toyota Camry • ABC-1234',
      insuranceStatus: true,
      backgroundCheck: true,
    },
    {
      id: 'app_002',
      name: 'Lisa Chen',
      email: 'lisa.chen@email.com',
      phone: '+44 7911 234567',
      experience: '3 years',
      documents: ['Driving License', 'Insurance Certificate'],
      status: 'pending',
      submittedDate: '2024-01-14',
      vehicleInfo: 'Honda Civic • DEF-5678',
      insuranceStatus: true,
      backgroundCheck: false,
    },
  ]);

  const [selectedTab, setSelectedTab] = useState('overview');
  const [showApplicationModal, setShowApplicationModal] = useState(false);
  const [selectedApplication, setSelectedApplication] = useState<ValeterApplication | null>(null);
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [withdrawalAmount, setWithdrawalAmount] = useState('');
  const [showRefundModal, setShowRefundModal] = useState(false);
  const [selectedRefund, setSelectedRefund] = useState<RefundRequest | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showCommissionModal, setShowCommissionModal] = useState(false);

  // Animation values
  const fadeAnim = new Animated.Value(0);
  const slideAnim = new Animated.Value(30);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleApproveApplication = (applicationId: string) => {
    Alert.alert(
      'Approve Application',
      'Are you sure you want to approve this valeter application?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Approve',
          onPress: () => {
            setPendingApplications(prev => 
              prev.map(app => 
                app.id === applicationId 
                  ? { ...app, status: 'approved' as const }
                  : app
              )
            );
            setShowApplicationModal(false);
            Alert.alert('Approved', 'Valeter application has been approved!');
          }
        }
      ]
    );
  };

  const handleRejectApplication = (applicationId: string) => {
    Alert.alert(
      'Reject Application',
      'Are you sure you want to reject this valeter application?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: () => {
            setPendingApplications(prev => 
              prev.map(app => 
                app.id === applicationId 
                  ? { ...app, status: 'rejected' as const }
                  : app
              )
            );
            setShowApplicationModal(false);
            Alert.alert('Rejected', 'Valeter application has been rejected.');
          }
        }
      ]
    );
  };

  const handleViewApplication = (application: ValeterApplication) => {
    setSelectedApplication(application);
    setShowApplicationModal(true);
  };

  // User Management Handlers
  const handleViewUserDetails = (user: any) => {
    Alert.alert(
      'User Details',
      `Name: ${user.name}\nEmail: ${user.email}\nType: ${user.userType}\nVerified: ${user.isEmailVerified ? 'Yes' : 'No'}`,
      [
        { text: 'View Full Profile', onPress: () => handleViewUserProfile(user) },
        { text: 'Edit User', onPress: () => handleEditUser(user) },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleViewUserProfile = (user: any) => {
    Alert.alert(
      'View User Profile',
      `Opening full profile for ${user.name}...`,
      [
        { text: 'View as Customer', onPress: () => Alert.alert('Customer View', 'Viewing user as customer') },
        { text: 'View as Valeter', onPress: () => Alert.alert('Valeter View', 'Viewing user as valeter') },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleEditUser = (user: any) => {
    Alert.alert(
      'Edit User',
      `Editing user: ${user.name}`,
      [
        { text: 'Edit Details', onPress: () => Alert.alert('Edit', 'Edit user details') },
        { text: 'Change Status', onPress: () => Alert.alert('Status', 'Change user status') },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  const handleSuspendUser = (user: any) => {
    Alert.alert(
      'Suspend User',
      `Are you sure you want to suspend ${user.name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Suspend',
          style: 'destructive',
          onPress: () => Alert.alert('Suspended', `${user.name} has been suspended from the platform.`)
        }
      ]
    );
  };

  const handleExportUserData = () => {
    Alert.alert(
      'Export User Data',
      'Export all user data?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Export', onPress: () => Alert.alert('Exported', 'User data exported successfully!') }
      ]
    );
  };



  const handleApproveRefund = (refundId: string) => {
    Alert.alert(
      'Approve Refund',
      'Are you sure you want to approve this refund request?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Approve',
          onPress: () => {
            setRefundRequests(prev => 
              prev.map(refund => 
                refund.id === refundId 
                  ? { ...refund, status: 'approved' as const }
                  : refund
              )
            );
            setShowRefundModal(false);
            Alert.alert('Approved', 'Refund request has been approved and processed!');
          }
        }
      ]
    );
  };

  const handleRejectRefund = (refundId: string) => {
    Alert.alert(
      'Reject Refund',
      'Are you sure you want to reject this refund request?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: () => {
            setRefundRequests(prev => 
              prev.map(refund => 
                refund.id === refundId 
                  ? { ...refund, status: 'rejected' as const }
                  : refund
              )
            );
            setShowRefundModal(false);
            Alert.alert('Rejected', 'Refund request has been rejected.');
          }
        }
      ]
    );
  };

  const handleViewRefund = (refund: RefundRequest) => {
    setSelectedRefund(refund);
    setShowRefundModal(true);
  };

  const handleAssignReport = (reportId: string) => {
    Alert.alert(
      'Assign Report',
      'Assign this report to a team member?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Assign to Security',
          onPress: () => {
            setReports(prev => 
              prev.map(report => 
                report.id === reportId 
                  ? { ...report, status: 'investigating' as const, assignedTo: 'Security Team' }
                  : report
              )
            );
            Alert.alert('Assigned', 'Report assigned to Security Team.');
          }
        },
        {
          text: 'Assign to Support',
          onPress: () => {
            setReports(prev => 
              prev.map(report => 
                report.id === reportId 
                  ? { ...report, status: 'investigating' as const, assignedTo: 'Customer Support' }
                  : report
              )
            );
            Alert.alert('Assigned', 'Report assigned to Customer Support.');
          }
        }
      ]
    );
  };

  const handleResolveReport = (reportId: string) => {
    Alert.alert(
      'Resolve Report',
      'Mark this report as resolved?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Resolve',
          onPress: () => {
            setReports(prev => 
              prev.map(report => 
                report.id === reportId 
                  ? { ...report, status: 'resolved' as const, resolution: 'Issue resolved by admin' }
                  : report
              )
            );
            Alert.alert('Resolved', 'Report marked as resolved.');
          }
        }
      ]
    );
  };

  const handleViewReport = (report: Report) => {
    setSelectedReport(report);
    setShowReportModal(true);
  };

  const handleUpdateCommissionRate = (serviceType: string, newRate: number) => {
    Alert.alert(
      'Update Commission Rate',
      `Update commission rate for ${serviceType} to ${newRate}%?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Update',
          onPress: () => {
            Alert.alert('Updated', `Commission rate for ${serviceType} updated to ${newRate}%`);
          }
        }
      ]
    );
  };

  const handleExportData = (dataType: string) => {
    Alert.alert('Export Data', `${dataType} data exported successfully!`);
  };

  const handleViewDetailedAnalytics = () => {
    router.push('/admin-analytics');
  };

  const handleManageUsers = () => {
    router.push('/admin-users');
  };

  const handleSystemSettings = () => {
    router.push('/admin-settings');
  };

  const handleViewTrustpilot = () => {
    Alert.alert('Trustpilot', 'Opening Trustpilot reviews in browser...');
  };

  const handleViewWebsite = () => {
    Alert.alert('Website', 'Opening Wish a Wash website in browser...');
  };

  const handleEmergencyContact = () => {
    Alert.alert('Emergency Contact', 'Calling emergency contact: +44 7700 900000');
  };

  // Mock data for refunds, reports, and commission rates
  const [refundRequests, setRefundRequests] = useState<RefundRequest[]>([
    {
      id: 'ref_001',
      customerName: 'Sarah Wilson',
      customerEmail: 'sarah.wilson@email.com',
      jobId: 'job_1234',
      amount: 45.99,
      reason: 'Service not completed as promised - valeter left early',
      status: 'pending',
      priority: 2,
      submittedDate: '2024-01-20',
      valeterName: 'Mike Johnson',
      serviceType: 'Premium Wash',
    },
    {
      id: 'ref_002',
      customerName: 'David Brown',
      customerEmail: 'david.brown@email.com',
      jobId: 'job_1235',
      amount: 29.99,
      reason: 'Payment charged twice for same service',
      status: 'pending',
      priority: 3,
      submittedDate: '2024-01-19',
      valeterName: 'Emma Davis',
      serviceType: 'Standard Wash',
    },
    {
      id: 'ref_003',
      customerName: 'Lisa Anderson',
      customerEmail: 'lisa.anderson@email.com',
      jobId: 'job_1236',
      amount: 89.99,
      reason: 'Vehicle damaged during service',
      status: 'pending',
      priority: 3,
      submittedDate: '2024-01-18',
      valeterName: 'John Smith',
      serviceType: 'Luxury Wash',
    },
  ]);

  const [reports, setReports] = useState<Report[]>([
    {
      id: 'rep_001',
      title: 'Suspicious payment activity',
      description: 'Multiple failed payment attempts from same IP address',
      priority: 3,
      status: 'investigating',
      reportedBy: 'System',
      reportedDate: '2024-01-20',
      category: 'fraud',
      assignedTo: 'Security Team',
    },
    {
      id: 'rep_002',
      title: 'Valeter safety concern',
      description: 'Customer reported aggressive behavior from valeter',
      priority: 3,
      status: 'open',
      reportedBy: 'Customer Support',
      reportedDate: '2024-01-19',
      category: 'safety',
    },
    {
      id: 'rep_003',
      title: 'App crash during booking',
      description: 'Multiple users experiencing app crashes on iOS',
      priority: 2,
      status: 'investigating',
      reportedBy: 'Technical Support',
      reportedDate: '2024-01-18',
      category: 'technical',
      assignedTo: 'Dev Team',
    },
  ]);

  const [commissionRates, setCommissionRates] = useState<CommissionRate[]>([
    {
      serviceType: 'Express Wash',
      vehicleSize: 'Small Car',
      baseRate: 8,
      minRate: 5,
      maxRate: 12,
      description: 'Quick exterior wash for small vehicles',
    },
    {
      serviceType: 'Standard Wash',
      vehicleSize: 'Medium Car',
      baseRate: 12,
      minRate: 8,
      maxRate: 15,
      description: 'Complete wash for medium vehicles',
    },
    {
      serviceType: 'Premium Wash',
      vehicleSize: 'Large Car/SUV',
      baseRate: 15,
      minRate: 12,
      maxRate: 18,
      description: 'Premium service for large vehicles',
    },
    {
      serviceType: 'Luxury Wash',
      vehicleSize: 'Luxury Vehicle',
      baseRate: 20,
      minRate: 15,
      maxRate: 25,
      description: 'Ultimate care for premium vehicles',
    },
  ]);

  const handleProcessWithdrawal = () => {
    const amount = parseFloat(withdrawalAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid withdrawal amount.');
      return;
    }
    if (amount > financialData.pendingWithdrawals) {
      Alert.alert('Insufficient Funds', 'Withdrawal amount exceeds available funds.');
      return;
    }

    Alert.alert(
      'Process Withdrawal',
      `Process withdrawal of £${amount.toFixed(2)} to business account?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Process',
          onPress: () => {
            setFinancialData(prev => ({
              ...prev,
              pendingWithdrawals: prev.pendingWithdrawals - amount,
              totalEarnings: prev.totalEarnings - amount,
            }));
            setShowWithdrawalModal(false);
            setWithdrawalAmount('');
            Alert.alert('Success', 'Withdrawal processed successfully!');
          }
        }
      ]
    );
  };

  const renderOverviewTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      {/* Key Metrics */}
      <View style={styles.metricsGrid}>
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>£{adminStats.totalRevenue.toLocaleString()}</Text>
          <Text style={styles.metricLabel}>Total Revenue</Text>
          <Text style={styles.metricGrowth}>+{adminStats.monthlyGrowth}% this month</Text>
        </View>
        
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>{adminStats.totalJobs.toLocaleString()}</Text>
          <Text style={styles.metricLabel}>Jobs Completed</Text>
          <Text style={styles.metricGrowth}>+12% this week</Text>
        </View>
        
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>{adminStats.activeValeters}</Text>
          <Text style={styles.metricLabel}>Active Valeters</Text>
          <Text style={styles.metricGrowth}>+8 new this month</Text>
        </View>
        
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>{adminStats.totalCustomers.toLocaleString()}</Text>
          <Text style={styles.metricLabel}>Total Customers</Text>
          <Text style={styles.metricGrowth}>+15% growth</Text>
        </View>
      </View>

      {/* Trustpilot & Ratings */}
      <View style={styles.ratingsSection}>
        <Text style={styles.sectionTitle}>⭐ Trustpilot & Ratings</Text>
        <View style={styles.ratingsCard}>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingLabel}>Trustpilot Rating:</Text>
            <Text style={styles.ratingValue}>{adminStats.trustpilotRating}/5</Text>
          </View>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingLabel}>App Store Rating:</Text>
            <Text style={styles.ratingValue}>4.9/5</Text>
          </View>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingLabel}>Google Play Rating:</Text>
            <Text style={styles.ratingValue}>4.8/5</Text>
          </View>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingLabel}>Average Customer Rating:</Text>
            <Text style={styles.ratingValue}>{adminStats.averageRating}/5</Text>
          </View>
        </View>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <Text style={styles.sectionTitle}>⚡ Quick Actions</Text>
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.actionButton} onPress={() => setSelectedTab('applications')}>
            <Text style={styles.actionButtonIcon}>📋</Text>
            <Text style={styles.actionButtonText}>Review Applications</Text>
            <Text style={styles.actionButtonBadge}>{adminStats.pendingApplications}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={() => setSelectedTab('financial')}>
            <Text style={styles.actionButtonIcon}>💰</Text>
            <Text style={styles.actionButtonText}>Financial Overview</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={() => setSelectedTab('analytics')}>
            <Text style={styles.actionButtonIcon}>📊</Text>
            <Text style={styles.actionButtonText}>Analytics</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton} onPress={() => setSelectedTab('users')}>
            <Text style={styles.actionButtonIcon}>👥</Text>
            <Text style={styles.actionButtonText}>User Management</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Animated.View>
  );

  const renderApplicationsTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>📋 Valeter Applications</Text>
      
      {pendingApplications.filter(app => app.status === 'pending').map((application) => (
        <View key={application.id} style={styles.applicationCard}>
          <View style={styles.applicationHeader}>
            <Text style={styles.applicationName}>{application.name}</Text>
            <Text style={styles.applicationDate}>{application.submittedDate}</Text>
          </View>
          
          <View style={styles.applicationDetails}>
            <Text style={styles.applicationDetail}>📧 {application.email}</Text>
            <Text style={styles.applicationDetail}>📞 {application.phone}</Text>
            <Text style={styles.applicationDetail}>🚗 {application.vehicleInfo}</Text>
            <Text style={styles.applicationDetail}>💼 {application.experience} experience</Text>
          </View>
          
          <View style={styles.documentStatus}>
            <Text style={styles.documentTitle}>Documents:</Text>
            {application.documents.map((doc, index) => (
              <Text key={index} style={styles.documentItem}>• {doc}</Text>
            ))}
          </View>
          
          <View style={styles.verificationStatus}>
            <View style={styles.statusItem}>
              <Text style={styles.statusLabel}>Insurance:</Text>
              <Text style={[styles.statusValue, { color: application.insuranceStatus ? '#10B981' : '#EF4444' }]}>
                {application.insuranceStatus ? '✓ Verified' : '✗ Missing'}
              </Text>
            </View>
            <View style={styles.statusItem}>
              <Text style={styles.statusLabel}>Background Check:</Text>
              <Text style={[styles.statusValue, { color: application.backgroundCheck ? '#10B981' : '#EF4444' }]}>
                {application.backgroundCheck ? '✓ Passed' : '✗ Pending'}
              </Text>
            </View>
          </View>
          
          <View style={styles.applicationActions}>
            <TouchableOpacity 
              style={styles.viewButton} 
              onPress={() => handleViewApplication(application)}
            >
              <Text style={styles.viewButtonText}>View Details</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.approveButton} 
              onPress={() => handleApproveApplication(application.id)}
            >
              <Text style={styles.approveButtonText}>Approve</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.rejectButton} 
              onPress={() => handleRejectApplication(application.id)}
            >
              <Text style={styles.rejectButtonText}>Reject</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}
    </Animated.View>
  );

  const renderFinancialTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>💰 Financial Overview</Text>
      
      {/* Financial Summary */}
      <View style={styles.financialSummary}>
        <View style={styles.financialCard}>
          <Text style={styles.financialValue}>£{financialData.totalEarnings.toLocaleString()}</Text>
          <Text style={styles.financialLabel}>Total Earnings</Text>
        </View>
        
        <View style={styles.financialCard}>
          <Text style={styles.financialValue}>£{financialData.platformFees.toLocaleString()}</Text>
          <Text style={styles.financialLabel}>Platform Fees</Text>
        </View>
        
        <View style={styles.financialCard}>
          <Text style={styles.financialValue}>£{financialData.valeterPayouts.toLocaleString()}</Text>
          <Text style={styles.financialLabel}>Valeter Payouts</Text>
        </View>
        
        <View style={styles.financialCard}>
          <Text style={styles.financialValue}>£{financialData.pendingWithdrawals.toLocaleString()}</Text>
          <Text style={styles.financialLabel}>Pending Withdrawals</Text>
        </View>
      </View>

      {/* Withdrawal Section */}
      <View style={styles.withdrawalSection}>
        <Text style={styles.sectionTitle}>🏦 Business Withdrawal</Text>
        <View style={styles.withdrawalCard}>
          <Text style={styles.withdrawalText}>
            Available for withdrawal: £{financialData.pendingWithdrawals.toLocaleString()}
          </Text>
          <TouchableOpacity 
            style={styles.withdrawalButton} 
            onPress={() => setShowWithdrawalModal(true)}
          >
            <Text style={styles.withdrawalButtonText}>Process Withdrawal</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Top Earning Valeters */}
      <View style={styles.topEarnersSection}>
        <Text style={styles.sectionTitle}>🏆 Top Earning Valeters</Text>
        {financialData.topEarningValeters.map((valeter, index) => (
          <View key={index} style={styles.earnerCard}>
            <View style={styles.earnerRank}>
              <Text style={styles.rankNumber}>#{index + 1}</Text>
            </View>
            <View style={styles.earnerInfo}>
              <Text style={styles.earnerName}>{valeter.name}</Text>
              <Text style={styles.earnerJobs}>{valeter.jobs} jobs completed</Text>
            </View>
            <View style={styles.earnerEarnings}>
              <Text style={styles.earningsAmount}>£{valeter.earnings.toLocaleString()}</Text>
              <Text style={styles.earningsLabel}>Total Earnings</Text>
            </View>
          </View>
        ))}
      </View>
    </Animated.View>
  );

  const renderAnalyticsTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>📊 Business Analytics</Text>
      
      {/* Monthly Revenue Chart */}
      <View style={styles.chartSection}>
        <Text style={styles.chartTitle}>Monthly Revenue Trend</Text>
        <View style={styles.chartContainer}>
          {financialData.monthlyRevenue.map((revenue, index) => (
            <View key={index} style={styles.chartBar}>
              <View 
                style={[
                  styles.bar, 
                  { 
                    height: (revenue / Math.max(...financialData.monthlyRevenue)) * 100,
                    backgroundColor: index === financialData.monthlyRevenue.length - 1 ? '#87CEEB' : '#1E3A8A'
                  }
                ]} 
              />
              <Text style={styles.barLabel}>£{(revenue / 1000).toFixed(0)}k</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Performance Metrics */}
      <View style={styles.performanceSection}>
        <Text style={styles.sectionTitle}>📈 Performance Metrics</Text>
        <View style={styles.metricsGrid}>
          <View style={styles.metricCard}>
            <Text style={styles.metricValue}>98.5%</Text>
            <Text style={styles.metricLabel}>Customer Satisfaction</Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricValue}>12.3 min</Text>
            <Text style={styles.metricLabel}>Average Response Time</Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricValue}>4.7/5</Text>
            <Text style={styles.metricLabel}>Average Rating</Text>
          </View>
          <View style={styles.metricCard}>
            <Text style={styles.metricValue}>23.5%</Text>
            <Text style={styles.metricLabel}>Monthly Growth</Text>
          </View>
        </View>
      </View>
    </Animated.View>
  );

  const renderUsersTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>👥 User Management</Text>
      
      <View style={styles.userStats}>
        <View style={styles.userStatCard}>
          <Text style={styles.userStatValue}>{adminStats.totalCustomers}</Text>
          <Text style={styles.userStatLabel}>Total Customers</Text>
        </View>
        <View style={styles.userStatCard}>
          <Text style={styles.userStatValue}>{adminStats.activeValeters}</Text>
          <Text style={styles.userStatLabel}>Active Valeters</Text>
        </View>
        <View style={styles.userStatCard}>
          <Text style={styles.userStatValue}>{adminStats.pendingApplications}</Text>
          <Text style={styles.userStatLabel}>Pending Applications</Text>
        </View>
      </View>

      {/* User Type Filter */}
      <View style={styles.userFilterSection}>
        <Text style={styles.filterTitle}>Filter by User Type:</Text>
        <View style={styles.filterButtons}>
          <TouchableOpacity 
            style={[styles.filterButton, userFilter === 'all' && styles.activeFilterButton]}
            onPress={() => setUserFilter('all')}
          >
            <Text style={[styles.filterButtonText, userFilter === 'all' && styles.activeFilterButtonText]}>All Users</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterButton, userFilter === 'customers' && styles.activeFilterButton]}
            onPress={() => setUserFilter('customers')}
          >
            <Text style={[styles.filterButtonText, userFilter === 'customers' && styles.activeFilterButtonText]}>Customers</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.filterButton, userFilter === 'valeters' && styles.activeFilterButton]}
            onPress={() => setUserFilter('valeters')}
          >
            <Text style={[styles.filterButtonText, userFilter === 'valeters' && styles.activeFilterButtonText]}>Valeters</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* User List */}
      <View style={styles.userListSection}>
        <Text style={styles.userListTitle}>User Accounts</Text>
        
        {/* Mock user data - in real app this would come from database */}
        {mockUsers.map((user) => (
          <TouchableOpacity 
            key={user.id} 
            style={styles.userCard}
            onPress={() => handleViewUserDetails(user)}
          >
            <View style={styles.userCardHeader}>
              <View style={styles.userInfo}>
                <Text style={styles.userName}>{user.name}</Text>
                <Text style={styles.userEmail}>{user.email}</Text>
                <View style={styles.userTypeBadge}>
                  <Text style={styles.userTypeText}>
                    {user.userType === 'customer' ? '👤 Customer' : '🚗 Valeter'}
                  </Text>
                </View>
              </View>
              <View style={styles.userStatus}>
                <View style={[
                  styles.statusDot,
                  { backgroundColor: user.isEmailVerified ? '#10B981' : '#F59E0B' }
                ]} />
                <Text style={styles.statusText}>
                  {user.isEmailVerified ? 'Verified' : 'Pending'}
                </Text>
              </View>
            </View>
            
            <View style={styles.userCardActions}>
              <TouchableOpacity 
                style={styles.userActionSmall}
                onPress={() => handleViewUserProfile(user)}
              >
                <Text style={styles.userActionSmallText}>View Profile</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.userActionSmall}
                onPress={() => handleEditUser(user)}
              >
                <Text style={styles.userActionSmallText}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.userActionSmall, styles.suspendButton]}
                onPress={() => handleSuspendUser(user)}
              >
                <Text style={[styles.userActionSmallText, styles.suspendButtonText]}>Suspend</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.userActions}>
        <TouchableOpacity style={styles.userActionButton} onPress={handleManageUsers}>
          <Text style={styles.userActionIcon}>👤</Text>
          <Text style={styles.userActionText}>View All Users</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.userActionButton} onPress={() => Alert.alert('Send Notifications', 'Send notifications to all users or specific groups.')}>
          <Text style={styles.userActionIcon}>📧</Text>
          <Text style={styles.userActionText}>Send Notifications</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.userActionButton} onPress={handleViewDetailedAnalytics}>
          <Text style={styles.userActionIcon}>📊</Text>
          <Text style={styles.userActionText}>User Analytics</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.userActionButton} onPress={handleExportUserData}>
          <Text style={styles.userActionIcon}>📥</Text>
          <Text style={styles.userActionText}>Export Data</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );

  const renderRefundsTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>💸 Refund Requests</Text>
      
      {refundRequests.map((refund) => (
        <View key={refund.id} style={styles.refundCard}>
          <View style={styles.refundHeader}>
            <View style={styles.refundInfo}>
              <Text style={styles.refundCustomer}>{refund.customerName}</Text>
              <Text style={styles.refundJob}>Job: {refund.jobId}</Text>
              <Text style={styles.refundValeter}>Valeter: {refund.valeterName}</Text>
              <Text style={styles.refundService}>{refund.serviceType}</Text>
            </View>
            <View style={styles.refundAmount}>
              <Text style={styles.amountValue}>£{refund.amount.toFixed(2)}</Text>
              <View style={[
                styles.priorityBadge,
                { backgroundColor: refund.priority === 3 ? '#EF4444' : refund.priority === 2 ? '#F59E0B' : '#10B981' }
              ]}>
                <Text style={styles.priorityText}>Priority {refund.priority}</Text>
              </View>
            </View>
          </View>
          
          <Text style={styles.refundReason}>{refund.reason}</Text>
          <Text style={styles.refundDate}>Submitted: {refund.submittedDate}</Text>
          
          <View style={styles.refundActions}>
            <TouchableOpacity 
              style={styles.viewButton} 
              onPress={() => handleViewRefund(refund)}
            >
              <Text style={styles.viewButtonText}>View Details</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.approveButton} 
              onPress={() => handleApproveRefund(refund.id)}
            >
              <Text style={styles.approveButtonText}>Approve</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.rejectButton} 
              onPress={() => handleRejectRefund(refund.id)}
            >
              <Text style={styles.rejectButtonText}>Reject</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}
    </Animated.View>
  );

  const renderReportsTab = () => (
    <Animated.View style={[styles.tabContent, { opacity: fadeAnim }]}>
      <Text style={styles.sectionTitle}>🚨 System Reports</Text>
      
      {reports.map((report) => (
        <View key={report.id} style={styles.reportCard}>
          <View style={styles.reportHeader}>
            <View style={styles.reportInfo}>
              <Text style={styles.reportTitle}>{report.title}</Text>
              <Text style={styles.reportCategory}>{report.category.replace('_', ' ')}</Text>
              <Text style={styles.reportReporter}>By: {report.reportedBy}</Text>
            </View>
            <View style={styles.reportStatus}>
              <View style={[
                styles.statusBadge,
                { backgroundColor: report.status === 'open' ? '#EF4444' : report.status === 'investigating' ? '#F59E0B' : '#10B981' }
              ]}>
                <Text style={styles.statusText}>{report.status}</Text>
              </View>
              <View style={[
                styles.priorityBadge,
                { backgroundColor: report.priority === 3 ? '#EF4444' : report.priority === 2 ? '#F59E0B' : '#10B981' }
              ]}>
                <Text style={styles.priorityText}>P{report.priority}</Text>
              </View>
            </View>
          </View>
          
          <Text style={styles.reportDescription}>{report.description}</Text>
          <Text style={styles.reportDate}>Reported: {report.reportedDate}</Text>
          {report.assignedTo && (
            <Text style={styles.reportAssigned}>Assigned to: {report.assignedTo}</Text>
          )}
          
          <View style={styles.reportActions}>
            <TouchableOpacity 
              style={styles.viewButton} 
              onPress={() => handleViewReport(report)}
            >
              <Text style={styles.viewButtonText}>View Details</Text>
            </TouchableOpacity>
            {report.status === 'open' && (
              <TouchableOpacity 
                style={styles.assignButton} 
                onPress={() => handleAssignReport(report.id)}
              >
                <Text style={styles.assignButtonText}>Assign</Text>
              </TouchableOpacity>
            )}
            {report.status === 'investigating' && (
              <TouchableOpacity 
                style={styles.resolveButton} 
                onPress={() => handleResolveReport(report.id)}
              >
                <Text style={styles.resolveButtonText}>Resolve</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      ))}
    </Animated.View>
  );



  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <LinearGradient
          colors={['#1E3A8A', '#87CEEB']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.headerContent}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Founder Dashboard</Text>
          <View style={styles.headerRight}>
            <Text style={styles.adminBadge}>👑 Wish a Wash Founder</Text>
          </View>
        </View>
      </View>

      {/* Tab Content */}
      <View style={styles.contentContainer}>
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedTab === 'overview' && renderOverviewTab()}
          {selectedTab === 'applications' && renderApplicationsTab()}
          {selectedTab === 'financial' && renderFinancialTab()}
          {selectedTab === 'analytics' && renderAnalyticsTab()}
          {selectedTab === 'users' && renderUsersTab()}
          {selectedTab === 'refunds' && renderRefundsTab()}
          {selectedTab === 'reports' && renderReportsTab()}
        </ScrollView>
      </View>

      {/* Bottom Tab Navigation */}
      <View style={styles.bottomTabNavigation}>
        <TouchableOpacity 
          style={[styles.bottomTabButton, selectedTab === 'overview' && styles.activeBottomTabButton]} 
          onPress={() => setSelectedTab('overview')}
        >
          <Text style={styles.bottomTabIcon}>📊</Text>
          <Text style={[styles.bottomTabText, selectedTab === 'overview' && styles.activeBottomTabText]}>Overview</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.bottomTabButton, selectedTab === 'users' && styles.activeBottomTabButton]} 
          onPress={() => setSelectedTab('users')}
        >
          <Text style={styles.bottomTabIcon}>👥</Text>
          <Text style={[styles.bottomTabText, selectedTab === 'users' && styles.activeBottomTabText]}>Users</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.bottomTabButton, selectedTab === 'financial' && styles.activeBottomTabButton]} 
          onPress={() => setSelectedTab('financial')}
        >
          <Text style={styles.bottomTabIcon}>💰</Text>
          <Text style={[styles.bottomTabText, selectedTab === 'financial' && styles.activeBottomTabText]}>Financial</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.bottomTabButton, selectedTab === 'applications' && styles.activeBottomTabButton]} 
          onPress={() => setSelectedTab('applications')}
        >
          <Text style={styles.bottomTabIcon}>📋</Text>
          <Text style={[styles.bottomTabText, selectedTab === 'applications' && styles.activeBottomTabText]}>
            Apps {adminStats.pendingApplications > 0 && `(${adminStats.pendingApplications})`}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.bottomTabButton, selectedTab === 'refunds' && styles.activeBottomTabButton]} 
          onPress={() => setSelectedTab('refunds')}
        >
          <Text style={styles.bottomTabIcon}>💸</Text>
          <Text style={[styles.bottomTabText, selectedTab === 'refunds' && styles.activeBottomTabText]}>
            Refunds {refundRequests.filter(r => r.status === 'pending').length > 0 && `(${refundRequests.filter(r => r.status === 'pending').length})`}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Application Detail Modal */}
      <Modal
        visible={showApplicationModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Application Details</Text>
              <TouchableOpacity onPress={() => setShowApplicationModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            {selectedApplication && (
              <ScrollView style={styles.modalBody}>
                <Text style={styles.modalSectionTitle}>Personal Information</Text>
                <Text style={styles.modalText}>Name: {selectedApplication.name}</Text>
                <Text style={styles.modalText}>Email: {selectedApplication.email}</Text>
                <Text style={styles.modalText}>Phone: {selectedApplication.phone}</Text>
                <Text style={styles.modalText}>Experience: {selectedApplication.experience}</Text>
                <Text style={styles.modalText}>Vehicle: {selectedApplication.vehicleInfo}</Text>
                
                <Text style={styles.modalSectionTitle}>Documents</Text>
                {selectedApplication.documents.map((doc, index) => (
                  <Text key={index} style={styles.modalText}>• {doc}</Text>
                ))}
                
                <Text style={styles.modalSectionTitle}>Verification Status</Text>
                <Text style={styles.modalText}>
                  Insurance: {selectedApplication.insuranceStatus ? '✓ Verified' : '✗ Missing'}
                </Text>
                <Text style={styles.modalText}>
                  Background Check: {selectedApplication.backgroundCheck ? '✓ Passed' : '✗ Pending'}
                </Text>
              </ScrollView>
            )}
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.modalRejectButton} 
                onPress={() => selectedApplication && handleRejectApplication(selectedApplication.id)}
              >
                <Text style={styles.modalRejectButtonText}>Reject</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalApproveButton} 
                onPress={() => selectedApplication && handleApproveApplication(selectedApplication.id)}
              >
                <Text style={styles.modalApproveButtonText}>Approve</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Withdrawal Modal */}
      <Modal
        visible={showWithdrawalModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Process Withdrawal</Text>
              <TouchableOpacity onPress={() => setShowWithdrawalModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.modalBody}>
              <Text style={styles.modalText}>
                Available for withdrawal: £{financialData.pendingWithdrawals.toLocaleString()}
              </Text>
              <TextInput
                style={styles.withdrawalInput}
                placeholder="Enter amount"
                value={withdrawalAmount}
                onChangeText={setWithdrawalAmount}
                keyboardType="numeric"
                placeholderTextColor="#666"
              />
            </View>
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.modalCancelButton} 
                onPress={() => setShowWithdrawalModal(false)}
              >
                <Text style={styles.modalCancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalProcessButton} 
                onPress={handleProcessWithdrawal}
              >
                <Text style={styles.modalProcessButtonText}>Process</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Refund Detail Modal */}
      <Modal
        visible={showRefundModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Refund Details</Text>
              <TouchableOpacity onPress={() => setShowRefundModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            {selectedRefund && (
              <ScrollView style={styles.modalBody}>
                <Text style={styles.modalSectionTitle}>Customer Information</Text>
                <Text style={styles.modalText}>Name: {selectedRefund.customerName}</Text>
                <Text style={styles.modalText}>Email: {selectedRefund.customerEmail}</Text>
                
                <Text style={styles.modalSectionTitle}>Job Information</Text>
                <Text style={styles.modalText}>Job ID: {selectedRefund.jobId}</Text>
                <Text style={styles.modalText}>Valeter: {selectedRefund.valeterName}</Text>
                <Text style={styles.modalText}>Service: {selectedRefund.serviceType}</Text>
                <Text style={styles.modalText}>Amount: £{selectedRefund.amount.toFixed(2)}</Text>
                
                <Text style={styles.modalSectionTitle}>Refund Reason</Text>
                <Text style={styles.modalText}>{selectedRefund.reason}</Text>
                
                <Text style={styles.modalSectionTitle}>Priority</Text>
                <Text style={styles.modalText}>
                  Level {selectedRefund.priority} - {
                    selectedRefund.priority === 3 ? 'Critical' : 
                    selectedRefund.priority === 2 ? 'Medium' : 'Low'
                  }
                </Text>
                
                <Text style={styles.modalSectionTitle}>Status</Text>
                <Text style={styles.modalText}>Status: {selectedRefund.status}</Text>
                <Text style={styles.modalText}>Submitted: {selectedRefund.submittedDate}</Text>
              </ScrollView>
            )}
            
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.modalRejectButton} 
                onPress={() => selectedRefund && handleRejectRefund(selectedRefund.id)}
              >
                <Text style={styles.modalRejectButtonText}>Reject</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.modalApproveButton} 
                onPress={() => selectedRefund && handleApproveRefund(selectedRefund.id)}
              >
                <Text style={styles.modalApproveButtonText}>Approve</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Report Detail Modal */}
      <Modal
        visible={showReportModal}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Report Details</Text>
              <TouchableOpacity onPress={() => setShowReportModal(false)}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>
            
            {selectedReport && (
              <ScrollView style={styles.modalBody}>
                <Text style={styles.modalSectionTitle}>Report Information</Text>
                <Text style={styles.modalText}>Title: {selectedReport.title}</Text>
                <Text style={styles.modalText}>Category: {selectedReport.category.replace('_', ' ')}</Text>
                <Text style={styles.modalText}>Reported by: {selectedReport.reportedBy}</Text>
                
                <Text style={styles.modalSectionTitle}>Description</Text>
                <Text style={styles.modalText}>{selectedReport.description}</Text>
                
                <Text style={styles.modalSectionTitle}>Priority & Status</Text>
                <Text style={styles.modalText}>
                  Priority: Level {selectedReport.priority} - {
                    selectedReport.priority === 3 ? 'Critical' : 
                    selectedReport.priority === 2 ? 'Medium' : 'Low'
                  }
                </Text>
                <Text style={styles.modalText}>Status: {selectedReport.status}</Text>
                {selectedReport.assignedTo && (
                  <Text style={styles.modalText}>Assigned to: {selectedReport.assignedTo}</Text>
                )}
                {selectedReport.resolution && (
                  <Text style={styles.modalText}>Resolution: {selectedReport.resolution}</Text>
                )}
                
                <Text style={styles.modalSectionTitle}>Timeline</Text>
                <Text style={styles.modalText}>Reported: {selectedReport.reportedDate}</Text>
              </ScrollView>
            )}
            
            <View style={styles.modalActions}>
              {selectedReport && selectedReport.status === 'open' && (
                <TouchableOpacity 
                  style={styles.modalAssignButton} 
                  onPress={() => selectedReport && handleAssignReport(selectedReport.id)}
                >
                  <Text style={styles.modalAssignButtonText}>Assign</Text>
                </TouchableOpacity>
              )}
              {selectedReport && selectedReport.status === 'investigating' && (
                <TouchableOpacity 
                  style={styles.modalResolveButton} 
                  onPress={() => selectedReport && handleResolveReport(selectedReport.id)}
                >
                  <Text style={styles.modalResolveButtonText}>Resolve</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  headerRight: {
    alignItems: 'center',
  },
  adminBadge: {
    backgroundColor: 'rgba(255, 215, 0, 0.2)',
    color: '#FFD700',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    fontSize: 12,
    fontWeight: 'bold',
  },
  tabNavigation: {
    backgroundColor: '#1E3A8A',
    paddingVertical: 10,
  },
  tabButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginHorizontal: 5,
    borderRadius: 20,
  },
  activeTabButton: {
    backgroundColor: '#87CEEB',
  },
  tabButtonText: {
    color: '#B0E0E6',
    fontSize: 14,
    fontWeight: '600',
  },
  activeTabButtonText: {
    color: '#0A1929',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
  },
  tabContent: {
    padding: 20,
  },
  // Bottom Tab Navigation Styles
  bottomTabNavigation: {
    flexDirection: 'row',
    backgroundColor: '#0A1929',
    borderTopWidth: 1,
    borderTopColor: '#1E3A8A',
    paddingBottom: 10,
    paddingTop: 10,
  },
  bottomTabButton: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  activeBottomTabButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
    marginHorizontal: 4,
  },
  bottomTabIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  bottomTabText: {
    fontSize: 10,
    color: '#B0E0E6',
    textAlign: 'center',
    fontWeight: '500',
  },
  activeBottomTabText: {
    color: '#87CEEB',
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 20,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
    marginBottom: 30,
  },
  metricCard: {
    width: (width - 55) / 2,
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  metricLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    textAlign: 'center',
    marginBottom: 5,
  },
  metricGrowth: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '600',
  },
  ratingsSection: {
    marginBottom: 30,
  },
  ratingsCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  ratingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  ratingLabel: {
    fontSize: 16,
    color: '#B0E0E6',
  },
  ratingValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  quickActions: {
    marginBottom: 30,
  },
  actionButtons: {
    gap: 15,
  },
  actionButton: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
  },
  actionButtonIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  actionButtonText: {
    fontSize: 16,
    color: '#F9FAFB',
    fontWeight: '600',
    flex: 1,
  },
  actionButtonBadge: {
    backgroundColor: '#EF4444',
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  applicationCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  applicationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  applicationName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  applicationDate: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  applicationDetails: {
    marginBottom: 15,
  },
  applicationDetail: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 5,
  },
  documentStatus: {
    marginBottom: 15,
  },
  documentTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 5,
  },
  documentItem: {
    fontSize: 14,
    color: '#B0E0E6',
    marginLeft: 10,
  },
  verificationStatus: {
    marginBottom: 20,
  },
  statusItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  statusLabel: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  statusValue: {
    fontSize: 14,
    fontWeight: '600',
  },
  applicationActions: {
    flexDirection: 'row',
    gap: 10,
  },
  viewButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  viewButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  approveButton: {
    flex: 1,
    backgroundColor: '#10B981',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  approveButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  rejectButton: {
    flex: 1,
    backgroundColor: '#EF4444',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  rejectButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  financialSummary: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
    marginBottom: 30,
  },
  financialCard: {
    width: (width - 55) / 2,
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  financialValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  financialLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  withdrawalSection: {
    marginBottom: 30,
  },
  withdrawalCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  withdrawalText: {
    fontSize: 16,
    color: '#F9FAFB',
    marginBottom: 15,
    textAlign: 'center',
  },
  withdrawalButton: {
    backgroundColor: '#87CEEB',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 10,
  },
  withdrawalButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  topEarnersSection: {
    marginBottom: 30,
  },
  earnerCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  earnerRank: {
    width: 40,
    height: 40,
    backgroundColor: '#87CEEB',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  rankNumber: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  earnerInfo: {
    flex: 1,
  },
  earnerName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  earnerJobs: {
    fontSize: 14,
    color: '#B0E0E6',
  },
  earnerEarnings: {
    alignItems: 'flex-end',
  },
  earningsAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
  },
  earningsLabel: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  chartSection: {
    marginBottom: 30,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 15,
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 120,
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
  },
  chartBar: {
    alignItems: 'center',
    flex: 1,
  },
  bar: {
    width: 20,
    backgroundColor: '#87CEEB',
    borderRadius: 10,
    marginBottom: 5,
  },
  barLabel: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  performanceSection: {
    marginBottom: 30,
  },
  userStats: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 30,
  },
  userStatCard: {
    flex: 1,
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
  },
  userStatValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 5,
  },
  userStatLabel: {
    fontSize: 14,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  userActions: {
    gap: 15,
  },
  userActionButton: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  // User Management Styles
  userFilterSection: {
    marginBottom: 20,
  },
  filterTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 10,
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  filterButton: {
    flex: 1,
    backgroundColor: '#1E3A8A',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  activeFilterButton: {
    backgroundColor: '#87CEEB',
  },
  filterButtonText: {
    color: '#B0E0E6',
    fontSize: 14,
    fontWeight: '600',
  },
  activeFilterButtonText: {
    color: '#0A1929',
  },
  userListSection: {
    marginBottom: 30,
  },
  userListTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 15,
  },
  userCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  userCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 8,
  },
  userTypeBadge: {
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  userTypeText: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  userStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 5,
  },
  statusText: {
    fontSize: 12,
    color: '#B0E0E6',
  },
  userCardActions: {
    flexDirection: 'row',
    gap: 10,
  },
  userActionSmall: {
    flex: 1,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  userActionSmallText: {
    fontSize: 12,
    color: '#87CEEB',
    fontWeight: '600',
  },
  suspendButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  suspendButtonText: {
    color: '#EF4444',
  },
  userActionIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  userActionText: {
    fontSize: 16,
    color: '#F9FAFB',
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#0A1929',
    borderRadius: 20,
    width: width * 0.9,
    maxHeight: height * 0.8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
  },
  closeButton: {
    fontSize: 24,
    color: '#B0E0E6',
  },
  modalBody: {
    padding: 20,
  },
  modalSectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginTop: 15,
    marginBottom: 10,
  },
  modalText: {
    fontSize: 16,
    color: '#B0E0E6',
    marginBottom: 5,
  },
  // Refund styles
  refundCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  refundHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  refundInfo: {
    flex: 1,
  },
  refundCustomer: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 5,
  },
  refundJob: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 2,
  },
  refundValeter: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 2,
  },
  refundService: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  refundAmount: {
    alignItems: 'flex-end',
  },
  amountValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F59E0B',
    marginBottom: 5,
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  priorityText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  refundReason: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 10,
    fontStyle: 'italic',
  },
  refundDate: {
    fontSize: 12,
    color: '#87CEEB',
    marginBottom: 15,
  },
  refundActions: {
    flexDirection: 'row',
    gap: 10,
  },
  // Report styles
  reportCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  reportInfo: {
    flex: 1,
  },
  reportTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 5,
  },
  reportCategory: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 2,
    textTransform: 'capitalize',
  },
  reportReporter: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  reportStatus: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 5,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textTransform: 'capitalize',
  },
  reportDescription: {
    fontSize: 14,
    color: '#B0E0E6',
    marginBottom: 10,
  },
  reportDate: {
    fontSize: 12,
    color: '#87CEEB',
    marginBottom: 5,
  },
  reportAssigned: {
    fontSize: 12,
    color: '#F59E0B',
    marginBottom: 15,
  },
  reportActions: {
    flexDirection: 'row',
    gap: 10,
  },
  assignButton: {
    flex: 1,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  assignButtonText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '600',
  },
  resolveButton: {
    flex: 1,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignItems: 'center',
  },
  resolveButtonText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  // Modal action styles
  modalAssignButton: {
    flex: 1,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  modalAssignButtonText: {
    color: '#8B5CF6',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalResolveButton: {
    flex: 1,
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  modalResolveButtonText: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalActions: {
    flexDirection: 'row',
    padding: 20,
    gap: 15,
  },
  modalRejectButton: {
    flex: 1,
    backgroundColor: '#EF4444',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalRejectButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalApproveButton: {
    flex: 1,
    backgroundColor: '#10B981',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalApproveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalCancelButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalCancelButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalProcessButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalProcessButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  withdrawalInput: {
    backgroundColor: '#1E3A8A',
    borderRadius: 10,
    padding: 15,
    fontSize: 16,
    color: '#F9FAFB',
    marginTop: 10,
  },
});

