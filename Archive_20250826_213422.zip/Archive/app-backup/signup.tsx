import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';

export default function SignupScreen() {
  const { register } = useAuth();
  const [userType, setUserType] = useState<'driver' | 'owner'>('driver');

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    vehicleInfo: '',
    licensePlate: '',
  });

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const backgroundAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
      Animated.timing(backgroundAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
    ]).start();
  }, []);

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      password: '',
      vehicleInfo: '',
      licensePlate: '',
    });
    setIsLoading(false);
  };

  const updateFormData = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = () => {
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.phone || !formData.password) {
      Alert.alert('Error', 'Please fill in all required fields');
      return false;
    }
    const email = formData.email.trim().toLowerCase();
    if (!email.includes('@') || !/^\S+@\S+\.\S+$/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return false;
    }
    if (formData.phone.replace(/\D/g, '').length < 10) {
      Alert.alert('Error', 'Please enter a valid phone number');
      return false;
    }
    if (formData.password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    if (userType === 'driver' && (!formData.vehicleInfo || !formData.licensePlate)) {
      Alert.alert('Error', 'Please fill in vehicle information for valeters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    setError(null);

    try {
      const mappedUserType: 'customer' | 'valeter' = userType === 'driver' ? 'valeter' : 'customer';
      const email = formData.email.trim().toLowerCase();
      const phoneUK = `+44${formData.phone.replace(/\D/g, '').slice(0, 10)}`;

      // keep your backend flow
      const success = await register({
        email,
        password: formData.password,
        name: `${formData.firstName} ${formData.lastName}`.trim(),
        phone: phoneUK,
        userType: mappedUserType,
      } as any);

      if (success) {
        resetForm();
        Alert.alert(
          'Success!',
          'Account created successfully! Please check your email for verification.',
          [{ text: 'OK', onPress: () => router.replace('/login') }]
        );
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (e: any) {
      setError(e?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderSignupForm = () => (
    <View style={styles.formContainer}>
      <Text style={styles.formTitle}>Create Your Account</Text>
      <Text style={styles.formSubtitle}>Join Wish a Wash in seconds</Text>

      {/* Personal */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Personal Information</Text>

        <View style={styles.inputRow}>
          <View style={[styles.inputContainer, { flex: 1, marginRight: 10 }]}>
            <Text style={styles.inputLabel}>First Name</Text>
            <TextInput
              style={styles.input}
              placeholder="First name"
              placeholderTextColor="#87CEEB"
              value={formData.firstName}
              onChangeText={(v) => updateFormData('firstName', v)}
              autoCapitalize="words"
            />
          </View>

          <View style={[styles.inputContainer, { flex: 1, marginLeft: 10 }]}>
            <Text style={styles.inputLabel}>Last Name</Text>
            <TextInput
              style={styles.input}
              placeholder="Last name"
              placeholderTextColor="#87CEEB"
              value={formData.lastName}
              onChangeText={(v) => updateFormData('lastName', v)}
              autoCapitalize="words"
            />
          </View>
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="your@email.com"
            placeholderTextColor="#87CEEB"
            value={formData.email}
            onChangeText={(v) => updateFormData('email', v)}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Phone Number</Text>
          <View style={styles.phoneInputContainer}>
            <Text style={styles.countryCode}>+44</Text>
            <TextInput
              style={styles.phoneInput}
              placeholder="7XXX XXX XXX"
              placeholderTextColor="#87CEEB"
              value={formData.phone}
              onChangeText={(v) => {
                const cleaned = v.replace(/\D/g, '').slice(0, 10);
                updateFormData('phone', cleaned);
              }}
              keyboardType="phone-pad"
            />
          </View>
        </View>
      </View>

      {/* Security */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Security</Text>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Create a password (min 6 characters)"
            placeholderTextColor="#87CEEB"
            value={formData.password}
            onChangeText={(v) => updateFormData('password', v)}
            secureTextEntry
            autoCapitalize="none"
            autoCorrect={false}
          />
        </View>
      </View>

      {/* Driver-only */}
      {userType === 'driver' && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Information</Text>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>Vehicle Details</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Ford Transit 2022"
              placeholderTextColor="#87CEEB"
              value={formData.vehicleInfo}
              onChangeText={(v) => updateFormData('vehicleInfo', v)}
            />
          </View>

          <View style={styles.inputContainer}>
            <Text style={styles.inputLabel}>License Plate</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., WAW-2024"
              placeholderTextColor="#87CEEB"
              value={formData.licensePlate}
              onChangeText={(v) => updateFormData('licensePlate', v)}
              autoCapitalize="characters"
            />
          </View>
        </View>
      )}
    </View>
  );

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      {/* Background */}
      <Animated.View style={[styles.backgroundContainer, { opacity: backgroundAnim }]}>
        <View style={[styles.gradient, { backgroundColor: userType === 'driver' ? '#0A1929' : '#1E3A8A' }]}>
          <Animated.View style={[styles.floatingElement, styles.element1]} />
          <Animated.View style={[styles.floatingElement, styles.element2]} />
          <Animated.View style={[styles.floatingElement, styles.element3]} />
        </View>
      </Animated.View>

      {/* Header */}
      <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
        <View style={styles.headerTopRow}>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>

          {(formData.firstName || formData.lastName || formData.email || formData.phone || formData.password) && (
            <TouchableOpacity
              style={styles.startOverButton}
              onPress={() => {
                Alert.alert('Start Over', 'Clear all entered information?', [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Start Over', style: 'destructive', onPress: resetForm },
                ]);
              }}
            >
              <Text style={styles.startOverButtonText}>Start Over</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={styles.headerContent}>
          <Text style={styles.logo}>Waw</Text>
          <Text style={styles.subtitle}>Create Account</Text>
        </View>
      </Animated.View>

      {/* Toggle */}
      <Animated.View style={[styles.toggleContainer, { opacity: fadeAnim }]}>
        <TouchableOpacity
          style={[styles.toggleButton, userType === 'driver' && styles.activeToggle]}
          onPress={() => setUserType('driver')}
        >
          <Text style={[styles.toggleText, userType === 'driver' && styles.activeToggleText]}>🧽 Valeter</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.toggleButton, userType === 'owner' && styles.activeToggle]}
          onPress={() => setUserType('owner')}
        >
          <Text style={[styles.toggleText, userType === 'owner' && styles.activeToggleText]}>👤 Car Owner</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Content */}
      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <Animated.View style={[styles.contentContainer, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>
          {renderSignupForm()}

          {/* Terms */}
          <View style={styles.termsContainer}>
            <Text style={styles.termsText}>
              By creating an account, you agree to our <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
              <Text style={styles.termsLink}>Privacy Policy</Text>
            </Text>
          </View>

          {/* Error */}
          {error && (
            <View style={styles.errorContainer}>
              <Text style={styles.errorText}>⚠️ {error}</Text>
            </View>
          )}

          {/* Submit */}
          <TouchableOpacity
            style={[styles.primaryButton, isLoading && styles.primaryButtonDisabled]}
            onPress={handleSignup}
            disabled={isLoading}
          >
            <Text style={styles.primaryButtonText}>{isLoading ? 'Creating Account...' : 'Create Account'}</Text>
          </TouchableOpacity>

          {/* Login link */}
          <View style={styles.loginContainer}>
            <Text style={styles.loginText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => router.replace('/login')}>
              <Text style={styles.loginLink}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  backgroundContainer: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  gradient: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  floatingElement: { position: 'absolute', borderRadius: 50, opacity: 0.15 },
  element1: { width: 100, height: 100, top: '20%', left: '10%', backgroundColor: '#87CEEB' },
  element2: { width: 150, height: 150, top: '60%', right: '15%', backgroundColor: '#4682B4' },
  element3: { width: 80, height: 80, bottom: '20%', left: '20%', backgroundColor: '#00BFFF' },

  header: { paddingTop: 50, paddingHorizontal: 20, paddingBottom: 20 },
  headerTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  backButton: { paddingVertical: 6, paddingHorizontal: 8 },
  backButtonText: { color: '#87CEEB', fontSize: 16, fontWeight: '600' },
  startOverButton: { backgroundColor: 'rgba(255,59,48,0.1)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, borderWidth: 1, borderColor: '#FF3B30' },
  startOverButtonText: { color: '#FF3B30', fontSize: 14, fontWeight: '600' },
  headerContent: { alignItems: 'center', marginBottom: 20 },
  logo: { fontSize: 32, fontWeight: 'bold', color: '#87CEEB', marginBottom: 5 },
  subtitle: { fontSize: 18, color: '#B0E0E6', fontWeight: '500' },

  toggleContainer: { flexDirection: 'row', backgroundColor: 'rgba(135,206,235,0.1)', borderRadius: 25, padding: 4, marginHorizontal: 20, marginBottom: 20 },
  toggleButton: { flex: 1, paddingVertical: 12, paddingHorizontal: 20, borderRadius: 21, alignItems: 'center' },
  activeToggle: { backgroundColor: '#87CEEB' },
  toggleText: { fontSize: 16, color: '#87CEEB', fontWeight: '600' },
  activeToggleText: { color: '#0A1929' },

  scrollContainer: { flex: 1 },
  contentContainer: { paddingHorizontal: 20, paddingBottom: 40 },

  formContainer: { paddingHorizontal: 20 },
  formTitle: { fontSize: 28, fontWeight: 'bold', color: '#fff', textAlign: 'center', marginBottom: 8 },
  formSubtitle: { fontSize: 16, color: '#B0E0E6', textAlign: 'center', marginBottom: 30 },

  section: { marginBottom: 25 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', color: '#87CEEB', marginBottom: 15 },

  inputRow: { flexDirection: 'row', marginBottom: 15 },
  inputContainer: { marginBottom: 20 },
  inputLabel: { fontSize: 16, color: '#87CEEB', marginBottom: 8, fontWeight: '600' },
  input: { backgroundColor: 'rgba(135,206,235,0.1)', borderRadius: 12, paddingHorizontal: 16, paddingVertical: 15, fontSize: 16, color: '#fff', borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)' },

  phoneInputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(135,206,235,0.1)', borderRadius: 12, borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)', paddingHorizontal: 16, paddingVertical: 15 },
  countryCode: { fontSize: 16, color: '#87CEEB', fontWeight: '600', marginRight: 8 },
  phoneInput: { flex: 1, fontSize: 16, color: '#fff' },

  termsContainer: { marginTop: 20, padding: 15, backgroundColor: 'rgba(135,206,235,0.1)', borderRadius: 12 },
  termsText: { color: '#B0E0E6', fontSize: 14, lineHeight: 20, textAlign: 'center' },
  termsLink: { color: '#87CEEB', textDecorationLine: 'underline' },

  errorContainer: { backgroundColor: 'rgba(255,59,48,0.1)', borderWidth: 1, borderColor: '#FF3B30', borderRadius: 8, padding: 12, marginBottom: 15 },
  errorText: { color: '#FF3B30', fontSize: 14, textAlign: 'center', fontWeight: '500' },

  primaryButton: { flex: 1, backgroundColor: '#87CEEB', borderRadius: 12, paddingVertical: 16, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 8, elevation: 8 },
  primaryButtonDisabled: { opacity: 0.7 },
  primaryButtonText: { fontSize: 18, fontWeight: 'bold', color: '#0A1929' },

  loginContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 30 },
  loginText: { color: '#B0E0E6', fontSize: 16 },
  loginLink: { color: '#87CEEB', fontSize: 16, fontWeight: 'bold', textDecorationLine: 'underline' },
});