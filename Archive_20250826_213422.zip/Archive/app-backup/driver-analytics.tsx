import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';

export default function DriverAnalytics() {
      console.log('📍 Rendering driver anlytics');

  const { user } = useAuth();

  const analyticsData = {
    totalEarnings: 1250,
    totalJobs: 127,
    averageRating: 4.8,
    completedJobs: 125,
    cancelledJobs: 2,
    onlineHours: 156,
    monthlyEarnings: [180, 220, 195, 240, 210, 205],
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Analytics</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{analyticsData.totalEarnings}</Text>
              <Text style={styles.statLabel}>Total Earnings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.totalJobs}</Text>
              <Text style={styles.statLabel}>Total Jobs</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.averageRating}⭐</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{analyticsData.onlineHours}h</Text>
              <Text style={styles.statLabel}>Online Hours</Text>
            </View>
          </View>
        </View>

        {/* Job Breakdown */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Job Breakdown</Text>
          <View style={styles.jobCard}>
            <Text style={styles.jobTitle}>Completed Jobs</Text>
            <Text style={styles.jobValue}>{analyticsData.completedJobs}</Text>
          </View>
          <View style={styles.jobCard}>
            <Text style={styles.jobTitle}>Cancelled Jobs</Text>
            <Text style={styles.jobValue}>{analyticsData.cancelledJobs}</Text>
          </View>
          <View style={styles.jobCard}>
            <Text style={styles.jobTitle}>Success Rate</Text>
            <Text style={styles.jobValue}>
              {Math.round((analyticsData.completedJobs / analyticsData.totalJobs) * 100)}%
            </Text>
          </View>
        </View>

        {/* Monthly Earnings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Earnings</Text>
          <View style={styles.chartContainer}>
            {analyticsData.monthlyEarnings.map((amount, index) => (
              <View key={index} style={styles.barContainer}>
                <View style={[styles.bar, { height: (amount / 250) * 100 }]} />
                <Text style={styles.barLabel}>£{amount}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push('/driver-dashboard')}
          >
            <Text style={styles.actionButtonText}>🏠 Go Online</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => router.push('/driver-profile')}
          >
            <Text style={styles.actionButtonText}>👤 View Profile</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 50,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#87CEEB',
    textAlign: 'center',
  },
  jobCard: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobTitle: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  jobValue: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  chartContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 120,
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 12,
  },
  barContainer: {
    alignItems: 'center',
  },
  bar: {
    width: 20,
    backgroundColor: '#10B981',
    borderRadius: 10,
    marginBottom: 8,
  },
  barLabel: {
    color: '#F9FAFB',
    fontSize: 12,
  },
  actionButton: {
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
});
