import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  FlatList,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

interface Vehicle {
  id: string;
  make: string;
  model: string;
  year: string;
  registration: string;
  color: string;
  type: 'car' | 'van' | 'suv' | 'luxury' | 'bike' | 'motorcycle' | 'truck' | 'bus' | 'coach';
  size: 'small' | 'medium' | 'large' | 'extra_large';
  fuelType: 'petrol' | 'diesel' | 'electric' | 'hybrid' | 'lpg';
  transmission: 'manual' | 'automatic';
  mileage: string;
  lastService: string;
  insuranceExpiry: string;
  motExpiry: string;
  isDefault: boolean;
  photo?: string;
}

export default function VehicleManagement() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [selectedVehicleType, setSelectedVehicleType] = useState<Vehicle['type']>('car');
  const [selectedSize, setSelectedSize] = useState<Vehicle['size']>('medium');

  // Form state
  const [formData, setFormData] = useState({
    make: '',
    model: '',
    year: '',
    registration: '',
    color: '',
    fuelType: 'petrol' as Vehicle['fuelType'],
    transmission: 'manual' as Vehicle['transmission'],
    mileage: '',
    lastService: '',
    insuranceExpiry: '',
    motExpiry: '',
  });

  // Vehicle types with icons and descriptions
  const vehicleTypes = [
    { type: 'car', icon: '🚗', name: 'Car', description: 'Standard passenger vehicle' },
    { type: 'van', icon: '🚐', name: 'Van', description: 'Commercial van or minivan' },
    { type: 'suv', icon: '🚙', name: 'SUV', description: 'Sport utility vehicle' },
    { type: 'luxury', icon: '🏎️', name: 'Luxury', description: 'High-end luxury vehicle' },
    { type: 'bike', icon: '🚲', name: 'Bicycle', description: 'Standard bicycle' },
    { type: 'motorcycle', icon: '🏍️', name: 'Motorcycle', description: 'Motorcycle or scooter' },
    { type: 'truck', icon: '🚛', name: 'Truck', description: 'Commercial truck' },
    { type: 'bus', icon: '🚌', name: 'Bus', description: 'Passenger bus' },
    { type: 'coach', icon: '🚎', name: 'Coach', description: 'Large passenger coach' },
  ];

  // Vehicle sizes
  const vehicleSizes = [
    { size: 'small', name: 'Small', description: 'Compact vehicles' },
    { size: 'medium', name: 'Medium', description: 'Standard size vehicles' },
    { size: 'large', name: 'Large', description: 'Large vehicles' },
    { size: 'extra_large', name: 'Extra Large', description: 'Very large vehicles' },
  ];

  // Fuel types
  const fuelTypes = [
    { type: 'petrol', name: 'Petrol' },
    { type: 'diesel', name: 'Diesel' },
    { type: 'electric', name: 'Electric' },
    { type: 'hybrid', name: 'Hybrid' },
    { type: 'lpg', name: 'LPG' },
  ];

  // Transmission types
  const transmissionTypes = [
    { type: 'manual', name: 'Manual' },
    { type: 'automatic', name: 'Automatic' },
  ];

  useEffect(() => {
    // Load mock vehicles
    const mockVehicles: Vehicle[] = [
      {
        id: '1',
        make: 'Toyota',
        model: 'Camry',
        year: '2020',
        registration: 'AB12 CDE',
        color: 'Silver',
        type: 'car',
        size: 'medium',
        fuelType: 'petrol',
        transmission: 'automatic',
        mileage: '45,000',
        lastService: '2024-01-15',
        insuranceExpiry: '2024-12-31',
        motExpiry: '2024-06-30',
        isDefault: true,
      },
      {
        id: '2',
        make: 'BMW',
        model: 'X5',
        year: '2022',
        registration: 'XY34 FGH',
        color: 'Black',
        type: 'suv',
        size: 'large',
        fuelType: 'diesel',
        transmission: 'automatic',
        mileage: '18,000',
        lastService: '2024-02-01',
        insuranceExpiry: '2024-11-30',
        motExpiry: '2025-02-28',
        isDefault: false,
      },
    ];
    setVehicles(mockVehicles);
  }, []);

  const resetForm = () => {
    setFormData({
      make: '',
      model: '',
      year: '',
      registration: '',
      color: '',
      fuelType: 'petrol',
      transmission: 'manual',
      mileage: '',
      lastService: '',
      insuranceExpiry: '',
      motExpiry: '',
    });
    setSelectedVehicleType('car');
    setSelectedSize('medium');
  };

  const handleAddVehicle = async () => {
    if (!formData.make || !formData.model || !formData.registration) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'Please fill in all required fields (Make, Model, Registration)');
      return;
    }

    await hapticFeedback.impact('medium');

    const newVehicle: Vehicle = {
      id: Date.now().toString(),
      ...formData,
      type: selectedVehicleType,
      size: selectedSize,
      isDefault: vehicles.length === 0, // First vehicle is default
    };

    setVehicles(prev => [...prev, newVehicle]);
    setShowAddModal(false);
    resetForm();
    
    await hapticFeedback.notification('success');
    Alert.alert('Success', 'Vehicle added successfully!');
  };

  const handleEditVehicle = async (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      make: vehicle.make,
      model: vehicle.model,
      year: vehicle.year,
      registration: vehicle.registration,
      color: vehicle.color,
      fuelType: vehicle.fuelType,
      transmission: vehicle.transmission,
      mileage: vehicle.mileage,
      lastService: vehicle.lastService,
      insuranceExpiry: vehicle.insuranceExpiry,
      motExpiry: vehicle.motExpiry,
    });
    setSelectedVehicleType(vehicle.type);
    setSelectedSize(vehicle.size);
    setShowAddModal(true);
  };

  const handleUpdateVehicle = async () => {
    if (!editingVehicle) return;

    if (!formData.make || !formData.model || !formData.registration) {
      await hapticFeedback.notification('error');
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    await hapticFeedback.impact('medium');

    const updatedVehicle: Vehicle = {
      ...editingVehicle,
      ...formData,
      type: selectedVehicleType,
      size: selectedSize,
    };

    setVehicles(prev => prev.map(v => v.id === editingVehicle.id ? updatedVehicle : v));
    setShowAddModal(false);
    setEditingVehicle(null);
    resetForm();
    
    await hapticFeedback.notification('success');
    Alert.alert('Success', 'Vehicle updated successfully!');
  };

  const handleDeleteVehicle = async (vehicle: Vehicle) => {
    await hapticFeedback.impact('medium');
    
    Alert.alert(
      'Delete Vehicle',
      `Are you sure you want to delete ${vehicle.make} ${vehicle.model}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setVehicles(prev => prev.filter(v => v.id !== vehicle.id));
            hapticFeedback.notification('success');
          }
        }
      ]
    );
  };

  const handleSetDefault = async (vehicle: Vehicle) => {
    await hapticFeedback.impact('medium');
    
    setVehicles(prev => prev.map(v => ({
      ...v,
      isDefault: v.id === vehicle.id
    })));
    
    await hapticFeedback.notification('success');
    Alert.alert('Success', `${vehicle.make} ${vehicle.model} set as default vehicle`);
  };

  const renderVehicleCard = ({ item }: { item: Vehicle }) => (
    <View style={styles.vehicleCard}>
      <View style={styles.vehicleHeader}>
        <View style={styles.vehicleInfo}>
          <Text style={styles.vehicleTitle}>{item.make} {item.model}</Text>
          <Text style={styles.vehicleSubtitle}>{item.year} • {item.registration}</Text>
          <Text style={styles.vehicleDetails}>
            {item.color} • {item.fuelType} • {item.transmission}
          </Text>
        </View>
        <View style={styles.vehicleActions}>
          {item.isDefault && (
            <View style={styles.defaultBadge}>
              <Text style={styles.defaultBadgeText}>Default</Text>
            </View>
          )}
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleEditVehicle(item)}
          >
            <Text style={styles.actionButtonText}>✏️</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => handleDeleteVehicle(item)}
          >
            <Text style={styles.actionButtonText}>🗑️</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.vehicleStats}>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Mileage</Text>
          <Text style={styles.statValue}>{item.mileage} miles</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>Insurance</Text>
          <Text style={styles.statValue}>{item.insuranceExpiry}</Text>
        </View>
        <View style={styles.statItem}>
          <Text style={styles.statLabel}>MOT</Text>
          <Text style={styles.statValue}>{item.motExpiry}</Text>
        </View>
      </View>

      {!item.isDefault && (
        <TouchableOpacity
          style={styles.setDefaultButton}
          onPress={() => handleSetDefault(item)}
        >
          <Text style={styles.setDefaultButtonText}>Set as Default</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Vehicle Management</Text>
        <TouchableOpacity
          style={styles.addButton}
          onPress={() => {
            resetForm();
            setShowAddModal(true);
            hapticFeedback.selection();
          }}
        >
          <Text style={styles.addButtonText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView style={styles.content}>
        {vehicles.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateIcon}>🚗</Text>
            <Text style={styles.emptyStateTitle}>No Vehicles Added</Text>
            <Text style={styles.emptyStateText}>
              Add your first vehicle to get started with bookings
            </Text>
            <TouchableOpacity
              style={styles.addFirstButton}
              onPress={() => {
                resetForm();
                setShowAddModal(true);
                hapticFeedback.selection();
              }}
            >
              <Text style={styles.addFirstButtonText}>Add Your First Vehicle</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={vehicles}
            renderItem={renderVehicleCard}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            style={styles.vehicleList}
          />
        )}
      </ScrollView>

      {/* Add/Edit Vehicle Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => {
              setShowAddModal(false);
              setEditingVehicle(null);
              resetForm();
            }}>
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              {editingVehicle ? 'Edit Vehicle' : 'Add New Vehicle'}
            </Text>
            <TouchableOpacity
              onPress={editingVehicle ? handleUpdateVehicle : handleAddVehicle}
            >
              <Text style={styles.modalSaveText}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            {/* Vehicle Type Selection */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Vehicle Type</Text>
              <View style={styles.typeGrid}>
                {vehicleTypes.map((type) => (
                  <TouchableOpacity
                    key={type.type}
                    style={[
                      styles.typeOption,
                      selectedVehicleType === type.type && styles.selectedTypeOption
                    ]}
                    onPress={() => {
                      setSelectedVehicleType(type.type as Vehicle['type']);
                      hapticFeedback.selection();
                    }}
                  >
                    <Text style={styles.typeIcon}>{type.icon}</Text>
                    <Text style={styles.typeName}>{type.name}</Text>
                    <Text style={styles.typeDescription}>{type.description}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Vehicle Size Selection */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Vehicle Size</Text>
              <View style={styles.sizeGrid}>
                {vehicleSizes.map((size) => (
                  <TouchableOpacity
                    key={size.size}
                    style={[
                      styles.sizeOption,
                      selectedSize === size.size && styles.selectedSizeOption
                    ]}
                    onPress={() => {
                      setSelectedSize(size.size as Vehicle['size']);
                      hapticFeedback.selection();
                    }}
                  >
                    <Text style={styles.sizeName}>{size.name}</Text>
                    <Text style={styles.sizeDescription}>{size.description}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Basic Information */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Basic Information</Text>
              
              <View style={styles.inputRow}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Make *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.make}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, make: text }))}
                    placeholder="e.g., Toyota"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Model *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.model}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, model: text }))}
                    placeholder="e.g., Camry"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>
              </View>

              <View style={styles.inputRow}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Year</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.year}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, year: text }))}
                    placeholder="e.g., 2020"
                    placeholderTextColor="#9CA3AF"
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Registration *</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.registration}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, registration: text.toUpperCase() }))}
                    placeholder="e.g., AB12 CDE"
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="characters"
                  />
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Color</Text>
                <TextInput
                  style={styles.input}
                  value={formData.color}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, color: text }))}
                  placeholder="e.g., Silver"
                  placeholderTextColor="#9CA3AF"
                />
              </View>
            </View>

            {/* Technical Details */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Technical Details</Text>
              
              <View style={styles.inputRow}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Fuel Type</Text>
                  <View style={styles.pickerContainer}>
                    {fuelTypes.map((fuel) => (
                      <TouchableOpacity
                        key={fuel.type}
                        style={[
                          styles.pickerOption,
                          formData.fuelType === fuel.type && styles.selectedPickerOption
                        ]}
                        onPress={() => {
                          setFormData(prev => ({ ...prev, fuelType: fuel.type }));
                          hapticFeedback.selection();
                        }}
                      >
                        <Text style={styles.pickerOptionText}>{fuel.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </View>

              <View style={styles.inputRow}>
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Transmission</Text>
                  <View style={styles.pickerContainer}>
                    {transmissionTypes.map((trans) => (
                      <TouchableOpacity
                        key={trans.type}
                        style={[
                          styles.pickerOption,
                          formData.transmission === trans.type && styles.selectedPickerOption
                        ]}
                        onPress={() => {
                          setFormData(prev => ({ ...prev, transmission: trans.type }));
                          hapticFeedback.selection();
                        }}
                      >
                        <Text style={styles.pickerOptionText}>{trans.name}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Mileage</Text>
                <TextInput
                  style={styles.input}
                  value={formData.mileage}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, mileage: text }))}
                  placeholder="e.g., 45,000"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                />
              </View>
            </View>

            {/* Important Dates */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Important Dates</Text>
              
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Last Service Date</Text>
                <TextInput
                  style={styles.input}
                  value={formData.lastService}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, lastService: text }))}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="#9CA3AF"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Insurance Expiry</Text>
                <TextInput
                  style={styles.input}
                  value={formData.insuranceExpiry}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, insuranceExpiry: text }))}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="#9CA3AF"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>MOT Expiry</Text>
                <TextInput
                  style={styles.input}
                  value={formData.motExpiry}
                  onChangeText={(text) => setFormData(prev => ({ ...prev, motExpiry: text }))}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="#9CA3AF"
                />
              </View>
            </View>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyStateIcon: {
    fontSize: 60,
    marginBottom: 20,
  },
  emptyStateTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  emptyStateText: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 30,
  },
  addFirstButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  vehicleList: {
    flex: 1,
  },
  vehicleCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  vehicleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  vehicleSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  vehicleDetails: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  vehicleActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  defaultBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  defaultBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  actionButton: {
    padding: 8,
  },
  actionButtonText: {
    fontSize: 16,
  },
  vehicleStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  statItem: {
    alignItems: 'center',
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 2,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  setDefaultButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderWidth: 1,
    borderColor: '#87CEEB',
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: 'center',
  },
  setDefaultButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#1E3A8A',
  },
  modalCancelText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalSaveText: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: '600',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeOption: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedTypeOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  typeIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  typeName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  typeDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  sizeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  sizeOption: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedSizeOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  sizeName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  sizeDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1E3A8A',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  pickerContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  pickerOption: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedPickerOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  pickerOptionText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
});
