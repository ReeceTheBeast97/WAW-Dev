import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  SafeAreaView,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './auth-context';
import { simpleDocumentUploadService, UploadedDocument } from '../src/services/SimpleDocumentUploadService';

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  required: boolean;
  type: 'photo' | 'document' | 'pdf';
  icon: string;
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const requiredDocuments: RequiredDocument[] = [
    {
      id: 'profile_photo',
      name: 'Profile Photo',
      description: 'Clear face shot on plain background',
      required: true,
      type: 'photo',
      icon: '📸'
    },
    {
      id: 'driving_license',
      name: 'Driving License',
      description: 'Valid UK driving license',
      required: true,
      type: 'document',
      icon: '🚗'
    },
    {
      id: 'dbs_check',
      name: 'DBS Check',
      description: 'Enhanced DBS certificate',
      required: true,
      type: 'document',
      icon: '🛡️'
    },
    {
      id: 'public_liability',
      name: 'Public Liability Insurance',
      description: 'Minimum £2M coverage',
      required: true,
      type: 'document',
      icon: '📋'
    },
    {
      id: 'vehicle_insurance',
      name: 'Vehicle Insurance',
      description: 'Comprehensive vehicle insurance',
      required: true,
      type: 'document',
      icon: '🚙'
    },
    {
      id: 'vehicle_registration',
      name: 'Vehicle Registration',
      description: 'V5C registration document',
      required: true,
      type: 'document',
      icon: '📄'
    },
    {
      id: 'id_proof',
      name: 'ID Proof',
      description: 'Passport or national ID',
      required: true,
      type: 'document',
      icon: '🆔'
    }
  ];

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const userDocs = simpleDocumentUploadService.getUserDocuments(user?.id || 'default');
      setDocuments(userDocs);
    } catch (error) {
      console.error('Error loading documents:', error);
      Alert.alert('Error', 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const handleTakePhoto = async (documentType: RequiredDocument) => {
    try {
      setUploading(documentType.id);
      
      const document = await simpleDocumentUploadService.takePhoto(documentType.name);

      if (document) {
        // Add progress listener
        simpleDocumentUploadService.addProgressListener(document.id, (progress) => {
          console.log(`Upload progress for ${documentType.name}: ${progress.progress}%`);
        });

        // Upload the document
        await simpleDocumentUploadService.uploadDocument(document.id);
        
        // Reload documents
        await loadDocuments();
        
        Alert.alert('Success', `${documentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to take photo');
    } finally {
      setUploading(null);
    }
  };

  const handlePickDocument = async (documentType: RequiredDocument) => {
    try {
      setUploading(documentType.id);
      
      const document = await realDocumentUploadService.pickDocument({
        allowsEditing: false,
        quality: 0.8,
        mediaTypes: documentType.type === 'photo' 
          ? ImagePicker.MediaTypeOptions.Images 
          : ImagePicker.MediaTypeOptions.All,
      });

      if (document) {
        // Add progress listener
        realDocumentUploadService.addProgressListener(document.id, (progress) => {
          console.log(`Upload progress for ${documentType.name}: ${progress.progress}%`);
        });

        // Upload the document
        await realDocumentUploadService.uploadDocument(document.id);
        
        // Reload documents
        await loadDocuments();
        
        Alert.alert('Success', `${documentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to pick document');
    } finally {
      setUploading(null);
    }
  };

  const handleDeleteDocument = async (documentId: string) => {
    Alert.alert(
      'Delete Document',
      'Are you sure you want to delete this document?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await realDocumentUploadService.deleteDocument(documentId);
              await loadDocuments();
              Alert.alert('Success', 'Document deleted successfully');
            } catch (error) {
              console.error('Error deleting document:', error);
              Alert.alert('Error', 'Failed to delete document');
            }
          }
        }
      ]
    );
  };

  const getDocumentStatus = (documentType: RequiredDocument) => {
    const doc = documents.find(d => d.name.toLowerCase().includes(documentType.name.toLowerCase()));
    if (!doc) return 'missing';
    if (doc.verificationStatus === 'approved') return 'approved';
    if (doc.verificationStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return '#4CAF50';
      case 'rejected': return '#EF4444';
      case 'pending': return '#F59E0B';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved': return '✓ Approved';
      case 'rejected': return '✗ Rejected';
      case 'pending': return '⏳ Pending';
      default: return '📄 Missing';
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading documents...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Documents</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Document Verification</Text>
          <Text style={styles.summarySubtitle}>
            Upload all required documents to start accepting jobs
          </Text>
          
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { 
                    width: `${(documents.filter(d => d.verificationStatus === 'approved').length / requiredDocuments.length) * 100}%` 
                  }
                ]} 
              />
            </View>
            <Text style={styles.progressText}>
              {documents.filter(d => d.verificationStatus === 'approved').length} of {requiredDocuments.length} documents approved
            </Text>
          </View>
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          
          {requiredDocuments.map((docType) => {
            const status = getDocumentStatus(docType);
            const document = documents.find(d => d.name.toLowerCase().includes(docType.name.toLowerCase()));
            
            return (
              <View key={docType.id} style={styles.documentCard}>
                <View style={styles.documentHeader}>
                  <View style={styles.documentInfo}>
                    <Text style={styles.documentIcon}>{docType.icon}</Text>
                    <View style={styles.documentDetails}>
                      <Text style={styles.documentName}>{docType.name}</Text>
                      <Text style={styles.documentDescription}>{docType.description}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.statusContainer}>
                    <Text style={[styles.statusText, { color: getStatusColor(status) }]}>
                      {getStatusText(status)}
                    </Text>
                  </View>
                </View>

                {document && (
                  <View style={styles.uploadedDocument}>
                    <View style={styles.documentPreview}>
                      {document.type === 'photo' ? (
                        <Image source={{ uri: document.uri }} style={styles.previewImage} />
                      ) : (
                        <View style={styles.documentIcon}>
                          <Text style={styles.fileIcon}>📄</Text>
                        </View>
                      )}
                      <View style={styles.documentInfo}>
                        <Text style={styles.fileName}>{document.name}</Text>
                        <Text style={styles.fileSize}>
                          {realDocumentUploadService.formatFileSize(document.size)}
                        </Text>
                        <Text style={styles.uploadDate}>
                          {document.uploadDate.toLocaleDateString()}
                        </Text>
                      </View>
                    </View>
                    
                    <View style={styles.documentActions}>
                      <TouchableOpacity 
                        style={styles.actionButton}
                        onPress={() => handleDeleteDocument(document.id)}
                      >
                        <Text style={styles.actionButtonText}>Delete</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}

                {!document && (
                  <View style={styles.uploadActions}>
                    <TouchableOpacity 
                      style={[styles.uploadButton, { opacity: uploading === docType.id ? 0.6 : 1 }]}
                      onPress={() => handleTakePhoto(docType)}
                      disabled={uploading === docType.id}
                    >
                      {uploading === docType.id ? (
                        <ActivityIndicator size="small" color="#FFFFFF" />
                      ) : (
                        <Text style={styles.uploadButtonText}>📸 Take Photo</Text>
                      )}
                    </TouchableOpacity>
                    
                    <TouchableOpacity 
                      style={[styles.uploadButton, { opacity: uploading === docType.id ? 0.6 : 1 }]}
                      onPress={() => handlePickDocument(docType)}
                      disabled={uploading === docType.id}
                    >
                      {uploading === docType.id ? (
                        <ActivityIndicator size="small" color="#FFFFFF" />
                      ) : (
                        <Text style={styles.uploadButtonText}>📁 Choose File</Text>
                      )}
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            );
          })}
        </View>

        {/* Help Section */}
        <View style={styles.helpSection}>
          <Text style={styles.helpTitle}>Need Help?</Text>
          <Text style={styles.helpText}>
            If you're having trouble uploading documents or have questions about requirements, 
            contact our support team.
          </Text>
          
          <TouchableOpacity 
            style={styles.helpButton}
            onPress={() => router.push('/live-chat')}
          >
            <Text style={styles.helpButtonText}>Contact Support</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 16,
    marginTop: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  summaryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  summarySubtitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 16,
  },
  progressContainer: {
    marginTop: 12,
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 12,
    color: '#87CEEB',
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  documentCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  documentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  documentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  documentIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  documentDetails: {
    flex: 1,
  },
  documentName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  documentDescription: {
    fontSize: 12,
    color: '#87CEEB',
  },
  statusContainer: {
    alignItems: 'flex-end',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  uploadedDocument: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    paddingTop: 12,
  },
  documentPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  previewImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  fileIcon: {
    fontSize: 24,
  },
  fileName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  fileSize: {
    fontSize: 12,
    color: '#87CEEB',
    marginBottom: 2,
  },
  uploadDate: {
    fontSize: 12,
    color: '#6B7280',
  },
  documentActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  actionButton: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '500',
  },
  uploadActions: {
    flexDirection: 'row',
    gap: 12,
  },
  uploadButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  uploadButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '500',
  },
  helpSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
  },
  helpTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  helpText: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 16,
    lineHeight: 20,
  },
  helpButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  helpButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
});
