-- Supabase Schema for Wish-A-Wash

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types
CREATE TYPE user_role AS ENUM ('customer', 'valeter', 'admin');
CREATE TYPE job_status AS ENUM ('REQUESTED', 'ACCEPTED', 'EN_ROUTE', 'ARRIVED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'EXPIRED');

-- Profiles table with role-based access
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  role user_role NOT NULL DEFAULT 'customer',
  user_type TEXT NOT NULL CHECK (user_type IN ('customer', 'valeter')),
  is_email_verified BOOLEAN DEFAULT FALSE,
  rating NUMERIC DEFAULT 0,
  jobs_completed INTEGER DEFAULT 0,
  years_experience INTEGER DEFAULT 0,
  badges TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Valeter-specific fields
CREATE TABLE IF NOT EXISTS valeter_profiles (
  id UUID PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  is_verified BOOLEAN DEFAULT FALSE,
  documents_uploaded BOOLEAN DEFAULT FALSE,
  insurance_verified BOOLEAN DEFAULT FALSE,
  license_verified BOOLEAN DEFAULT FALSE,
  background_check_passed BOOLEAN DEFAULT FALSE,
  bio TEXT,
  experience TEXT,
  vehicle_info TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Services table
CREATE TABLE IF NOT EXISTS services (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  price INTEGER NOT NULL, -- pence
  duration_min INTEGER NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id BIGSERIAL PRIMARY KEY,
  customer_id UUID REFERENCES profiles(id) NOT NULL,
  valeter_id UUID REFERENCES profiles(id),
  service_id BIGINT REFERENCES services(id) NOT NULL,
  status job_status NOT NULL DEFAULT 'REQUESTED',
  pickup_lat DOUBLE PRECISION NOT NULL,
  pickup_lng DOUBLE PRECISION NOT NULL,
  pickup_address TEXT,
  eta_minutes INTEGER,
  total_amount INTEGER NOT NULL, -- pence
  commission_amount INTEGER DEFAULT 0, -- pence
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- GPS tracking table
CREATE TABLE IF NOT EXISTS locations (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) NOT NULL,
  job_id BIGINT REFERENCES jobs(id),
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  heading DOUBLE PRECISION,
  speed DOUBLE PRECISION,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT REFERENCES jobs(id) NOT NULL,
  sender_id UUID REFERENCES profiles(id) NOT NULL,
  receiver_id UUID REFERENCES profiles(id) NOT NULL,
  content TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Refund requests table (admin-only)
CREATE TABLE IF NOT EXISTS refund_requests (
  id BIGSERIAL PRIMARY KEY,
  job_id BIGINT REFERENCES jobs(id) NOT NULL,
  customer_id UUID REFERENCES profiles(id) NOT NULL,
  valeter_id UUID REFERENCES profiles(id) NOT NULL,
  amount INTEGER NOT NULL, -- pence
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  priority INTEGER NOT NULL DEFAULT 1 CHECK (priority IN (1, 2, 3)),
  admin_notes TEXT,
  processed_by UUID REFERENCES profiles(id),
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- System reports table (admin-only)
CREATE TABLE IF NOT EXISTS system_reports (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('fraud', 'service_quality', 'payment_issue', 'safety', 'technical', 'other')),
  priority INTEGER NOT NULL DEFAULT 1 CHECK (priority IN (1, 2, 3)),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'investigating', 'resolved', 'closed')),
  reported_by UUID REFERENCES profiles(id) NOT NULL,
  assigned_to UUID REFERENCES profiles(id),
  resolution TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Admin function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(uid UUID)
RETURNS BOOLEAN 
LANGUAGE SQL 
STABLE 
AS $$
  SELECT EXISTS(
    SELECT 1 FROM profiles 
    WHERE id = uid AND role = 'admin'
  );
$$;

-- Function to get current user ID
CREATE OR REPLACE FUNCTION auth.uid()
RETURNS UUID
LANGUAGE SQL
STABLE
AS $$
  SELECT COALESCE(
    NULLIF(current_setting('request.jwt.claims', true)::json->>'sub', ''),
    (NULLIF(current_setting('request.jwt.claims', true)::json->>'user_id', ''))::UUID
  );
$$;

-- RLS Policies

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE valeter_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE refund_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_reports ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" ON profiles
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update all profiles" ON profiles
  FOR UPDATE USING (is_admin(auth.uid()));

-- Valeter profiles policies
CREATE POLICY "Valeters can view their own profile" ON valeter_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Valeters can update their own profile" ON valeter_profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Admins can view all valeter profiles" ON valeter_profiles
  FOR SELECT USING (is_admin(auth.uid()));

CREATE POLICY "Admins can update all valeter profiles" ON valeter_profiles
  FOR UPDATE USING (is_admin(auth.uid()));

-- Services policies (read-only for all users)
CREATE POLICY "All users can view services" ON services
  FOR SELECT USING (true);

CREATE POLICY "Only admins can manage services" ON services
  FOR ALL USING (is_admin(auth.uid()));

-- Jobs policies
CREATE POLICY "Users can view their own jobs" ON jobs
  FOR SELECT USING (
    auth.uid() = customer_id OR 
    auth.uid() = valeter_id OR 
    is_admin(auth.uid())
  );

CREATE POLICY "Users can create jobs" ON jobs
  FOR INSERT WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Users can update their own jobs" ON jobs
  FOR UPDATE USING (
    auth.uid() = customer_id OR 
    auth.uid() = valeter_id OR 
    is_admin(auth.uid())
  );

-- Locations policies
CREATE POLICY "Users can view job-related locations" ON locations
  FOR SELECT USING (
    auth.uid() = user_id OR 
    EXISTS (
      SELECT 1 FROM jobs 
      WHERE jobs.id = locations.job_id 
      AND (jobs.customer_id = auth.uid() OR jobs.valeter_id = auth.uid())
    ) OR 
    is_admin(auth.uid())
  );

CREATE POLICY "Users can update their own location" ON locations
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own location" ON locations
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Messages policies
CREATE POLICY "Users can view job messages" ON messages
  FOR SELECT USING (
    auth.uid() = sender_id OR 
    auth.uid() = receiver_id OR 
    is_admin(auth.uid())
  );

CREATE POLICY "Users can send messages" ON messages
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- Admin-only tables policies
CREATE POLICY "Only admins can access refund requests" ON refund_requests
  FOR ALL USING (is_admin(auth.uid()));

CREATE POLICY "Only admins can access system reports" ON system_reports
  FOR ALL USING (is_admin(auth.uid()));

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_jobs_customer_id ON jobs(customer_id);
CREATE INDEX IF NOT EXISTS idx_jobs_valeter_id ON jobs(valeter_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_locations_user_id ON locations(user_id);
CREATE INDEX IF NOT EXISTS idx_locations_job_id ON locations(job_id);
CREATE INDEX IF NOT EXISTS idx_messages_job_id ON messages(job_id);
CREATE INDEX IF NOT EXISTS idx_refund_requests_status ON refund_requests(status);
CREATE INDEX IF NOT EXISTS idx_system_reports_status ON system_reports(status);

-- Insert default services
INSERT INTO services (name, description, price, duration_min) VALUES
('Basic Wash', 'Exterior wash and interior vacuum', 2500, 30),
('Premium Wash', 'Basic wash plus interior cleaning and tire shine', 3500, 45),
('Luxury Wash', 'Premium wash plus wax and full interior detail', 5000, 60),
('Express Wash', 'Quick exterior wash only', 1500, 15);

-- Insert admin users (replace with actual emails)
INSERT INTO profiles (id, email, name, phone, role, user_type, is_email_verified) VALUES
('00000000-0000-0000-0000-000000000001', 'reece@wishawash.com', 'Reece Dixon', '+44 7700 900000', 'admin', 'customer', true),
('00000000-0000-0000-0000-000000000002', 'charlie@wishawash.com', 'Charlie Blunden', '+44 7700 900002', 'admin', 'customer', true);

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_valeter_profiles_updated_at BEFORE UPDATE ON valeter_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_jobs_updated_at BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_reports_updated_at BEFORE UPDATE ON system_reports
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
