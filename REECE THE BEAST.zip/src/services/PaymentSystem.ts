export interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'apple_pay' | 'google_pay';
  name: string;
  last4?: string;
  brand?: string;
  isDefault: boolean;
  expiryDate?: string;
}

export interface Payment {
  id: string;
  jobId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  paymentMethodId: string;
  createdAt: Date;
  refundedAt?: Date;
  refundAmount?: number;
}

export interface RefundRequest {
  id: string;
  jobId: string;
  paymentId: string;
  reason: 'customer_cancelled' | 'valeter_cancelled' | 'service_issue' | 'technical_issue';
  amount: number;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  requestedAt: Date;
  processedAt?: Date;
  notes?: string;
}

export class PaymentSystem {
  private static instance: PaymentSystem;
  private payments: Map<string, Payment> = new Map();
  private refunds: Map<string, RefundRequest> = new Map();
  private userPaymentMethods: Map<string, PaymentMethod[]> = new Map();

  static getInstance(): PaymentSystem {
    if (!PaymentSystem.instance) {
      PaymentSystem.instance = new PaymentSystem();
    }
    return PaymentSystem.instance;
  }

  // Payment Methods Management
  getUserPaymentMethods(userId: string): PaymentMethod[] {
    if (!this.userPaymentMethods.has(userId)) {
      // Default payment methods for demo
      this.userPaymentMethods.set(userId, [
        {
          id: '1',
          type: 'card',
          name: 'Visa ending in 1234',
          last4: '1234',
          brand: 'Visa',
          isDefault: true,
          expiryDate: '12/25'
        },
        {
          id: '2',
          type: 'paypal',
          name: 'PayPal',
          isDefault: false
        },
        {
          id: '3',
          type: 'apple_pay',
          name: 'Apple Pay',
          isDefault: false
        }
      ]);
    }
    return this.userPaymentMethods.get(userId)!;
  }

  addPaymentMethod(userId: string, paymentMethod: Omit<PaymentMethod, 'id'>): string {
    const methods = this.getUserPaymentMethods(userId);
    const newMethod: PaymentMethod = {
      ...paymentMethod,
      id: Date.now().toString()
    };
    
    if (newMethod.isDefault) {
      methods.forEach(m => m.isDefault = false);
    }
    
    methods.push(newMethod);
    return newMethod.id;
  }

  removePaymentMethod(userId: string, methodId: string): boolean {
    const methods = this.getUserPaymentMethods(userId);
    const index = methods.findIndex(m => m.id === methodId);
    if (index === -1) return false;
    
    methods.splice(index, 1);
    return true;
  }

  setDefaultPaymentMethod(userId: string, methodId: string): boolean {
    const methods = this.getUserPaymentMethods(userId);
    const method = methods.find(m => m.id === methodId);
    if (!method) return false;
    
    methods.forEach(m => m.isDefault = false);
    method.isDefault = true;
    return true;
  }

  // Payment Processing
  processPayment(jobId: string, amount: number, paymentMethodId: string, userId: string): Payment {
    const payment: Payment = {
      id: Date.now().toString(),
      jobId,
      amount,
      currency: 'GBP',
      status: 'completed', // Simulated successful payment
      paymentMethodId,
      createdAt: new Date()
    };
    
    this.payments.set(payment.id, payment);
    return payment;
  }

  getPayment(paymentId: string): Payment | undefined {
    return this.payments.get(paymentId);
  }

  getPaymentByJobId(jobId: string): Payment | undefined {
    return Array.from(this.payments.values()).find(p => p.jobId === jobId);
  }

  // Refund System
  requestRefund(
    jobId: string, 
    paymentId: string, 
    reason: RefundRequest['reason'], 
    amount: number,
    notes?: string
  ): RefundRequest {
    const refund: RefundRequest = {
      id: Date.now().toString(),
      jobId,
      paymentId,
      reason,
      amount,
      status: 'pending',
      requestedAt: new Date(),
      notes
    };
    
    this.refunds.set(refund.id, refund);
    
    // Auto-approve refunds for demo (in real app, this would go through review)
    setTimeout(() => {
      this.approveRefund(refund.id);
    }, 2000);
    
    return refund;
  }

  approveRefund(refundId: string): boolean {
    const refund = this.refunds.get(refundId);
    if (!refund || refund.status !== 'pending') return false;
    
    refund.status = 'approved';
    refund.processedAt = new Date();
    
    // Process the actual refund
    setTimeout(() => {
      refund.status = 'completed';
      this.processRefund(refund);
    }, 1000);
    
    return true;
  }

  rejectRefund(refundId: string, reason?: string): boolean {
    const refund = this.refunds.get(refundId);
    if (!refund || refund.status !== 'pending') return false;
    
    refund.status = 'rejected';
    refund.processedAt = new Date();
    if (reason) refund.notes = reason;
    
    return true;
  }

  private processRefund(refund: RefundRequest): void {
    const payment = this.payments.get(refund.paymentId);
    if (!payment) return;
    
    payment.status = 'refunded';
    payment.refundedAt = new Date();
    payment.refundAmount = refund.amount;
  }

  getRefund(refundId: string): RefundRequest | undefined {
    return this.refunds.get(refundId);
  }

  getRefundsByJobId(jobId: string): RefundRequest[] {
    return Array.from(this.refunds.values()).filter(r => r.jobId === jobId);
  }

  // Cancellation and Refund Logic for Instant Booking
  cancelJobWithRefund(jobId: string, reason: RefundRequest['reason'], userId: string): {
    success: boolean;
    refund?: RefundRequest;
    message: string;
  } {
    const payment = this.getPaymentByJobId(jobId);
    if (!payment) {
      return {
        success: false,
        message: 'No payment found for this job'
      };
    }

    if (payment.status === 'refunded') {
      return {
        success: false,
        message: 'Payment has already been refunded'
      };
    }

    // Calculate refund amount based on cancellation time (instant booking system)
    const jobAge = Date.now() - payment.createdAt.getTime();
    const minutesSincePayment = jobAge / (1000 * 60);
    const hoursSincePayment = minutesSincePayment / 60;
    
    let refundAmount = payment.amount;
    let refundReason = reason;
    let refundMessage = '';
    
    if (minutesSincePayment <= 5) {
      // Within 5 minutes: Full refund (100%)
      refundAmount = payment.amount;
      refundMessage = 'Full refund - cancelled within 5 minutes';
    } else if (minutesSincePayment <= 15) {
      // Within 15 minutes: 90% refund
      refundAmount = payment.amount * 0.9;
      refundMessage = '90% refund - cancelled within 15 minutes';
    } else if (minutesSincePayment <= 30) {
      // Within 30 minutes: 75% refund
      refundAmount = payment.amount * 0.75;
      refundMessage = '75% refund - cancelled within 30 minutes';
    } else if (hoursSincePayment <= 1) {
      // Within 1 hour: 50% refund
      refundAmount = payment.amount * 0.5;
      refundMessage = '50% refund - cancelled within 1 hour';
    } else if (hoursSincePayment <= 2) {
      // Within 2 hours: 25% refund
      refundAmount = payment.amount * 0.25;
      refundMessage = '25% refund - cancelled within 2 hours';
    } else {
      // After 2 hours: No refund
      refundAmount = 0;
      refundMessage = 'No refund - cancelled after 2 hours';
    }

    if (refundAmount > 0) {
      const refund = this.requestRefund(jobId, payment.id, refundReason, refundAmount);
      
      return {
        success: true,
        refund,
        message: `${refundMessage}. Refund of £${refundAmount.toFixed(2)} will be processed within 24 hours.`
      };
    } else {
      return {
        success: false,
        message: 'No refund available - cancellation time exceeded'
      };
    }
  }

  // Security and Validation
  validatePaymentMethod(paymentMethod: Partial<PaymentMethod>): {
    valid: boolean;
    errors: string[];
  } {
    const errors: string[] = [];
    
    if (!paymentMethod.type) {
      errors.push('Payment method type is required');
    }
    
    if (!paymentMethod.name) {
      errors.push('Payment method name is required');
    }
    
    if (paymentMethod.type === 'card') {
      if (!paymentMethod.last4 || paymentMethod.last4.length !== 4) {
        errors.push('Card must have last 4 digits');
      }
      if (!paymentMethod.expiryDate) {
        errors.push('Card expiry date is required');
      }
    }
    
    return {
      valid: errors.length === 0,
      errors
    };
  }
}

export const paymentSystem = PaymentSystem.getInstance();
