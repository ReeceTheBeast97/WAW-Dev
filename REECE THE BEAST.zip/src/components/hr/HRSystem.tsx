import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
  SafeAreaView,
  Switch,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../app/enhanced-auth-context';

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string;
  position: string;
  salary: number;
  status: 'active' | 'inactive' | 'pending' | 'suspended';
  performance: number;
  joinDate: Date;
  documents: {
    idProof: boolean;
    insurance: boolean;
    license: boolean;
    backgroundCheck: boolean;
  };
  workSchedule: {
    monday: boolean;
    tuesday: boolean;
    wednesday: boolean;
    thursday: boolean;
    friday: boolean;
    saturday: boolean;
    sunday: boolean;
  };
  permissions: {
    canManageTeam: boolean;
    canViewPayroll: boolean;
    canApproveBookings: boolean;
    isAdmin: boolean;
  };
}

interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  period: string;
  baseSalary: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'pending' | 'paid' | 'processing';
  paidDate?: Date;
  hoursWorked: number;
  overtimeHours: number;
  commission: number;
}

interface Schedule {
  id: string;
  employeeId: string;
  employeeName: string;
  date: Date;
  startTime: string;
  endTime: string;
  status: 'scheduled' | 'completed' | 'absent' | 'late';
  notes?: string;
}

interface OrganizationRequest {
  id: string;
  valeterId: string;
  valeterName: string;
  valeterEmail: string;
  organizationId: string;
  organizationName: string;
  status: 'pending' | 'approved' | 'rejected';
  requestDate: Date;
  message?: string;
}

export default function HRSystem() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'employees' | 'payroll' | 'schedule' | 'requests'>('employees');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [organizationRequests, setOrganizationRequests] = useState<OrganizationRequest[]>([]);
  
  const [showAddEmployee, setShowAddEmployee] = useState(false);
  const [showPayrollModal, setShowPayrollModal] = useState(false);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showEmployeeDetails, setShowEmployeeDetails] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    salary: '',
    permissions: {
      canManageTeam: false,
      canViewPayroll: false,
      canApproveBookings: false,
      isAdmin: false,
    },
  });

  const [newSchedule, setNewSchedule] = useState({
    employeeId: '',
    date: new Date().toISOString().split('T')[0],
    startTime: '09:00',
    endTime: '17:00',
    notes: '',
  });

  useEffect(() => {
    loadMockData();
  }, []);

  const loadMockData = () => {
    const mockEmployees: Employee[] = [
      {
        id: '1',
        name: 'Mike Johnson',
        email: 'mike@company.com',
        phone: '+44 7700 900001',
        position: 'Senior Valeter',
        salary: 28000,
        status: 'active',
        performance: 4.8,
        joinDate: new Date('2023-01-15'),
        documents: {
          idProof: true,
          insurance: true,
          license: true,
          backgroundCheck: true,
        },
        workSchedule: {
          monday: true,
          tuesday: true,
          wednesday: true,
          thursday: true,
          friday: true,
          saturday: false,
          sunday: false,
        },
        permissions: {
          canManageTeam: true,
          canViewPayroll: false,
          canApproveBookings: true,
          isAdmin: false,
        },
      },
      {
        id: '2',
        name: 'Sarah Williams',
        email: 'sarah@company.com',
        phone: '+44 7700 900002',
        position: 'Valeter',
        salary: 24000,
        status: 'active',
        performance: 4.5,
        joinDate: new Date('2023-03-20'),
        documents: {
          idProof: true,
          insurance: true,
          license: true,
          backgroundCheck: true,
        },
        workSchedule: {
          monday: true,
          tuesday: true,
          wednesday: true,
          thursday: true,
          friday: true,
          saturday: true,
          sunday: false,
        },
        permissions: {
          canManageTeam: false,
          canViewPayroll: false,
          canApproveBookings: false,
          isAdmin: false,
        },
      },
      {
        id: '3',
        name: 'David Brown',
        email: 'david@company.com',
        phone: '+44 7700 900003',
        position: 'Junior Valeter',
        salary: 22000,
        status: 'pending',
        performance: 0,
        joinDate: new Date('2024-01-10'),
        documents: {
          idProof: true,
          insurance: false,
          license: true,
          backgroundCheck: false,
        },
        workSchedule: {
          monday: true,
          tuesday: true,
          wednesday: true,
          thursday: true,
          friday: true,
          saturday: false,
          sunday: false,
        },
        permissions: {
          canManageTeam: false,
          canViewPayroll: false,
          canApproveBookings: false,
          isAdmin: false,
        },
      },
    ];

    const mockPayroll: PayrollRecord[] = [
      {
        id: '1',
        employeeId: '1',
        employeeName: 'Mike Johnson',
        period: 'January 2024',
        baseSalary: 28000,
        bonuses: 2000,
        deductions: 1500,
        netPay: 28500,
        status: 'paid',
        paidDate: new Date('2024-01-31'),
        hoursWorked: 160,
        overtimeHours: 8,
        commission: 500,
      },
      {
        id: '2',
        employeeId: '2',
        employeeName: 'Sarah Williams',
        period: 'January 2024',
        baseSalary: 24000,
        bonuses: 1500,
        deductions: 1200,
        netPay: 24300,
        status: 'paid',
        paidDate: new Date('2024-01-31'),
        hoursWorked: 168,
        overtimeHours: 0,
        commission: 300,
      },
    ];

    const mockSchedules: Schedule[] = [
      {
        id: '1',
        employeeId: '1',
        employeeName: 'Mike Johnson',
        date: new Date('2024-01-15'),
        startTime: '09:00',
        endTime: '17:00',
        status: 'completed',
        notes: 'Completed 8 washes',
      },
      {
        id: '2',
        employeeId: '2',
        employeeName: 'Sarah Williams',
        date: new Date('2024-01-15'),
        startTime: '10:00',
        endTime: '18:00',
        status: 'completed',
        notes: 'Completed 6 washes',
      },
    ];

    const mockRequests: OrganizationRequest[] = [
      {
        id: '1',
        valeterId: 'val_123',
        valeterName: 'John Smith',
        valeterEmail: 'john.smith@email.com',
        organizationId: user?.id || 'org_1',
        organizationName: 'Professional Valeting Co.',
        status: 'pending',
        requestDate: new Date('2024-01-10'),
        message: 'I would like to join your organization as a valeter. I have 3 years of experience.',
      },
    ];

    setEmployees(mockEmployees);
    setPayrollRecords(mockPayroll);
    setSchedules(mockSchedules);
    setOrganizationRequests(mockRequests);
  };

  const handleAddEmployee = () => {
    if (!newEmployee.name || !newEmployee.email || !newEmployee.salary) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    const employee: Employee = {
      id: Date.now().toString(),
      name: newEmployee.name,
      email: newEmployee.email,
      phone: newEmployee.phone,
      position: newEmployee.position,
      salary: parseFloat(newEmployee.salary),
      status: 'pending',
      performance: 0,
      joinDate: new Date(),
      documents: {
        idProof: false,
        insurance: false,
        license: false,
        backgroundCheck: false,
      },
      workSchedule: {
        monday: true,
        tuesday: true,
        wednesday: true,
        thursday: true,
        friday: true,
        saturday: false,
        sunday: false,
      },
      permissions: newEmployee.permissions,
    };

    setEmployees([...employees, employee]);
    setNewEmployee({
      name: '',
      email: '',
      phone: '',
      position: '',
      salary: '',
      permissions: {
        canManageTeam: false,
        canViewPayroll: false,
        canApproveBookings: false,
        isAdmin: false,
      },
    });
    setShowAddEmployee(false);
    Alert.alert('Success', 'Employee added successfully');
  };

  const handleProcessPayroll = () => {
    Alert.alert('Payroll Processing', 'Payroll processing initiated. Employees will be notified.');
    setShowPayrollModal(false);
  };

  const handleApproveRequest = (requestId: string) => {
    setOrganizationRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: 'approved' as const }
          : req
      )
    );
    Alert.alert('Request Approved', 'The valeter has been approved to join your organization.');
  };

  const handleRejectRequest = (requestId: string) => {
    setOrganizationRequests(prev => 
      prev.map(req => 
        req.id === requestId 
          ? { ...req, status: 'rejected' as const }
          : req
      )
    );
    Alert.alert('Request Rejected', 'The valeter request has been rejected.');
  };

  const getTotalPayroll = () => {
    return payrollRecords.reduce((total, record) => total + record.netPay, 0);
  };

  const getActiveEmployees = () => {
    return employees.filter(emp => emp.status === 'active').length;
  };

  const getPendingEmployees = () => {
    return employees.filter(emp => emp.status === 'pending').length;
  };

  const getPendingRequests = () => {
    return organizationRequests.filter(req => req.status === 'pending').length;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return '#10B981';
      case 'pending': return '#F59E0B';
      case 'inactive': return '#6B7280';
      case 'suspended': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return '🟢 Active';
      case 'pending': return '🟡 Pending';
      case 'inactive': return '⚪ Inactive';
      case 'suspended': return '🔴 Suspended';
      default: return '⚪ Unknown';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>HR Management</Text>
        <Text style={styles.headerSubtitle}>Manage your team and operations</Text>
      </View>

      {/* Stats Overview */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{employees.length}</Text>
          <Text style={styles.statLabel}>Total Employees</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{getActiveEmployees()}</Text>
          <Text style={styles.statLabel}>Active</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{getPendingEmployees()}</Text>
          <Text style={styles.statLabel}>Pending</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>£{getTotalPayroll().toLocaleString()}</Text>
          <Text style={styles.statLabel}>Total Payroll</Text>
        </View>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'employees' && styles.activeTab]}
          onPress={() => setActiveTab('employees')}
        >
          <Text style={[styles.tabText, activeTab === 'employees' && styles.activeTabText]}>
            👥 Employees
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'payroll' && styles.activeTab]}
          onPress={() => setActiveTab('payroll')}
        >
          <Text style={[styles.tabText, activeTab === 'payroll' && styles.activeTabText]}>
            💰 Payroll
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'schedule' && styles.activeTab]}
          onPress={() => setActiveTab('schedule')}
        >
          <Text style={[styles.tabText, activeTab === 'schedule' && styles.activeTabText]}>
            📅 Schedule
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'requests' && styles.activeTab]}
          onPress={() => setActiveTab('requests')}
        >
          <Text style={[styles.tabText, activeTab === 'requests' && styles.activeTabText]}>
            📋 Requests {getPendingRequests() > 0 && `(${getPendingRequests()})`}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {activeTab === 'employees' && (
          <View style={styles.tabContent}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Team Members</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => setShowAddEmployee(true)}
              >
                <Text style={styles.addButtonText}>+ Add Employee</Text>
              </TouchableOpacity>
            </View>
            
            {employees.map((employee) => (
              <TouchableOpacity
                key={employee.id}
                style={[styles.employeeCard, { borderColor: getStatusColor(employee.status) }]}
                onPress={() => {
                  setSelectedEmployee(employee);
                  setShowEmployeeDetails(true);
                }}
              >
                <View style={styles.employeeHeader}>
                  <View style={styles.employeeInfo}>
                    <Text style={styles.employeeName}>{employee.name}</Text>
                    <Text style={styles.employeePosition}>{employee.position}</Text>
                    <Text style={styles.employeeEmail}>{employee.email}</Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: getStatusColor(employee.status) }]}>
                    <Text style={styles.statusText}>{getStatusText(employee.status)}</Text>
                  </View>
                </View>
                <View style={styles.employeeDetails}>
                  <Text style={styles.employeeSalary}>£{employee.salary.toLocaleString()}/year</Text>
                  <Text style={styles.employeePerformance}>⭐ {employee.performance}</Text>
                </View>
                <View style={styles.documentsStatus}>
                  <Text style={styles.documentsTitle}>Documents:</Text>
                  <View style={styles.documentChecks}>
                    <Text style={[styles.documentCheck, employee.documents.idProof && styles.documentComplete]}>
                      {employee.documents.idProof ? '✓' : '○'} ID
                    </Text>
                    <Text style={[styles.documentCheck, employee.documents.insurance && styles.documentComplete]}>
                      {employee.documents.insurance ? '✓' : '○'} Insurance
                    </Text>
                    <Text style={[styles.documentCheck, employee.documents.license && styles.documentComplete]}>
                      {employee.documents.license ? '✓' : '○'} License
                    </Text>
                    <Text style={[styles.documentCheck, employee.documents.backgroundCheck && styles.documentComplete]}>
                      {employee.documents.backgroundCheck ? '✓' : '○'} Background
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {activeTab === 'payroll' && (
          <View style={styles.tabContent}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Payroll Records</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => setShowPayrollModal(true)}
              >
                <Text style={styles.addButtonText}>Process Payroll</Text>
              </TouchableOpacity>
            </View>
            
            {payrollRecords.map((record) => (
              <View key={record.id} style={styles.payrollCard}>
                <View style={styles.payrollHeader}>
                  <Text style={styles.payrollEmployee}>{record.employeeName}</Text>
                  <Text style={styles.payrollPeriod}>{record.period}</Text>
                </View>
                <View style={styles.payrollDetails}>
                  <Text style={styles.payrollAmount}>£{record.netPay.toLocaleString()}</Text>
                  <Text style={styles.payrollStatus}>{record.status}</Text>
                </View>
                <View style={styles.payrollBreakdown}>
                  <Text style={styles.payrollBreakdownText}>
                    Base: £{record.baseSalary.toLocaleString()} | 
                    Bonus: £{record.bonuses.toLocaleString()} | 
                    Hours: {record.hoursWorked}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {activeTab === 'schedule' && (
          <View style={styles.tabContent}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Work Schedule</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => setShowScheduleModal(true)}
              >
                <Text style={styles.addButtonText}>+ Add Shift</Text>
              </TouchableOpacity>
            </View>
            
            {schedules.map((schedule) => (
              <View key={schedule.id} style={styles.scheduleCard}>
                <View style={styles.scheduleHeader}>
                  <Text style={styles.scheduleEmployee}>{schedule.employeeName}</Text>
                  <Text style={styles.scheduleDate}>
                    {schedule.date.toLocaleDateString()}
                  </Text>
                </View>
                <View style={styles.scheduleDetails}>
                  <Text style={styles.scheduleTime}>
                    {schedule.startTime} - {schedule.endTime}
                  </Text>
                  <Text style={styles.scheduleStatus}>{schedule.status}</Text>
                </View>
                {schedule.notes && (
                  <Text style={styles.scheduleNotes}>{schedule.notes}</Text>
                )}
              </View>
            ))}
          </View>
        )}

        {activeTab === 'requests' && (
          <View style={styles.tabContent}>
            <Text style={styles.sectionTitle}>Join Requests</Text>
            
            {organizationRequests.map((request) => (
              <View key={request.id} style={styles.requestCard}>
                <View style={styles.requestHeader}>
                  <Text style={styles.requestValeter}>{request.valeterName}</Text>
                  <Text style={styles.requestDate}>
                    {request.requestDate.toLocaleDateString()}
                  </Text>
                </View>
                <Text style={styles.requestEmail}>{request.valeterEmail}</Text>
                {request.message && (
                  <Text style={styles.requestMessage}>{request.message}</Text>
                )}
                <View style={styles.requestActions}>
                  {request.status === 'pending' && (
                    <>
                      <TouchableOpacity
                        style={[styles.requestButton, styles.approveButton]}
                        onPress={() => handleApproveRequest(request.id)}
                      >
                        <Text style={styles.approveButtonText}>✓ Approve</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.requestButton, styles.rejectButton]}
                        onPress={() => handleRejectRequest(request.id)}
                      >
                        <Text style={styles.rejectButtonText}>✗ Reject</Text>
                      </TouchableOpacity>
                    </>
                  )}
                  {request.status !== 'pending' && (
                    <Text style={[
                      styles.requestStatus,
                      { color: request.status === 'approved' ? '#10B981' : '#EF4444' }
                    ]}>
                      {request.status.toUpperCase()}
                    </Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Add Employee Modal */}
      <Modal
        visible={showAddEmployee}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
          
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Add New Employee</Text>
            <TouchableOpacity onPress={() => setShowAddEmployee(false)}>
              <Text style={styles.closeButton}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalContent}>
            <TextInput
              style={styles.input}
              placeholder="Full Name"
              placeholderTextColor="#87CEEB"
              value={newEmployee.name}
              onChangeText={(text) => setNewEmployee({...newEmployee, name: text})}
            />
            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor="#87CEEB"
              value={newEmployee.email}
              onChangeText={(text) => setNewEmployee({...newEmployee, email: text})}
              keyboardType="email-address"
            />
            <TextInput
              style={styles.input}
              placeholder="Phone"
              placeholderTextColor="#87CEEB"
              value={newEmployee.phone}
              onChangeText={(text) => setNewEmployee({...newEmployee, phone: text})}
              keyboardType="phone-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Position"
              placeholderTextColor="#87CEEB"
              value={newEmployee.position}
              onChangeText={(text) => setNewEmployee({...newEmployee, position: text})}
            />
            <TextInput
              style={styles.input}
              placeholder="Annual Salary (£)"
              placeholderTextColor="#87CEEB"
              value={newEmployee.salary}
              onChangeText={(text) => setNewEmployee({...newEmployee, salary: text})}
              keyboardType="numeric"
            />

            <Text style={styles.permissionsTitle}>Permissions:</Text>
            <View style={styles.permissionItem}>
              <Text style={styles.permissionText}>Can Manage Team</Text>
              <Switch
                value={newEmployee.permissions.canManageTeam}
                onValueChange={(value) => setNewEmployee({
                  ...newEmployee,
                  permissions: {...newEmployee.permissions, canManageTeam: value}
                })}
                trackColor={{ false: '#767577', true: '#87CEEB' }}
                thumbColor={newEmployee.permissions.canManageTeam ? '#0A1929' : '#f4f3f4'}
              />
            </View>
            <View style={styles.permissionItem}>
              <Text style={styles.permissionText}>Can View Payroll</Text>
              <Switch
                value={newEmployee.permissions.canViewPayroll}
                onValueChange={(value) => setNewEmployee({
                  ...newEmployee,
                  permissions: {...newEmployee.permissions, canViewPayroll: value}
                })}
                trackColor={{ false: '#767577', true: '#87CEEB' }}
                thumbColor={newEmployee.permissions.canViewPayroll ? '#0A1929' : '#f4f3f4'}
              />
            </View>
            <View style={styles.permissionItem}>
              <Text style={styles.permissionText}>Can Approve Bookings</Text>
              <Switch
                value={newEmployee.permissions.canApproveBookings}
                onValueChange={(value) => setNewEmployee({
                  ...newEmployee,
                  permissions: {...newEmployee.permissions, canApproveBookings: value}
                })}
                trackColor={{ false: '#767577', true: '#87CEEB' }}
                thumbColor={newEmployee.permissions.canApproveBookings ? '#0A1929' : '#f4f3f4'}
              />
            </View>
            <View style={styles.permissionItem}>
              <Text style={styles.permissionText}>Admin Access</Text>
              <Switch
                value={newEmployee.permissions.isAdmin}
                onValueChange={(value) => setNewEmployee({
                  ...newEmployee,
                  permissions: {...newEmployee.permissions, isAdmin: value}
                })}
                trackColor={{ false: '#767577', true: '#87CEEB' }}
                thumbColor={newEmployee.permissions.isAdmin ? '#0A1929' : '#f4f3f4'}
              />
            </View>

            <TouchableOpacity style={styles.submitButton} onPress={handleAddEmployee}>
              <Text style={styles.submitButtonText}>Add Employee</Text>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Employee Details Modal */}
      <Modal
        visible={showEmployeeDetails}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
          
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Employee Details</Text>
            <TouchableOpacity onPress={() => setShowEmployeeDetails(false)}>
              <Text style={styles.closeButton}>✕</Text>
            </TouchableOpacity>
          </View>

          {selectedEmployee && (
            <ScrollView style={styles.modalContent}>
              <View style={styles.employeeDetailCard}>
                <Text style={styles.employeeDetailName}>{selectedEmployee.name}</Text>
                <Text style={styles.employeeDetailPosition}>{selectedEmployee.position}</Text>
                <Text style={styles.employeeDetailEmail}>{selectedEmployee.email}</Text>
                <Text style={styles.employeeDetailPhone}>{selectedEmployee.phone}</Text>
                <Text style={styles.employeeDetailSalary}>£{selectedEmployee.salary.toLocaleString()}/year</Text>
                <Text style={styles.employeeDetailPerformance}>Performance: ⭐ {selectedEmployee.performance}</Text>
                <Text style={styles.employeeDetailJoinDate}>
                  Joined: {selectedEmployee.joinDate.toLocaleDateString()}
                </Text>
              </View>

              <View style={styles.employeeDetailSection}>
                <Text style={styles.sectionTitle}>Work Schedule</Text>
                <View style={styles.scheduleGrid}>
                  {Object.entries(selectedEmployee.workSchedule).map(([day, works]) => (
                    <View key={day} style={styles.scheduleDay}>
                      <Text style={styles.scheduleDayName}>{day.charAt(0).toUpperCase() + day.slice(1)}</Text>
                      <Text style={[styles.scheduleDayStatus, works && styles.scheduleDayActive]}>
                        {works ? '✓' : '✗'}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.employeeDetailSection}>
                <Text style={styles.sectionTitle}>Permissions</Text>
                <View style={styles.permissionsList}>
                  {Object.entries(selectedEmployee.permissions).map(([permission, hasPermission]) => (
                    <View key={permission} style={styles.permissionItem}>
                      <Text style={styles.permissionText}>
                        {permission.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </Text>
                      <Text style={[styles.permissionStatus, hasPermission && styles.permissionGranted]}>
                        {hasPermission ? '✓' : '✗'}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
            </ScrollView>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#87CEEB',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  statCard: {
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    padding: 15,
    width: '23%',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  statLabel: {
    fontSize: 14,
    color: '#87CEEB',
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    marginHorizontal: 20,
    marginBottom: 20,
    paddingVertical: 10,
  },
  tab: {
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  activeTab: {
    backgroundColor: '#87CEEB',
    borderRadius: 8,
  },
  tabText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  activeTabText: {
    color: '#0A1929',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  tabContent: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
  },
  addButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
    fontSize: 14,
  },
  employeeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  employeeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  employeeInfo: {
    flex: 1,
  },
  employeeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  employeePosition: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 2,
  },
  employeeEmail: {
    fontSize: 12,
    color: '#87CEEB',
  },
  statusBadge: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  statusText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  employeeDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  employeeSalary: {
    fontSize: 14,
    color: '#87CEEB',
  },
  employeePerformance: {
    fontSize: 14,
    color: '#87CEEB',
  },
  documentsStatus: {
    marginTop: 10,
  },
  documentsTitle: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  documentChecks: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 5,
  },
  documentCheck: {
    fontSize: 16,
    color: '#87CEEB',
  },
  documentComplete: {
    color: '#10B981',
  },
  payrollCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  payrollHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  payrollEmployee: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  payrollPeriod: {
    fontSize: 14,
    color: '#87CEEB',
  },
  payrollDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  payrollAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#10B981',
  },
  payrollStatus: {
    fontSize: 14,
    color: '#87CEEB',
  },
  payrollBreakdown: {
    marginTop: 5,
  },
  payrollBreakdownText: {
    fontSize: 14,
    color: '#87CEEB',
  },
  scheduleCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  scheduleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleEmployee: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  scheduleDate: {
    fontSize: 14,
    color: '#87CEEB',
  },
  scheduleDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  scheduleTime: {
    fontSize: 14,
    color: '#87CEEB',
  },
  scheduleStatus: {
    fontSize: 14,
    color: '#87CEEB',
  },
  scheduleNotes: {
    fontSize: 12,
    color: '#87CEEB',
    marginTop: 5,
  },
  requestCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  requestValeter: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  requestDate: {
    fontSize: 14,
    color: '#87CEEB',
  },
  requestEmail: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  requestMessage: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 10,
  },
  requestActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  requestButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 8,
    borderWidth: 1,
  },
  approveButton: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
    borderWidth: 1,
  },
  approveButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
    fontSize: 14,
  },
  rejectButton: {
    backgroundColor: '#EF4444',
    borderColor: '#EF4444',
    borderWidth: 1,
  },
  rejectButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
    fontSize: 14,
  },
  requestStatus: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  closeButton: {
    fontSize: 24,
    color: '#fff',
  },
  modalContent: {
    padding: 20,
  },
  input: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 15,
    marginBottom: 15,
    color: '#fff',
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  permissionsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  permissionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  permissionText: {
    fontSize: 14,
    color: '#87CEEB',
  },
  permissionStatus: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  permissionGranted: {
    color: '#10B981',
  },
  submitButton: {
    backgroundColor: '#87CEEB',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButtonText: {
    color: '#0A1929',
    fontWeight: 'bold',
    fontSize: 16,
  },
  employeeDetailCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  employeeDetailName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 5,
  },
  employeeDetailPosition: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 5,
  },
  employeeDetailEmail: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  employeeDetailPhone: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  employeeDetailSalary: {
    fontSize: 16,
    color: '#87CEEB',
    marginBottom: 5,
  },
  employeeDetailPerformance: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  employeeDetailJoinDate: {
    fontSize: 14,
    color: '#87CEEB',
  },
  employeeDetailSection: {
    marginBottom: 20,
  },
  scheduleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  scheduleDay: {
    alignItems: 'center',
    marginVertical: 5,
  },
  scheduleDayName: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 5,
  },
  scheduleDayStatus: {
    fontSize: 20,
  },
  scheduleDayActive: {
    color: '#10B981',
  },
  permissionsList: {
    // No specific styles for this, just a container for permission items
  },
});
