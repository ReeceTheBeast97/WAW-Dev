import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Animated, 
  Dimensions,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../app/enhanced-auth-context';
import ExpoMap from '../../../app/components/ExpoMap';
import AIChatComponent from '../chat/AIChatComponent';

const { width } = Dimensions.get('window');

interface Booking {
  id: string;
  serviceType: string;
  date: string;
  time: string;
  status: string;
  price: number;
  valeterName?: string;
  valeterRating?: number;
}

interface Stats {
  totalBookings: number;
  totalSpent: number;
  averageRating: number;
  completedServices: number;
}

export default function PowerfulDashboard() {
  const { user, logout } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
  });
  const [loading, setLoading] = useState(true);
  const [showChat, setShowChat] = useState(false);
  
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [200, 120],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    // Simulate loading real data
    setTimeout(() => {
      setBookings([
        {
          id: '1',
          serviceType: 'Full Valet',
          date: '2024-01-15',
          time: '14:00',
          status: 'completed',
          price: 45.00,
          valeterName: 'John Smith',
          valeterRating: 4.8,
        },
        {
          id: '2',
          serviceType: 'Interior Clean',
          date: '2024-01-20',
          time: '10:30',
          status: 'scheduled',
          price: 25.00,
        },
        {
          id: '3',
          serviceType: 'Express Wash',
          date: '2024-01-22',
          time: '09:00',
          status: 'in_progress',
          price: 15.00,
          valeterName: 'Sarah Wilson',
          valeterRating: 4.9,
        },
      ]);

      setStats({
        totalBookings: 12,
        totalSpent: 380.00,
        averageRating: 4.7,
        completedServices: 10,
      });

      setLoading(false);
    }, 1000);
  }, []);

  const handleQuickBook = async () => {
    router.push('/enhanced-booking');
  };

  const handleInstantWash = async () => {
    router.push('/instant-wash');
  };

  const handlePriorityWash = async () => {
    router.push('/priority-wash');
  };

  const handleViewProfile = () => {
    router.push('/owner-profile');
  };

  const handleViewAnalytics = () => {
    router.push('/detailed-stats');
  };

  const handleViewNetwork = () => {
    router.push('/car-owner-network');
  };

  const handleSystemMonitor = () => {
    router.push('/system-monitor');
  };

  const handleLogout = async () => {
    // Simple logout without confirmation for better UX
    try {
      await logout();
      router.replace('/');
    } catch (error) {
      console.log('Logout error:', error);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
          },
        ]}
      >
                  <LinearGradient
            colors={['#1E3A8A', '#87CEEB']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12 ? 'Good morning! 👋' : 
                 new Date().getHours() < 17 ? 'Good afternoon! 🌟' : 'Good evening! 🌙'}
              </Text>
              <Text style={styles.userName}>{user?.name || 'Customer'}</Text>
              <Text style={styles.subtitle}>Welcome to Wish a Wash</Text>
            </View>
            
            <View style={styles.headerActions}>
              <TouchableOpacity
                style={styles.profileButton}
                onPress={handleViewProfile}
              >
                <Text style={styles.profileIcon}>👤</Text>
              </TouchableOpacity>
            </View>
                    </View>
          
          <View style={styles.poweredByContainer}>
            <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
            <TouchableOpacity 
              style={styles.chatButton} 
              onPress={() => setShowChat(true)}
            >
              <Text style={styles.chatButtonText}>💬</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickActionCard} onPress={handleQuickBook}>
            <LinearGradient
              colors={['#6B7280', '#4B5563']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>📅</Text>
              <Text style={styles.quickActionTitle}>Book Service</Text>
              <Text style={styles.quickActionSubtitle}>Schedule a valet</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionCard} onPress={handleInstantWash}>
            <LinearGradient
              colors={['#10B981', '#059669']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>⚡</Text>
              <Text style={styles.quickActionTitle}>Instant Wash</Text>
              <Text style={styles.quickActionSubtitle}>15 min service</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.quickActionCard} onPress={handlePriorityWash}>
            <LinearGradient
              colors={['#000000', '#FFD700']}
              style={styles.quickActionGradient}
            >
              <Text style={styles.quickActionIcon}>🏆</Text>
              <Text style={styles.quickActionTitle}>Local Priority</Text>
              <Text style={styles.quickActionSubtitle}>Skip the queue</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Stats Cards */}
        <View style={styles.statsSection}>
          <Text style={styles.sectionTitle}>📊 Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.totalBookings}</Text>
              <Text style={styles.statLabel}>Total Bookings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{stats.totalSpent}</Text>
              <Text style={styles.statLabel}>Total Spent</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating}⭐</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.completedServices}</Text>
              <Text style={styles.statLabel}>Completed</Text>
            </View>
          </View>
        </View>

        {/* Live Map */}
        <View style={styles.mapSection}>
          <Text style={styles.sectionTitle}>📍 Follow Your Valeter</Text>
          <TouchableOpacity style={styles.mapContainer} onPress={() => router.push('/live-tracking')}>
            <ExpoMap
              valeterLocation={{
                latitude: 51.5074 + (Math.random() - 0.5) * 0.01,
                longitude: -0.1278 + (Math.random() - 0.5) * 0.01,
                address: 'Valeter Location'
              }}
              userLocation={{
                latitude: 51.5074 + 0.002,
                longitude: -0.1278 + 0.002,
                address: 'Your Location'
              }}
              showMap={true}
              isCustomerView={true}
            />

          </TouchableOpacity>
        </View>

        {/* Recent Bookings */}
        <View style={styles.bookingsSection}>
          <Text style={styles.sectionTitle}>📋 Recent Bookings</Text>
          {bookings.map((booking) => (
            <View key={booking.id} style={styles.bookingCard}>
              <View style={styles.bookingHeader}>
                <Text style={styles.bookingService}>{booking.serviceType}</Text>
                <View style={[
                  styles.bookingStatus,
                  { backgroundColor: booking.status === 'completed' ? '#10B981' : 
                    booking.status === 'in_progress' ? '#F59E0B' : '#6B7280' }
                ]}>
                  <Text style={styles.bookingStatusText}>{booking.status}</Text>
                </View>
              </View>
              <Text style={styles.bookingDetails}>
                {booking.date} at {booking.time} • £{booking.price}
              </Text>
              {booking.valeterName && (
                <Text style={styles.valeterInfo}>
                  Valeter: {booking.valeterName} {booking.valeterRating}⭐
                </Text>
              )}
            </View>
          ))}
        </View>

        {/* Quick Navigation */}
        <View style={styles.quickNav}>
          <TouchableOpacity style={styles.navButton} onPress={handleViewProfile}>
            <Text style={styles.navButtonIcon}>👤</Text>
            <Text style={styles.navButtonText}>Profile</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={handleViewAnalytics}>
            <Text style={styles.navButtonIcon}>📊</Text>
            <Text style={styles.navButtonText}>Analytics</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={handleViewNetwork}>
            <Text style={styles.navButtonIcon}>🌐</Text>
            <Text style={styles.navButtonText}>Network</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={handleSystemMonitor}>
            <Text style={styles.navButtonIcon}>🛡️</Text>
            <Text style={styles.navButtonText}>System</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.navButton} onPress={() => router.push('/admin-dashboard')}>
            <Text style={styles.navButtonIcon}>👑</Text>
            <Text style={styles.navButtonText}>Admin</Text>
          </TouchableOpacity>
        </View>

       </Animated.ScrollView>

      {/* AI Chat Modal */}
      <Modal
        visible={showChat}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        <AIChatComponent 
          userType="customer" 
          onClose={() => setShowChat(false)} 
        />
      </Modal>
     </SafeAreaView>
   );
}

const styles = StyleSheet.create({
          container: {
          flex: 1,
          backgroundColor: '#0A1929',
        },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A1929',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  headerContent: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  headerLeft: {
    flex: 1,
  },
  headerCenter: {
    flex: 2,
    alignItems: 'center',
  },
  headerActions: {
    flex: 1,
    alignItems: 'flex-end',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  greeting: {
    color: '#F9FAFB',
    fontSize: 18,
    marginBottom: 4,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  subtitle: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileIcon: {
    fontSize: 20,
  },
  poweredByContainer: {
    alignItems: 'flex-end',
    marginTop: 8,
  },
  poweredByText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 10,
    fontWeight: '400',
  },
  chatButton: {
    position: 'absolute',
    right: 0,
    top: -5,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  chatButtonText: {
    fontSize: 16,
    color: '#0A1929',
  },
  scrollView: {
    flex: 1,
    paddingTop: 200,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 24,
  },
  quickActionCard: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  quickActionGradient: {
    padding: 20,
    alignItems: 'center',
  },
  quickActionIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  quickActionTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  quickActionSubtitle: {
    color: '#FFFFFF',
    fontSize: 12,
    opacity: 0.9,
  },
  statsSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: (width - 52) / 2,
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#87CEEB',
    textAlign: 'center',
  },
  mapSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  mapPlaceholder: {
    backgroundColor: '#1E3A8A',
    padding: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 200,
  },
  mapPlaceholderText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 8,
  },
  mapPlaceholderSubtext: {
    fontSize: 14,
    color: '#87CEEB',
    textAlign: 'center',
  },
  mapContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    marginBottom: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    height: 300,
    position: 'relative',
  },
  mapOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(10, 25, 41, 0.9)',
    padding: 10,
    alignItems: 'center',
  },
  mapOverlayText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  bookingsSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  bookingCard: {
    backgroundColor: '#1E3A8A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  bookingService: {
    fontSize: 16,
    fontWeight: '600',
    color: '#F9FAFB',
  },
  bookingStatus: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  bookingStatusText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  bookingDetails: {
    fontSize: 14,
    color: '#87CEEB',
    marginBottom: 4,
  },
  valeterInfo: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  quickNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#1E3A8A',
    marginHorizontal: 20,
    marginTop: 20,
    borderRadius: 16,
  },
  navButton: {
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  navButtonIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  navButtonText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '500',
  },
  logoutSection: {
    alignItems: 'center',
    paddingVertical: 20,
  },
  logoutButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#EF4444',
    borderWidth: 3,
    borderColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  logoutIcon: {
    fontSize: 24,
  },
});
