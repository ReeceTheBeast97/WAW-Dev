import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { organizationVerificationService } from '../src/services/OrganizationVerificationService';

export interface Organization {
  id: string;
  name: string;
  registrationNumber: string;
  address: string;
  contactEmail: string;
  contactPhone: string;
  isVerified: boolean;
  insuranceVerified: boolean;
  licenseVerified: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  userType: 'customer' | 'valeter' | 'organization';
  organizationId?: string;
  organizationType?: 'independent' | 'registered';
  profilePicture?: string;
  isVerified: boolean;
  verificationType: 'none' | 'profile' | 'car';
  totalWashes: number;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  tierPoints: number;
  joinDate: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: Omit<User, 'id' | 'isEmailVerified' | 'createdAt' | 'updatedAt'> & { 
    password: string;
    isIndividualValeter?: boolean;
    organizationId?: string;
  }) => Promise<boolean>;
  updateUser: (updates: Partial<User>) => Promise<void>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  updateProfile: (updates: Partial<User>) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  autoLoginCustomer: () => Promise<void>;
  autoLoginValeter: () => Promise<void>;
  hasAdminAccess: () => boolean;
  isBusinessOwner: () => boolean;
  markWelcomeSeen: (userType: 'customer' | 'valeter') => Promise<void>;
  hasSeenWelcome: (userType: 'customer' | 'valeter') => Promise<boolean>;
  
  // Organization specific methods
  isIndividualValeter: () => boolean;
  isOrganizationValeter: () => boolean;
  requiresIndividualDocuments: () => boolean;
  requiresOrganizationDocuments: () => boolean;
  getOrganization: () => Organization | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock organizations database
const mockOrganizations: Organization[] = [
  {
    id: 'org_1',
    name: 'Elite Valet Services Ltd',
    registrationNumber: 'ELITE001',
    address: '123 Business Street, London, UK',
    contactEmail: 'contact@elitevalet.com',
    contactPhone: '+44 7700 900100',
    isVerified: true,
    insuranceVerified: true,
    licenseVerified: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'org_2',
    name: 'Premium Car Care Ltd',
    registrationNumber: 'PREMIUM002',
    address: '456 Service Avenue, Manchester, UK',
    contactEmail: 'info@premiumcarcare.com',
    contactPhone: '+44 7700 900200',
    isVerified: true,
    insuranceVerified: true,
    licenseVerified: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'org_3',
    name: 'Quick Clean Pro Ltd',
    registrationNumber: 'QUICK003',
    address: '789 Wash Lane, Birmingham, UK',
    contactEmail: 'hello@quickcleanpro.com',
    contactPhone: '+44 7700 900300',
    isVerified: false,
    insuranceVerified: false,
    licenseVerified: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

// Mock user database with organization support
const mockUsers: User[] = [
  {
    id: 'customer_1',
    email: 'customer@test.com',
    name: 'John Customer',
    phone: '+44 7700 900001',
    userType: 'customer',
    isVerified: true,
    verificationType: 'none',
    totalWashes: 0,
    tier: 'bronze',
    tierPoints: 0,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'valeter_individual_1',
    email: 'individual@valeter.com',
    name: 'Mike Individual',
    phone: '+44 7700 900123',
    userType: 'valeter',
    isVerified: true,
    verificationType: 'profile',
    totalWashes: 10,
    tier: 'silver',
    tierPoints: 100,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'valeter_org_1',
    email: 'org@valeter.com',
    name: 'Sarah Organization',
    phone: '+44 7700 900456',
    userType: 'valeter',
    isVerified: true,
    verificationType: 'car',
    totalWashes: 50,
    tier: 'gold',
    tierPoints: 500,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'valeter_org_2',
    email: 'premium@valeter.com',
    name: 'David Premium',
    phone: '+44 7700 900789',
    userType: 'valeter',
    isVerified: true,
    verificationType: 'profile',
    totalWashes: 100,
    tier: 'platinum',
    tierPoints: 1000,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    id: 'valeter_org_3',
    email: 'quick@valeter.com',
    name: 'Lisa Quick',
    phone: '+44 7700 900012',
    userType: 'valeter',
    isVerified: false,
    verificationType: 'none',
    totalWashes: 0,
    tier: 'bronze',
    tierPoints: 0,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },

  // Sample Organization user
  {
    id: 'org_1',
    email: 'admin@elitevalet.com',
    name: 'Elite Valet Services Ltd',
    phone: '+44 7700 900100',
    userType: 'organization',
    isVerified: false,
    verificationType: 'none',
    totalWashes: 0,
    tier: 'bronze',
    tierPoints: 0,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  // Special admin access users
  {
    id: 'admin_user_1',
    email: 'admin@wishawash.com',
    name: 'Admin User',
    phone: '+44 7700 900000',
    userType: 'customer',
    isVerified: true,
    verificationType: 'none',
    totalWashes: 0,
    tier: 'bronze',
    tierPoints: 0,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  // Business owner test account
  {
    id: 'business_owner_1',
    email: 'business@elitevalet.com',
    name: 'Elite Valet Services Ltd',
    phone: '+44 7700 900003',
    userType: 'customer',
    isVerified: true,
    verificationType: 'none',
    totalWashes: 0,
    tier: 'bronze',
    tierPoints: 0,
    joinDate: new Date().toISOString(),
    createdAt: new Date(),
    updatedAt: new Date(),
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const checkStoredUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem('user_session');
        if (storedUser) {
          const userData = JSON.parse(storedUser);
          setUser(userData);
        }
      } catch (error) {
        console.error('Error checking stored user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    checkStoredUser();
  }, []);

  const login = async (email: string, _password: string): Promise<boolean> => {
    setIsLoading(true);
    
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Find user in mock database
      const foundUser = mockUsers.find(u => u.email === email);
      
      if (foundUser) {
        // In real app, verify password here
        // For now, we ignore the password parameter in mock implementation
        await AsyncStorage.setItem('user_session', JSON.stringify(foundUser));
        setUser(foundUser);
        return true;
      } else {
        return false;
      }
    } catch (error: any) {
      console.error('Login error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    console.log('Logout: Starting logout process...');
    console.log('Logout: Current user before logout:', user);
    
    try {
      await AsyncStorage.removeItem('user_session');
      console.log('Logout: AsyncStorage cleared successfully');
      setUser(null);
      console.log('Logout: User state set to null');
      console.log('Logout: Logout process completed successfully');
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  };

  const register = async (userData: any): Promise<boolean> => {
    try {
      // Create new user based on type
      const newUser: User = {
        id: `${userData.userType}_${Date.now()}`,
        name: userData.name,
        email: userData.email,
        phone: userData.phone || '',
        userType: userData.userType,
        isVerified: false,
        verificationType: 'none',
        totalWashes: 0,
        tier: 'bronze',
        tierPoints: 0,
        joinDate: new Date().toISOString(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Add to mock users array
      mockUsers.push(newUser);

      // If organization, create organization record
      if (userData.userType === 'organization') {
        // Create organization in the verification service
        await organizationVerificationService.createOrganization({
          name: userData.name,
          email: userData.email,
          phone: userData.phone || '',
          address: '',
          businessType: 'valeting',
        });
      }

      console.log('Registration successful for:', userData.userType);
      return true;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const updateUser = async (updates: Partial<User>): Promise<void> => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      await AsyncStorage.setItem('user_session', JSON.stringify(updatedUser));
    }
  };

  const updatePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
    // Mock password update
  };

  const updateProfile = async (updates: Partial<User>): Promise<void> => {
    await updateUser(updates);
  };

  const resetPassword = async (email: string): Promise<void> => {
    // Mock password reset
  };

  const autoLoginCustomer = async (): Promise<void> => {
    const customer = mockUsers.find(u => u.email === 'customer@test.com');
    if (customer) {
      await AsyncStorage.setItem('user_session', JSON.stringify(customer));
      setUser(customer);
    }
  };

  const autoLoginValeter = async (): Promise<void> => {
    console.log('Auto-login: Starting valeter auto-login...');
    // Use a more complete valeter account for better testing
    const valeter = mockUsers.find(u => u.email === 'org@valeter.com');
    if (valeter) {
      console.log('Auto-login: Found valeter account:', valeter.name);
      await AsyncStorage.setItem('user_session', JSON.stringify(valeter));
      setUser(valeter);
      console.log('Auto-login: Valeter auto-login completed successfully');
    } else {
      console.log('Auto-login: No valeter account found');
    }
  };



  const hasAdminAccess = (): boolean => {
    return user?.email === 'admin@wishawash.com';
  };

  const isBusinessOwner = (): boolean => {
    return user?.userType === 'valeter' && !user?.isIndividualValeter;
  };



  const markWelcomeSeen = async (userType: 'customer' | 'valeter'): Promise<void> => {
    await AsyncStorage.setItem('welcome_seen', 'true');
  };

  const hasSeenWelcome = async (userType: 'customer' | 'valeter'): Promise<boolean> => {
    const seen = await AsyncStorage.getItem('welcome_seen');
    return seen === 'true';
  };

  // Organization specific methods
  const isIndividualValeter = (): boolean => {
    return user?.userType === 'valeter' && user?.isIndividualValeter === true;
  };

  const isOrganizationValeter = (): boolean => {
    return user?.userType === 'valeter' && user?.isIndividualValeter === false;
  };

  const requiresIndividualDocuments = (): boolean => {
    return isIndividualValeter() && (
      !user?.individualLicenseVerified || 
      !user?.individualInsuranceVerified || 
      !user?.individualDocumentsUploaded
    );
  };

  const requiresOrganizationDocuments = (): boolean => {
    return isOrganizationValeter() && user?.organization && (
      !user.organization.isVerified || 
      !user.organization.insuranceVerified || 
      !user.organization.licenseVerified
    );
  };

  const getOrganization = (): Organization | null => {
    return user?.organization || null;
  };

  const value: AuthContextType = {
    user,
    isLoading,
    login,
    logout,
    register,
    updateUser,
    updatePassword,
    updateProfile,
    resetPassword,
    autoLoginCustomer,
    autoLoginValeter,
    hasAdminAccess,
    isBusinessOwner,
    markWelcomeSeen,
    hasSeenWelcome,
    isIndividualValeter,
    isOrganizationValeter,
    requiresIndividualDocuments,
    requiresOrganizationDocuments,
    getOrganization,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Add default export
export default AuthProvider;
