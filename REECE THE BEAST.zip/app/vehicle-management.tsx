import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  Modal,
  FlatList,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

interface Vehicle {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  isDefault: boolean;
  photo?: string;
}

export default function VehicleManagement() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedVehicleType, setSelectedVehicleType] = useState('');
  const [selectedMake, setSelectedMake] = useState('');
  const [selectedModel, setSelectedModel] = useState('');
  const [selectedColor, setSelectedColor] = useState('');

  // Form state
  const [formData, setFormData] = useState({
    registration: '',
  });

  // AI-powered vehicle data
  const vehicleTypes = [
    'Car', 'SUV', 'Van', 'Truck', 'Motorcycle', 'Bicycle', 'Luxury Car', 'Sports Car', 'Electric Car', 'Hybrid Car'
  ];

  const vehicleMakes = {
    'Car': ['Toyota', 'Honda', 'Ford', 'BMW', 'Mercedes-Benz', 'Audi', 'Volkswagen', 'Nissan', 'Hyundai', 'Kia', 'Mazda', 'Subaru', 'Volvo', 'Peugeot', 'Renault', 'Citroën', 'Fiat', 'Alfa Romeo', 'Skoda', 'Seat'],
    'SUV': ['Range Rover', 'BMW X Series', 'Mercedes GLE', 'Audi Q Series', 'Volkswagen Tiguan', 'Toyota RAV4', 'Honda CR-V', 'Ford Kuga', 'Nissan Qashqai', 'Hyundai Tucson', 'Kia Sportage', 'Mazda CX-5', 'Subaru Forester', 'Volvo XC Series', 'Jeep', 'Land Rover', 'Lexus RX', 'Porsche Cayenne', 'Bentley Bentayga', 'Rolls-Royce Cullinan'],
    'Van': ['Ford Transit', 'Mercedes Sprinter', 'Volkswagen Transporter', 'Peugeot Boxer', 'Citroën Relay', 'Fiat Ducato', 'Renault Master', 'Vauxhall Vivaro', 'Nissan NV200', 'Toyota Proace', 'Hyundai H350', 'Iveco Daily', 'LDV V80', 'Maxus Deliver 9', 'Ford Transit Custom', 'Mercedes Vito', 'Volkswagen Caddy', 'Peugeot Partner', 'Citroën Berlingo', 'Fiat Doblo'],
    'Truck': ['Ford F-Series', 'Chevrolet Silverado', 'Ram 1500', 'Toyota Tacoma', 'Nissan Frontier', 'GMC Sierra', 'Dodge Ram', 'Honda Ridgeline', 'Mazda BT-50', 'Isuzu D-Max', 'Mitsubishi L200', 'Ford Ranger', 'Volkswagen Amarok', 'Mercedes X-Class', 'Nissan Navara', 'Toyota Hilux', 'Mitsubishi Triton', 'Mazda BT-50', 'Isuzu D-Max', 'Suzuki Jimny'],
    'Motorcycle': ['Honda', 'Yamaha', 'Kawasaki', 'Suzuki', 'BMW', 'Ducati', 'Harley-Davidson', 'Triumph', 'KTM', 'Aprilia', 'Moto Guzzi', 'Indian', 'Royal Enfield', 'Norton', 'MV Agusta', 'Benelli', 'Husqvarna', 'Gas Gas', 'Beta', 'Sherco'],
    'Bicycle': ['Trek', 'Specialized', 'Giant', 'Cannondale', 'Scott', 'Bianchi', 'Pinarello', 'Cervelo', 'Ridley', 'Canyon', 'Merida', 'Cube', 'Focus', 'Wilier', 'Colnago', 'BMC', 'Orbea', 'Look', 'Time', 'Lapierre'],
    'Luxury Car': ['Rolls-Royce', 'Bentley', 'Aston Martin', 'Ferrari', 'Lamborghini', 'McLaren', 'Bugatti', 'Pagani', 'Koenigsegg', 'Rimac', 'Lotus', 'Alpine', 'Noble', 'Gumpert', 'Arrinera', 'W Motors', 'Zenvo', 'Tushek', 'Rimac', 'Pininfarina'],
    'Sports Car': ['Porsche', 'Ferrari', 'Lamborghini', 'McLaren', 'Aston Martin', 'Corvette', 'Viper', 'Lotus', 'Alpine', 'Caterham', 'Ariel', 'BAC', 'KTM', 'Radical', 'Ginetta', 'Morgan', 'TVR', 'Noble', 'Gumpert', 'Arrinera'],
    'Electric Car': ['Tesla', 'Nissan Leaf', 'BMW i3', 'Audi e-tron', 'Mercedes EQC', 'Jaguar I-Pace', 'Porsche Taycan', 'Volkswagen ID.3', 'Volkswagen ID.4', 'Hyundai Kona Electric', 'Kia e-Niro', 'Peugeot e-208', 'Renault Zoe', 'Citroën ë-C4', 'Opel Corsa-e', 'Mini Electric', 'Honda e', 'Fiat 500e', 'Smart EQ', 'Polestar'],
    'Hybrid Car': ['Toyota Prius', 'Toyota Camry Hybrid', 'Honda Insight', 'Honda CR-Z', 'Ford Fusion Hybrid', 'Ford C-Max', 'Chevrolet Volt', 'BMW i8', 'Mercedes C-Class Hybrid', 'Audi A3 e-tron', 'Volkswagen Golf GTE', 'Porsche Panamera Hybrid', 'Lexus CT', 'Lexus ES Hybrid', 'Lexus LS Hybrid', 'Infiniti Q50 Hybrid', 'Acura RLX Hybrid', 'Kia Optima Hybrid', 'Hyundai Sonata Hybrid', 'Mazda 3 Hybrid']
  };

  const vehicleModels = {
    'Toyota': ['Corolla', 'Camry', 'Prius', 'RAV4', 'Highlander', 'Sienna', 'Tacoma', 'Tundra', '4Runner', 'Sequoia', 'Land Cruiser', 'Avalon', 'C-HR', 'Venza', 'bZ4X', 'Mirai', 'Yaris', 'Aygo', 'Auris', 'Verso'],
    'Honda': ['Civic', 'Accord', 'CR-V', 'Pilot', 'Odyssey', 'Ridgeline', 'HR-V', 'Passport', 'Insight', 'Clarity', 'Fit', 'Jazz', 'CR-Z', 'NSX', 'Legend', 'Prelude', 'Integra', 'S2000', 'Element', 'Crosstour'],
    'Ford': ['Focus', 'Fiesta', 'Mondeo', 'Kuga', 'Puma', 'EcoSport', 'Edge', 'Explorer', 'Expedition', 'F-150', 'Ranger', 'Transit', 'Transit Custom', 'Tourneo', 'Galaxy', 'S-Max', 'Mustang', 'GT', 'Bronco', 'Maverick'],
    'BMW': ['1 Series', '2 Series', '3 Series', '4 Series', '5 Series', '6 Series', '7 Series', '8 Series', 'X1', 'X2', 'X3', 'X4', 'X5', 'X6', 'X7', 'Z4', 'i3', 'i4', 'i7', 'iX'],
    'Mercedes-Benz': ['A-Class', 'B-Class', 'C-Class', 'E-Class', 'S-Class', 'CLA', 'CLS', 'GLA', 'GLB', 'GLC', 'GLE', 'GLS', 'G-Class', 'AMG GT', 'SL', 'SLS', 'EQC', 'EQS', 'EQE', 'EQB'],
    'Audi': ['A1', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'Q2', 'Q3', 'Q4', 'Q5', 'Q7', 'Q8', 'TT', 'R8', 'RS3', 'RS4', 'RS5', 'RS6', 'RS7'],
    'Volkswagen': ['Golf', 'Polo', 'Passat', 'Jetta', 'Tiguan', 'Touareg', 'Atlas', 'ID.3', 'ID.4', 'ID.5', 'Arteon', 'T-Roc', 'T-Cross', 'Touran', 'Sharan', 'Caddy', 'Transporter', 'Amarok', 'Scirocco', 'Beetle'],
    'Nissan': ['Micra', 'Juke', 'Qashqai', 'X-Trail', 'Murano', 'Pathfinder', 'Armada', 'Frontier', 'Titan', 'Leaf', 'Ariya', 'Z', 'GT-R', '370Z', 'Altima', 'Maxima', 'Sentra', 'Versa', 'Rogue', 'Kicks'],
    'Hyundai': ['i10', 'i20', 'i30', 'Elantra', 'Sonata', 'Tucson', 'Santa Fe', 'Palisade', 'Kona', 'Venue', 'Accent', 'Veloster', 'Genesis', 'Ioniq', 'Kona Electric', 'Tucson Hybrid', 'Santa Fe Hybrid', 'Staria', 'Bayon', 'Casino'],
    'Kia': ['Picanto', 'Rio', 'Ceed', 'Cerato', 'Optima', 'Sportage', 'Sorento', 'Telluride', 'Stonic', 'XCeed', 'ProCeed', 'Soul', 'Niro', 'EV6', 'Sorento Hybrid', 'Sportage Hybrid', 'Carnival', 'Stinger', 'K5', 'K8']
  };

  const vehicleColors = [
    'White', 'Black', 'Silver', 'Gray', 'Red', 'Blue', 'Green', 'Yellow', 'Orange', 'Purple', 'Pink', 'Brown', 'Beige', 'Gold', 'Bronze', 'Navy Blue', 'Dark Green', 'Light Blue', 'Cream', 'Pearl White', 'Metallic Black', 'Chrome Silver', 'Gunmetal Gray', 'Racing Red', 'Electric Blue', 'Forest Green', 'Sunset Orange', 'Royal Purple', 'Rose Gold', 'Copper'
  ];

  useEffect(() => {
    // Load mock vehicles
    const mockVehicles: Vehicle[] = [
      {
        id: '1',
        type: 'Car',
        make: 'Toyota',
        model: 'Corolla',
        color: 'Silver',
        registration: 'AB12 CDE',
        isDefault: true
      },
      {
        id: '2',
        type: 'SUV',
        make: 'BMW',
        model: 'X5',
        color: 'Black',
        registration: 'XY34 FGH',
        isDefault: false
      }
    ];
    setVehicles(mockVehicles);
  }, []);

  const resetForm = () => {
    setFormData({ registration: '' });
    setSelectedVehicleType('');
    setSelectedMake('');
    setSelectedModel('');
    setSelectedColor('');
    setEditingVehicle(null);
    setCurrentStep(1);
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceedToNextStep = () => {
    switch (currentStep) {
      case 1: return selectedVehicleType !== '';
      case 2: return selectedMake !== '';
      case 3: return selectedModel !== '';
      case 4: return formData.registration !== '';
      default: return false;
    }
  };

  const handleAddVehicle = async () => {
    if (!selectedVehicleType || !selectedMake || !selectedModel || !formData.registration) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please fill in all required fields (Type, Make, Model, Registration)');
      return;
    }

    await hapticFeedback('medium');

    const newVehicle: Vehicle = {
      id: Date.now().toString(),
      type: selectedVehicleType,
      make: selectedMake,
      model: selectedModel,
      color: selectedColor || 'Not specified',
      registration: formData.registration.toUpperCase(),
      isDefault: vehicles.length === 0, // First vehicle is default
    };

    setVehicles(prev => [...prev, newVehicle]);
    setShowAddModal(false);
    resetForm();
    
    await hapticFeedback('light');
    Alert.alert('Success', 'Vehicle added successfully!');
  };

  const handleEditVehicle = async (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setSelectedVehicleType(vehicle.type);
    setSelectedMake(vehicle.make);
    setSelectedModel(vehicle.model);
    setSelectedColor(vehicle.color);
    setFormData({ registration: vehicle.registration });
    setCurrentStep(4); // Go directly to registration step for editing
    setShowAddModal(true);
  };

  const handleUpdateVehicle = async () => {
    if (!editingVehicle) return;

    if (!selectedVehicleType || !selectedMake || !selectedModel || !formData.registration) {
      await hapticFeedback('medium');
      Alert.alert('Error', 'Please fill in all required fields (Type, Make, Model, Registration)');
      return;
    }

    await hapticFeedback('medium');

    const updatedVehicle: Vehicle = {
      ...editingVehicle,
      type: selectedVehicleType,
      make: selectedMake,
      model: selectedModel,
      color: selectedColor || 'Not specified',
      registration: formData.registration.toUpperCase(),
    };

    setVehicles(prev => prev.map(v => v.id === editingVehicle.id ? updatedVehicle : v));
    setShowAddModal(false);
    resetForm();
    
    await hapticFeedback('light');
    Alert.alert('Success', 'Vehicle updated successfully!');
  };

  const handleDeleteVehicle = async (vehicleId: string) => {
    Alert.alert(
      'Delete Vehicle',
      'Are you sure you want to delete this vehicle?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await hapticFeedback('medium');
            setVehicles(prev => prev.filter(v => v.id !== vehicleId));
            await hapticFeedback('light');
            Alert.alert('Success', 'Vehicle deleted successfully!');
          }
        }
      ]
    );
  };

  const handleSetDefault = async (vehicleId: string) => {
    await hapticFeedback('medium');
    setVehicles(prev => prev.map(v => ({
      ...v,
      isDefault: v.id === vehicleId
    })));
    await hapticFeedback('light');
    Alert.alert('Success', 'Default vehicle updated!');
  };

  const renderDropdown = (title: string, options: string[], selectedValue: string, onSelect: (value: string) => void) => (
    <View style={styles.inputGroup}>
      <Text style={styles.inputLabel}>{title}</Text>
      <View style={styles.dropdownContainer}>
        {options.map((option) => (
          <TouchableOpacity
            key={option}
            style={[
              styles.dropdownOption,
              selectedValue === option && styles.selectedDropdownOption
            ]}
            onPress={async () => {
              onSelect(option);
              await hapticFeedback('light');
            }}
          >
            <Text style={[
              styles.dropdownOptionText,
              selectedValue === option && styles.selectedDropdownOptionText
            ]}>
              {option}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );

  const renderStepIndicator = () => {
    const steps = [
      { number: 1, title: 'Type', completed: selectedVehicleType !== '' },
      { number: 2, title: 'Make', completed: selectedMake !== '' },
      { number: 3, title: 'Model', completed: selectedModel !== '' },
      { number: 4, title: 'Reg', completed: formData.registration !== '' }
    ];

    return (
      <View style={styles.stepIndicator}>
        {steps.map((step, index) => (
          <View key={`step-${step.number}`} style={styles.stepContainer}>
            <View style={[
              styles.stepCircle,
              currentStep === step.number && styles.currentStepCircle,
              step.completed && styles.completedStepCircle
            ]}>
              <Text style={[
                styles.stepNumber,
                currentStep === step.number && styles.currentStepNumber,
                step.completed && styles.completedStepNumber
              ]}>
                {step.completed ? '✓' : step.number}
              </Text>
            </View>
            <Text style={[
              styles.stepTitle,
              currentStep === step.number && styles.currentStepTitle
            ]}>
              {step.title}
            </Text>
            {index < steps.length - 1 && (
              <View 
                key={`line-${step.number}`}
                style={[
                  styles.stepLine,
                  step.completed && styles.completedStepLine
                ]} 
              />
            )}
          </View>
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Vehicles</Text>
        <TouchableOpacity 
          style={styles.addButton} 
          onPress={() => {
            resetForm();
            setShowAddModal(true);
          }}
        >
          <Text style={styles.addButtonText}>+ Add</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <View style={styles.content}>
        {vehicles.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateIcon}>🚗</Text>
            <Text style={styles.emptyStateTitle}>No Vehicles Added</Text>
            <Text style={styles.emptyStateText}>
              Add your first vehicle to get started with quick bookings
            </Text>
            <TouchableOpacity 
              style={styles.addFirstButton}
              onPress={() => setShowAddModal(true)}
            >
              <Text style={styles.addFirstButtonText}>Add Your First Vehicle</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <ScrollView style={styles.vehicleList}>
            {vehicles.map((vehicle) => (
              <View key={vehicle.id} style={styles.vehicleCard}>
                <View style={styles.vehicleHeader}>
                  <View style={styles.vehicleInfo}>
                    <Text style={styles.vehicleTitle}>
                      {vehicle.make} {vehicle.model}
                    </Text>
                    <Text style={styles.vehicleSubtitle}>
                      {vehicle.type} • {vehicle.color} • {vehicle.registration}
                    </Text>
                    {vehicle.isDefault && (
                      <View style={styles.defaultBadge}>
                        <Text style={styles.defaultBadgeText}>Default</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.vehicleActions}>
                    {!vehicle.isDefault && (
                      <TouchableOpacity 
                        style={styles.actionButton}
                        onPress={() => handleSetDefault(vehicle.id)}
                      >
                        <Text style={styles.actionButtonText}>Set Default</Text>
                      </TouchableOpacity>
                    )}
                    <TouchableOpacity 
                      style={[styles.actionButton, styles.editButton]}
                      onPress={() => handleEditVehicle(vehicle)}
                    >
                      <Text style={styles.actionButtonText}>Edit</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.actionButton, styles.deleteButton]}
                      onPress={() => handleDeleteVehicle(vehicle.id)}
                    >
                      <Text style={styles.actionButtonText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>
        )}
      </View>

      {/* Add/Edit Vehicle Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity 
              style={styles.modalCloseButton}
              onPress={() => setShowAddModal(false)}
            >
              <Text style={styles.modalCloseButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              {editingVehicle ? 'Edit Vehicle' : `Step ${currentStep} of 4`}
            </Text>
            <View style={styles.modalActions}>
              {currentStep > 1 && (
                <TouchableOpacity 
                  style={styles.modalActionButton}
                  onPress={prevStep}
                >
                  <Text style={styles.modalActionButtonText}>Back</Text>
                </TouchableOpacity>
              )}
              {currentStep < 4 ? (
                <TouchableOpacity 
                  style={[styles.modalActionButton, !canProceedToNextStep() && styles.disabledButton]}
                  onPress={nextStep}
                  disabled={!canProceedToNextStep()}
                >
                  <Text style={styles.modalActionButtonText}>Next</Text>
                </TouchableOpacity>
              ) : (
                <TouchableOpacity 
                  style={[styles.modalSaveButton, !canProceedToNextStep() && styles.disabledButton]}
                  onPress={editingVehicle ? handleUpdateVehicle : handleAddVehicle}
                  disabled={!canProceedToNextStep()}
                >
                  <Text style={styles.modalSaveButtonText}>Save</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>

          <ScrollView style={styles.modalContent}>
            {renderStepIndicator()}

            {/* Step 1: Vehicle Type */}
            {currentStep === 1 && (
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Select Vehicle Type</Text>
                <Text style={styles.stepSubtitle}>What type of vehicle are you adding?</Text>
                {renderDropdown('Vehicle Type', vehicleTypes, selectedVehicleType, setSelectedVehicleType)}
              </View>
            )}

            {/* Step 2: Make */}
            {currentStep === 2 && (
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Select Make</Text>
                <Text style={styles.stepSubtitle}>Choose the vehicle manufacturer</Text>
                {renderDropdown(
                  'Make', 
                  vehicleMakes[selectedVehicleType as keyof typeof vehicleMakes] || [], 
                  selectedMake, 
                  setSelectedMake
                )}
              </View>
            )}

            {/* Step 3: Model */}
            {currentStep === 3 && (
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Select Model</Text>
                <Text style={styles.stepSubtitle}>Choose the specific model</Text>
                {renderDropdown(
                  'Model', 
                  vehicleModels[selectedMake as keyof typeof vehicleModels] || [], 
                  selectedModel, 
                  setSelectedModel
                )}
              </View>
            )}

            {/* Step 4: Registration */}
            {currentStep === 4 && (
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Enter Registration</Text>
                <Text style={styles.stepSubtitle}>Enter the vehicle registration number</Text>
                
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Registration Number</Text>
                  <TextInput
                    style={styles.input}
                    value={formData.registration}
                    onChangeText={(text) => setFormData(prev => ({ ...prev, registration: text }))}
                    placeholder="e.g., AB12 CDE"
                    placeholderTextColor="#9CA3AF"
                    autoCapitalize="characters"
                  />
                </View>

                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Color (Optional)</Text>
                  {renderDropdown('Color', vehicleColors, selectedColor, setSelectedColor)}
                </View>

                {/* Vehicle Summary */}
                <View style={styles.vehicleSummary}>
                  <Text style={styles.summaryTitle}>Vehicle Summary:</Text>
                  <Text style={styles.summaryText}>
                    {selectedVehicleType} • {selectedMake} {selectedModel}
                  </Text>
                  <Text style={styles.summarySubtext}>
                    Reg: {formData.registration || 'Not entered'}
                    {selectedColor && ` • Color: ${selectedColor}`}
                  </Text>
                </View>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyStateIcon: {
    fontSize: 60,
    marginBottom: 20,
  },
  emptyStateTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  emptyStateText: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 30,
  },
  addFirstButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  vehicleList: {
    flex: 1,
  },
  vehicleCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  vehicleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  vehicleSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  vehicleDetails: {
    color: '#B0E0E6',
    fontSize: 12,
  },
  vehicleActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  defaultBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  defaultBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  actionButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  actionButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  editButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderColor: '#87CEEB',
  },
  deleteButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderColor: '#EF4444',
  },
  vehicleStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  statItem: {
    alignItems: 'center',
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginBottom: 2,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  setDefaultButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderWidth: 1,
    borderColor: '#87CEEB',
    borderRadius: 8,
    paddingVertical: 8,
    alignItems: 'center',
  },
  setDefaultButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: '#1E3A8A',
  },
  modalCancelText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalSaveText: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: '600',
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  typeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  typeOption: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedTypeOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  typeIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  typeName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  typeDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  sizeGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  sizeOption: {
    width: '48%',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedSizeOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  sizeName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  sizeDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  inputRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  inputGroup: {
    flex: 1,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#1E3A8A',
    borderRadius: 8,
    padding: 12,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  pickerContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  pickerOption: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedPickerOption: {
    borderColor: '#87CEEB',
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  pickerOptionText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  dropdownContainer: {
    backgroundColor: '#1E3A8A',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#3B82F6',
    overflow: 'hidden',
  },
  dropdownOption: {
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  selectedDropdownOption: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
  },
  dropdownOptionText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  selectedDropdownOptionText: {
    color: '#87CEEB',
  },
  modalCloseButton: {
    padding: 8,
  },
  modalCloseButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  modalSaveButton: {
    backgroundColor: '#10B981',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  modalSaveButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalActionButton: {
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  modalActionButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  disabledButton: {
    opacity: 0.5,
  },
  stepIndicator: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  stepContainer: {
    alignItems: 'center',
    flex: 1,
  },
  stepCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    borderWidth: 2,
    borderColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  stepNumber: {
    color: '#87CEEB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  currentStepCircle: {
    backgroundColor: '#87CEEB',
    borderColor: '#87CEEB',
  },
  currentStepNumber: {
    color: '#FFFFFF',
  },
  completedStepCircle: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  completedStepNumber: {
    color: '#FFFFFF',
  },
  stepTitle: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 8,
  },
  currentStepTitle: {
    color: '#87CEEB',
  },
  stepLine: {
    position: 'absolute',
    top: 20,
    width: '100%',
    height: 2,
    backgroundColor: 'rgba(135, 206, 235, 0.3)',
  },
  completedStepLine: {
    backgroundColor: '#10B981',
  },
  stepContent: {
    marginBottom: 20,
  },
  stepSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  vehicleSummary: {
    backgroundColor: '#1E3A8A',
    borderRadius: 12,
    padding: 16,
    marginTop: 20,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  summaryText: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  summarySubtext: {
    color: '#B0E0E6',
    fontSize: 12,
  },
});
