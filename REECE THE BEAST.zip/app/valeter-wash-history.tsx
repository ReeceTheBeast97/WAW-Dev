import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { washCompletionService, WashCompletion } from '../src/services/WashCompletionService';

export default function ValeterWashHistoryScreen() {
  const { user } = useAuth();
  const [washCompletions, setWashCompletions] = useState<WashCompletion[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalWashes: 0,
    totalTips: 0,
    averageRating: 0,
    totalEarnings: 0,
  });

  useEffect(() => {
    loadWashHistory();
  }, []);

  const loadWashHistory = async () => {
    if (!user) return;

    try {
      const completions = await washCompletionService.getValeterWashCompletions(user.id);
      setWashCompletions(completions);

      // Calculate stats
      const totalTips = await washCompletionService.getValeterTotalTips(user.id);
      const averageRating = await washCompletionService.getValeterAverageRating(user.id);
      
      setStats({
        totalWashes: completions.length,
        totalTips,
        averageRating,
        totalEarnings: totalTips + (completions.length * 25), // Assuming £25 base per wash
      });
    } catch (error) {
      console.error('Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getRatingText = (rating: number) => {
    switch (rating) {
      case 1: return 'Poor';
      case 2: return 'Fair';
      case 3: return 'Good';
      case 4: return 'Very Good';
      case 5: return 'Excellent';
      default: return 'Not Rated';
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FFFFFF" />
        <Text style={styles.loadingText}>Loading wash history...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wash History</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {washCompletions.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🚗</Text>
            <Text style={styles.emptyTitle}>No Wash History</Text>
            <Text style={styles.emptyText}>
              You haven't completed any washes yet. Start working to see your history here!
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.totalWashes}</Text>
                <Text style={styles.statLabel}>Total Washes</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>£{stats.totalTips}</Text>
                <Text style={styles.statLabel}>Total Tips</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
            </View>

            <View style={styles.earningsCard}>
              <Text style={styles.earningsTitle}>💰 Total Earnings</Text>
              <Text style={styles.earningsAmount}>£{stats.totalEarnings}</Text>
              <Text style={styles.earningsBreakdown}>
                £{stats.totalWashes * 25} from washes + £{stats.totalTips} in tips
              </Text>
            </View>

            <Text style={styles.sectionTitle}>Recent Washes</Text>

            {washCompletions.map((completion) => (
              <View key={completion.id} style={styles.washCard}>
                <View style={styles.washHeader}>
                  <View style={styles.washInfo}>
                    <Text style={styles.washDate}>
                      {formatDate(completion.completedAt)}
                    </Text>
                    <Text style={styles.washId}>#{completion.id.slice(-6)}</Text>
                  </View>
                  <View style={styles.washStatus}>
                    {completion.status === 'completed' && (
                      <Text style={styles.statusCompleted}>Completed</Text>
                    )}
                    {completion.status === 'rated' && (
                      <Text style={styles.statusRated}>Rated</Text>
                    )}
                    {completion.status === 'tipped' && (
                      <Text style={styles.statusTipped}>Tipped</Text>
                    )}
                  </View>
                </View>

                {completion.notes && (
                  <View style={styles.notesContainer}>
                    <Text style={styles.notesTitle}>Your Notes:</Text>
                    <Text style={styles.notesText}>{completion.notes}</Text>
                  </View>
                )}

                {completion.photos.length > 0 && (
                  <View style={styles.photosContainer}>
                    <Text style={styles.photosTitle}>Photos Uploaded ({completion.photos.length})</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                      {completion.photos.map((photo, index) => (
                        <View key={index} style={styles.photoContainer}>
                          <View style={styles.photoPlaceholder}>
                            <Text style={styles.photoPlaceholderText}>📸</Text>
                            <Text style={styles.photoPlaceholderLabel}>Photo {index + 1}</Text>
                          </View>
                        </View>
                      ))}
                    </ScrollView>
                  </View>
                )}

                {completion.rating ? (
                  <View style={styles.ratingContainer}>
                    <View style={styles.ratingInfo}>
                      <Text style={styles.ratingStars}>
                        {'⭐'.repeat(completion.rating)}
                      </Text>
                      <Text style={styles.ratingText}>
                        {getRatingText(completion.rating)}
                      </Text>
                    </View>
                    {completion.customerReview && (
                      <Text style={styles.reviewText}>"{completion.customerReview}"</Text>
                    )}
                    {completion.tipAmount && completion.tipAmount > 0 && (
                      <View style={styles.tipContainer}>
                        <Text style={styles.tipIcon}>💰</Text>
                        <Text style={styles.tipText}>£{completion.tipAmount} tip received</Text>
                      </View>
                    )}
                  </View>
                ) : (
                  <View style={styles.pendingRating}>
                    <Text style={styles.pendingRatingText}>
                      ⏳ Waiting for customer rating
                    </Text>
                  </View>
                )}
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginTop: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  emptyText: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    paddingHorizontal: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
  },
  earningsCard: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    alignItems: 'center',
  },
  earningsTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  earningsAmount: {
    color: '#4CAF50',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  earningsBreakdown: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 20,
  },
  washCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  washHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  washInfo: {
    flex: 1,
  },
  washDate: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  washId: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 2,
  },
  washStatus: {
    alignItems: 'flex-end',
  },
  statusCompleted: {
    color: '#4CAF50',
    fontSize: 12,
    fontWeight: '600',
  },
  statusRated: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
  statusTipped: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '600',
  },
  notesContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  notesTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  notesText: {
    color: '#87CEEB',
    fontSize: 14,
    lineHeight: 20,
  },
  photosContainer: {
    marginBottom: 12,
  },
  photosTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  photoContainer: {
    marginRight: 8,
  },
  photoPlaceholder: {
    width: 80,
    height: 80,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  photoPlaceholderText: {
    fontSize: 20,
    marginBottom: 2,
  },
  photoPlaceholderLabel: {
    color: '#87CEEB',
    fontSize: 10,
  },
  ratingContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
  },
  ratingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingStars: {
    fontSize: 16,
    marginRight: 8,
  },
  ratingText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  reviewText: {
    color: '#87CEEB',
    fontSize: 14,
    fontStyle: 'italic',
    marginBottom: 8,
  },
  tipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tipIcon: {
    fontSize: 16,
    marginRight: 4,
  },
  tipText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  pendingRating: {
    backgroundColor: 'rgba(255, 193, 7, 0.2)',
    borderWidth: 1,
    borderColor: '#FFC107',
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
  },
  pendingRatingText: {
    color: '#FFC107',
    fontSize: 14,
    fontWeight: '600',
  },
});
