import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from './enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function OrganizationRewardsSystem() {
  const { user } = useAuth();
  const [selectedReward, setSelectedReward] = useState('');

  // Enhanced organization-specific rewards data
  const rewards = [
    {
      id: 'team-bonus',
      title: 'Team Performance Bonus',
      description: '15% bonus for all team members for 30 days',
      points: 800,
      icon: '👥',
      category: 'team',
      available: (user?.tierPoints || 0) >= 800
    },
    {
      id: 'business-insurance',
      title: 'Business Insurance',
      description: 'Free comprehensive business liability insurance for 6 months',
      points: 1200,
      icon: '🛡️',
      category: 'insurance',
      available: (user?.tierPoints || 0) >= 1200
    },
    {
      id: 'marketing-package',
      title: 'Marketing Package',
      description: 'Professional marketing materials, social media campaigns, and local SEO',
      points: 600,
      icon: '📢',
      category: 'marketing',
      available: (user?.tierPoints || 0) >= 600
    },
    {
      id: 'training-program',
      title: 'Team Training Program',
      description: 'Advanced training for all team members with certification',
      points: 1000,
      icon: '📚',
      category: 'training',
      available: (user?.tierPoints || 0) >= 1000
    },
    {
      id: 'equipment-subsidy',
      title: 'Equipment Subsidy',
      description: '60% off professional equipment and supplies for team',
      points: 1500,
      icon: '🛠️',
      category: 'equipment',
      available: (user?.tierPoints || 0) >= 1500
    },
    {
      id: 'priority-support',
      title: 'Priority Business Support',
      description: 'Dedicated business support line with 24/7 availability for 90 days',
      points: 400,
      icon: '🎯',
      category: 'support',
      available: (user?.tierPoints || 0) >= 400
    },
    {
      id: 'analytics-dashboard',
      title: 'Advanced Analytics',
      description: 'Premium business analytics, performance tracking, and insights',
      points: 700,
      icon: '📊',
      category: 'analytics',
      available: (user?.tierPoints || 0) >= 700
    },
    {
      id: 'certification-program',
      title: 'Team Certification',
      description: 'Official industry certification for all team members',
      points: 900,
      icon: '🏆',
      category: 'certification',
      available: (user?.tierPoints || 0) >= 900
    },
    {
      id: 'networking-access',
      title: 'Business Networking',
      description: 'Access to exclusive business networking events and partnerships',
      points: 500,
      icon: '🤝',
      category: 'networking',
      available: (user?.tierPoints || 0) >= 500
    },
    {
      id: 'expansion-support',
      title: 'Business Expansion',
      description: 'Full support for expanding to new locations and territories',
      points: 2000,
      icon: '🚀',
      category: 'expansion',
      available: (user?.tierPoints || 0) >= 2000
    },
    {
      id: 'financial-advisory',
      title: 'Financial Advisory',
      description: 'Free consultation with business financial advisors for 3 months',
      points: 800,
      icon: '💰',
      category: 'financial',
      available: (user?.tierPoints || 0) >= 800
    },
    {
      id: 'legal-support',
      title: 'Legal Support',
      description: 'Access to business legal consultation and contract review',
      points: 1000,
      icon: '⚖️',
      category: 'legal',
      available: (user?.tierPoints || 0) >= 1000
    },
    {
      id: 'technology-upgrade',
      title: 'Technology Upgrade',
      description: 'Latest business management software and mobile apps',
      points: 1200,
      icon: '💻',
      category: 'technology',
      available: (user?.tierPoints || 0) >= 1200
    },
    {
      id: 'customer-acquisition',
      title: 'Customer Acquisition',
      description: 'Premium customer leads and referral program access',
      points: 600,
      icon: '🎯',
      category: 'customers',
      available: (user?.tierPoints || 0) >= 600
    },
    {
      id: 'quality-assurance',
      title: 'Quality Assurance',
      description: 'ISO certification and quality management system setup',
      points: 1500,
      icon: '✅',
      category: 'quality',
      available: (user?.tierPoints || 0) >= 1500
    },
    {
      id: 'sustainability-program',
      title: 'Sustainability Program',
      description: 'Eco-friendly certification and green business practices',
      points: 800,
      icon: '🌱',
      category: 'sustainability',
      available: (user?.tierPoints || 0) >= 800
    },
    {
      id: 'franchise-opportunity',
      title: 'Franchise Opportunity',
      description: 'Exclusive franchise development and licensing support',
      points: 3000,
      icon: '🏢',
      category: 'franchise',
      available: (user?.tierPoints || 0) >= 3000
    },
    {
      id: 'international-expansion',
      title: 'International Expansion',
      description: 'Support for expanding business internationally',
      points: 2500,
      icon: '🌍',
      category: 'international',
      available: (user?.tierPoints || 0) >= 2500
    },
    {
      id: 'ai-integration',
      title: 'AI Integration',
      description: 'AI-powered business tools and automation systems',
      points: 1800,
      icon: '🤖',
      category: 'ai',
      available: (user?.tierPoints || 0) >= 1800
    },
    {
      id: 'premium-branding',
      title: 'Premium Branding',
      description: 'Professional branding package with logo design and guidelines',
      points: 1000,
      icon: '🎨',
      category: 'branding',
      available: (user?.tierPoints || 0) >= 1000
    }
  ];

  const handleRewardSelect = (rewardId: string) => {
    setSelectedReward(rewardId);
    hapticFeedback('light');
  };

  const handleRedeemReward = async () => {
    if (!selectedReward) {
      Alert.alert('No Reward Selected', 'Please select a reward to redeem');
      return;
    }

    const reward = rewards.find(r => r.id === selectedReward);
    if (!reward) return;

    if (!reward.available) {
      Alert.alert('Insufficient Points', `You need ${reward.points} points to redeem this reward`);
      return;
    }

    Alert.alert(
      'Redeem Reward',
      `Are you sure you want to redeem "${reward.title}" for ${reward.points} points?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            // Here you would typically call an API to redeem the reward
            Alert.alert(
              'Reward Redeemed!',
              `Congratulations! You've successfully redeemed "${reward.title}". Our business team will contact you within 24 hours.`,
              [{ text: 'OK', onPress: () => setSelectedReward('') }]
            );
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Business Rewards</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Stats Section */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{user?.tierPoints || 0}</Text>
            <Text style={styles.statLabel}>Reward Points</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>12</Text>
            <Text style={styles.statLabel}>Team Members</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>£2,450</Text>
            <Text style={styles.statLabel}>Monthly Revenue</Text>
          </View>
        </View>

        {/* Tier Info */}
        <View style={styles.tierContainer}>
          <Text style={styles.tierTitle}>Business Tier: {user?.tier || 'Bronze'}</Text>
          <Text style={styles.tierDescription}>
            Earn points for team performance, customer satisfaction, and business growth
          </Text>
          <View style={styles.progressBar}>
            <View 
              style={[
                styles.progressFill, 
                { width: `${Math.min((user?.tierPoints || 0) / 1000 * 100, 100)}%` }
              ]} 
            />
          </View>
          <Text style={styles.progressText}>
            {user?.tierPoints || 0} / 1000 points to next tier
          </Text>
        </View>

        {/* Rewards Grid */}
        <Text style={styles.sectionTitle}>Available Rewards</Text>
        
        <View style={styles.rewardsGrid}>
          {rewards.map((reward) => (
            <TouchableOpacity
              key={reward.id}
              style={[
                styles.rewardCard,
                selectedReward === reward.id && styles.selectedRewardCard,
                !reward.available && styles.unavailableRewardCard
              ]}
              onPress={() => handleRewardSelect(reward.id)}
              disabled={!reward.available}
            >
              <Text style={styles.rewardIcon}>{reward.icon}</Text>
              <Text style={styles.rewardTitle}>{reward.title}</Text>
              <Text style={styles.rewardDescription}>{reward.description}</Text>
              <View style={styles.rewardPoints}>
                <Text style={styles.pointsText}>{reward.points} points</Text>
              </View>
              {!reward.available && (
                <View style={styles.unavailableOverlay}>
                  <Text style={styles.unavailableText}>Need {reward.points} points</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Redeem Button */}
        {selectedReward && (
          <TouchableOpacity
            style={styles.redeemButton}
            onPress={handleRedeemReward}
          >
            <Text style={styles.redeemButtonText}>
              Redeem Selected Reward
            </Text>
          </TouchableOpacity>
        )}

        {/* How to Earn */}
        <View style={styles.earnSection}>
          <Text style={styles.earnTitle}>How to Earn Points</Text>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>👥</Text>
            <Text style={styles.earnText}>Team member completes wash: 25 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>⭐</Text>
            <Text style={styles.earnText}>5-star team rating: 50 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>📈</Text>
            <Text style={styles.earnText}>Monthly revenue target: 200 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🎯</Text>
            <Text style={styles.earnText}>Customer retention: 100 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🏆</Text>
            <Text style={styles.earnText}>Team member certification: 150 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>💼</Text>
            <Text style={styles.earnText}>New team member onboarded: 75 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>📊</Text>
            <Text style={styles.earnText}>Business growth milestone: 300 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🤝</Text>
            <Text style={styles.earnText}>Partnership agreement: 250 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🌱</Text>
            <Text style={styles.earnText}>Sustainability initiative: 150 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🎨</Text>
            <Text style={styles.earnText}>Brand development: 200 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>📱</Text>
            <Text style={styles.earnText}>Technology adoption: 175 points</Text>
          </View>
          <View style={styles.earnItem}>
            <Text style={styles.earnIcon}>🏢</Text>
            <Text style={styles.earnText}>New location opened: 500 points</Text>
          </View>
        </View>

        {/* Business Benefits */}
        <View style={styles.benefitsSection}>
          <Text style={styles.benefitsTitle}>Business Benefits</Text>
          <View style={styles.benefitItem}>
            <Text style={styles.benefitIcon}>💼</Text>
            <Text style={styles.benefitText}>Professional business tools and analytics</Text>
          </View>
          <View style={styles.benefitItem}>
            <Text style={styles.benefitIcon}>👥</Text>
            <Text style={styles.benefitText}>Team management and coordination features</Text>
          </View>
          <View style={styles.benefitItem}>
            <Text style={styles.benefitIcon}>📊</Text>
            <Text style={styles.benefitText}>Detailed performance reporting</Text>
          </View>
          <View style={styles.benefitItem}>
            <Text style={styles.benefitIcon}>🛡️</Text>
            <Text style={styles.benefitText}>Business insurance and liability protection</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  statNumber: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
  },
  tierContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  tierTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  tierDescription: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    borderRadius: 4,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 20,
  },
  rewardsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  rewardCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    width: '48%',
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedRewardCard: {
    borderColor: '#4CAF50',
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
  },
  unavailableRewardCard: {
    opacity: 0.5,
  },
  rewardIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  rewardTitle: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 4,
  },
  rewardDescription: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 8,
  },
  rewardPoints: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  pointsText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  unavailableOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unavailableText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  redeemButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    marginVertical: 20,
  },
  redeemButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  earnSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginVertical: 20,
  },
  earnTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  earnItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  earnIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  earnText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  benefitsSection: {
    backgroundColor: 'rgba(76, 175, 80, 0.2)',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 12,
    padding: 20,
    marginVertical: 20,
  },
  benefitsTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  benefitIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  benefitText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
});
