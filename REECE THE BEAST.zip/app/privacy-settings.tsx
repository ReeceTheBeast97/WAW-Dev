import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Switch,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from './enhanced-auth-context';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function PrivacySettings() {
  const { user } = useAuth();
  const [locationSharing, setLocationSharing] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [dataAnalytics, setDataAnalytics] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  const [thirdPartySharing, setThirdPartySharing] = useState(false);

  const handleToggleSetting = async (setting: string, value: boolean) => {
    try {
      await hapticFeedback('light');
      
      switch (setting) {
        case 'location':
          setLocationSharing(value);
          if (!value) {
            Alert.alert(
              'Location Disabled',
              'Location sharing is required for booking services. You can still use saved addresses.',
              [{ text: 'OK' }]
            );
          }
          break;
        case 'push':
          setPushNotifications(value);
          break;
        case 'email':
          setEmailNotifications(value);
          break;
        case 'sms':
          setSmsNotifications(value);
          break;
        case 'analytics':
          setDataAnalytics(value);
          break;
        case 'marketing':
          setMarketingEmails(value);
          break;
        case 'thirdParty':
          setThirdPartySharing(value);
          break;
      }
    } catch (error) {
      console.error('Error toggling setting:', error);
    }
  };

  const handleDownloadData = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Download Data',
        'Your data will be prepared and sent to your email address. This may take up to 24 hours.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Download',
            onPress: async () => {
              try {
                // Here you would normally make an API call to request data download
                console.log('Requesting data download for user:', user?.id);
                
                await hapticFeedback('success');
                Alert.alert(
                  'Data Download Requested',
                  'We\'ll email you a link to download your data within 24 hours.',
                  [{ text: 'OK' }]
                );
              } catch (error) {
                console.error('Error requesting data download:', error);
                Alert.alert('Error', 'Failed to request data download. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleDownloadData:', error);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Delete Account',
        'This action cannot be undone. All your data, bookings, and rewards will be permanently deleted.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete Account',
            style: 'destructive',
            onPress: async () => {
              try {
                Alert.alert(
                  'Confirm Deletion',
                  'Are you absolutely sure you want to delete your account? This action is irreversible.',
                  [
                    { text: 'Cancel', style: 'cancel' },
                    {
                      text: 'Yes, Delete',
                      style: 'destructive',
                      onPress: async () => {
                        try {
                          // Here you would normally make an API call to delete the account
                          console.log('Deleting account for user:', user?.id);
                          
                          await hapticFeedback('success');
                          Alert.alert(
                            'Account Deleted',
                            'Your account has been successfully deleted. Thank you for using Wish a Wash.',
                            [
                              {
                                text: 'OK',
                                onPress: () => {
                                  // Navigate to login or home
                                  router.replace('/');
                                }
                              }
                            ]
                          );
                        } catch (error) {
                          console.error('Error deleting account:', error);
                          Alert.alert('Error', 'Failed to delete account. Please try again.');
                        }
                      }
                    }
                  ]
                );
              } catch (error) {
                console.error('Error in delete confirmation:', error);
              }
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleDeleteAccount:', error);
    }
  };

  const handleViewPrivacyPolicy = async () => {
    try {
      await hapticFeedback('light');
      router.push('/privacy-policy');
    } catch (error) {
      console.error('Error navigating to privacy policy:', error);
    }
  };

  const handleViewTerms = async () => {
    try {
      await hapticFeedback('light');
      router.push('/terms-of-service');
    } catch (error) {
      console.error('Error navigating to terms:', error);
    }
  };

  const handleContactPrivacy = async () => {
    try {
      await hapticFeedback('light');
      Alert.alert(
        'Contact Privacy Team',
        'How would you like to contact our privacy team?',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📧 Email', 
            onPress: () => {
              // Open email app
              console.log('Opening email to privacy team');
            }
          },
          { 
            text: '📞 Call', 
            onPress: () => {
              // Open phone app
              console.log('Opening phone to privacy team');
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error in handleContactPrivacy:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Privacy Settings</Text>
          <View style={styles.headerSpacer} />
        </View>

        {/* Privacy Overview */}
        <View style={styles.section}>
          <View style={styles.overviewCard}>
            <Text style={styles.overviewIcon}>🔒</Text>
            <Text style={styles.overviewTitle}>Your Privacy Matters</Text>
            <Text style={styles.overviewDescription}>
              Control how your data is used and shared. We're committed to protecting your privacy and giving you full control over your information.
            </Text>
          </View>
        </View>

        {/* Location & Tracking */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location & Tracking</Text>
          <View style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Location Sharing</Text>
                <Text style={styles.settingDescription}>
                  Required for booking services and finding nearby valeters
                </Text>
              </View>
              <Switch
                value={locationSharing}
                onValueChange={(value) => handleToggleSetting('location', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={locationSharing ? '#0A1929' : '#9CA3AF'}
              />
            </View>
          </View>
        </View>

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          <View style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Push Notifications</Text>
                <Text style={styles.settingDescription}>
                  Booking updates, valeter status, and service reminders
                </Text>
              </View>
              <Switch
                value={pushNotifications}
                onValueChange={(value) => handleToggleSetting('push', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={pushNotifications ? '#0A1929' : '#9CA3AF'}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Email Notifications</Text>
                <Text style={styles.settingDescription}>
                  Booking confirmations, receipts, and account updates
                </Text>
              </View>
              <Switch
                value={emailNotifications}
                onValueChange={(value) => handleToggleSetting('email', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={emailNotifications ? '#0A1929' : '#9CA3AF'}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>SMS Notifications</Text>
                <Text style={styles.settingDescription}>
                  Urgent updates and valeter arrival notifications
                </Text>
              </View>
              <Switch
                value={smsNotifications}
                onValueChange={(value) => handleToggleSetting('sms', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={smsNotifications ? '#0A1929' : '#9CA3AF'}
              />
            </View>
          </View>
        </View>

        {/* Data & Analytics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data & Analytics</Text>
          <View style={styles.settingsCard}>
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Data Analytics</Text>
                <Text style={styles.settingDescription}>
                  Help us improve our service with anonymous usage data
                </Text>
              </View>
              <Switch
                value={dataAnalytics}
                onValueChange={(value) => handleToggleSetting('analytics', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={dataAnalytics ? '#0A1929' : '#9CA3AF'}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Marketing Emails</Text>
                <Text style={styles.settingDescription}>
                  Receive promotional offers and service updates
                </Text>
              </View>
              <Switch
                value={marketingEmails}
                onValueChange={(value) => handleToggleSetting('marketing', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={marketingEmails ? '#0A1929' : '#9CA3AF'}
              />
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingInfo}>
                <Text style={styles.settingTitle}>Third-Party Sharing</Text>
                <Text style={styles.settingDescription}>
                  Share data with trusted partners for service improvement
                </Text>
              </View>
              <Switch
                value={thirdPartySharing}
                onValueChange={(value) => handleToggleSetting('thirdParty', value)}
                trackColor={{ false: '#4B5563', true: '#87CEEB' }}
                thumbColor={thirdPartySharing ? '#0A1929' : '#9CA3AF'}
              />
            </View>
          </View>
        </View>

        {/* Data Control */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data Control</Text>
          <View style={styles.actionsCard}>
            <TouchableOpacity style={styles.actionButton} onPress={handleDownloadData}>
              <Text style={styles.actionIcon}>📥</Text>
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Download My Data</Text>
                <Text style={styles.actionDescription}>
                  Get a copy of all your personal data
                </Text>
              </View>
              <Text style={styles.actionArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton} onPress={handleContactPrivacy}>
              <Text style={styles.actionIcon}>📞</Text>
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Contact Privacy Team</Text>
                <Text style={styles.actionDescription}>
                  Ask questions about your data privacy
                </Text>
              </View>
              <Text style={styles.actionArrow}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Legal Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal Documents</Text>
          <View style={styles.actionsCard}>
            <TouchableOpacity style={styles.actionButton} onPress={handleViewPrivacyPolicy}>
              <Text style={styles.actionIcon}>📋</Text>
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Privacy Policy</Text>
                <Text style={styles.actionDescription}>
                  How we collect, use, and protect your data
                </Text>
              </View>
              <Text style={styles.actionArrow}>›</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionButton} onPress={handleViewTerms}>
              <Text style={styles.actionIcon}>📄</Text>
              <View style={styles.actionInfo}>
                <Text style={styles.actionTitle}>Terms of Service</Text>
                <Text style={styles.actionDescription}>
                  Our terms and conditions of service
                </Text>
              </View>
              <Text style={styles.actionArrow}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Deletion */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Management</Text>
          <View style={styles.dangerCard}>
            <Text style={styles.dangerIcon}>⚠️</Text>
            <Text style={styles.dangerTitle}>Delete Account</Text>
            <Text style={styles.dangerDescription}>
              Permanently delete your account and all associated data. This action cannot be undone.
            </Text>
            <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteAccount}>
              <Text style={styles.deleteButtonText}>Delete My Account</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Privacy Info */}
        <View style={styles.section}>
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Your Rights</Text>
            <Text style={styles.infoText}>
              • Access your personal data{'\n'}
              • Correct inaccurate data{'\n'}
              • Request data deletion{'\n'}
              • Object to data processing{'\n'}
              • Data portability{'\n'}
              • Withdraw consent
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    paddingTop: 10,
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerSpacer: {
    width: 60,
  },
  section: {
    padding: 20,
    paddingBottom: 10,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  overviewCard: {
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 15,
  },
  overviewIcon: {
    fontSize: 50,
    marginBottom: 10,
  },
  overviewTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  overviewDescription: {
    color: '#87CEEB',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
  },
  settingsCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  settingItemLast: {
    borderBottomWidth: 0,
  },
  settingInfo: {
    flex: 1,
  },
  settingTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  settingDescription: {
    color: '#87CEEB',
    fontSize: 14,
  },
  actionsCard: {
    backgroundColor: '#1E3A8A',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  actionButtonLast: {
    borderBottomWidth: 0,
  },
  actionIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  actionInfo: {
    flex: 1,
  },
  actionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  actionDescription: {
    color: '#87CEEB',
    fontSize: 14,
  },
  actionArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  dangerCard: {
    backgroundColor: '#DC2626',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 15,
  },
  dangerIcon: {
    fontSize: 50,
    marginBottom: 10,
  },
  dangerTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  dangerDescription: {
    color: '#87CEEB',
    fontSize: 15,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 20,
  },
  deleteButton: {
    backgroundColor: '#E53E3E',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 8,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  infoCard: {
    backgroundColor: '#1E3A8A',
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  infoText: {
    color: '#87CEEB',
    fontSize: 14,
    lineHeight: 20,
  },
});
