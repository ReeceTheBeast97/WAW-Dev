import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, StyleSheet, SafeAreaView } from 'react-native';
import { Link, router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoadingScreen from '../src/components/LoadingScreen';

export default function HomeScreen() {
  const { user, isLoading } = useAuth();
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState<boolean | null>(null);

  useEffect(() => {
    // Check if user has seen onboarding
    const checkOnboardingStatus = async () => {
      try {
        const onboardingSeen = await AsyncStorage.getItem('onboarding_seen');
        setHasSeenOnboarding(onboardingSeen === 'true');
      } catch (error) {
        console.error('Error checking onboarding status:', error);
        setHasSeenOnboarding(false);
      }
    };

    checkOnboardingStatus();
  }, []);

  useEffect(() => {
    // Immediate redirect without delay
    const handleRouting = async () => {
      if (!isLoading && hasSeenOnboarding !== null) {
        if (user) {
          // Check if user has seen their specific onboarding
          const userOnboardingKey = `${user.userType}_onboarding_seen`;
          const hasSeenUserOnboarding = await AsyncStorage.getItem(userOnboardingKey);
          
          if (hasSeenUserOnboarding === 'true') {
            // User has seen onboarding, redirect to appropriate dashboard
            if (user.userType === 'valeter') {
              router.replace('/driver-dashboard');
            } else if (user.userType === 'organization') {
              router.replace('/organization-dashboard');
            } else {
              router.replace('/owner-dashboard');
            }
          } else {
            // User hasn't seen onboarding, redirect to appropriate onboarding page
            if (user.userType === 'valeter') {
              router.replace('/valeter-onboarding');
            } else if (user.userType === 'organization') {
              router.replace('/organization-onboarding');
            } else {
              router.replace('/customer-onboarding');
            }
          }
        } else {
          // No user logged in, check if they've seen general onboarding
          if (hasSeenOnboarding) {
            router.replace('/login');
          } else {
            router.replace('/onboarding');
          }
        }
      }
    };

    handleRouting();
  }, [user, isLoading, hasSeenOnboarding]);

  // Show loading screen while determining where to redirect
  return <LoadingScreen message="Initializing..." />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    padding: 24,
  },
  header: {
    alignItems: 'center',
    marginBottom: 60,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#87CEEB',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#B0E0E6',
    textAlign: 'center',
  },
  buttonContainer: {
    gap: 16,
  },
  primaryButton: {
    backgroundColor: '#87CEEB',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonText: {
    color: '#0A1929',
    fontSize: 18,
    fontWeight: '600',
  },
  secondaryButton: {
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#87CEEB',
  },
  secondaryButtonText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '500',
  },
  debugButton: {
    backgroundColor: '#FF6B6B', // Red for debug
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10, // Add some space above
  },
  loadingContainer: {
    alignItems: 'center',
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 16,
    marginTop: 16,
  },
});

