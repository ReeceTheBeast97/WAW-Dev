import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  SafeAreaView,
} from 'react-native';
import { router } from 'expo-router';
import { useAuth } from './enhanced-auth-context';
import { simulationService } from '../src/services/SimulationService';
import { pricingEngine } from '../src/utils/pricing-engine';

export default function UnifiedBooking() {
  const { user } = useAuth();
  const [selectedService, setSelectedService] = useState<'wash' | 'valet' | 'priority_wash'>('wash');
  const [selectedLocation, setSelectedLocation] = useState('Central London');
  const [isBooking, setIsBooking] = useState(false);

  const services = [
    { id: 'wash', name: 'Quick Wash', price: 15, duration: '15 min', icon: '🚿' },
    { id: 'valet', name: 'Full Valet', price: 25, duration: '30 min', icon: '✨' },
    { id: 'priority_wash', name: 'Express Wash', price: 35, duration: '10 min', icon: '⚡' },
  ];

  const locations = [
    'Current Location',
    'Central London',
    'West London',
    'East London',
    'North London',
    'South London',
  ];

  const handleBookService = async () => {
    if (!user) {
      Alert.alert('Error', 'Please login to book a service');
      return;
    }

    setIsBooking(true);
    
    try {
      // Calculate price
      const price = pricingEngine.calculatePrice({
        serviceType: selectedService,
        location: selectedLocation,
        timeOfDay: new Date().getHours(),
        dayOfWeek: new Date().getDay(),
        demandLevel: 'medium',
        customerRating: 4.5,
      });

      // Create job
      const jobId = simulationService.createJob(
        user.id,
        selectedService,
        { lat: 51.5074, lng: -0.1278, address: selectedLocation },
        price
      );

      Alert.alert(
        'Booking Successful! 🎉',
        `Your ${services.find(s => s.id === selectedService)?.name} has been booked for £${price}. We'll notify you when a valeter accepts your job.`,
        [
          { text: 'View Booking', onPress: () => router.push('/tracking') },
          { text: 'Back to Dashboard', onPress: () => router.push('/owner-dashboard') }
        ]
      );
    } catch (error) {
      Alert.alert('Error', 'Failed to book service. Please try again.');
    } finally {
      setIsBooking(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      router.replace('/');
    } catch (error) {
      console.log('Logout error:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Book Service</Text>
          <View style={styles.placeholder} />
        </View>

        {/* Service Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Service</Text>
          {services.map((service) => (
            <TouchableOpacity
              key={service.id}
              style={[
                styles.serviceCard,
                selectedService === service.id && styles.selectedServiceCard
              ]}
              onPress={() => setSelectedService(service.id as any)}
            >
              <Text style={styles.serviceIcon}>{service.icon}</Text>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDetails}>
                  {service.duration} • £{service.price}
                </Text>
              </View>
              {selectedService === service.id && (
                <Text style={styles.selectedIcon}>✓</Text>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Location Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select Location</Text>
          {locations.map((location) => (
            <TouchableOpacity
              key={location}
              style={[
                styles.locationCard,
                selectedLocation === location && styles.selectedLocationCard
              ]}
              onPress={() => setSelectedLocation(location)}
            >
              <Text style={styles.locationText}>{location}</Text>
              {selectedLocation === location && (
                <Text style={styles.selectedIcon}>✓</Text>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Booking Button */}
        <View style={styles.bookingSection}>
          <TouchableOpacity
            style={[styles.bookButton, isBooking && styles.bookButtonDisabled]}
            onPress={handleBookService}
            disabled={isBooking}
          >
            <Text style={styles.bookButtonText}>
              {isBooking ? 'Booking...' : 'Book Now'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#1E3A8A',
  },
  backButton: {
    padding: 8,
  },
  backButtonText: {
    color: '#87CEEB',
    fontSize: 16,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 50,
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
  },
  serviceCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
  },
  selectedServiceCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  serviceIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },
  serviceDetails: {
    color: '#87CEEB',
    fontSize: 14,
    marginTop: 2,
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1E3A8A',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
  },
  selectedLocationCard: {
    backgroundColor: '#3B82F6',
    borderWidth: 2,
    borderColor: '#87CEEB',
  },
  locationText: {
    color: '#F9FAFB',
    fontSize: 16,
  },
  selectedIcon: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bookingSection: {
    padding: 20,
    paddingBottom: 40,
  },
  bookButton: {
    backgroundColor: '#10B981',
    padding: 18,
    borderRadius: 12,
    alignItems: 'center',
  },
  bookButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
