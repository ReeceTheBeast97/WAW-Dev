import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
  TextInput,
  Modal,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from './enhanced-auth-context';
import { valeterVerificationService, ValeterProfileData, ValeterDocument } from '../src/services/ValeterVerificationService';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { ValeterTierService, ValeterStats, ValeterTier } from '../src/services/ValeterTierService';
import * as ImagePicker from 'expo-image-picker';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const isMediumScreen = width >= 375 && width < 414;
const isLargeScreen = width >= 414;

export default function ValeterProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDocumentModal, setShowDocumentModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<ValeterDocument | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [valeterStats, setValeterStats] = useState<ValeterStats>({
    totalJobs: 45,
    experienceMonths: 8,
    averageRating: 4.7,
    totalEarnings: 2850,
    jobsThisMonth: 12,
    customerReviews: 38,
    onTimePercentage: 96,
    cancellationRate: 2
  });
  const [currentTier, setCurrentTier] = useState<ValeterTier | null>(null);
  const [isOrganizationMember, setIsOrganizationMember] = useState(false);
  const [organizationName, setOrganizationName] = useState<string | undefined>();

  useEffect(() => {
    if (user) {
      const valeterProfile = valeterVerificationService.getValeterProfile(user.id);
      setProfile(valeterProfile || null);
      setProfilePicture(valeterProfile?.profilePhoto || null);
      
      // Check organization status
      const { isMember, organizationName: orgName } = valeterVerificationService.isOrganizationMember(user.id);
      setIsOrganizationMember(isMember);
      setOrganizationName(orgName);
      
      // Calculate current tier based on stats
      const tier = ValeterTierService.calculateTier(valeterStats);
      setCurrentTier(tier);
    }
  }, [user, valeterStats]);

  const handleSaveProfile = async () => {
    if (!profile || !user) return;

    try {
      await hapticFeedback('medium');
      valeterVerificationService.updateValeterProfile(user.id, profile);
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleLogout = async () => {
    console.log('Valeter Profile: Logout button pressed');
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Logout',
        'Are you sure you want to logout?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Logout',
            style: 'destructive',
            onPress: async () => {
              console.log('Valeter Profile: Logout confirmed, calling logout function');
              try {
                await logout();
                console.log('Valeter Profile: Logout successful, navigating to home');
                router.replace('/');
                // Force a page refresh to ensure clean state
                setTimeout(() => {
                  router.replace('/');
                }, 100);
              } catch (error) {
                console.error('Valeter Profile: Logout error:', error);
                Alert.alert('Logout Error', 'Failed to logout. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert(
        'Delete Account',
        'This action cannot be undone. Are you sure you want to delete your account?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete',
            style: 'destructive',
            onPress: () => {
              Alert.alert('Account Deleted', 'Your account has been deleted.');
            }
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');
      
      Alert.alert(
        'Upload Clear Face Picture',
        'Your profile picture must show your face clearly for customer trust and verification. Choose how you want to add your picture:',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: '📸 Take Photo', 
            onPress: () => takePhoto() 
          },
          { 
            text: '🖼️ Choose from Gallery', 
            onPress: () => pickImage() 
          }
        ]
      );
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const validateClearFacePicture = (imageUri: string): Promise<boolean> => {
    return new Promise((resolve) => {
      // In a real app, you would use AI/ML to detect faces
      // For now, we'll simulate validation with a simple check
      Alert.alert(
        'Picture Validation',
        'Please confirm this picture shows your face clearly and is suitable for customer profiles.',
        [
          { 
            text: '❌ Not Clear', 
            onPress: () => resolve(false),
            style: 'cancel'
          },
          { 
            text: '✅ Clear Face', 
            onPress: () => resolve(true)
          }
        ]
      );
    });
  };

  const takePhoto = async () => {
    try {
      setIsLoading(true);
      
      // Request camera permissions
      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      // Launch camera
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const imageUri = result.assets[0].uri;
        
        // Validate that the picture shows a clear face
        const isValid = await validateClearFacePicture(imageUri);
        
        if (isValid) {
          setProfilePicture(imageUri);
          
          // Update profile with new picture
          if (profile) {
            const updatedProfile = { ...profile, profilePhoto: imageUri };
            setProfile(updatedProfile);
            valeterVerificationService.updateValeterProfile(user!.id, updatedProfile);
          }
          
          try {
            await hapticFeedback('medium');
          } catch (error) {
            console.log('Haptic feedback not available');
          }
          Alert.alert('Success', 'Clear face picture uploaded successfully!');
        } else {
          Alert.alert('Picture Not Accepted', 'Please upload a picture that clearly shows your face for customer trust and verification.');
        }
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const pickImage = async () => {
    try {
      setIsLoading(true);
      
      // Request media library permissions
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      // Launch image picker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        const imageUri = result.assets[0].uri;
        
        // Validate that the picture shows a clear face
        const isValid = await validateClearFacePicture(imageUri);
        
        if (isValid) {
          setProfilePicture(imageUri);
          
          // Update profile with new picture
          if (profile) {
            const updatedProfile = { ...profile, profilePhoto: imageUri };
            setProfile(updatedProfile);
            valeterVerificationService.updateValeterProfile(user!.id, updatedProfile);
          }
          
          try {
            await hapticFeedback('medium');
          } catch (error) {
            console.log('Haptic feedback not available');
          }
          Alert.alert('Success', 'Clear face picture uploaded successfully!');
        } else {
          Alert.alert('Picture Not Accepted', 'Please upload a picture that clearly shows your face for customer trust and verification.');
        }
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUploadDocument = async (document: ValeterDocument) => {
    try {
      await hapticFeedback('light');
      setSelectedDocument(document);
      setShowDocumentModal(true);
    } catch (error) {
      console.log('Haptic feedback not available');
    }
  };

  const simulateDocumentUpload = async () => {
    if (!selectedDocument || !user) return;

    // Simulate file upload
    Alert.alert('Uploading...', 'Document upload in progress...');
    
    setTimeout(async () => {
      valeterVerificationService.uploadDocument(
        user.id,
        selectedDocument.type,
        'https://example.com/document.pdf'
      );
      
      setShowDocumentModal(false);
      setSelectedDocument(null);
      
      // Refresh profile
      const updatedProfile = valeterVerificationService.getValeterProfile(user.id);
      setProfile(updatedProfile || null);
      
      try {
        await hapticFeedback('medium');
      } catch (error) {
        console.log('Haptic feedback not available');
      }
      Alert.alert('Success', `${selectedDocument.name} uploaded successfully!`);
    }, 2000);
  };

  const getVerificationProgress = () => {
    if (!user) return { total: 0, completed: 0, percentage: 0, missing: [] };
    
    // Get documents based on organization status
    const requiredDocuments = valeterVerificationService.getRequiredDocuments(user.id);
    const uploadedDocuments = profile?.documents || [];
    
    const total = requiredDocuments.length;
    const completed = uploadedDocuments.filter(doc => doc.status === 'approved').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    const missing = requiredDocuments
      .filter(doc => !uploadedDocuments.find(uploaded => uploaded.type === doc.type && uploaded.status === 'approved'))
      .map(doc => doc.name);
    
    return { total, completed, percentage, missing };
  };

  const getComplianceStatus = () => {
    if (!user) return { compliant: false, issues: [], recommendations: [] };
    return valeterVerificationService.isLegallyCompliant(user.id);
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'bronze': return ['#CD7F32', '#B8860B'];
      case 'silver': return ['#C0C0C0', '#A9A9A9'];
      case 'gold': return ['#FFD700', '#FFA500'];
      case 'platinum': return ['#E5E4E2', '#BCC6CC'];
      default: return ['#CD7F32', '#B8860B'];
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'bronze': return '🥉';
      case 'silver': return '🥈';
      case 'gold': return '🥇';
      case 'platinum': return '💎';
      default: return '🥉';
    }
  };

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const progress = getVerificationProgress();
  const compliance = getComplianceStatus();

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={async () => {
              try {
                await hapticFeedback('light');
              } catch (error) {
                console.log('Haptic feedback not available');
              }
              router.back();
            }} 
            style={styles.backButton}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Valeter Profile</Text>
          <TouchableOpacity 
            onPress={async () => {
              try {
                await hapticFeedback('light');
              } catch (error) {
                console.log('Haptic feedback not available');
              }
              setIsEditing(!isEditing);
            }} 
            style={styles.editButton}
          >
            <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
          </TouchableOpacity>
        </View>

        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {profile.verificationBadge && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Text style={styles.profilePictureText}>👤</Text>
                {profile.verificationBadge && (
                  <View style={styles.verificationBadge}>
                    <Text style={styles.verificationIcon}>✓</Text>
                  </View>
                )}
              </View>
            )}
            <TouchableOpacity 
              style={[styles.uploadButton, isLoading && styles.uploadButtonDisabled]} 
              onPress={handleUploadProfilePicture}
              disabled={isLoading}
            >
              <Text style={styles.uploadButtonText}>
                {isLoading ? '⏳' : '📷'}
              </Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{profile.name || user?.name || 'Valeter Name'}</Text>
              {profile.verificationBadge && (
                <View style={styles.verificationBadgeSmall}>
                  <Text style={styles.verificationIconSmall}>✓</Text>
                </View>
              )}
            </View>
            <Text style={styles.userEmail}>{user?.email || 'valeter@example.com'}</Text>
            <Text style={styles.userPhone}>{user?.phone || '+44 7700 900000'}</Text>
            {profile.experience && (
              <Text style={styles.userExperience}>{profile.experience} experience</Text>
            )}
          </View>
        </View>

        {/* Tier & Stats Section */}
        {currentTier && (
          <View style={styles.tierSection}>
            <LinearGradient
              colors={[currentTier.color, currentTier.color + '80']}
              style={styles.tierCard}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View style={styles.tierContent}>
                <Text style={styles.tierIcon}>{currentTier.icon}</Text>
                <View style={styles.tierInfo}>
                  <Text style={styles.tierText}>{currentTier.name} Valeter</Text>
                  <Text style={styles.tierStats}>
                    {valeterStats.totalJobs} jobs • {valeterStats.experienceMonths} months • ⭐ {valeterStats.averageRating}
                  </Text>
                  {currentTier.nextTierProgress > 0 && (
                    <View style={styles.progressToNext}>
                      <Text style={styles.progressText}>
                        {currentTier.nextTierProgress}% to next tier
                      </Text>
                      <View style={styles.progressBar}>
                        <View 
                          style={[
                            styles.progressFill, 
                            { width: `${currentTier.nextTierProgress}%` }
                          ]} 
                        />
                      </View>
                    </View>
                  )}
                </View>
              </View>
            </LinearGradient>
            
            {/* Tier Benefits */}
            <View style={styles.tierBenefits}>
              <Text style={styles.benefitsTitle}>🎁 {currentTier.name} Benefits:</Text>
              {currentTier.benefits.map((benefit, index) => (
                <Text key={index} style={styles.benefitText}>• {benefit}</Text>
              ))}
            </View>
          </View>
        )}

        {/* Valeter Stats Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Performance Stats</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{valeterStats.totalJobs}</Text>
              <Text style={styles.statLabel}>Total Jobs</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>£{valeterStats.totalEarnings}</Text>
              <Text style={styles.statLabel}>Total Earnings</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{valeterStats.jobsThisMonth}</Text>
              <Text style={styles.statLabel}>This Month</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{valeterStats.customerReviews}</Text>
              <Text style={styles.statLabel}>Reviews</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{valeterStats.onTimePercentage}%</Text>
              <Text style={styles.statLabel}>On Time</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{valeterStats.cancellationRate}%</Text>
              <Text style={styles.statLabel}>Cancellation</Text>
            </View>
          </View>
        </View>

        {/* Organization Status */}
        {isOrganizationMember && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Organization Status</Text>
            <View style={styles.organizationCard}>
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.organizationGradient}
              >
                <Text style={styles.organizationIcon}>🏢</Text>
                <View style={styles.organizationInfo}>
                  <Text style={styles.organizationName}>{organizationName}</Text>
                  <Text style={styles.organizationStatus}>Organization Member</Text>
                  <Text style={styles.organizationBenefit}>
                    Reduced document requirements - company handles liability
                  </Text>
                </View>
              </LinearGradient>
            </View>
          </View>
        )}

        {/* Verification Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Verification Progress {isOrganizationMember && '(Reduced Requirements)'}
          </Text>
          <View style={styles.verificationCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {progress.completed} of {progress.total} completed
              </Text>
              <Text style={styles.progressPercentage}>{progress.percentage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${progress.percentage}%` }
                ]} 
              />
            </View>
            {progress.missing.length > 0 && (
              <Text style={styles.missingText}>
                Missing: {progress.missing.join(', ')}
              </Text>
            )}
            {isOrganizationMember && (
              <Text style={styles.organizationNote}>
                💡 Organization members have reduced requirements as the company handles liability and insurance.
              </Text>
            )}
          </View>
        </View>

        {/* Personal Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>👤</Text>
                <Text style={styles.settingText}>Name</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.name}
                  onChangeText={(text) => setProfile({ ...profile, name: text })}
                  placeholder="Enter your name"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.name}</Text>
              )}
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>📝</Text>
                <Text style={styles.settingText}>Bio</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={[styles.settingInput, styles.bioInput]}
                  value={profile.bio}
                  onChangeText={(text) => setProfile({ ...profile, bio: text })}
                  placeholder="Tell customers about yourself"
                  placeholderTextColor="#87CEEB"
                  multiline
                />
              ) : (
                <Text style={styles.settingValue}>{profile.bio || 'No bio added'}</Text>
              )}
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>⏱️</Text>
                <Text style={styles.settingText}>Experience</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.experience}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g., 3+ years"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.experience || 'Not specified'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Vehicle Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle Information</Text>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🚗</Text>
                <Text style={styles.settingText}>Make</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicleDetails.make}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, make: text }
                  })}
                  placeholder="e.g., Ford"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicleDetails.make || 'Not set'}</Text>
              )}
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🚙</Text>
                <Text style={styles.settingText}>Model</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicleDetails.model}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, model: text }
                  })}
                  placeholder="e.g., Transit"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicleDetails.model || 'Not set'}</Text>
              )}
            </View>
            
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🔢</Text>
                <Text style={styles.settingText}>Registration</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicleDetails.registration}
                  onChangeText={(text) => setProfile({
                    ...profile,
                    vehicleDetails: { ...profile.vehicleDetails, registration: text }
                  })}
                  placeholder="e.g., AB12 CDE"
                  placeholderTextColor="#87CEEB"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicleDetails.registration || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          <View style={styles.settingsContainer}>
            {profile.documents.map((document) => (
              <TouchableOpacity
                key={document.id}
                style={styles.settingItem}
                onPress={() => handleUploadDocument(document)}
              >
                <View style={styles.settingLeft}>
                  <Text style={styles.settingIcon}>📄</Text>
                  <View style={styles.documentInfo}>
                    <Text style={styles.settingText}>{document.name}</Text>
                    <Text style={styles.documentDescription}>{document.description}</Text>
                  </View>
                </View>
                <View style={[
                  styles.documentStatus,
                  { backgroundColor: 
                    document.status === 'approved' ? '#4CAF50' :
                    document.status === 'pending' ? '#FF9800' :
                    document.status === 'rejected' ? '#EF4444' : '#666'
                  }
                ]}>
                  <Text style={styles.documentStatusText}>
                    {document.status === 'approved' ? '✓' :
                     document.status === 'pending' ? '⏳' :
                     document.status === 'rejected' ? '✗' : '📄'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Legal Compliance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Legal Compliance</Text>
          <View style={[
            styles.complianceCard,
            { backgroundColor: compliance.compliant ? 'rgba(76, 175, 80, 0.1)' : 'rgba(239, 68, 68, 0.1)' }
          ]}>
            <View style={styles.complianceHeader}>
              <Text style={styles.complianceIcon}>
                {compliance.compliant ? '✅' : '⚠️'}
              </Text>
              <Text style={styles.complianceTitle}>
                {compliance.compliant ? 'Legally Compliant' : 'Compliance Issues'}
              </Text>
            </View>
            
            {compliance.issues.length > 0 && (
              <View style={styles.complianceIssues}>
                <Text style={styles.complianceSubtitle}>Issues to resolve:</Text>
                {compliance.issues.map((issue, index) => (
                  <Text key={index} style={styles.complianceIssue}>• {issue}</Text>
                ))}
              </View>
            )}
            
            {compliance.recommendations.length > 0 && (
              <View style={styles.complianceRecommendations}>
                <Text style={styles.complianceSubtitle}>Recommendations:</Text>
                {compliance.recommendations.map((rec, index) => (
                  <Text key={index} style={styles.complianceRecommendation}>• {rec}</Text>
                ))}
              </View>
            )}
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile}>
              <Text style={styles.saveButtonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          
          <View style={styles.settingsContainer}>
            <TouchableOpacity 
              style={styles.settingItem} 
              onPress={async () => {
                try {
                  await hapticFeedback('light');
                } catch (error) {
                  console.log('Haptic feedback not available');
                }
                // Navigate directly to organization dashboard
                router.push('/organization-dashboard');
              }}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🏢</Text>
                <Text style={styles.settingText}>Organizations</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.settingItem} 
              onPress={async () => {
                try {
                  await hapticFeedback('light');
                } catch (error) {
                  console.log('Haptic feedback not available');
                }
                router.push('/privacy-settings');
              }}
            >
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>⚙️</Text>
                <Text style={styles.settingText}>Privacy & Security</Text>
              </View>
              <Text style={styles.settingArrow}>›</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>
          
          <TouchableOpacity style={[styles.settingItem, styles.logoutItem]} onPress={handleLogout}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🚪</Text>
              <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.settingItem, styles.deleteItem]} onPress={handleDeleteAccount}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🗑️</Text>
              <Text style={[styles.settingText, styles.deleteText]}>Delete Account</Text>
            </View>
            <Text style={styles.settingArrow}>›</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2024 Wish a Wash. All rights reserved.</Text>
        </View>
      </ScrollView>

      {/* Document Upload Modal */}
      <Modal
        visible={showDocumentModal}
        transparent={true}
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload {selectedDocument?.name}</Text>
            <Text style={styles.modalDescription}>{selectedDocument?.description}</Text>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={simulateDocumentUpload}
              >
                <Text style={styles.modalButtonText}>Upload Document</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setShowDocumentModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: 'bold',
  },
  editButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(135, 206, 235, 0.2)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  editButtonText: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
  },
  heroSection: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
    marginBottom: 0,
  },
  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  profilePicturePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135, 206, 235, 0.3)',
  },
  profilePictureText: {
    fontSize: 48,
  },
  profileImage: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#87CEEB',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  uploadButtonDisabled: {
    opacity: 0.7,
    backgroundColor: '#6B7280',
  },
  uploadButtonText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: 'bold',
  },
  profileInfo: {
    alignItems: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
  },
  userEmail: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
  },
  userPhone: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
  },
  userExperience: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    fontStyle: 'italic',
  },
  tierSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 0,
    marginBottom: 20,
  },
  tierCard: {
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  tierContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  tierIcon: {
    fontSize: 48,
    marginRight: 16,
  },
  tierInfo: {
    flexDirection: 'column',
  },
  tierText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tierPoints: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    opacity: 0.9,
  },
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  verificationCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  progressPercentage: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 4,
  },
  missingText: {
    color: '#EF4444',
    fontSize: 12,
  },
  settingsContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.03)',
    borderRadius: 12,
    overflow: 'hidden',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.05)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 20,
    marginRight: 12,
    width: 24,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '500',
  },
  settingValue: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: '#87CEEB',
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
    textAlign: 'left',
  },
  documentInfo: {
    flex: 1,
  },
  documentDescription: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 2,
  },
  documentStatus: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  documentStatusText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceCard: {
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#87CEEB',
  },
  complianceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  complianceIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  complianceTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  complianceSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    marginBottom: 4,
  },
  complianceIssues: {
    marginBottom: 12,
  },
  complianceIssue: {
    color: '#EF4444',
    fontSize: 12,
    marginBottom: 2,
  },
  complianceRecommendations: {
    marginBottom: 8,
  },
  complianceRecommendation: {
    color: '#4CAF50',
    fontSize: 12,
    marginBottom: 2,
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  logoutItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  deleteItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
  },
  logoutText: {
    color: '#EF4444',
  },
  deleteText: {
    color: '#EF4444',
  },
  settingArrow: {
    color: '#87CEEB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 20,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    backgroundColor: '#87CEEB',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  modalButtonCancel: {
    backgroundColor: '#666',
  },
  modalButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '600',
  },
  appInfoSection: {
    padding: 20,
  },
  // New tier system styles
  tierStats: {
    color: '#E0E7FF',
    fontSize: 14,
    marginTop: 4,
  },
  progressToNext: {
    marginTop: 8,
  },
  progressText: {
    color: '#E0E7FF',
    fontSize: 12,
    marginBottom: 4,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 2,
  },
  tierBenefits: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
  },
  benefitsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  benefitText: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
    lineHeight: 18,
  },
  // Stats grid styles
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
  },
  // Organization status styles
  organizationCard: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  organizationGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  organizationIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  organizationInfo: {
    flex: 1,
  },
  organizationName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  organizationStatus: {
    color: '#E0E7FF',
    fontSize: 14,
    marginBottom: 4,
  },
  organizationBenefit: {
    color: '#E0E7FF',
    fontSize: 12,
    opacity: 0.9,
  },
  organizationNote: {
    color: '#10B981',
    fontSize: 12,
    marginTop: 8,
    fontStyle: 'italic',
  },
  appInfoText: {
    color: '#87CEEB',
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
    opacity: 0.7,
  },
  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#0A1929',
  },
  verificationIcon: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  verificationIconSmall: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
